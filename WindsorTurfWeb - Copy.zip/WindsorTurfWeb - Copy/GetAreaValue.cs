﻿// Decompiled with JetBrains decompiler
// Type: GetAreaValue
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.FrontUserControl;

public class GetAreaValue : Page
{
  protected HtmlForm areacalculator;
  protected FieldInformation FieldInformation1;
  protected DropDownList drpFindTheAreaOf;
  protected HtmlGenericControl trCircle;
  protected TextBox txtCircleAreaValue;
  protected RequiredFieldValidator RequiredFieldValidator6;
  protected HtmlGenericControl trSquare;
  protected TextBox txtSquareAreaValue;
  protected RequiredFieldValidator RequiredFieldValidator1;
  protected HtmlGenericControl trRectangle1;
  protected TextBox txtRectangleAreaValue1;
  protected RequiredFieldValidator RequiredFieldValidator2;
  protected HtmlGenericControl trRectangle2;
  protected TextBox txtRectangleAreaValue2;
  protected RequiredFieldValidator RequiredFieldValidator3;
  protected HtmlGenericControl trTriangle1;
  protected TextBox txtTriangleAreaValue1;
  protected RequiredFieldValidator RequiredFieldValidator4;
  protected HtmlGenericControl trTriangle2;
  protected TextBox txtTriangleAreaValue2;
  protected RequiredFieldValidator RequiredFieldValidator5;
  protected HiddenField hdnField;
  protected Button btnAdd;

  protected void Page_Load(object sender, EventArgs e)
  {
    if (this.IsPostBack)
      return;
    string selectedValue = this.drpFindTheAreaOf.SelectedValue;
  }

  protected void drpFindTheAreaOf_SelectedIndexChanged(object sender, EventArgs e)
  {
    if (this.drpFindTheAreaOf.SelectedValue == "1")
    {
      this.trCircle.Visible = true;
      this.trSquare.Visible = false;
      this.trTriangle1.Visible = false;
      this.trTriangle2.Visible = false;
      this.trRectangle1.Visible = false;
      this.trRectangle2.Visible = false;
    }
    else if (this.drpFindTheAreaOf.SelectedValue == "2")
    {
      this.trCircle.Visible = false;
      this.trSquare.Visible = true;
      this.trTriangle1.Visible = false;
      this.trTriangle2.Visible = false;
      this.trRectangle1.Visible = false;
      this.trRectangle2.Visible = false;
    }
    else if (this.drpFindTheAreaOf.SelectedValue == "3")
    {
      this.trCircle.Visible = false;
      this.trSquare.Visible = false;
      this.trTriangle1.Visible = false;
      this.trTriangle2.Visible = false;
      this.trRectangle1.Visible = true;
      this.trRectangle2.Visible = true;
    }
    else
    {
      if (!(this.drpFindTheAreaOf.SelectedValue == "4"))
        return;
      this.trCircle.Visible = false;
      this.trSquare.Visible = false;
      this.trTriangle1.Visible = true;
      this.trTriangle2.Visible = true;
      this.trRectangle1.Visible = false;
      this.trRectangle2.Visible = false;
    }
  }

  protected void btnAdd_Click(object sender, EventArgs e) => this.Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", "getArea();", true);
}
