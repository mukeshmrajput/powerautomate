﻿// Decompiled with JetBrains decompiler
// Type: PayPalAPIHelper.PayPalExpressHelper
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PaymentOptions.PaymentType;
using BLL.PurchaseOrderDetail;
using Entity.Common.PurchaseOrderDetail;
using Entity.Common.Response;
using Helper;
using PayPalAPIHelper.PayPalSandboxWS;
using PayPalAPIHelper.PayPalWS;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Web;
using WindsorTurfWeb.Common;

namespace PayPalAPIHelper
{
  public static class PayPalExpressHelper
  {
    public static string CreatePaypalExpressPayment(
      bool isPaypalorSandbox,
      Decimal itemPrice,
      Decimal FinalTotal,
      PayPalCurrency currency,
      string ItemName,
      double Quantity,
      string ReturnUrl,
      string CancelUrl,
      out string paypalToken)
    {
      return isPaypalorSandbox ? PayPalExpressHelper.CreatePaypalExpressPaymentSandbox(itemPrice, currency, FinalTotal, ItemName, Quantity, ReturnUrl, CancelUrl, out paypalToken) : PayPalExpressHelper.CreatePaypalExpressPaymentReal(itemPrice, currency, FinalTotal, ItemName, Quantity, ReturnUrl, CancelUrl, out paypalToken);
    }

    private static string CreatePaypalExpressPaymentSandbox(
      Decimal itemPrice,
      PayPalCurrency currency,
      Decimal FinalTotal,
      string ItemName,
      double Quantity,
      string ReturnUrl,
      string CancelUrl,
      out string paypalToken)
    {
      Decimal num = FinalTotal;
      SetExpressCheckoutRequestDetailsType requestDetailsType = new SetExpressCheckoutRequestDetailsType();
      requestDetailsType.ReturnURL = ReturnUrl;
      requestDetailsType.CancelURL = CancelUrl;
      requestDetailsType.NoShipping = "1";
      requestDetailsType.OrderTotal = new BasicAmountType()
      {
        currencyID = PayPalExpressHelper.ConvertProgramCurrencyToPayPalSandbox(currency),
        Value = num.ToString()
      };
      PaymentDetailsType paymentDetailsType = new PaymentDetailsType();
      PaymentDetailsItemType paymentDetailsItemType = new PaymentDetailsItemType()
      {
        Amount = new BasicAmountType()
      };
      paymentDetailsItemType.Amount.currencyID = PayPalExpressHelper.ConvertProgramCurrencyToPayPalSandbox(currency);
      paymentDetailsItemType.Amount.Value = num.ToString();
      paymentDetailsItemType.Name = ItemName;
      paymentDetailsType.PaymentDetailsItem = new PaymentDetailsItemType[1]
      {
        paymentDetailsItemType
      };
      requestDetailsType.PaymentDetails = new PaymentDetailsType[1]
      {
        paymentDetailsType
      };
      SetExpressCheckoutReq expressCheckoutReq1 = new SetExpressCheckoutReq();
      SetExpressCheckoutRequestType checkoutRequestType = new SetExpressCheckoutRequestType();
      ((AbstractRequestType) checkoutRequestType).Version = PayPalExpressHelper.Version;
      checkoutRequestType.SetExpressCheckoutRequestDetails = requestDetailsType;
      expressCheckoutReq1.SetExpressCheckoutRequest = checkoutRequestType;
      SetExpressCheckoutReq expressCheckoutReq2 = expressCheckoutReq1;
      ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
      SetExpressCheckoutResponseType resp = PayPalExpressHelper.BuildPayPalSandboxWebservice().SetExpressCheckout(expressCheckoutReq2);
      PayPalExpressHelper.HandleErrorSandbox((AbstractResponseType) resp);
      paypalToken = resp.Token;
      return string.Format("{0}?cmd=_express-checkout&token={1}", (object) "https://www.sandbox.paypal.com/cgi-bin/webscr", (object) paypalToken);
    }

    private static string CreatePaypalExpressPaymentReal(
      Decimal itemPrice,
      PayPalCurrency currency,
      Decimal FinalTotal,
      string ItemName,
      double Quantity,
      string ReturnUrl,
      string CancelUrl,
      out string paypalToken)
    {
      Decimal num = FinalTotal;
      SetExpressCheckoutRequestDetailsType requestDetailsType = new SetExpressCheckoutRequestDetailsType();
      requestDetailsType.ReturnURL = ReturnUrl;
      requestDetailsType.CancelURL = CancelUrl;
      requestDetailsType.NoShipping = "1";
      requestDetailsType.OrderTotal = new BasicAmountType()
      {
        currencyID = PayPalExpressHelper.ConvertProgramCurrencyToPayPal(currency),
        Value = num.ToString()
      };
      PaymentDetailsType paymentDetailsType = new PaymentDetailsType();
      PaymentDetailsItemType paymentDetailsItemType = new PaymentDetailsItemType()
      {
        Amount = new BasicAmountType()
      };
      paymentDetailsItemType.Amount.currencyID = PayPalExpressHelper.ConvertProgramCurrencyToPayPal(currency);
      paymentDetailsItemType.Amount.Value = num.ToString();
      paymentDetailsItemType.Name = ItemName;
      paymentDetailsType.PaymentDetailsItem = new PaymentDetailsItemType[1]
      {
        paymentDetailsItemType
      };
      requestDetailsType.PaymentDetails = new PaymentDetailsType[1]
      {
        paymentDetailsType
      };
      SetExpressCheckoutReq expressCheckoutReq1 = new SetExpressCheckoutReq();
      SetExpressCheckoutRequestType checkoutRequestType = new SetExpressCheckoutRequestType();
      ((AbstractRequestType) checkoutRequestType).Version = PayPalExpressHelper.Version;
      checkoutRequestType.SetExpressCheckoutRequestDetails = requestDetailsType;
      expressCheckoutReq1.SetExpressCheckoutRequest = checkoutRequestType;
      SetExpressCheckoutReq expressCheckoutReq2 = expressCheckoutReq1;
      ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
      SetExpressCheckoutResponseType resp = PayPalExpressHelper.BuildPayPalWebservice().SetExpressCheckout(expressCheckoutReq2);
      PayPalExpressHelper.HandleError((AbstractResponseType) resp);
      paypalToken = resp.Token;
      return string.Format("{0}?cmd=_express-checkout&token={1}", (object) "https://www.paypal.com/cgi-bin/webscr", (object) paypalToken);
    }

    public static void GetExpressCheckoutDetails(
      bool isPaypalorSandbox,
      string token,
      out string amount,
      out string currecny,
      out string itemName,
      out string payerDetails,
      out string payerFirstName,
      out string payerLastName,
      out string payerPhone)
    {
      if (isPaypalorSandbox)
        PayPalExpressHelper.GetExpressCheckoutDetailsSandBox(token, out amount, out currecny, out itemName, out payerDetails, out payerFirstName, out payerLastName, out payerPhone);
      else
        PayPalExpressHelper.GetExpressCheckoutDetailsReal(token, out amount, out currecny, out itemName, out payerDetails, out payerFirstName, out payerLastName, out payerPhone);
    }

    private static void GetExpressCheckoutDetailsReal(
      string token,
      out string amount,
      out string currecny,
      out string itemName,
      out string payerDetails,
      out string payerFirstName,
      out string payerLastName,
      out string payerPhone)
    {
      GetExpressCheckoutDetailsReq checkoutDetailsReq1 = new GetExpressCheckoutDetailsReq();
      GetExpressCheckoutDetailsRequestType detailsRequestType = new GetExpressCheckoutDetailsRequestType();
      ((AbstractRequestType) detailsRequestType).Version = PayPalExpressHelper.Version;
      detailsRequestType.Token = token;
      checkoutDetailsReq1.GetExpressCheckoutDetailsRequest = detailsRequestType;
      GetExpressCheckoutDetailsReq checkoutDetailsReq2 = checkoutDetailsReq1;
      GetExpressCheckoutDetailsResponseType expressCheckoutDetails = PayPalExpressHelper.BuildPayPalWebservice().GetExpressCheckoutDetails(checkoutDetailsReq2);
      PayPalExpressHelper.HandleError((AbstractResponseType) expressCheckoutDetails);
      GetExpressCheckoutDetailsResponseDetailsType detailsResponseDetails = expressCheckoutDetails.GetExpressCheckoutDetailsResponseDetails;
      amount = detailsResponseDetails.PaymentDetails[0].ItemTotal.Value;
      currecny = detailsResponseDetails.PaymentDetails[0].PaymentDetailsItem[0].Amount.currencyID.ToString();
      itemName = detailsResponseDetails.PaymentDetails[0].PaymentDetailsItem[0].Name;
      payerDetails = string.Format("PayerDetails:FirstName={0};LastName={1};Phone{2};", (object) detailsResponseDetails.PayerInfo.PayerName.FirstName, (object) detailsResponseDetails.PayerInfo.PayerName.LastName, (object) detailsResponseDetails.PayerInfo.ContactPhone);
      payerFirstName = string.Format("{0}", (object) detailsResponseDetails.PayerInfo.PayerName.FirstName);
      payerLastName = string.Format("{0}", (object) detailsResponseDetails.PayerInfo.PayerName.LastName);
      payerPhone = string.Format("{0}", (object) detailsResponseDetails.PayerInfo.ContactPhone);
    }

    private static void GetExpressCheckoutDetailsSandBox(
      string token,
      out string amount,
      out string currecny,
      out string itemName,
      out string payerDetails,
      out string payerFirstName,
      out string payerLastName,
      out string payerPhone)
    {
      string empty = string.Empty;
      GetExpressCheckoutDetailsReq checkoutDetailsReq1 = new GetExpressCheckoutDetailsReq();
      GetExpressCheckoutDetailsRequestType detailsRequestType = new GetExpressCheckoutDetailsRequestType();
      ((AbstractRequestType) detailsRequestType).Version = PayPalExpressHelper.Version;
      detailsRequestType.Token = token;
      checkoutDetailsReq1.GetExpressCheckoutDetailsRequest = detailsRequestType;
      GetExpressCheckoutDetailsReq checkoutDetailsReq2 = checkoutDetailsReq1;
      GetExpressCheckoutDetailsResponseType expressCheckoutDetails = PayPalExpressHelper.BuildPayPalSandboxWebservice().GetExpressCheckoutDetails(checkoutDetailsReq2);
      PayPalExpressHelper.HandleErrorSandbox((AbstractResponseType) expressCheckoutDetails);
      GetExpressCheckoutDetailsResponseDetailsType detailsResponseDetails = expressCheckoutDetails.GetExpressCheckoutDetailsResponseDetails;
      amount = detailsResponseDetails.PaymentDetails[0].ItemTotal.Value;
      currecny = detailsResponseDetails.PaymentDetails[0].PaymentDetailsItem[0].Amount.currencyID.ToString();
      itemName = detailsResponseDetails.PaymentDetails[0].PaymentDetailsItem[0].Name;
      payerDetails = string.Format("PayerDetails:FirstName={0};LastName={1};Phone{2};", (object) detailsResponseDetails.PayerInfo.PayerName.FirstName, (object) detailsResponseDetails.PayerInfo.PayerName.LastName, (object) detailsResponseDetails.PayerInfo.ContactPhone);
      payerFirstName = string.Format("{0}", (object) detailsResponseDetails.PayerInfo.PayerName.FirstName);
      payerLastName = string.Format("{0}", (object) detailsResponseDetails.PayerInfo.PayerName.LastName);
      payerPhone = string.Format("{0}", (object) detailsResponseDetails.PayerInfo.ContactPhone);
    }

    public static bool DoExpressCheckoutPayment(
      bool isPaypalorSandbox,
      string expressCheckoutToken,
      string expressCheckoutPayerID,
      string orderTotalValue,
      PayPalCurrency currency)
    {
      return isPaypalorSandbox ? PayPalExpressHelper.DoExpressCheckoutPaymentSandBox(expressCheckoutToken, expressCheckoutPayerID, orderTotalValue, currency) : PayPalExpressHelper.DoExpressCheckoutPaymentReal(expressCheckoutToken, expressCheckoutPayerID, orderTotalValue, currency);
    }

    private static bool DoExpressCheckoutPaymentReal(
      string expressCheckoutToken,
      string expressCheckoutPayerID,
      string orderTotalValue,
      PayPalCurrency currency)
    {
      PaymentDetailsType paymentDetailsType = new PaymentDetailsType()
      {
        OrderTotal = new BasicAmountType()
      };
      paymentDetailsType.OrderTotal.currencyID = PayPalExpressHelper.ConvertProgramCurrencyToPayPal(currency);
      paymentDetailsType.OrderTotal.Value = orderTotalValue;
      DoExpressCheckoutPaymentReq checkoutPaymentReq1 = new DoExpressCheckoutPaymentReq();
      DoExpressCheckoutPaymentReq checkoutPaymentReq2 = checkoutPaymentReq1;
      DoExpressCheckoutPaymentRequestType paymentRequestType1 = new DoExpressCheckoutPaymentRequestType();
      ((AbstractRequestType) paymentRequestType1).Version = PayPalExpressHelper.Version;
      paymentRequestType1.DoExpressCheckoutPaymentRequestDetails = new DoExpressCheckoutPaymentRequestDetailsType()
      {
        Token = expressCheckoutToken,
        PaymentAction = (PaymentActionCodeType) 2,
        PayerID = expressCheckoutPayerID,
        PaymentDetails = new PaymentDetailsType[1]
        {
          paymentDetailsType
        }
      };
      DoExpressCheckoutPaymentRequestType paymentRequestType2 = paymentRequestType1;
      checkoutPaymentReq2.DoExpressCheckoutPaymentRequest = paymentRequestType2;
      DoExpressCheckoutPaymentReq checkoutPaymentReq3 = checkoutPaymentReq1;
      DoExpressCheckoutPaymentResponseType resp = PayPalExpressHelper.BuildPayPalWebservice().DoExpressCheckoutPayment(checkoutPaymentReq3);
      PayPalExpressHelper.HandleError((AbstractResponseType) resp);
      bool flag;
      if (resp != null)
      {
        PaymentStatusCodeType paymentStatus = resp.DoExpressCheckoutPaymentResponseDetails.PaymentInfo[0].PaymentStatus;
        flag = paymentStatus.ToString() == "Completed";
        PaymentPurchaseOrderDetailBE purchaseOrderDetailBe = new PaymentPurchaseOrderDetailBE();
        string transactionId = resp.DoExpressCheckoutPaymentResponseDetails.PaymentInfo[0].TransactionID;
        paymentStatus = resp.DoExpressCheckoutPaymentResponseDetails.PaymentInfo[0].PaymentStatus;
        string str1 = paymentStatus.ToString();
        long int64_1 = Convert.ToInt64(HttpContext.Current.Session["PurchaseOrderId"]);
        long int64_2 = Convert.ToInt64(HttpContext.Current.Session["PaypalRetailPurchaseOrderID"]);
        Decimal num1 = Convert.ToDecimal(HttpContext.Current.Session["SubTotalforPDF"]);
        PurchaseOrderDetailBE retailPurchaseOrderId = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(int64_2);
        purchaseOrderDetailBe.PurchaseOrderId = int64_1;
        purchaseOrderDetailBe.TransactionId = transactionId;
        if (str1 == "Completed")
        {
          List<PaymentTypeResponse> list = PaymentTypeMgmt.GetPaymentOptions().Where<PaymentTypeResponse>((System.Func<PaymentTypeResponse, bool>) (m => m.PaymentTypeName == Convert.ToString((object) (Enums.PaymentTypes) 5))).ToList<PaymentTypeResponse>();
          purchaseOrderDetailBe.PaymentTypeId = list[0].PaymentTypeID;
          purchaseOrderDetailBe.PaymentStatus = 1;
          DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
          purchaseOrderDetailBe.PaymentDate = new DateTime?(dateTime);
          List<PurchaseOrderProductDetailBE> orderProductDetailBeList = new List<PurchaseOrderProductDetailBE>();
          List<PurchaseOrderProductDetailBE> lstProduct = PurchaseOrderDetailMgmt.PurchaseOrderDetailByPurchaseOrderID(int64_1);
          string appSetting1 = ConfigurationManager.AppSettings["CompletedOrderedPickUpInvoicePath"];
          string appSetting2 = ConfigurationManager.AppSettings["CompletedOrderedDeliveryInvoicePath"];
          string str2 = UtilityFunctions.BindProductDetailForInvoice((DataTable) null, lstProduct, (List<PurchaseOrderProductDetailBE>) null);
          if (Convert.ToInt32(retailPurchaseOrderId.PickUpDetailID.ToString()) == 1)
          {
            DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
            if (!nullable.HasValue)
            {
              retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
            }
            else
            {
              nullable = retailPurchaseOrderId.PickupDate;
              if (!nullable.HasValue)
                retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
            }
            string PurchaseProductDetail = str2;
            long num2 = retailPurchaseOrderId.OrderNo;
            string iOrderNo = num2.ToString();
            nullable = retailPurchaseOrderId.DeliveryDate;
            DateTime minValue1 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue1 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId.PickupDate;
            DateTime minValue2 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue2 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            string PaymentStatus = retailPurchaseOrderId.PaymentStatus.ToString() == "1" ? "Paid" : "Failed";
            num2 = retailPurchaseOrderId.PickUpDetailID;
            string PickUpdetail = num2.ToString() == "1" ? "PickUp" : "Delivery";
            num2 = retailPurchaseOrderId.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num2.ToString();
            num2 = retailPurchaseOrderId.PickUpDetailID;
            string hdnPickUpDetailID = num2.ToString();
            string hdnSubTotal = num1.ToString();
            string hdnFinalTotal = retailPurchaseOrderId.GrandTotal.ToString();
            string hdnPickDeliveryPrice = retailPurchaseOrderId.PickUpPrice.ToString();
            string CompletedOrderedPickUpInvoicePath = appSetting1;
            string CompletedOrderedDeliveryInvoicePath = appSetting2;
            string hdnGSTVal = retailPurchaseOrderId.GST.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, PaymentStatus, "Paypal", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, CompletedOrderedPickUpInvoicePath, CompletedOrderedDeliveryInvoicePath, hdnGSTVal);
          }
          else if (Convert.ToInt32(retailPurchaseOrderId.PickUpDetailID.ToString()) == 2)
          {
            DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
            if (!nullable.HasValue)
            {
              retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
            }
            else
            {
              nullable = retailPurchaseOrderId.PickupDate;
              if (!nullable.HasValue)
                retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
            }
            string PurchaseProductDetail = str2;
            long num3 = retailPurchaseOrderId.OrderNo;
            string iOrderNo = num3.ToString();
            nullable = retailPurchaseOrderId.DeliveryDate;
            DateTime minValue3 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue3 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId.PickupDate;
            DateTime minValue4 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue4 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            string PaymentStatus = retailPurchaseOrderId.PaymentStatus.ToString() == "1" ? "Paid" : "Failed";
            num3 = retailPurchaseOrderId.PickUpDetailID;
            string PickUpdetail = num3.ToString() == "1" ? "PickUp" : "Delivery";
            num3 = retailPurchaseOrderId.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num3.ToString();
            num3 = retailPurchaseOrderId.PickUpDetailID;
            string hdnPickUpDetailID = num3.ToString();
            string hdnSubTotal = num1.ToString();
            string hdnFinalTotal = retailPurchaseOrderId.GrandTotal.ToString();
            string hdnPickDeliveryPrice = retailPurchaseOrderId.DeliveryPrice.ToString();
            string CompletedOrderedPickUpInvoicePath = appSetting1;
            string CompletedOrderedDeliveryInvoicePath = appSetting2;
            string hdnGSTVal = retailPurchaseOrderId.GST.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, PaymentStatus, "Paypal", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, CompletedOrderedPickUpInvoicePath, CompletedOrderedDeliveryInvoicePath, hdnGSTVal);
          }
        }
        else
        {
          DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
          if (!nullable.HasValue)
          {
            retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
          }
          else
          {
            nullable = retailPurchaseOrderId.PickupDate;
            if (!nullable.HasValue)
              retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
          }
          purchaseOrderDetailBe.PaymentStatus = 0;
          string emailAddress = retailPurchaseOrderId.EmailAddress;
          string name = retailPurchaseOrderId.Name;
          string OrderID = Convert.ToString("I-" + retailPurchaseOrderId.OrderNo.ToString());
          string OrderPrice = retailPurchaseOrderId.GrandTotal.ToString();
          nullable = retailPurchaseOrderId.DeliveryDate;
          DateTime minValue5 = DateTime.MinValue;
          string ExpectedDeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue5 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
          nullable = retailPurchaseOrderId.PickupDate;
          DateTime minValue6 = DateTime.MinValue;
          string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue6 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
          string Specialinstructions = retailPurchaseOrderId.DeliveryInstructions.ToString() == "" ? retailPurchaseOrderId.DeliveryInstructions.ToString() : "N/A";
          string PickUpDetail = retailPurchaseOrderId.PickUpDetailID.ToString() == "1" ? "PickUp" : "Delivery";
          Mail.OrderEmailForFailedPayment(emailAddress, name, OrderID, OrderPrice, ExpectedDeliveryDate, PickupDate, Specialinstructions, PickUpDetail);
        }
        long num4 = (long) PurchaseOrderDetailMgmt.UpdatePaymentDetail(purchaseOrderDetailBe);
      }
      else
        flag = false;
      return flag;
    }

    private static bool DoExpressCheckoutPaymentSandBox(
      string expressCheckoutToken,
      string expressCheckoutPayerID,
      string orderTotalValue,
      PayPalCurrency currency)
    {
      PaymentDetailsType paymentDetailsType = new PaymentDetailsType()
      {
        OrderTotal = new BasicAmountType()
      };
      paymentDetailsType.OrderTotal.currencyID = PayPalExpressHelper.ConvertProgramCurrencyToPayPalSandbox(currency);
      paymentDetailsType.OrderTotal.Value = orderTotalValue;
      paymentDetailsType.NotifyURL = "https://www.windsorturf.com.au/PaymentResponce.aspx";
      DoExpressCheckoutPaymentReq checkoutPaymentReq1 = new DoExpressCheckoutPaymentReq();
      DoExpressCheckoutPaymentReq checkoutPaymentReq2 = checkoutPaymentReq1;
      DoExpressCheckoutPaymentRequestType paymentRequestType1 = new DoExpressCheckoutPaymentRequestType();
      ((AbstractRequestType) paymentRequestType1).Version = PayPalExpressHelper.Version;
      paymentRequestType1.ReturnFMFDetailsSpecified = true;
      paymentRequestType1.DoExpressCheckoutPaymentRequestDetails = new DoExpressCheckoutPaymentRequestDetailsType()
      {
        Token = expressCheckoutToken,
        PaymentAction = (PaymentActionCodeType) 2,
        PayerID = expressCheckoutPayerID,
        PaymentDetails = new PaymentDetailsType[1]
        {
          paymentDetailsType
        }
      };
      DoExpressCheckoutPaymentRequestType paymentRequestType2 = paymentRequestType1;
      checkoutPaymentReq2.DoExpressCheckoutPaymentRequest = paymentRequestType2;
      DoExpressCheckoutPaymentReq checkoutPaymentReq3 = checkoutPaymentReq1;
      DoExpressCheckoutPaymentResponseType resp = PayPalExpressHelper.BuildPayPalSandboxWebservice().DoExpressCheckoutPayment(checkoutPaymentReq3);
      PayPalExpressHelper.HandleErrorSandbox((AbstractResponseType) resp);
      bool flag;
      if (resp != null)
      {
        PaymentStatusCodeType paymentStatus = resp.DoExpressCheckoutPaymentResponseDetails.PaymentInfo[0].PaymentStatus;
        flag = paymentStatus.ToString() == "Completed";
        PaymentPurchaseOrderDetailBE purchaseOrderDetailBe = new PaymentPurchaseOrderDetailBE();
        string transactionId = resp.DoExpressCheckoutPaymentResponseDetails.PaymentInfo[0].TransactionID;
        paymentStatus = resp.DoExpressCheckoutPaymentResponseDetails.PaymentInfo[0].PaymentStatus;
        string str1 = paymentStatus.ToString();
        long int64_1 = Convert.ToInt64(HttpContext.Current.Session["PurchaseOrderId"]);
        long int64_2 = Convert.ToInt64(HttpContext.Current.Session["PaypalRetailPurchaseOrderID"]);
        Decimal num1 = Convert.ToDecimal(HttpContext.Current.Session["SubTotalforPDF"]);
        PurchaseOrderDetailBE retailPurchaseOrderId = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(int64_2);
        purchaseOrderDetailBe.PurchaseOrderId = int64_1;
        purchaseOrderDetailBe.TransactionId = transactionId;
        if (str1 == "Completed")
        {
          purchaseOrderDetailBe.PaymentStatus = 1;
          DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
          purchaseOrderDetailBe.PaymentDate = new DateTime?(dateTime);
          List<PurchaseOrderProductDetailBE> orderProductDetailBeList = new List<PurchaseOrderProductDetailBE>();
          List<PurchaseOrderProductDetailBE> lstProduct = PurchaseOrderDetailMgmt.PurchaseOrderDetailByPurchaseOrderID(int64_1);
          string appSetting1 = ConfigurationManager.AppSettings["CompletedOrderedPickUpInvoicePath"];
          string appSetting2 = ConfigurationManager.AppSettings["CompletedOrderedDeliveryInvoicePath"];
          string str2 = UtilityFunctions.BindProductDetailForInvoice((DataTable) null, lstProduct, (List<PurchaseOrderProductDetailBE>) null);
          long num2 = retailPurchaseOrderId.PickUpDetailID;
          if (Convert.ToInt32(num2.ToString()) == 1)
          {
            DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
            if (!nullable.HasValue)
              retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
            string PurchaseProductDetail = str2;
            num2 = retailPurchaseOrderId.OrderNo;
            string iOrderNo = num2.ToString();
            nullable = retailPurchaseOrderId.DeliveryDate;
            DateTime minValue1 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue1 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId.PickupDate;
            DateTime minValue2 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue2 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            num2 = retailPurchaseOrderId.PickUpDetailID;
            string PickUpdetail = num2.ToString() == "1" ? "PickUp" : "Delivery";
            num2 = retailPurchaseOrderId.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num2.ToString();
            num2 = retailPurchaseOrderId.PickUpDetailID;
            string hdnPickUpDetailID = num2.ToString();
            string hdnSubTotal = num1.ToString();
            string hdnFinalTotal = retailPurchaseOrderId.GrandTotal.ToString();
            string hdnPickDeliveryPrice = retailPurchaseOrderId.PickUpPrice.ToString();
            string CompletedOrderedPickUpInvoicePath = appSetting1;
            string CompletedOrderedDeliveryInvoicePath = appSetting2;
            string hdnGSTVal = retailPurchaseOrderId.GST.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, "Paid", "Paypal", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, CompletedOrderedPickUpInvoicePath, CompletedOrderedDeliveryInvoicePath, hdnGSTVal);
          }
          else
          {
            num2 = retailPurchaseOrderId.PickUpDetailID;
            if (Convert.ToInt32(num2.ToString()) == 2)
            {
              DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
              if (!nullable.HasValue)
              {
                retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
              }
              else
              {
                nullable = retailPurchaseOrderId.PickupDate;
                if (!nullable.HasValue)
                  retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
              }
              string PurchaseProductDetail = str2;
              num2 = retailPurchaseOrderId.OrderNo;
              string iOrderNo = num2.ToString();
              nullable = retailPurchaseOrderId.DeliveryDate;
              DateTime minValue3 = DateTime.MinValue;
              string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue3 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
              nullable = retailPurchaseOrderId.PickupDate;
              DateTime minValue4 = DateTime.MinValue;
              string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue4 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
              num2 = retailPurchaseOrderId.PickUpDetailID;
              string PickUpdetail = num2.ToString() == "1" ? "PickUp" : "Delivery";
              num2 = retailPurchaseOrderId.RetailPurchaseOrderID;
              string hdnRetailPurchaseOrderID = num2.ToString();
              num2 = retailPurchaseOrderId.PickUpDetailID;
              string hdnPickUpDetailID = num2.ToString();
              string hdnSubTotal = num1.ToString();
              string hdnFinalTotal = retailPurchaseOrderId.GrandTotal.ToString();
              string hdnPickDeliveryPrice = retailPurchaseOrderId.DeliveryPrice.ToString();
              string CompletedOrderedPickUpInvoicePath = appSetting1;
              string CompletedOrderedDeliveryInvoicePath = appSetting2;
              string hdnGSTVal = retailPurchaseOrderId.GST.ToString();
              UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, "Paid", "Paypal", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, CompletedOrderedPickUpInvoicePath, CompletedOrderedDeliveryInvoicePath, hdnGSTVal);
            }
          }
        }
        else
        {
          purchaseOrderDetailBe.PaymentStatus = 0;
          DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
          if (!nullable.HasValue)
          {
            retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
          }
          else
          {
            nullable = retailPurchaseOrderId.PickupDate;
            if (!nullable.HasValue)
              retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
          }
          string emailAddress = retailPurchaseOrderId.EmailAddress;
          string name = retailPurchaseOrderId.Name;
          long num3 = retailPurchaseOrderId.OrderNo;
          string OrderID = Convert.ToString("I-" + num3.ToString());
          string OrderPrice = retailPurchaseOrderId.GrandTotal.ToString();
          nullable = retailPurchaseOrderId.DeliveryDate;
          DateTime minValue5 = DateTime.MinValue;
          string ExpectedDeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue5 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
          nullable = retailPurchaseOrderId.PickupDate;
          DateTime minValue6 = DateTime.MinValue;
          string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue6 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
          string Specialinstructions = retailPurchaseOrderId.DeliveryInstructions.ToString() == "" ? retailPurchaseOrderId.DeliveryInstructions.ToString() : "N/A";
          num3 = retailPurchaseOrderId.PickUpDetailID;
          string PickUpDetail = num3.ToString() == "1" ? "PickUp" : "Delivery";
          Mail.OrderEmailForFailedPayment(emailAddress, name, OrderID, OrderPrice, ExpectedDeliveryDate, PickupDate, Specialinstructions, PickUpDetail);
        }
        purchaseOrderDetailBe.PaymentTypeId = 4L;
        purchaseOrderDetailBe.RetailPurchaseOrderID = retailPurchaseOrderId.RetailPurchaseOrderID;
        long num4 = (long) PurchaseOrderDetailMgmt.UpdatePaymentDetail(purchaseOrderDetailBe);
      }
      else
        flag = false;
      return flag;
    }

    private static string Version => "63.0";

    private static CurrencyCodeType ConvertProgramCurrencyToPayPal(PayPalCurrency currency) => (CurrencyCodeType) System.Enum.Parse(typeof (CurrencyCodeType), System.Enum.GetName(typeof (PayPalCurrency), (object) currency));

    private static CurrencyCodeType ConvertProgramCurrencyToPayPalSandbox(PayPalCurrency currency) => (CurrencyCodeType) System.Enum.Parse(typeof (CurrencyCodeType), System.Enum.GetName(typeof (PayPalCurrency), (object) currency));

    private static PayPalAPIAASoapBinding BuildPayPalWebservice()
    {
      UserIdPasswordType userIdPasswordType = new UserIdPasswordType()
      {
        Username = ConfigurationManager.AppSettings["PayPalAPIUserName"].ToString().Trim(),
        Password = ConfigurationManager.AppSettings["PayPalAPIPassword"].ToString().Trim(),
        Signature = ConfigurationManager.AppSettings["PayPalAPISignature"].ToString().Trim()
      };
      return new PayPalAPIAASoapBinding()
      {
        RequesterCredentials = new CustomSecurityHeaderType()
        {
          Credentials = userIdPasswordType
        }
      };
    }

    private static PayPalAPIAASoapBinding BuildPayPalSandboxWebservice()
    {
      UserIdPasswordType userIdPasswordType = new UserIdPasswordType()
      {
        Username = ConfigurationManager.AppSettings["PayPalSandboxAPIUserName"].ToString().Trim(),
        Password = ConfigurationManager.AppSettings["PayPalSandboxAPIPassword"].ToString().Trim(),
        Signature = ConfigurationManager.AppSettings["PayPalSandboxAPISignature"].ToString().Trim()
      };
      return new PayPalAPIAASoapBinding()
      {
        RequesterCredentials = new CustomSecurityHeaderType()
        {
          Credentials = userIdPasswordType
        }
      };
    }

    private static void HandleError(AbstractResponseType resp)
    {
      if (resp.Errors != null && resp.Errors.Length != 0)
        throw new Exception("Exception(s) occured when calling PayPal. First exception: " + resp.Errors[0].LongMessage);
    }

    private static void HandleErrorSandbox(AbstractResponseType resp)
    {
      if (resp.Errors != null && resp.Errors.Length != 0)
        throw new Exception("Exception(s) occured when calling PayPal. First exception: " + resp.Errors[0].LongMessage);
    }
  }
}
