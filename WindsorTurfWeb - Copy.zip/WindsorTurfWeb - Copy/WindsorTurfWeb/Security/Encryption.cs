﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Security.Encryption
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace WindsorTurfWeb.Security
{
  public class Encryption
  {
    private static string key = "ba507a88715e8214";

    public static string Encrypt(string plainText)
    {
      string str;
      try
      {
        byte[] bytes = Encoding.ASCII.GetBytes(plainText);
        byte[] hash = new MD5CryptoServiceProvider().ComputeHash(Encoding.ASCII.GetBytes(Encryption.key));
        TripleDESCryptoServiceProvider cryptoServiceProvider = new TripleDESCryptoServiceProvider();
        cryptoServiceProvider.Key = hash;
        cryptoServiceProvider.Mode = CipherMode.ECB;
        str = HttpUtility.UrlEncode(Convert.ToBase64String(cryptoServiceProvider.CreateEncryptor().TransformFinalBlock(bytes, 0, bytes.Length)));
      }
      catch (Exception ex)
      {
        string message = ex.Message;
        throw;
      }
      return str;
    }

    public static string Decrypt(string encryptedString)
    {
      string str;
      try
      {
        byte[] inputBuffer = Convert.FromBase64String(HttpUtility.UrlDecode(encryptedString).Replace(" ", "+"));
        byte[] hash = new MD5CryptoServiceProvider().ComputeHash(Encoding.ASCII.GetBytes(Encryption.key));
        TripleDESCryptoServiceProvider cryptoServiceProvider = new TripleDESCryptoServiceProvider();
        cryptoServiceProvider.Key = hash;
        cryptoServiceProvider.Mode = CipherMode.ECB;
        str = Encoding.ASCII.GetString(cryptoServiceProvider.CreateDecryptor().TransformFinalBlock(inputBuffer, 0, inputBuffer.Length));
      }
      catch (Exception ex)
      {
        string message = ex.Message;
        throw;
      }
      return str;
    }

    public static string EncryptQueryString(string originalString)
    {
      byte[] bytes = Encoding.ASCII.GetBytes("013A1V1a");
      DESCryptoServiceProvider cryptoServiceProvider = new DESCryptoServiceProvider();
      MemoryStream memoryStream = new MemoryStream();
      CryptoStream cryptoStream = new CryptoStream((Stream) memoryStream, cryptoServiceProvider.CreateEncryptor(bytes, bytes), CryptoStreamMode.Write);
      StreamWriter streamWriter = new StreamWriter((Stream) cryptoStream);
      streamWriter.Write(originalString);
      streamWriter.Flush();
      cryptoStream.FlushFinalBlock();
      streamWriter.Flush();
      return HttpUtility.UrlEncode(Convert.ToBase64String(memoryStream.GetBuffer(), 0, (int) memoryStream.Length)).Replace("%2b", "@@@").Replace("%2f", "~");
    }

    public static string DecryptQueryString(string cryptedString)
    {
      cryptedString = HttpUtility.UrlDecode(cryptedString);
      cryptedString = cryptedString.Replace(" ", "+");
      cryptedString = cryptedString.Replace("@@@", "+");
      cryptedString = cryptedString.Replace("~", "/");
      byte[] bytes = Encoding.ASCII.GetBytes("013A1V1a");
      if (string.IsNullOrEmpty(cryptedString))
        throw new ArgumentNullException("The string which needs to be decrypted can not be null.");
      DESCryptoServiceProvider cryptoServiceProvider = new DESCryptoServiceProvider();
      return HttpUtility.UrlDecode(new StreamReader((Stream) new CryptoStream((Stream) new MemoryStream(Convert.FromBase64String(cryptedString)), cryptoServiceProvider.CreateDecryptor(bytes, bytes), CryptoStreamMode.Read)).ReadToEnd());
    }
  }
}
