﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.GetQuote
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using BLL.PageManagement;
using BLL.ProductPricing.NonTurfProductPricing.DeliveryRegion;
using Entity.Common.CommonList;
using Entity.Common.PurchaseOrderDetail;
using Entity.Response.CommercialPartner;
using Entity.Response.PageManagement;
using Helper;
using Resources;
using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;

namespace WindsorTurfWeb
{
  public class GetQuote : Page
  {
    public string strValidationUserGrp = "ValGrpCommercial";
    private DataTable dt = new DataTable();
    private DataTable _dtQUOTE = new DataTable();
    private DataTable dtQuoteDetail = new DataTable();
    private DataRow drProduct;
    protected HighslideControlFront HighslideControlFront1;
    protected HiddenField hdnFlagVal;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected HtmlGenericControl divContinueShopBtn;
    protected Button btnContShopping;
    protected HtmlGenericControl divMainRetailDetail;
    protected FieldInformation FieldInformation1;
    protected Repeater rpt_cart;
    protected HtmlGenericControl divQuoteDetail;
    protected HtmlGenericControl divOrderUnderCompany;
    protected RadioButtonList rdlOrderUnderCompany;
    protected RadioButtonList rdlPickUpDetails;
    protected HtmlGenericControl divBusinessName;
    protected TextBox txtBusinessName;
    protected HtmlGenericControl spnBusinessName;
    protected RequiredFieldValidator rfvBusinessName;
    protected RegularExpressionValidator regBusinessName;
    protected TextBox txtFirstName;
    protected RequiredFieldValidator rfvFirstName;
    protected RegularExpressionValidator regFirstName;
    protected TextBox txtLastName;
    protected RequiredFieldValidator rfvLastName;
    protected RegularExpressionValidator regLastName;
    protected TextBox txtEmail;
    protected RequiredFieldValidator rfvEmail;
    protected RegularExpressionValidator regEmail;
    protected HtmlGenericControl DivPickuppostcode;
    protected TextBox txtPostcodePickup;
    protected RequiredFieldValidator rfvPostcodePickup;
    protected HtmlGenericControl DivDeliverypostcode;
    protected TextBox txtPostcodeDelivery;
    protected RequiredFieldValidator rfvPostcodeDelivery;
    protected Button btnContinue;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      if (this.Session["dtCART"] != null)
        UtilityFunctions.SetCartEmptyMessage(this.Page, (DataTable) this.Session["dtCART"]);
      if (this.Session["dtQUOTE"] != null)
        UtilityFunctions.CheckForInactiveUserForLogout(this.Page, (DataTable) this.Session["dtQUOTE"]);
      PageManagementResponseBE managementResponseBe = new PageManagementResponseBE();
      PageManagementResponseBE pageByLinkUrl = PageManagementMgmt.GetPageByLinkURL("get-quote");
      if (pageByLinkUrl != null && pageByLinkUrl.PageManagementID > 0L)
        UtilityFunctions.SetDefaultCommonHeader(this.Page, pageByLinkUrl.HeaderImage, pageByLinkUrl.NameOnMenu);
      if (this.IsPostBack)
        return;
      this.ValidationExpression();
      this.BindRepeter();
      PurchaseOrderDetailBE purchaseOrderDetailBe = new PurchaseOrderDetailBE();
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
        this.FillCommercialPartnerData(Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")));
    }

    protected void FillCommercialPartnerData(long LoginUserMasterID)
    {
      CommercialPartnerResponseBE detailByLoginMasterId = CommercialPartnerMgmt.GetCommercialPartnerDetailByLoginMasterID(LoginUserMasterID);
      if (detailByLoginMasterId == null)
        return;
      this.rdlOrderUnderCompany.SelectedValue = "1";
      this.rdlOrderUnderCompany.Enabled = false;
      if (this.rdlPickUpDetails.SelectedValue == "1")
      {
        this.txtEmail.Text = string.Empty;
        this.txtBusinessName.Text = string.Empty;
        this.txtFirstName.Text = string.Empty;
        this.txtLastName.Text = string.Empty;
        this.txtPostcodeDelivery.Text = string.Empty;
        this.txtEmail.Text = detailByLoginMasterId.Email;
        this.txtBusinessName.Text = detailByLoginMasterId.BusinessName;
        this.txtFirstName.Text = detailByLoginMasterId.FirstName;
        this.txtLastName.Text = detailByLoginMasterId.LastName;
        this.txtPostcodePickup.Text = detailByLoginMasterId.PostCode;
      }
      else if (this.rdlPickUpDetails.SelectedValue == "2")
      {
        this.txtEmail.Text = string.Empty;
        this.txtBusinessName.Text = string.Empty;
        this.txtFirstName.Text = string.Empty;
        this.txtLastName.Text = string.Empty;
        this.txtPostcodeDelivery.Text = string.Empty;
        this.txtEmail.Text = detailByLoginMasterId.Email;
        this.txtBusinessName.Text = detailByLoginMasterId.BusinessName;
        this.txtFirstName.Text = detailByLoginMasterId.FirstName;
        this.txtLastName.Text = detailByLoginMasterId.LastName;
        this.txtPostcodeDelivery.Text = detailByLoginMasterId.PostCode;
      }
    }

    public void BindRepeter()
    {
      if (this.Session["dtQUOTE"] != null)
      {
        this._dtQUOTE = (DataTable) this.Session["dtQUOTE"];
        if (this._dtQUOTE.Rows.Count > 0)
        {
          this._dtQUOTE = UtilityFunctions.ReverseRowsInDataTable(this._dtQUOTE);
          this.rpt_cart.DataSource = (object) this._dtQUOTE;
          this.rpt_cart.DataBind();
        }
        else
        {
          if (this._dtQUOTE.Rows.Count != 0)
            return;
          this.rpt_cart.DataSource = (object) this._dtQUOTE;
          this.rpt_cart.DataBind();
          this.rpt_cart.Visible = false;
        }
      }
      else
      {
        this.spnMsg.Style.Add("display", "block");
        this.divContinueShopBtn.Visible = true;
        this.lblMsg.Text = string.Format(Messages.ShoppingCartEmpty);
        this.divMainRetailDetail.Visible = false;
        this.spnMsg.Style.Add("color", UtilityFunctions.SetMessageColor(0));
        UtilityFunctions.SetCartEmptyMessage(this.Page, this._dtQUOTE);
      }
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorForFront(this.rfvEmail, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regEmail, Regex.Email, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvFirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regFirstName, Regex.FirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvLastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regLastName, Regex.LastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvEmail, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regEmail, Regex.Email, true, (object) this.txtEmail, this.strValidationUserGrp);
      this.btnContinue.ValidationGroup = this.strValidationUserGrp;
    }

    private DataTable AddColumns(DataTable dtQuoteDetail)
    {
      dtQuoteDetail.Columns.Add(new DataColumn("Email", typeof (string)));
      dtQuoteDetail.Columns.Add(new DataColumn("BusinessName", typeof (string)));
      dtQuoteDetail.Columns.Add(new DataColumn("FirstName", typeof (string)));
      dtQuoteDetail.Columns.Add(new DataColumn("LastName", typeof (string)));
      dtQuoteDetail.Columns.Add(new DataColumn("PostCode", typeof (long)));
      dtQuoteDetail.Columns.Add(new DataColumn("PickUpDeliveryID", typeof (long)));
      dtQuoteDetail.Columns.Add(new DataColumn("OrderUnderCompany", typeof (int)));
      dtQuoteDetail.Columns.Add(new DataColumn("TurfType", typeof (string)));
      return dtQuoteDetail;
    }

    protected void AddItem()
    {
      DataTable dataTable = (DataTable) null;
      if (this.Session["dtQuoteDetail"] != null)
        dataTable = (DataTable) this.Session["dtQuoteDetail"];
      if (dataTable == null)
      {
        this.dtQuoteDetail = new DataTable();
        this.dtQuoteDetail = this.AddColumns(this.dtQuoteDetail);
        this.drProduct = this.dtQuoteDetail.NewRow();
        this.drProduct["Email"] = (object) this.txtEmail.Text.Trim();
        this.drProduct["BusinessName"] = (object) this.txtBusinessName.Text.Trim();
        this.drProduct["FirstName"] = (object) this.txtFirstName.Text.Trim();
        this.drProduct["LastName"] = (object) this.txtLastName.Text.Trim();
        this.drProduct["PickUpDeliveryID"] = (object) this.rdlPickUpDetails.SelectedValue;
        this.drProduct["OrderUnderCompany"] = (object) this.rdlOrderUnderCompany.SelectedValue;
        this.drProduct["PostCode"] = !(this.txtPostcodeDelivery.Text == "") ? (object) this.txtPostcodeDelivery.Text : (object) this.txtPostcodePickup.Text;
        this.dtQuoteDetail.Rows.Add(this.drProduct);
        this.Session["dtQuoteDetail"] = (object) this.dtQuoteDetail;
        this.Response.Redirect("/calculate-turfarea");
      }
      else if (dataTable != null && dataTable.Rows.Count > 0)
      {
        this.Session["dtQuoteDetail"] = (object) dataTable;
        this.Response.Redirect("/calculate-turfarea");
      }
    }

    protected void btnContinue_Click(object sender, EventArgs e)
    {
      if (!string.IsNullOrEmpty(this.txtPostcodeDelivery.Text))
      {
        int num = DeliveryRegionMgmt.CheckPostalCodeRangeByDeliveryRegionAndQuantityZone(Convert.ToInt32(this.txtPostcodeDelivery.Text));
        HandlerResponse handlerResponse = new HandlerResponse();
        if (num > 0)
        {
          this.spnMsg.Style.Add("display", "none");
          this.lblMsg.Text = string.Empty;
          this.AddItem();
        }
        else
        {
          string format = "We cannot deliver to your Postal Code " + this.txtPostcodeDelivery.Text + ". Please contact Windsor Turf on (02) 4557 2550 to discuss delivery options.";
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(format), (Enums.NotificationType) 3), true);
          this.txtPostcodeDelivery.Text = string.Empty;
        }
      }
      else
        this.AddItem();
    }
  }
}
