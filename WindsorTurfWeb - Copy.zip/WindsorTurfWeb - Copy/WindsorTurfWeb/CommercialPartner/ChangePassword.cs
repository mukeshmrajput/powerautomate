﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.CommercialPartner.ChangePassword
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Miscellaneous;
using Helper;
using Resources;
using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.CommercialPartner
{
  public class ChangePassword : Page
  {
    public string strValidationUserGrp = "ValGrpCommercial";
    private long LoginFrontMasterId;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected TextBox txtCurrentPassword;
    protected RequiredFieldValidator rfvCurrentPassword;
    protected RegularExpressionValidator regCurrentPassword;
    protected TextBox txtNewPassword;
    protected RequiredFieldValidator rfvNewPassword;
    protected RegularExpressionValidator regNewPassword;
    protected TextBox txtConfirmPassword;
    protected RequiredFieldValidator rfvConfirmPassword;
    protected CompareValidator cvconfirmpassword;
    protected Button btnSubmit;
    protected Button btnCancel;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Session["dtCART"] != null)
        UtilityFunctions.CheckForInactiveUserForLogout(this.Page, (DataTable) this.Session["dtCART"]);
      this.ValidationExpression();
      this.txtCurrentPassword.Focus();
      ((HtmlControl) this.Master.FindControl("aOrderHistory")).Attributes.Add("class", "buttion SetNavMenu");
      ((HtmlControl) this.Master.FindControl("aUpdateProfile")).Attributes.Add("class", "buttion SetNavMenu");
      ((HtmlControl) this.Master.FindControl("aChangePassword")).Attributes.Add("class", "buttion SetNavMenu active");
      this.Page.Form.Action = this.Request.RawUrl;
      UtilityFunctions.SetDefaultCommonHeader(this.Page, "", PageName.strMenuChangePassowrd);
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
        this.LoginFrontMasterId = Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID"));
      else
        this.Response.Redirect("/default.aspx?ReturnURL=" + this.Request.RawUrl);
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorForFront(this.rfvCurrentPassword, true, (object) this.txtCurrentPassword, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regCurrentPassword, Regex.Password, true, (object) this.txtCurrentPassword, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvNewPassword, true, (object) this.txtNewPassword, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvConfirmPassword, true, (object) this.txtConfirmPassword, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regNewPassword, Regex.Password, true, (object) this.txtNewPassword, this.strValidationUserGrp);
      Validations.SetCompareFieldValidatorForResetChangePasswordFront(this.cvconfirmpassword, true, (object) this.txtConfirmPassword, (object) this.txtNewPassword, this.strValidationUserGrp);
      this.btnSubmit.ValidationGroup = this.strValidationUserGrp;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.IsValid)
        return;
      if (string.Compare(this.txtNewPassword.Text.Trim(), this.txtConfirmPassword.Text.Trim(), StringComparison.OrdinalIgnoreCase) == 0)
      {
        if ((long) ChangePasswordMgmt.UpdateCommercialPartnerPassword(new Entity.Common.Miscellaneous.ChangePassword()
        {
          UserLoginId = Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")),
          NewsPassword = Encryption.EncryptQueryString(this.txtNewPassword.Text.Trim()),
          CurrentPassword = Encryption.EncryptQueryString(this.txtCurrentPassword.Text.Trim()),
          UserTypeID = Convert.ToInt64((object) (Enums.PersonType) 4)
        }) == Convert.ToInt64((object) (Enums.ResponseType) 2))
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.ChangePasswordSuccess.ToString(), (object) "Password"), (Enums.NotificationType) 1), true);
        else
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.CurrentPasswordNotMatch.ToString(), (object) "Password"), (Enums.NotificationType) 3), true);
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.NewPassAndConfirmPassNotMatch.ToString()), (Enums.NotificationType) 3), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("/default.aspx");
  }
}
