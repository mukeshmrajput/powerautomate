﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.CommercialPartner.UpdateProfile
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using Entity.Common.CommercialPartner;
using Entity.Response.CommercialPartner;
using Helper;
using Resources;
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.CommercialPartner
{
  public class UpdateProfile : Page
  {
    public string strValidationUserGrp = "ValGrpCommercial";
    private long LoginFrontMasterId;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected TextBox txtBusinessName;
    protected RequiredFieldValidator rfvBusinessName;
    protected RegularExpressionValidator regBusinessName;
    protected TextBox txtCompanyABN;
    protected RequiredFieldValidator rfvCompanyABN;
    protected CustomValidator cvalCompanyABN;
    protected TextBox txtFirstName;
    protected RequiredFieldValidator rfvFirstName;
    protected RegularExpressionValidator regFirstName;
    protected TextBox txtLastName;
    protected RequiredFieldValidator rfvLastName;
    protected RegularExpressionValidator regLastName;
    protected TextBox txtEmail;
    protected RequiredFieldValidator rfvEmail;
    protected RegularExpressionValidator regEmail;
    protected TextBox txtTelephone;
    protected RequiredFieldValidator rfvTelephone;
    protected TextBox txtFax;
    protected TextBox txtMobileNumber;
    protected TextBox txtAddressLine1;
    protected RequiredFieldValidator rfvAddressLine1;
    protected RegularExpressionValidator regAddressLine1;
    protected TextBox txtAddressLine2;
    protected RegularExpressionValidator regAddressLine2;
    protected TextBox txtSuburb;
    protected RequiredFieldValidator rfvSuburb;
    protected RegularExpressionValidator regSuburb;
    protected DropDownList ddlState;
    protected RequiredFieldValidator rfvState;
    protected TextBox txtPostcode;
    protected RequiredFieldValidator rfvPostcode;
    protected RegularExpressionValidator regPostcode;
    protected Button btnSubmit;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Session["dtCART"] != null)
        UtilityFunctions.CheckForInactiveUserForLogout(this.Page, (DataTable) this.Session["dtCART"]);
      this.Page.Form.Action = this.Request.RawUrl;
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
        this.LoginFrontMasterId = Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID"));
      else
        this.Response.Redirect("/default.aspx?ReturnURL=" + this.Request.RawUrl);
      if (!this.IsPostBack)
      {
        BindDropDown.BindAllStates((ListControl) this.ddlState);
        this.ValidationExpression();
        this.txtBusinessName.Focus();
        ((HtmlControl) this.Master.FindControl("aOrderHistory")).Attributes.Add("class", "buttion SetNavMenu");
        ((HtmlControl) this.Master.FindControl("aUpdateProfile")).Attributes.Add("class", "buttion SetNavMenu active");
        ((HtmlControl) this.Master.FindControl("aChangePassword")).Attributes.Add("class", "buttion SetNavMenu");
        this.txtEmail.Attributes.Add("readonly", "readonly");
        this.txtCompanyABN.Attributes.Add("readonly", "readonly");
        if (this.LoginFrontMasterId > 0L)
          this.GetCommercialPartnerDetail(CommercialPartnerMgmt.GetCommercialPartnerDetailByCommercialPartnerID(Convert.ToInt64(CommercialPartnerMgmt.GetCommercialPartnerIDByLoginMasterID(Convert.ToInt64(this.LoginFrontMasterId)).CommercialPartnerID)));
      }
      UtilityFunctions.SetDefaultCommonHeader(this.Page, "", PageName.strMenuUpdateProfile);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      long commercialPartnerId = CommercialPartnerMgmt.GetCommercialPartnerIDByLoginMasterID(Convert.ToInt64(this.LoginFrontMasterId)).CommercialPartnerID;
      if (CommercialPartnerMgmt.AddUpdateCommercialPartner(new CommercialPartnerBE()
      {
        CommercialPartnerID = commercialPartnerId,
        FirstName = this.txtFirstName.Text,
        LastName = this.txtLastName.Text,
        Email = this.txtEmail.Text,
        Telephone = this.txtTelephone.Text,
        Mobile = this.txtMobileNumber.Text,
        Address1 = this.txtAddressLine1.Text,
        Address2 = this.txtAddressLine2.Text,
        Suburb = this.txtSuburb.Text,
        StateMasterID = Convert.ToInt64(this.ddlState.SelectedValue),
        PostCode = this.txtPostcode.Text,
        CompanyABN = this.txtCompanyABN.Text,
        BusinessName = this.txtBusinessName.Text,
        Fax = this.txtFax.Text,
        CreatedBy = 0L,
        CreatedByIP = HttpContext.Current.Request.UserHostAddress,
        UserTypeID = Convert.ToInt64((object) (Enums.PersonType) 4),
        UserStatusID = Convert.ToInt64((object) (Enums.UserStatus) 4)
      }) <= 0L)
        return;
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.UpdateSuccess, (object) "Profile"), (Enums.NotificationType) 1), true);
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorForFront(this.rfvBusinessName, true, (object) this.txtBusinessName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regBusinessName, Regex.Title, true, (object) this.txtBusinessName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvCompanyABN, true, (object) this.txtCompanyABN, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvFirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regFirstName, Regex.FirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvLastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regLastName, Regex.LastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvEmail, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regEmail, Regex.Email, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvTelephone, true, (object) this.txtTelephone, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvPostcode, true, (object) this.txtPostcode, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regPostcode, Regex.ZipCode, true, (object) this.txtPostcode, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvAddressLine1, true, (object) this.txtAddressLine1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regAddressLine1, Regex.Address, true, (object) this.txtAddressLine1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regAddressLine2, Regex.Address, true, (object) this.txtAddressLine2, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdownForFront(this.rfvState, true, (object) this.ddlState, "-1", this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvSuburb, true, (object) this.txtSuburb, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regSuburb, Regex.Address, true, (object) this.txtSuburb, this.strValidationUserGrp);
      this.btnSubmit.ValidationGroup = this.strValidationUserGrp;
    }

    protected void GetCommercialPartnerDetail(
      CommercialPartnerResponseBE objCommercialPartnerResponse)
    {
      if (objCommercialPartnerResponse == null)
        return;
      this.txtBusinessName.Text = objCommercialPartnerResponse.BusinessName.Trim();
      this.txtCompanyABN.Text = objCommercialPartnerResponse.CompanyABN.Trim();
      this.txtEmail.Text = objCommercialPartnerResponse.Email.Trim();
      this.txtFirstName.Text = objCommercialPartnerResponse.FirstName.Trim();
      this.txtLastName.Text = objCommercialPartnerResponse.LastName.Trim();
      this.txtAddressLine1.Text = objCommercialPartnerResponse.Address1.Trim();
      this.txtAddressLine2.Text = objCommercialPartnerResponse.Address2.Trim();
      this.txtTelephone.Text = objCommercialPartnerResponse.Telephone.Trim();
      this.txtFax.Text = objCommercialPartnerResponse.Fax.Trim();
      this.txtMobileNumber.Text = objCommercialPartnerResponse.Mobile.Trim();
      this.txtSuburb.Text = objCommercialPartnerResponse.Suburb.Trim();
      this.ddlState.SelectedValue = Convert.ToString(objCommercialPartnerResponse.StateMasterID);
      this.txtPostcode.Text = objCommercialPartnerResponse.PostCode.Trim();
    }
  }
}
