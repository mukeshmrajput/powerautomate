﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.CommercialPartner.CommercialPartnerMaster
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;

namespace WindsorTurfWeb.CommercialPartner
{
  public class CommercialPartnerMaster : MasterPage
  {
    protected ContentPlaceHolder head;
    protected HtmlForm form1;
    protected ScriptManager Scrpt1;
    protected Image imgHeader;
    protected HeaderTopMenu HeaderTopMenu1;
    protected Literal ltrPageName;
    protected Literal ltrMainPageName;
    protected HtmlAnchor aOrderHistory;
    protected HtmlAnchor aQuoteHistory;
    protected HtmlAnchor aUpdateProfile;
    protected HtmlAnchor aChangePassword;
    protected ContentPlaceHolder ContentPlaceHolder1;
    protected FooterPart FooterPart1;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.aOrderHistory.HRef = "/order-history";
      this.aQuoteHistory.HRef = "/quote-history";
      this.aUpdateProfile.HRef = "/updateprofile";
      this.aChangePassword.HRef = "/change-password";
      this.aOrderHistory.InnerText = PageName.strMenuOrderHistory;
      this.aOrderHistory.Title = PageName.strMenuOrderHistory;
      this.aQuoteHistory.InnerText = PageName.strMenuQuoteHistory;
      this.aQuoteHistory.Title = PageName.strMenuQuoteHistory;
      this.aUpdateProfile.InnerText = PageName.strMenuUpdateProfile;
      this.aUpdateProfile.Title = PageName.strMenuUpdateProfile;
      this.aChangePassword.InnerText = PageName.strMenuChangePassowrd;
      this.aChangePassword.Title = PageName.strMenuChangePassowrd;
    }
  }
}
