﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.CommercialPartner.OrderHistory
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PurchaseOrderDetail;
using Entity.Common.PurchaseOrderDetail;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;

namespace WindsorTurfWeb.CommercialPartner
{
  public class OrderHistory : Page
  {
    public string HeaderImagePath = ConfigurationManager.AppSettings[nameof (HeaderImagePath)];
    public string CardImagePath = ConfigurationManager.AppSettings[nameof (CardImagePath)];
    public string CommonInternalBannerName = ConfigurationManager.AppSettings[nameof (CommonInternalBannerName)];
    public long LoginFrontMasterId;
    public int TotalRecords;
    private PurchaseOrderDetailBE objPurchase = new PurchaseOrderDetailBE();
    protected HtmlGenericControl divShoppingCartDetail;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected Button btnPurchaseOrder;
    protected TextBox txtSearch;
    protected RadDatePicker radFromDate;
    protected RadDatePicker radToDate;
    protected CompareValidator dateCompareValidator;
    protected Button btnSearch;
    protected Button btnViewAll;
    protected Repeater rptCommercialPartnerOrderHistory;
    protected HtmlGenericControl DivNoRecord;
    protected Label lblMsgNoRecord;
    protected HtmlGenericControl divAdd;
    protected Paging CustomPaging;
    protected HtmlGenericControl Divlegend;
    protected HiddenField hdnSortName;
    protected HiddenField hdnSortExpr;
    protected HiddenField hdnSearch;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Session["dtCART"] != null)
        UtilityFunctions.CheckForInactiveUserForLogout(this.Page, (DataTable) this.Session["dtCART"]);
      this.Page.Form.Action = this.Request.RawUrl;
      this.Form.DefaultButton = this.btnSearch.UniqueID;
      ((HtmlControl) this.Master.FindControl("aOrderHistory")).Attributes.Add("class", "buttion SetNavMenu active");
      ((HtmlControl) this.Master.FindControl("aUpdateProfile")).Attributes.Add("class", "buttion SetNavMenu");
      ((HtmlControl) this.Master.FindControl("aChangePassword")).Attributes.Add("class", "buttion SetNavMenu");
      UtilityFunctions.SetDefaultCommonHeader(this.Page, "", PageName.strMenuOrderHistory);
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
      {
        this.LoginFrontMasterId = Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID"));
        if (!this.IsPostBack)
          this.BindPurchaseOrderList();
      }
      else
        this.Response.Redirect("/default.aspx?ReturnURL=" + this.Request.RawUrl);
      if (this.Session["TransactionSucessFront"] != null)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(this.Session["TransactionSucessFront"].ToString()), (Enums.NotificationType) 1), true);
      if (this.Session["TransactionFailFront"] != null)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(this.Session["TransactionFailFront"].ToString()), (Enums.NotificationType) 3), true);
      if (this.Session["returnUrl"] != null)
      {
        this.Response.Redirect(this.Session["returnUrl"].ToString());
        this.Session["returnUrl"] = (object) null;
      }
      this.txtSearch.Focus();
    }

    private void BindPurchaseOrderList()
    {
      this.objPurchase.SortField = this.hdnSortName.Value;
      this.objPurchase.SortExpr = this.hdnSortExpr.Value;
      DateTime? selectedDate;
      if (!string.IsNullOrEmpty(this.radFromDate.SelectedDate.ToString()))
      {
        PurchaseOrderDetailBE objPurchase = this.objPurchase;
        selectedDate = this.radFromDate.SelectedDate;
        DateTime? nullable = new DateTime?(Convert.ToDateTime(selectedDate.ToString()));
        objPurchase.FromDate = nullable;
      }
      selectedDate = this.radToDate.SelectedDate;
      if (!string.IsNullOrEmpty(selectedDate.ToString()))
      {
        PurchaseOrderDetailBE objPurchase = this.objPurchase;
        selectedDate = this.radToDate.SelectedDate;
        DateTime? nullable = new DateTime?(Convert.ToDateTime(selectedDate.ToString()));
        objPurchase.ToDate = nullable;
      }
      this.objPurchase.PageSize = this.CustomPaging.PageSize;
      this.objPurchase.PageIndex = this.CustomPaging.PageId;
      this.objPurchase.SearchKeyword = !string.IsNullOrEmpty(this.txtSearch.Text.Trim()) && !(this.txtSearch.Text == "Keyword") ? (!(this.hdnSearch.Value == "1") ? "" : this.txtSearch.Text.Trim()) : "";
      this.objPurchase.LoginFrontMasterID = this.LoginFrontMasterId;
      this.GetPurchaseOrderDetail(this.objPurchase);
    }

    protected void GetPurchaseOrderDetail(PurchaseOrderDetailBE objPurchase)
    {
      List<PurchaseOrderDetailBE> loginFrontMasterId = PurchaseOrderDetailMgmt.GetAllCommercialPartnerOrdersByLoginFrontMasterID(objPurchase, ref this.TotalRecords);
      if (loginFrontMasterId.Count == 0 && objPurchase.PageIndex > 0)
      {
        --this.CustomPaging.PageId;
        this.BindPurchaseOrderList();
      }
      else
      {
        if (loginFrontMasterId.Count > 0)
        {
          this.CustomPaging.TotalRecords = this.TotalRecords;
          this.CustomPaging.Visible = true;
          this.CustomPaging.ReloadPaging();
          this.Divlegend.Visible = true;
          this.DivNoRecord.Visible = false;
          this.lblMsgNoRecord.Text = string.Empty;
        }
        else
        {
          this.CustomPaging.Visible = false;
          this.Divlegend.Visible = false;
          this.DivNoRecord.Visible = true;
          this.lblMsgNoRecord.Text = string.Format(Messages.NoOrderHistoryfound);
          this.DivNoRecord.Style.Add("color", UtilityFunctions.SetMessageColor(0));
        }
        this.rptCommercialPartnerOrderHistory.DataSource = (object) loginFrontMasterId;
        this.rptCommercialPartnerOrderHistory.DataBind();
      }
    }

    protected void btnPurchaseOrder_Click(object sender, EventArgs e) => this.Response.Redirect("/shop");

    protected void btnViewAll_Click(object sender, EventArgs e) => this.Response.Redirect("/order-history");

    protected void btnSearch_Click(object sender, EventArgs e)
    {
      this.hdnSearch.Value = "1";
      this.CustomPaging.PageId = 0;
      this.BindPurchaseOrderList();
      this.spnMsg.Visible = true;
      this.lblMsg.Text = string.Empty;
    }

    protected void CustomPaging_CustomPageSelectedIndexChanged(object sender, EventArgs e)
    {
      this.BindPurchaseOrderList();
      this.spnMsg.Visible = false;
      this.lblMsg.Text = string.Empty;
    }

    protected void btnGotoPage_Click(object sender, EventArgs e)
    {
      this.BindPurchaseOrderList();
      this.spnMsg.Visible = false;
      this.lblMsg.Text = string.Empty;
    }

    protected void rptCommercialPartnerOrderHistory_ItemDataBound(
      object sender,
      RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType == ListItemType.Header)
      {
        string str = !(this.hdnSortName.Value.ToLower() == "paiddate") && !(this.hdnSortName.Value.ToLower() == "deliverydate") && !(this.hdnSortName.Value.ToLower() == "submitteddate") ? (!(this.hdnSortExpr.Value.ToLower() == "asc") ? "ztoaimg" : "atozimg") : (!(this.hdnSortExpr.Value.ToLower() == "asc") ? "ztoaarrow" : "atozarrow");
        switch (this.hdnSortName.Value.ToLower())
        {
          case "billingbusinessname":
            ((HtmlControl) e.Item.FindControl("spnBusinessName"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkBusinessName")).Style.Add("text-decoration", "underline");
            break;
          case "customername":
            ((HtmlControl) e.Item.FindControl("spnCustomerName"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkCustomerName")).Style.Add("text-decoration", "underline");
            break;
          case "deliverydate":
            ((HtmlControl) e.Item.FindControl("spnDeliveryDate"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkDeliveryDate")).Style.Add("text-decoration", "underline");
            break;
          case "grandtotal":
            ((HtmlControl) e.Item.FindControl("spnGrandTotal"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkGrandTotal")).Style.Add("text-decoration", "underline");
            break;
          case "ordernostr":
            ((HtmlControl) e.Item.FindControl("spnOrderNo"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkOrderNo")).Style.Add("text-decoration", "underline");
            break;
          case "paiddate":
            ((HtmlControl) e.Item.FindControl("spnPaidDate"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkPaidDate")).Style.Add("text-decoration", "underline");
            break;
          case "paymentstatus":
            ((HtmlControl) e.Item.FindControl("spnPaymentStatus"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkPaymentStatus")).Style.Add("text-decoration", "underline");
            break;
          case "paymenttypename":
            ((HtmlControl) e.Item.FindControl("spnPaymentTypeName"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkPaymentTypeName")).Style.Add("text-decoration", "underline");
            break;
          case "submitteddate":
            ((HtmlControl) e.Item.FindControl("spnOrderDate"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkOrderDate")).Style.Add("text-decoration", "underline");
            break;
        }
      }
      if (this.TotalRecords == 0)
        this.Divlegend.Visible = false;
      else
        this.Divlegend.Visible = true;
    }

    protected void rptCommercialPartnerOrderHistory_ItemCommand(
      object source,
      RepeaterCommandEventArgs e)
    {
      if (!(e.CommandName == "SortColumn"))
        return;
      if (this.hdnSortName.Value == e.CommandArgument.ToString())
      {
        this.hdnSortExpr.Value = !(this.hdnSortExpr.Value == "ASC") ? "ASC" : "DESC";
      }
      else
      {
        this.hdnSortName.Value = e.CommandArgument.ToString();
        this.hdnSortExpr.Value = "ASC";
      }
      this.BindPurchaseOrderList();
    }
  }
}
