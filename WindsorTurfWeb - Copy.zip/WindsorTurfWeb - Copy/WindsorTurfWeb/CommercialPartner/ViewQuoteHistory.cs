﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.CommercialPartner.ViewQuoteHistory
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.QuoteDetail;
using Entity.Common.QuoteDetail;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;

namespace WindsorTurfWeb.CommercialPartner
{
  public class ViewQuoteHistory : Page
  {
    public string HeaderImagePath = ConfigurationManager.AppSettings[nameof (HeaderImagePath)];
    public string CardImagePath = ConfigurationManager.AppSettings[nameof (CardImagePath)];
    public string CommonInternalBannerName = ConfigurationManager.AppSettings[nameof (CommonInternalBannerName)];
    public long LoginFrontMasterId;
    public int TotalRecords;
    private QuoteDetailBE objPurchase = new QuoteDetailBE();
    protected HtmlGenericControl divShoppingCartDetail;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected TextBox txtSearch;
    protected RadDatePicker radFromDate;
    protected RadDatePicker radToDate;
    protected CompareValidator dateCompareValidator;
    protected Button btnSearch;
    protected Button btnViewAll;
    protected Repeater rptCommercialPartnerOrderHistory;
    protected HtmlGenericControl DivNoRecord;
    protected Label lblMsgNoRecord;
    protected HtmlGenericControl divAdd;
    protected Paging CustomPaging;
    protected HtmlGenericControl Divlegend;
    protected HiddenField hdnSortName;
    protected HiddenField hdnSortExpr;
    protected HiddenField hdnSearch;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Session["dtCART"] != null)
        UtilityFunctions.CheckForInactiveUserForLogout(this.Page, (DataTable) this.Session["dtCART"]);
      this.Page.Form.Action = this.Request.RawUrl;
      this.Form.DefaultButton = this.btnSearch.UniqueID;
      ((HtmlControl) this.Master.FindControl("aQuoteHistory")).Attributes.Add("class", "buttion SetNavMenu active");
      ((HtmlControl) this.Master.FindControl("aOrderHistory")).Attributes.Add("class", "buttion SetNavMenu");
      ((HtmlControl) this.Master.FindControl("aUpdateProfile")).Attributes.Add("class", "buttion SetNavMenu");
      ((HtmlControl) this.Master.FindControl("aChangePassword")).Attributes.Add("class", "buttion SetNavMenu");
      UtilityFunctions.SetDefaultCommonHeader(this.Page, "", PageName.strMenuQuoteHistory);
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
      {
        this.LoginFrontMasterId = Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID"));
        this.BindQuoteList();
      }
      else
        this.Response.Redirect("/default.aspx?ReturnURL=" + this.Request.RawUrl);
      if (this.Session["TransactionSucessFront"] != null)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(this.Session["TransactionSucessFront"].ToString()), (Enums.NotificationType) 1), true);
      if (this.Session["TransactionFailFront"] != null)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(this.Session["TransactionFailFront"].ToString()), (Enums.NotificationType) 3), true);
      if (this.Session["returnUrl"] != null)
      {
        this.Response.Redirect(this.Session["returnUrl"].ToString());
        this.Session["returnUrl"] = (object) null;
      }
      if (this.Session["QuoteDetailID"] != null)
        this.Session["QuoteDetailID"] = (object) null;
      this.txtSearch.Focus();
    }

    private void BindQuoteList()
    {
      this.objPurchase.SortField = this.hdnSortName.Value;
      this.objPurchase.SortExpr = this.hdnSortExpr.Value;
      DateTime? selectedDate;
      if (!string.IsNullOrEmpty(this.radFromDate.SelectedDate.ToString()))
      {
        QuoteDetailBE objPurchase = this.objPurchase;
        selectedDate = this.radFromDate.SelectedDate;
        DateTime? nullable = new DateTime?(Convert.ToDateTime(selectedDate.ToString()));
        objPurchase.FromDate = nullable;
      }
      selectedDate = this.radToDate.SelectedDate;
      if (!string.IsNullOrEmpty(selectedDate.ToString()))
      {
        QuoteDetailBE objPurchase = this.objPurchase;
        selectedDate = this.radToDate.SelectedDate;
        DateTime? nullable = new DateTime?(Convert.ToDateTime(selectedDate.ToString()));
        objPurchase.ToDate = nullable;
      }
      this.objPurchase.PageSize = this.CustomPaging.PageSize;
      this.objPurchase.PageIndex = this.CustomPaging.PageId;
      this.objPurchase.SearchKeyword = !string.IsNullOrEmpty(this.txtSearch.Text.Trim()) && !(this.txtSearch.Text == "Keyword") ? (!(this.hdnSearch.Value == "1") ? "" : this.txtSearch.Text.Trim()) : "";
      this.objPurchase.LoginFrontMasterID = this.LoginFrontMasterId;
      this.GetQuoteDetail(this.objPurchase);
    }

    protected void GetQuoteDetail(QuoteDetailBE objQuote)
    {
      List<QuoteDetailBE> commecialPartner = QuoteDetailMgmt.GetQuoteDetailForLoginCommecialPartner(objQuote, ref this.TotalRecords);
      if (commecialPartner.Count == 0 && this.objPurchase.PageIndex > 0)
      {
        --this.CustomPaging.PageId;
        this.BindQuoteList();
      }
      else
      {
        if (commecialPartner.Count > 0)
        {
          this.CustomPaging.TotalRecords = this.TotalRecords;
          this.CustomPaging.Visible = true;
          this.CustomPaging.ReloadPaging();
          this.Divlegend.Visible = true;
          this.DivNoRecord.Visible = false;
          this.lblMsgNoRecord.Text = string.Empty;
        }
        else
        {
          this.CustomPaging.Visible = false;
          this.Divlegend.Visible = false;
          this.DivNoRecord.Visible = true;
          this.lblMsgNoRecord.Text = string.Format(Messages.NoRecordFound, (object) "Quote History");
          this.DivNoRecord.Style.Add("color", UtilityFunctions.SetMessageColor(0));
        }
        this.rptCommercialPartnerOrderHistory.DataSource = (object) commecialPartner;
        this.rptCommercialPartnerOrderHistory.DataBind();
      }
    }

    protected void btnPurchaseOrder_Click(object sender, EventArgs e) => this.Response.Redirect("/shop");

    protected void btnViewAll_Click(object sender, EventArgs e) => this.Response.Redirect("/quote-history");

    protected void btnSearch_Click(object sender, EventArgs e)
    {
      this.hdnSearch.Value = "1";
      this.CustomPaging.PageId = 0;
      this.BindQuoteList();
      this.spnMsg.Visible = true;
      this.lblMsg.Text = string.Empty;
    }

    protected void CustomPaging_CustomPageSelectedIndexChanged(object sender, EventArgs e)
    {
      this.BindQuoteList();
      this.spnMsg.Visible = false;
      this.lblMsg.Text = string.Empty;
    }

    protected void btnGotoPage_Click(object sender, EventArgs e)
    {
      this.BindQuoteList();
      this.spnMsg.Visible = false;
      this.lblMsg.Text = string.Empty;
    }

    protected void rptCommercialPartnerOrderHistory_ItemDataBound(
      object sender,
      RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
      {
        Label control1 = (Label) e.Item.FindControl("lblQuoteStatus");
        LinkButton control2 = (LinkButton) e.Item.FindControl("lnkPurchaseOrderforQuote");
        if (control1.Text == "Success")
        {
          control1.Text = "Completed";
          control2.Enabled = false;
          control1.Style.Add("color", "green");
        }
        else
          control1.Style.Add("color", "red");
      }
      if (e.Item.ItemType == ListItemType.Header)
      {
        string str = !(this.hdnSortName.Value.ToLower() == "submitteddate") ? (!(this.hdnSortExpr.Value.ToLower() == "asc") ? "ztoaimg" : "atozimg") : (!(this.hdnSortExpr.Value.ToLower() == "asc") ? "ztoaarrow" : "atozarrow");
        switch (this.hdnSortName.Value.ToLower())
        {
          case "quotefor":
            ((HtmlControl) e.Item.FindControl("spnQuoteFor"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkQuoteFor")).Style.Add("text-decoration", "underline");
            break;
          case "businessname":
            ((HtmlControl) e.Item.FindControl("spnBusinessName"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkBusinessName")).Style.Add("text-decoration", "underline");
            break;
          case "quotestatus":
            ((HtmlControl) e.Item.FindControl("spnQuoteStatus"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkQuoteStatus")).Style.Add("text-decoration", "underline");
            break;
          case "paymenttypename":
            ((HtmlControl) e.Item.FindControl("spnPickUpDetail"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkPickUpDetail")).Style.Add("text-decoration", "underline");
            break;
          case "submitteddate":
            ((HtmlControl) e.Item.FindControl("spnQuoteDate"))?.Attributes.Add("class", str);
            ((WebControl) e.Item.FindControl("lnkQuoteDate")).Style.Add("text-decoration", "underline");
            break;
        }
      }
      if (this.TotalRecords == 0)
        this.Divlegend.Visible = false;
      else
        this.Divlegend.Visible = true;
    }

    protected void rptCommercialPartnerOrderHistory_ItemCommand(
      object source,
      RepeaterCommandEventArgs e)
    {
      if (!(e.CommandName == "SortColumn"))
        return;
      if (this.hdnSortName.Value == e.CommandArgument.ToString())
      {
        this.hdnSortExpr.Value = !(this.hdnSortExpr.Value == "ASC") ? "ASC" : "DESC";
      }
      else
      {
        this.hdnSortName.Value = e.CommandArgument.ToString();
        this.hdnSortExpr.Value = "ASC";
      }
      this.BindQuoteList();
    }

    protected void lnkPurchaseOrderforQuote_Click(object sender, EventArgs e)
    {
      this.Session["QuoteDetailID"] = (object) ((LinkButton) sender).CommandArgument;
      this.Response.Redirect("/retail-purchase-detail");
    }
  }
}
