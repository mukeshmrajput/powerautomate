﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.SetPassword
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Miscellaneous;
using BLL.UserManagement;
using Entity.Common.Miscellaneous;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class SetPassword : Page
  {
    public string strValidationUserGrp = "PasswordValGrp";
    public string HeaderImagePath = ConfigurationManager.AppSettings["ImagePath"];
    public string CommonInternalBannerName = ConfigurationManager.AppSettings[nameof (CommonInternalBannerName)];
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected FieldInformation FieldInformation1;
    protected TextBox txtPassword;
    protected RequiredFieldValidator rfvPassword;
    protected RegularExpressionValidator regPassword;
    protected TextBox txtConfirmPassword;
    protected RequiredFieldValidator rfvConfirmPassword;
    protected RegularExpressionValidator regConfirmPassword;
    protected CompareValidator cvconfirmpassword;
    protected HiddenField hdnUserID;
    protected Button btnSubmit;
    protected Button btnCancel;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      Literal control1 = (Literal) this.Master.FindControl("ltrPageName");
      Literal control2 = (Literal) this.Master.FindControl("ltrMainPageName");
      ((Image) this.Master.FindControl("imgHeader")).ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.HeaderImagePath + this.CommonInternalBannerName;
      control1.Text = "Set Password";
      control2.Text = "Set Password";
      this.ValidationExpression();
      if (!string.IsNullOrEmpty(this.Request.QueryString["UserID"]))
        this.hdnUserID.Value = Convert.ToString(Encryption.DecryptQueryString(this.Request.QueryString["UserID"]));
      if (this.IsPostBack || !UserMgmt.CheckExistPassword(Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["UserID"]))))
        return;
      this.Session["AlreadySetPassword"] = (object) "AlreadySet";
      this.Response.Redirect("/default.aspx");
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorForFront(this.rfvPassword, true, (object) this.txtPassword, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regPassword, Regex.Password, true, (object) this.txtPassword, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvConfirmPassword, true, (object) this.txtConfirmPassword, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regConfirmPassword, Regex.Password, true, (object) this.txtConfirmPassword, this.strValidationUserGrp);
      Validations.SetCompareFieldValidatorForResetChangePasswordFront(this.cvconfirmpassword, true, (object) this.txtConfirmPassword, (object) this.txtPassword, this.strValidationUserGrp);
      this.btnSubmit.ValidationGroup = this.strValidationUserGrp;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.IsValid)
        return;
      if (string.Compare(this.txtPassword.Text.Trim(), this.txtConfirmPassword.Text.Trim(), StringComparison.OrdinalIgnoreCase) == 0)
      {
        ChangePasswordMgmt.UpdateCommercialPartnerPassword(new ChangePassword()
        {
          UserLoginId = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["UserID"])),
          NewsPassword = Encryption.EncryptQueryString(this.txtPassword.Text.Trim()),
          UserTypeID = Convert.ToInt64((object) (Enums.PersonType) 4),
          ModifiedBy = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["UserID"])),
          ModifiedByIP = HttpContext.Current.Request.UserHostAddress
        });
        this.Response.Redirect("/default.aspx");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.NewPassAndConfirmPassNotMatch), (Enums.NotificationType) 3), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("/default.aspx");
  }
}
