﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.ViewOrderProcessingPurchaseDetails
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Common;
using BLL.PaymentOptions.PaymentType;
using BLL.PurchaseOrderDetail;
using Entity.Common.PurchaseOrderDetail;
using Entity.Common.Response;
using Helper;
using PayPalAPIHelper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class ViewOrderProcessingPurchaseDetails : Page
  {
    private long RetailPurchaseOrderID;
    public string strValidationUserGrp = "ValGrpCommercial";
    public string CardImagePath = ConfigurationManager.AppSettings[nameof (CardImagePath)];
    public string CompletedOrderedPickUpInvoicePath = ConfigurationManager.AppSettings[nameof (CompletedOrderedPickUpInvoicePath)];
    public string CompletedOrderedDeliveryInvoicePath = ConfigurationManager.AppSettings[nameof (CompletedOrderedDeliveryInvoicePath)];
    protected HtmlForm form1;
    protected HtmlGenericControl h1Title;
    protected DropDownList ddlPaypalType;
    protected Literal ltrOrderNo;
    protected Literal ltrName;
    protected Literal ltrEmail;
    protected Literal ltrPaymentTypeName;
    protected Literal ltrSubTotal;
    protected Literal ltrPaidDate;
    protected HtmlGenericControl divExpectedDeliveryDate;
    protected Literal ltrDeliveryDate;
    protected HtmlGenericControl divPickUpDate;
    protected Literal ltrPickUpDate;
    protected HtmlGenericControl divDeliveryInstructions;
    protected Literal ltrDeliveryInstructions;
    protected Literal ltrSubmittedDate;
    protected Literal ltrUserTypeName;
    protected Literal ltrHearAboutUs;
    protected Literal ltrDeliveryRegionName;
    protected Literal ltrIsOrderUnderCompany;
    protected Literal ltrNote;
    protected HtmlGenericControl DivPaymentMethod;
    protected RadioButtonList rdbPaymentMethod;
    protected HtmlGenericControl divCreditcarddetail;
    protected HtmlGenericControl divCreditcarddetails;
    protected RadioButtonList rdlCardType;
    protected TextBox txtCardOwnerName;
    protected RequiredFieldValidator rfvCardOwnerName;
    protected RegularExpressionValidator regCardOwnerName;
    protected TextBox txtCardNo;
    protected RequiredFieldValidator rfvCardNo;
    protected CustomValidator ccNumCustVal;
    protected TextBox txtCVV;
    protected RequiredFieldValidator rfvCVV;
    protected DropDownList ddlExpireMonth;
    protected RequiredFieldValidator rfvExpireMonth;
    protected DropDownList ddlExpireYear;
    protected RequiredFieldValidator rfvExpireYear;
    protected Label txtAmoutInAud;
    protected HtmlGenericControl divBilling;
    protected Literal ltrBillingAddressLine1;
    protected Literal ltrBillingAddressLine2;
    protected Literal ltrBillingSuburb;
    protected Literal ltrBillingPostCode;
    protected Literal ltrBillingBusinessName;
    protected HtmlGenericControl divShipping;
    protected Literal ltrShippingAddressLine1;
    protected Literal ltrShippingAddressLine2;
    protected Literal ltrShippingSuburb;
    protected Literal ltrShippingPostCode;
    protected Literal ltrShippingBusinessName;
    protected HtmlGenericControl divAddress;
    protected Literal ltrBusinessName;
    protected Literal ltrABN;
    protected Literal ltrAddressLine1;
    protected Literal ltrAddressLine2;
    protected Literal ltrSuburb;
    protected Literal ltrStateName;
    protected Literal ltrPostCode;
    protected HtmlGenericControl DivCreditCard;
    protected Literal ltrCardHolderName;
    protected Literal ltrCreditCardNo;
    protected Literal ltrExpiryDate;
    protected HtmlGenericControl Divrpt;
    protected Repeater rptProductDetail;
    protected HtmlGenericControl DivbtnPaymentUpdate;
    protected Button btnContinue;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Request.QueryString[QueryStrings.RetailPurchaseOrderID] != null)
        this.RetailPurchaseOrderID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.RetailPurchaseOrderID].ToString()));
      if (this.IsPostBack || this.RetailPurchaseOrderID <= 0L)
        return;
      this.FillAllData(PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(this.RetailPurchaseOrderID));
    }

    protected void FillAllData(PurchaseOrderDetailBE obj)
    {
      if (obj == null)
        return;
      this.ltrDeliveryInstructions.Text = !string.IsNullOrEmpty(obj.DeliveryInstructions) ? obj.DeliveryInstructions : "N/A";
      this.ltrBillingBusinessName.Text = !string.IsNullOrEmpty(obj.BillingBusinessName) ? obj.BillingBusinessName : "N/A";
      this.ltrShippingBusinessName.Text = !string.IsNullOrEmpty(obj.objBillingResponse.ShippingBusinessName) ? obj.objBillingResponse.ShippingBusinessName : "N/A";
      this.ltrDeliveryRegionName.Text = !string.IsNullOrEmpty(obj.DeliveryRegionName) ? obj.DeliveryRegionName : "N/A";
      this.ltrNote.Text = !string.IsNullOrEmpty(obj.Note) ? obj.Note : "N/A";
      this.ltrName.Text = obj.Name;
      this.ltrOrderNo.Text = obj.OrderNostr;
      this.ltrEmail.Text = obj.EmailAddress;
      DateTime dateTime;
      if (obj.PaymentStatus == 1)
      {
        Literal ltrPaidDate = this.ltrPaidDate;
        string str;
        if (!(obj.PaidDate != DateTime.MinValue))
        {
          str = "N/A";
        }
        else
        {
          dateTime = Convert.ToDateTime(obj.PaidDate);
          str = dateTime.ToString("dd/MM/yyyy");
        }
        ltrPaidDate.Text = str;
      }
      else
        this.ltrPaidDate.Text = "N/A";
      this.ltrSubTotal.Text = obj.GrandTotal.ToString();
      Literal ltrDeliveryDate = this.ltrDeliveryDate;
      DateTime? nullable = obj.DeliveryDate;
      dateTime = DateTime.MinValue;
      string str1;
      if ((nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != dateTime ? 1 : 0) : 0) : 1) == 0)
      {
        str1 = "N/A";
      }
      else
      {
        dateTime = Convert.ToDateTime((object) obj.DeliveryDate);
        str1 = dateTime.ToString("dd/MM/yyyy");
      }
      ltrDeliveryDate.Text = str1;
      Literal ltrPickUpDate = this.ltrPickUpDate;
      nullable = obj.PickupDate;
      dateTime = DateTime.MinValue;
      string str2;
      if ((nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != dateTime ? 1 : 0) : 0) : 1) == 0)
      {
        str2 = "N/A";
      }
      else
      {
        dateTime = Convert.ToDateTime((object) obj.PickupDate);
        str2 = dateTime.ToString("dd/MM/yyyy");
      }
      ltrPickUpDate.Text = str2;
      Literal ltrSubmittedDate = this.ltrSubmittedDate;
      dateTime = obj.SubmittedDate;
      string str3 = dateTime.ToString("dd/MM/yyyy");
      ltrSubmittedDate.Text = str3;
      this.ltrUserTypeName.Text = obj.UserTypeName;
      if (obj.objUserCreditCardMaster.CreditCardNo != "")
        this.ltrCreditCardNo.Text = "XXXX-XXXX-XXXX-" + obj.objUserCreditCardMaster.CreditCardNo.ToString().Substring(obj.objUserCreditCardMaster.CreditCardNo.ToString().Length - 4, 4);
      Literal ltrExpiryDate = this.ltrExpiryDate;
      int num = obj.objUserCreditCardMaster.ExpiryMonth;
      string str4 = num.ToString();
      num = obj.objUserCreditCardMaster.ExpiryYear;
      string str5 = num.ToString();
      string str6 = str4 + "/" + str5;
      ltrExpiryDate.Text = str6;
      this.ltrBillingAddressLine1.Text = obj.objBillingResponse.BillingAddressLine1;
      this.ltrBillingAddressLine2.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingAddressLine2) ? obj.objBillingResponse.BillingAddressLine2 : "N/A";
      this.ltrBillingSuburb.Text = obj.objBillingResponse.BillingSuburb;
      Literal ltrBillingPostCode = this.ltrBillingPostCode;
      num = obj.objBillingResponse.BillingPostcode;
      string str7 = num.ToString();
      ltrBillingPostCode.Text = str7;
      this.ltrHearAboutUs.Text = obj.HearAboutUsName;
      this.ltrPaymentTypeName.Text = obj.PaymentTypeName;
      this.ltrCardHolderName.Text = obj.objUserCreditCardMaster.CardHolderName;
      if (obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 4) || obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 3) && obj.PaymentStatus == 0)
      {
        this.DivPaymentMethod.Visible = true;
        this.ddlPaypalType.DataSource = (object) Enum.GetValues(typeof (PayPalEnvironment)).Cast<PayPalEnvironment>().ToList<PayPalEnvironment>();
        this.ddlPaypalType.DataBind();
        this.txtAmoutInAud.Text = obj.GrandTotal.ToString();
        List<PaymentTypeResponse> paymentOptions = PaymentTypeMgmt.GetPaymentOptions();
        List<PaymentTypeResponse> list;
        if (obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 4))
        {
          IEnumerable<string> strTypes = ((IEnumerable<string>) (Convert.ToString((object) (Enums.PaymentTypes) 2) + "," + Convert.ToString((object) (Enums.PaymentTypes) 4)).Split(',')).Select<string, string>((System.Func<string, string>) (str => Convert.ToString(str)));
          list = paymentOptions.Where<PaymentTypeResponse>((System.Func<PaymentTypeResponse, bool>) (m => !strTypes.Contains<string>(m.PaymentTypeName.Replace(" ", "")))).ToList<PaymentTypeResponse>();
        }
        else if (obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 3))
        {
          IEnumerable<string> strTypes = ((IEnumerable<string>) (Convert.ToString((object) (Enums.PaymentTypes) 2) + "," + Convert.ToString((object) (Enums.PaymentTypes) 4) + "," + Convert.ToString((object) (Enums.PaymentTypes) 3)).Split(',')).Select<string, string>((System.Func<string, string>) (str => Convert.ToString(str)));
          list = paymentOptions.Where<PaymentTypeResponse>((System.Func<PaymentTypeResponse, bool>) (m => !strTypes.Contains<string>(m.PaymentTypeName.Replace(" ", "")))).ToList<PaymentTypeResponse>();
        }
        else
        {
          IEnumerable<string> strTypes = ((IEnumerable<string>) (Convert.ToString((object) (Enums.PaymentTypes) 2) + "," + Convert.ToString((object) (Enums.PaymentTypes) 4)).Split(',')).Select<string, string>((System.Func<string, string>) (str => Convert.ToString(str)));
          list = paymentOptions.Where<PaymentTypeResponse>((System.Func<PaymentTypeResponse, bool>) (m => !strTypes.Contains<string>(m.PaymentTypeName.Replace(" ", "")))).ToList<PaymentTypeResponse>();
        }
        this.rdbPaymentMethod.DataSource = (object) list;
        this.rdbPaymentMethod.DataTextField = "PaymentTypeName";
        this.rdbPaymentMethod.DataValueField = "PaymentTypeID";
        this.rdbPaymentMethod.DataBind();
        this.rdbPaymentMethod.SelectedValue = this.rdbPaymentMethod.Items[0].Value;
        this.BindYear();
        this.BindDropDown();
        this.ValidationExpression();
        this.DivbtnPaymentUpdate.Visible = true;
        if (this.rdbPaymentMethod.SelectedItem.Text.Replace(" ", "") == ((Enums.PaymentTypes) 1).ToString())
          this.divCreditcarddetail.Visible = true;
        else
          this.divCreditcarddetail.Visible = false;
      }
      else if ((obj.PaymentTypeName.Replace(" ", "") != Convert.ToString((object) (Enums.PaymentTypes) 4) || obj.PaymentTypeName.Replace(" ", "") != Convert.ToString((object) (Enums.PaymentTypes) 3)) && obj.PaymentStatus == 0)
      {
        this.DivPaymentMethod.Visible = true;
        this.ddlPaypalType.DataSource = (object) Enum.GetValues(typeof (PayPalEnvironment)).Cast<PayPalEnvironment>().ToList<PayPalEnvironment>();
        this.ddlPaypalType.DataBind();
        this.txtAmoutInAud.Text = obj.GrandTotal.ToString();
        List<PaymentTypeResponse> paymentOptions = PaymentTypeMgmt.GetPaymentOptions();
        IEnumerable<string> strTypes = ((IEnumerable<string>) (Convert.ToString((object) (Enums.PaymentTypes) 2) + "," + Convert.ToString((object) (Enums.PaymentTypes) 4)).Split(',')).Select<string, string>((System.Func<string, string>) (str => Convert.ToString(str)));
        this.rdbPaymentMethod.DataSource = (object) paymentOptions.Where<PaymentTypeResponse>((System.Func<PaymentTypeResponse, bool>) (m => !strTypes.Contains<string>(m.PaymentTypeName.Replace(" ", "")))).ToList<PaymentTypeResponse>();
        this.rdbPaymentMethod.DataTextField = "PaymentTypeName";
        this.rdbPaymentMethod.DataValueField = "PaymentTypeID";
        this.rdbPaymentMethod.DataBind();
        this.rdbPaymentMethod.SelectedValue = this.rdbPaymentMethod.Items[0].Value;
        this.BindYear();
        this.BindDropDown();
        this.ValidationExpression();
        this.DivbtnPaymentUpdate.Visible = true;
        if (this.rdbPaymentMethod.SelectedItem.Text.Replace(" ", "") == ((Enums.PaymentTypes) 1).ToString())
          this.divCreditcarddetail.Visible = true;
        else
          this.divCreditcarddetail.Visible = false;
      }
      else
        this.DivPaymentMethod.Visible = false;
      this.ltrShippingAddressLine1.Text = !string.IsNullOrEmpty(obj.objBillingResponse.ShippingAddressLine1) ? obj.objBillingResponse.ShippingAddressLine1 : "N/A";
      this.ltrShippingAddressLine2.Text = !string.IsNullOrEmpty(obj.objBillingResponse.ShippingAddressLine2) ? obj.objBillingResponse.ShippingAddressLine2 : "N/A";
      this.ltrShippingSuburb.Text = !string.IsNullOrEmpty(obj.objBillingResponse.ShippingSuburb) ? obj.objBillingResponse.ShippingSuburb : "N/A";
      Literal shippingPostCode = this.ltrShippingPostCode;
      num = obj.objBillingResponse.ShippingPostcode;
      string str8;
      if (string.IsNullOrEmpty(num.ToString()))
      {
        str8 = "N/A";
      }
      else
      {
        num = obj.objBillingResponse.ShippingPostcode;
        str8 = num.ToString();
      }
      shippingPostCode.Text = str8;
      this.ltrStateName.Text = obj.StateName;
      this.ltrIsOrderUnderCompany.Text = obj.IsOrderUnderCompany == 1 ? "Yes" : "No";
      if (obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 1))
        this.DivCreditCard.Visible = true;
      else
        this.DivCreditCard.Visible = false;
      if (obj.PickUpDetailID == 1L)
      {
        this.divBilling.Visible = false;
        this.divShipping.Visible = false;
        this.divExpectedDeliveryDate.Visible = false;
        this.divDeliveryInstructions.Visible = false;
        this.ltrAddressLine1.Text = obj.objBillingResponse.BillingAddressLine1;
        this.ltrAddressLine2.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingAddressLine2) ? obj.objBillingResponse.BillingAddressLine2 : "N/A";
        this.ltrSuburb.Text = obj.objBillingResponse.BillingSuburb;
        Literal ltrPostCode = this.ltrPostCode;
        num = obj.objBillingResponse.BillingPostcode;
        string str9 = num.ToString();
        ltrPostCode.Text = str9;
        this.ltrABN.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingCompanyABN) ? obj.objBillingResponse.BillingCompanyABN : "N/A";
        this.ltrStateName.Text = obj.objBillingResponse.BillingStateName;
        this.ltrBusinessName.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingBusinessName) ? obj.objBillingResponse.BillingBusinessName : "N/A";
      }
      else if (obj.PickUpDetailID == 2L)
      {
        this.divPickUpDate.Visible = false;
        this.divAddress.Visible = false;
      }
      List<PurchaseOrderProductDetailBE> orderProductDetailBeList = new List<PurchaseOrderProductDetailBE>();
      this.rptProductDetail.DataSource = (object) PurchaseOrderDetailMgmt.PurchaseOrderDetailByPurchaseOrderID(obj.PurchaseOrderId);
      this.rptProductDetail.DataBind();
    }

    protected void rdbPaymentMethod_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.DivbtnPaymentUpdate.Visible = true;
      if (this.rdbPaymentMethod.SelectedItem.Text.Replace(" ", "") == ((Enums.PaymentTypes) 1).ToString())
        this.divCreditcarddetail.Visible = true;
      else
        this.divCreditcarddetail.Visible = false;
    }

    protected void BindDropDown()
    {
      int num = 0;
      this.BindYear();
      foreach (CardNameResponse cardNameResponse in DropDownMgmt.GetCardDetail())
      {
        this.rdlCardType.Items.Add(new ListItem("<img src='" + ConfigurationManager.AppSettings["LivePath"] + this.CardImagePath + cardNameResponse.CardImage + "' alt='" + cardNameResponse.CardName + "' title='" + cardNameResponse.CardName + "'/>", num.ToString()));
        this.rdlCardType.CellPadding = 5;
        this.rdlCardType.CellSpacing = 5;
        ++num;
      }
      this.rdlCardType.SelectedValue = this.rdlCardType.Items[0].Value;
    }

    protected void BindYear()
    {
      int year = DateTime.UtcNow.Year;
      this.ddlExpireYear.Items.Add(new ListItem("Year", "-1"));
      for (int index = year; index <= 2050; ++index)
        this.ddlExpireYear.Items.Add(new ListItem(index.ToString(), index.ToString()));
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvCardOwnerName, true, (object) this.txtCardOwnerName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regCardOwnerName, Regex.Title, true, (object) this.txtCardOwnerName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvCardNo, true, (object) this.txtCardNo, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvCVV, true, (object) this.txtCVV, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvExpireMonth, true, (object) this.ddlExpireMonth, "-1", this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvExpireYear, true, (object) this.ddlExpireYear, "-1", this.strValidationUserGrp);
      this.btnContinue.ValidationGroup = this.strValidationUserGrp;
    }

    protected void btnContinue_Click(object sender, EventArgs e)
    {
      if (this.rdbPaymentMethod.SelectedItem.Text.Replace(" ", "") == ((Enums.PaymentTypes) 1).ToString())
      {
        PurchaseOrderDetailBE retailPurchaseOrderId1 = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(this.RetailPurchaseOrderID);
        PaymentPurchaseOrderDetailBE purchaseOrderDetailBe1 = new PaymentPurchaseOrderDetailBE();
        PurchaseOrderDetailBE purchaseOrderDetailBe2 = new PurchaseOrderDetailBE();
        purchaseOrderDetailBe1.PurchaseOrderId = retailPurchaseOrderId1.PurchaseOrderId;
        purchaseOrderDetailBe1.TransactionId = retailPurchaseOrderId1.TransactionId;
        PurchaseOrderDetailBE purchaseOrderDetailBe3 = new PurchaseOrderDetailBE();
        purchaseOrderDetailBe3.objUserCreditCardMaster.CreditCardType = this.rdlCardType.SelectedValue;
        purchaseOrderDetailBe3.objUserCreditCardMaster.CreditCardNo = this.txtCardNo.Text;
        purchaseOrderDetailBe3.objUserCreditCardMaster.ExpiryMonth = Convert.ToInt32(this.ddlExpireMonth.SelectedValue);
        purchaseOrderDetailBe3.objUserCreditCardMaster.ExpiryYear = Convert.ToInt32(this.ddlExpireYear.SelectedValue);
        purchaseOrderDetailBe3.objUserCreditCardMaster.CardHolderName = this.txtCardOwnerName.Text;
        purchaseOrderDetailBe3.objUserCreditCardMaster.CVVCode = Convert.ToInt32(this.txtCVV.Text);
        PaymentGatewayResponse paymentGatewayResponse = new PaymentGatewayResponse();
        PaymentGatewayResponse responseFromXmlPostData = UtilityFunctions.GetPaymentResponseFromXMLPostData(Convert.ToString(retailPurchaseOrderId1.GrandTotal.ToString().Replace(".", "").Replace(",", "")), this.txtCardNo.Text, this.ddlExpireMonth.SelectedValue + "/" + this.ddlExpireYear.SelectedValue.ToString().Substring(2, 2), this.txtCVV.Text, this.rdlCardType.SelectedValue, this.rdlCardType.SelectedItem.Text, this.txtCardOwnerName.Text, retailPurchaseOrderId1.OrderNostr);
        if (responseFromXmlPostData != null)
        {
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.MessageID = responseFromXmlPostData.messageID;
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.MessageTimestamp = responseFromXmlPostData.messageTimestamp;
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.RequestType = "Payment";
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.statusCode = Convert.ToInt32(responseFromXmlPostData.statusCode);
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.StatusDescription = responseFromXmlPostData.statusDescription;
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.ResponseCode = Convert.ToInt32(responseFromXmlPostData.responseCode);
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.ResponseText = responseFromXmlPostData.responseText;
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.TxnID = responseFromXmlPostData.txnID;
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.TxnType = Convert.ToInt64(responseFromXmlPostData.txnType);
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.TxnSource = Convert.ToInt64(responseFromXmlPostData.txnSource);
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.Amount = purchaseOrderDetailBe3.objPaymentPurchaseOrder.GrandPrice;
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.Approved = responseFromXmlPostData.approved;
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.CardDescription = responseFromXmlPostData.cardDescription;
          purchaseOrderDetailBe3.objPaymentCreditCardResponse.SettlementDate = responseFromXmlPostData.settlementDate;
          try
          {
            UtilityFunctions.writetext("======================== Popup Credit Card Response start ====================================" + DateTime.Now.ToString());
            UtilityFunctions.writetext("OrderNo :" + Convert.ToString(purchaseOrderDetailBe3.OrderNo));
            UtilityFunctions.writetext("OrderNostr :" + Convert.ToString(purchaseOrderDetailBe3.OrderNostr));
            UtilityFunctions.writetext("MessageID :" + Convert.ToString(responseFromXmlPostData.messageID));
            UtilityFunctions.writetext("MessageTimestamp :" + Convert.ToString(responseFromXmlPostData.messageTimestamp));
            UtilityFunctions.writetext("StatusCode :" + Convert.ToString(responseFromXmlPostData.statusCode));
            UtilityFunctions.writetext("statusDescription :" + Convert.ToString(responseFromXmlPostData.statusDescription));
            UtilityFunctions.writetext("ResponseCode :" + Convert.ToString(responseFromXmlPostData.responseCode));
            UtilityFunctions.writetext("ResponseText : " + Convert.ToString(responseFromXmlPostData.responseText));
            UtilityFunctions.writetext("TxnID :" + Convert.ToString(responseFromXmlPostData.txnID));
            UtilityFunctions.writetext("TxnType :" + Convert.ToString(responseFromXmlPostData.txnType));
            UtilityFunctions.writetext("TxnSource :" + Convert.ToString(responseFromXmlPostData.txnSource));
            UtilityFunctions.writetext("GrandPrice :" + Convert.ToString(purchaseOrderDetailBe3.objPaymentPurchaseOrder.GrandPrice));
            UtilityFunctions.writetext("Approved :" + Convert.ToString(responseFromXmlPostData.approved));
            UtilityFunctions.writetext("CardDescription :" + Convert.ToString(responseFromXmlPostData.cardDescription));
            UtilityFunctions.writetext("SettlementDate : " + Convert.ToString(responseFromXmlPostData.settlementDate));
            UtilityFunctions.writetext("======================== Credit Card Response end ====================================" + DateTime.Now.ToString());
          }
          catch (Exception ex)
          {
          }
          if (responseFromXmlPostData.responseCode == "00" || responseFromXmlPostData.responseCode == "08" || responseFromXmlPostData.responseCode == "11" || responseFromXmlPostData.responseCode == "16" || responseFromXmlPostData.responseCode == "77")
          {
            purchaseOrderDetailBe3.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
            DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
            purchaseOrderDetailBe3.PaymentDate = new DateTime?(dateTime);
          }
          else
            purchaseOrderDetailBe3.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 0);
        }
        else
          purchaseOrderDetailBe3.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 0);
        long purchaseOrderId = retailPurchaseOrderId1.PurchaseOrderId;
        if (purchaseOrderId > 0L)
        {
          purchaseOrderDetailBe3.PurchaseOrderId = purchaseOrderId;
          PurchaseOrderDetailMgmt.AddUpdatePurchaseOrderCreditCardDetail(purchaseOrderDetailBe3);
        }
        if (purchaseOrderDetailBe3.PaymentStatus == 1)
        {
          PurchaseOrderDetailBE retailPurchaseOrderId2 = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(Convert.ToInt64(retailPurchaseOrderId1.RetailPurchaseOrderID.ToString()));
          List<PurchaseOrderProductDetailBE> orderProductDetailBeList = new List<PurchaseOrderProductDetailBE>();
          List<PurchaseOrderProductDetailBE> lstProduct = PurchaseOrderDetailMgmt.PurchaseOrderDetailByPurchaseOrderID(retailPurchaseOrderId1.PurchaseOrderId);
          purchaseOrderDetailBe1.PaymentTypeId = (long) Convert.ToInt32(this.rdbPaymentMethod.SelectedValue);
          purchaseOrderDetailBe1.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
          purchaseOrderDetailBe1.RetailPurchaseOrderID = retailPurchaseOrderId2.RetailPurchaseOrderID;
          DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
          purchaseOrderDetailBe2.PaymentDate = new DateTime?(dateTime);
          long num1 = (long) PurchaseOrderDetailMgmt.UpdatePaymentDetail(purchaseOrderDetailBe1);
          retailPurchaseOrderId1.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
          PurchaseOrderDetailMgmt.AddPurchaseOrderTrack(retailPurchaseOrderId1);
          string str = UtilityFunctions.BindProductDetailForInvoice((DataTable) null, lstProduct, (List<PurchaseOrderProductDetailBE>) null);
          long num2 = retailPurchaseOrderId1.PickUpDetailID;
          if (Convert.ToInt32(num2.ToString()) == 1)
          {
            DateTime? nullable = retailPurchaseOrderId1.DeliveryDate;
            if (!nullable.HasValue)
            {
              retailPurchaseOrderId1.DeliveryDate = new DateTime?(DateTime.MinValue);
            }
            else
            {
              nullable = retailPurchaseOrderId1.PickupDate;
              if (!nullable.HasValue)
                retailPurchaseOrderId1.PickupDate = new DateTime?(DateTime.MinValue);
            }
            string PurchaseProductDetail = str;
            num2 = retailPurchaseOrderId1.OrderNo;
            string iOrderNo = num2.ToString();
            nullable = retailPurchaseOrderId1.DeliveryDate;
            DateTime minValue1 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue1 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId1.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId1.PickupDate;
            DateTime minValue2 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue2 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId1.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            string PaymentStatus = purchaseOrderDetailBe3.PaymentStatus.ToString() == "1" ? "Paid" : "Failed";
            num2 = retailPurchaseOrderId1.PickUpDetailID;
            string PickUpdetail = num2.ToString() == "1" ? "PickUp" : "Delivery";
            num2 = retailPurchaseOrderId1.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num2.ToString();
            num2 = retailPurchaseOrderId1.PickUpDetailID;
            string hdnPickUpDetailID = num2.ToString();
            string hdnSubTotal = retailPurchaseOrderId1.SubTotal.ToString();
            string hdnFinalTotal = retailPurchaseOrderId1.GrandTotal.ToString();
            Decimal num3 = retailPurchaseOrderId1.PickUpPrice;
            string hdnPickDeliveryPrice = num3.ToString();
            string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
            string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
            num3 = retailPurchaseOrderId1.GST;
            string hdnGSTVal = num3.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, PaymentStatus, "Credit Card", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
          }
          else
          {
            num2 = retailPurchaseOrderId1.PickUpDetailID;
            if (Convert.ToInt32(num2.ToString()) == 2)
            {
              DateTime? nullable = retailPurchaseOrderId1.DeliveryDate;
              if (!nullable.HasValue)
              {
                retailPurchaseOrderId1.DeliveryDate = new DateTime?(DateTime.MinValue);
              }
              else
              {
                nullable = retailPurchaseOrderId1.PickupDate;
                if (!nullable.HasValue)
                  retailPurchaseOrderId1.PickupDate = new DateTime?(DateTime.MinValue);
              }
              string PurchaseProductDetail = str;
              num2 = retailPurchaseOrderId1.OrderNo;
              string iOrderNo = num2.ToString();
              nullable = retailPurchaseOrderId1.DeliveryDate;
              DateTime minValue3 = DateTime.MinValue;
              string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue3 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId1.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
              nullable = retailPurchaseOrderId1.PickupDate;
              DateTime minValue4 = DateTime.MinValue;
              string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue4 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId1.PickupDate).ToString("dd/MM/yyyy") : "N/A";
              string PaymentStatus = purchaseOrderDetailBe3.PaymentStatus.ToString() == "1" ? "Paid" : "Failed";
              num2 = retailPurchaseOrderId1.PickUpDetailID;
              string PickUpdetail = num2.ToString() == "1" ? "PickUp" : "Delivery";
              num2 = retailPurchaseOrderId1.RetailPurchaseOrderID;
              string hdnRetailPurchaseOrderID = num2.ToString();
              num2 = retailPurchaseOrderId1.PickUpDetailID;
              string hdnPickUpDetailID = num2.ToString();
              string hdnSubTotal = retailPurchaseOrderId1.SubTotal.ToString();
              string hdnFinalTotal = retailPurchaseOrderId1.GrandTotal.ToString();
              Decimal num4 = retailPurchaseOrderId1.DeliveryPrice;
              string hdnPickDeliveryPrice = num4.ToString();
              string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
              string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
              num4 = retailPurchaseOrderId1.GST;
              string hdnGSTVal = num4.ToString();
              UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, PaymentStatus, "Credit Card", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
            }
          }
          this.Session["TransactionSucessFront"] = (object) string.Format(Messages.TransactionSuccess, (object) retailPurchaseOrderId1.OrderNostr);
          System.Web.UI.ScriptManager.RegisterStartupScript((Page) this, typeof (string), "Saved", "parent.fancyboxclose();window.parent.location = '/order-history';", true);
        }
        else
        {
          if (purchaseOrderDetailBe3.PaymentStatus != 0)
            return;
          this.Session["TransactionFailFront"] = (object) string.Format(Messages.TransactionFailed);
          System.Web.UI.ScriptManager.RegisterStartupScript((Page) this, typeof (string), "Saved", "parent.fancyboxclose();window.parent.location = '/order-history';", true);
        }
      }
      else if (this.rdbPaymentMethod.SelectedItem.Text.Replace(" ", "") == ((Enums.PaymentTypes) 3).ToString())
      {
        PurchaseOrderDetailBE retailPurchaseOrderId = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(this.RetailPurchaseOrderID);
        PaymentPurchaseOrderDetailBE purchaseOrderDetailBe4 = new PaymentPurchaseOrderDetailBE();
        PurchaseOrderDetailBE purchaseOrderDetailBe5 = new PurchaseOrderDetailBE();
        try
        {
          UtilityFunctions.writetext("======================== Popup Direct Deposit Response start ====================================" + DateTime.Now.ToString());
          UtilityFunctions.writetext(Convert.ToString(retailPurchaseOrderId.objPaymentPurchaseOrder.OrderNostr));
          UtilityFunctions.writetext(Convert.ToString(retailPurchaseOrderId.objPaymentPurchaseOrder.OrderNo));
        }
        catch (Exception ex)
        {
        }
        purchaseOrderDetailBe5.RetailPurchaseOrderID = this.RetailPurchaseOrderID;
        purchaseOrderDetailBe4.PurchaseOrderId = retailPurchaseOrderId.PurchaseOrderId;
        purchaseOrderDetailBe4.TransactionId = retailPurchaseOrderId.TransactionId;
        purchaseOrderDetailBe4.PaymentTypeId = Convert.ToInt64(this.rdbPaymentMethod.SelectedValue);
        purchaseOrderDetailBe4.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 2);
        purchaseOrderDetailBe4.RetailPurchaseOrderID = this.RetailPurchaseOrderID;
        DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
        purchaseOrderDetailBe5.PaymentDate = new DateTime?(dateTime);
        long num5 = (long) PurchaseOrderDetailMgmt.UpdatePaymentDetail(purchaseOrderDetailBe4);
        retailPurchaseOrderId.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 2);
        retailPurchaseOrderId.PaymentTypeId = Convert.ToInt64(this.rdbPaymentMethod.SelectedValue);
        PurchaseOrderDetailMgmt.AddPurchaseOrderTrack(retailPurchaseOrderId);
        List<PurchaseOrderProductDetailBE> orderProductDetailBeList = new List<PurchaseOrderProductDetailBE>();
        string str = UtilityFunctions.BindProductDetailForInvoice((DataTable) null, PurchaseOrderDetailMgmt.PurchaseOrderDetailByPurchaseOrderID(retailPurchaseOrderId.PurchaseOrderId), (List<PurchaseOrderProductDetailBE>) null);
        if (Convert.ToInt32(retailPurchaseOrderId.PickUpDetailID.ToString()) == 1)
        {
          DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
          if (!nullable.HasValue)
          {
            retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
          }
          else
          {
            nullable = retailPurchaseOrderId.PickupDate;
            if (!nullable.HasValue)
              retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
          }
          string PurchaseProductDetail = str;
          long num6 = retailPurchaseOrderId.OrderNo;
          string iOrderNo = num6.ToString();
          nullable = retailPurchaseOrderId.DeliveryDate;
          DateTime minValue5 = DateTime.MinValue;
          string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue5 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
          nullable = retailPurchaseOrderId.PickupDate;
          DateTime minValue6 = DateTime.MinValue;
          string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue6 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
          num6 = retailPurchaseOrderId.PickUpDetailID;
          string PickUpdetail = num6.ToString() == "1" ? "PickUp" : "Delivery";
          num6 = retailPurchaseOrderId.RetailPurchaseOrderID;
          string hdnRetailPurchaseOrderID = num6.ToString();
          num6 = retailPurchaseOrderId.PickUpDetailID;
          string hdnPickUpDetailID = num6.ToString();
          string hdnSubTotal = retailPurchaseOrderId.SubTotal.ToString();
          string hdnFinalTotal = retailPurchaseOrderId.GrandTotal.ToString();
          Decimal num7 = retailPurchaseOrderId.PickUpPrice;
          string hdnPickDeliveryPrice = num7.ToString();
          string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
          string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
          num7 = retailPurchaseOrderId.GST;
          string hdnGSTVal = num7.ToString();
          UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, "Awaiting Payment", "Direct Deposit", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
        }
        else
        {
          long num8 = retailPurchaseOrderId.PickUpDetailID;
          if (Convert.ToInt32(num8.ToString()) == 2)
          {
            DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
            if (!nullable.HasValue)
            {
              retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
            }
            else
            {
              nullable = retailPurchaseOrderId.PickupDate;
              if (!nullable.HasValue)
                retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
            }
            string PurchaseProductDetail = str;
            num8 = retailPurchaseOrderId.OrderNo;
            string iOrderNo = num8.ToString();
            nullable = retailPurchaseOrderId.DeliveryDate;
            DateTime minValue7 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue7 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId.PickupDate;
            DateTime minValue8 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue8 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            num8 = retailPurchaseOrderId.PickUpDetailID;
            string PickUpdetail = num8.ToString() == "1" ? "PickUp" : "Delivery";
            num8 = retailPurchaseOrderId.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num8.ToString();
            num8 = retailPurchaseOrderId.PickUpDetailID;
            string hdnPickUpDetailID = num8.ToString();
            string hdnSubTotal = retailPurchaseOrderId.SubTotal.ToString();
            string hdnFinalTotal = retailPurchaseOrderId.GrandTotal.ToString();
            Decimal num9 = retailPurchaseOrderId.DeliveryPrice;
            string hdnPickDeliveryPrice = num9.ToString();
            string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
            string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
            num9 = retailPurchaseOrderId.GST;
            string hdnGSTVal = num9.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, "Awaiting Payment", "Direct Deposit", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
          }
        }
        this.Session["TransactionSucessFront"] = (object) string.Format(Messages.TransactionSuccess, (object) retailPurchaseOrderId.OrderNostr);
        System.Web.UI.ScriptManager.RegisterStartupScript((Page) this, typeof (string), "Saved", "parent.fancyboxclose();window.parent.location = '/order-history';", true);
      }
      else
      {
        PurchaseOrderDetailBE retailPurchaseOrderId = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(this.RetailPurchaseOrderID);
        PaymentPurchaseOrderDetailBE purchaseOrderDetailBe6 = new PaymentPurchaseOrderDetailBE();
        PurchaseOrderDetailBE purchaseOrderDetailBe7 = new PurchaseOrderDetailBE();
        try
        {
          UtilityFunctions.writetext("======================== Popup Paypal Response start ====================================" + DateTime.Now.ToString());
          UtilityFunctions.writetext(Convert.ToString(retailPurchaseOrderId.objPaymentPurchaseOrder.OrderNostr));
          UtilityFunctions.writetext(Convert.ToString(retailPurchaseOrderId.objPaymentPurchaseOrder.OrderNo));
        }
        catch (Exception ex)
        {
        }
        bool boolean = Convert.ToBoolean(ConfigurationManager.AppSettings["UseSandbox"]);
        PayPalCurrency currency = (PayPalCurrency) Enum.Parse(typeof (PayPalCurrency), ConfigurationManager.AppSettings["UseCurrencyCode"].ToString());
        Decimal num = retailPurchaseOrderId.SubTotal;
        Decimal itemPrice = Decimal.Parse(num.ToString());
        num = retailPurchaseOrderId.GrandTotal;
        Decimal FinalTotal = Decimal.Parse(num.ToString());
        int Quantity = int.Parse(retailPurchaseOrderId.NoOfProducts.ToString());
        string paypalToken;
        string paypalExpressPayment = PayPalExpressHelper.CreatePaypalExpressPayment(boolean, itemPrice, FinalTotal, currency, "Products", (double) Quantity, ConfigurationManager.AppSettings["PaypalReturnUrl"], ConfigurationManager.AppSettings["PaypalCancelUrl"], out paypalToken);
        this.Session["PayPalToken"] = (object) paypalToken;
        this.Session["IsText"] = (object) boolean;
        this.Session["PurchaseOrderId"] = (object) retailPurchaseOrderId.PurchaseOrderId;
        this.Session["PaypalRetailPurchaseOrderID"] = (object) retailPurchaseOrderId.RetailPurchaseOrderID;
        this.Session["SubTotalforPDF"] = (object) itemPrice;
        this.Session["returnUrl"] = (object) paypalExpressPayment;
        System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, typeof (string), "nofile", "parent.fancyboxclose();window.parent.location = 'order-history'", true);
      }
    }
  }
}
