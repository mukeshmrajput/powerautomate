﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.ViewQuoteDetailPopUpFront
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.NonTurfProductPricing.QuantityZone;
using BLL.ProductPricing.TurfProductPricing.TurfZone;
using BLL.QuoteDetail;
using Entity.Common.ProductPricing.TurfProductPricing.TurfZone;
using Entity.Common.QuoteDetail;
using Entity.Response.ProductPricing.NonTurfProductPricing.QuantityZone;
using Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class ViewQuoteDetailPopUpFront : Page
  {
    private long NewQuoteDetailID;
    protected HtmlForm form1;
    protected HtmlGenericControl h1Title;
    protected Literal ltrQuoteFor;
    protected Literal ltrBusinessName;
    protected Literal ltrEmail;
    protected Literal ltrQuoteStatus;
    protected Literal ltrQuotePrice;
    protected Literal ltrQuoteDate;
    protected Literal ltrPickUpType;
    protected Literal ltrPaymentType;
    protected Literal ltrPaymentStatus;
    protected HtmlGenericControl divAreaCalculation;
    protected Repeater rptRectangularAreaCalculation;
    protected Repeater rptTriangularAreaCalculation;
    protected Repeater rptCircleAreaCalculation;
    protected Repeater rptHalfCircleAreaCalculation;
    protected Label lblTotalAllAreas;
    protected HtmlGenericControl Divrpt;
    protected Repeater rptProductDetail;
    protected HtmlGenericControl DivbtnPaymentUpdate;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Request.QueryString[QueryStrings.QuoteDetailID] != null)
        this.NewQuoteDetailID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.QuoteDetailID].ToString()));
      if (this.IsPostBack || this.NewQuoteDetailID <= 0L)
        return;
      this.FillAllData(QuoteDetailMgmt.GetQuoteDetailByQuoteDetailID(this.NewQuoteDetailID));
    }

    protected void FillAllData(QuoteDetailBE objQuote)
    {
      if (objQuote == null)
        return;
      this.ltrQuoteFor.Text = objQuote.FirstName + " " + objQuote.LastName;
      this.ltrEmail.Text = objQuote.EmailAddress;
      this.ltrQuoteStatus.Text = objQuote.QuoteStatus;
      this.ltrQuotePrice.Text = Convert.ToString(objQuote.TotalQuotePrice);
      this.ltrQuoteDate.Text = objQuote.SubmittedDate.ToString("dd/MM/yyyy");
      this.ltrPickUpType.Text = objQuote.PickUpDetailID == 1L ? "PickUp" : "Delivery";
      this.ltrPaymentStatus.Text = objQuote.PaymentStatusName;
      this.ltrPaymentType.Text = !string.IsNullOrEmpty(objQuote.PaymentTypeName) ? objQuote.PaymentTypeName : "N/A";
      this.ltrBusinessName.Text = !string.IsNullOrEmpty(objQuote.BusinessName) ? objQuote.BusinessName : "N/A";
      List<QuoteDetailBE> detailByQuoteDetailId1 = QuoteDetailMgmt.GetAllQuoteDetailByQuoteDetailID(this.NewQuoteDetailID);
      if (detailByQuoteDetailId1 != null)
      {
        this.rptProductDetail.DataSource = (object) detailByQuoteDetailId1;
        this.rptProductDetail.DataBind();
      }
      List<QuoteTurfAreaWiseDetail> detailByQuoteDetailId2 = QuoteDetailMgmt.GetQuoteTurfAreaWiseDetailByQuoteDetailID(this.NewQuoteDetailID);
      if (detailByQuoteDetailId2 != null)
      {
        List<QuoteTurfAreaWiseDetail> list1 = detailByQuoteDetailId2.Where<QuoteTurfAreaWiseDetail>((Func<QuoteTurfAreaWiseDetail, bool>) (m => m.AreaTypeID == Convert.ToInt64((object) (Enums.AreaTypes) 1))).ToList<QuoteTurfAreaWiseDetail>();
        this.rptRectangularAreaCalculation.DataSource = (object) list1;
        this.rptRectangularAreaCalculation.DataBind();
        bool flag1 = false;
        bool flag2 = false;
        bool flag3 = false;
        bool flag4 = false;
        Decimal num = 0M;
        foreach (RepeaterItem repeaterItem in this.rptRectangularAreaCalculation.Items)
        {
          HiddenField hdnSubAreaName = (HiddenField) repeaterItem.FindControl("hdnSubAreaName");
          HiddenField control1 = (HiddenField) repeaterItem.FindControl("hdnAreaSubTotal");
          Repeater control2 = (Repeater) repeaterItem.FindControl("rptAreaSizeValues");
          ((Label) this.rptRectangularAreaCalculation.Controls[this.rptRectangularAreaCalculation.Controls.Count - 1].FindControl("lblAreaTotal")).Text = control1.Value;
          if (!flag1)
          {
            num += Convert.ToDecimal(control1.Value);
            flag1 = true;
          }
          control2.DataSource = (object) list1.Where<QuoteTurfAreaWiseDetail>((Func<QuoteTurfAreaWiseDetail, bool>) (m => m.SubAreaName == hdnSubAreaName.Value)).ToList<QuoteTurfAreaWiseDetail>();
          control2.DataBind();
        }
        List<QuoteTurfAreaWiseDetail> list2 = detailByQuoteDetailId2.Where<QuoteTurfAreaWiseDetail>((Func<QuoteTurfAreaWiseDetail, bool>) (m => m.AreaTypeID == Convert.ToInt64((object) (Enums.AreaTypes) 2))).ToList<QuoteTurfAreaWiseDetail>();
        this.rptTriangularAreaCalculation.DataSource = (object) list2;
        this.rptTriangularAreaCalculation.DataBind();
        foreach (RepeaterItem repeaterItem in this.rptTriangularAreaCalculation.Items)
        {
          HiddenField hdnSubAreaName = (HiddenField) repeaterItem.FindControl("hdnSubAreaName");
          HiddenField control3 = (HiddenField) repeaterItem.FindControl("hdnAreaSubTotal");
          Repeater control4 = (Repeater) repeaterItem.FindControl("rptAreaSizeValues");
          ((Label) this.rptTriangularAreaCalculation.Controls[this.rptTriangularAreaCalculation.Controls.Count - 1].FindControl("lblAreaTotal")).Text = control3.Value;
          if (!flag2)
          {
            num += Convert.ToDecimal(control3.Value);
            flag2 = true;
          }
          control4.DataSource = (object) list2.Where<QuoteTurfAreaWiseDetail>((Func<QuoteTurfAreaWiseDetail, bool>) (m => m.SubAreaName == hdnSubAreaName.Value)).ToList<QuoteTurfAreaWiseDetail>();
          control4.DataBind();
        }
        List<QuoteTurfAreaWiseDetail> list3 = detailByQuoteDetailId2.Where<QuoteTurfAreaWiseDetail>((Func<QuoteTurfAreaWiseDetail, bool>) (m => m.AreaTypeID == Convert.ToInt64((object) (Enums.AreaTypes) 3))).ToList<QuoteTurfAreaWiseDetail>();
        this.rptCircleAreaCalculation.DataSource = (object) list3;
        this.rptCircleAreaCalculation.DataBind();
        foreach (RepeaterItem repeaterItem in this.rptCircleAreaCalculation.Items)
        {
          HiddenField hdnSubAreaName = (HiddenField) repeaterItem.FindControl("hdnSubAreaName");
          HiddenField control5 = (HiddenField) repeaterItem.FindControl("hdnAreaSubTotal");
          Repeater control6 = (Repeater) repeaterItem.FindControl("rptAreaSizeValues");
          ((Label) this.rptCircleAreaCalculation.Controls[this.rptCircleAreaCalculation.Controls.Count - 1].FindControl("lblAreaTotal")).Text = control5.Value;
          if (!flag3)
          {
            num += Convert.ToDecimal(control5.Value);
            flag3 = true;
          }
          control6.DataSource = (object) list3.Where<QuoteTurfAreaWiseDetail>((Func<QuoteTurfAreaWiseDetail, bool>) (m => m.SubAreaName == hdnSubAreaName.Value)).ToList<QuoteTurfAreaWiseDetail>();
          control6.DataBind();
        }
        List<QuoteTurfAreaWiseDetail> list4 = detailByQuoteDetailId2.Where<QuoteTurfAreaWiseDetail>((Func<QuoteTurfAreaWiseDetail, bool>) (m => m.AreaTypeID == Convert.ToInt64((object) (Enums.AreaTypes) 4))).ToList<QuoteTurfAreaWiseDetail>();
        this.rptHalfCircleAreaCalculation.DataSource = (object) list4;
        this.rptHalfCircleAreaCalculation.DataBind();
        foreach (RepeaterItem repeaterItem in this.rptHalfCircleAreaCalculation.Items)
        {
          HiddenField hdnSubAreaName = (HiddenField) repeaterItem.FindControl("hdnSubAreaName");
          HiddenField control7 = (HiddenField) repeaterItem.FindControl("hdnAreaSubTotal");
          Repeater control8 = (Repeater) repeaterItem.FindControl("rptAreaSizeValues");
          ((Label) this.rptHalfCircleAreaCalculation.Controls[this.rptHalfCircleAreaCalculation.Controls.Count - 1].FindControl("lblAreaTotal")).Text = control7.Value;
          if (!flag4)
          {
            num += Convert.ToDecimal(control7.Value);
            flag4 = true;
          }
          control8.DataSource = (object) list4.Where<QuoteTurfAreaWiseDetail>((Func<QuoteTurfAreaWiseDetail, bool>) (m => m.SubAreaName == hdnSubAreaName.Value)).ToList<QuoteTurfAreaWiseDetail>();
          control8.DataBind();
        }
        this.lblTotalAllAreas.Text = Convert.ToString(num);
      }
    }

    protected void rptProductDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      HiddenField control1 = (HiddenField) e.Item.FindControl("hdnTurfZoneID");
      HiddenField control2 = (HiddenField) e.Item.FindControl("hdnProductType");
      Label control3 = (Label) e.Item.FindControl("ltrTurfZoneName");
      if (control2.Value == "1")
      {
        TurfZoneBE turfZoneDetailById = TurfZoneMgmt.GetTurfZoneDetailByID(Convert.ToInt64(control1.Value));
        if (turfZoneDetailById != null)
          control3.Text = turfZoneDetailById.Name;
      }
      else if (control2.Value == "2")
      {
        QuantityZoneResponseBE quantityZoneDetailById = QuantityZoneMgmt.GetQuantityZoneDetailByID(Convert.ToInt64(control1.Value));
        if (quantityZoneDetailById != null)
          control3.Text = quantityZoneDetailById.Name;
      }
    }
  }
}
