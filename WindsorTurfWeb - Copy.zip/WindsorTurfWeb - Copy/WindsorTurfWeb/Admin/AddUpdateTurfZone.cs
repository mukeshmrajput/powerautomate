﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateTurfZone
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.TurfProductPricing.TurfZone;
using Entity.Common.ProductPricing.TurfProductPricing.TurfZone;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateTurfZone : Page
  {
    public static long fTurfZoneID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtTurfZoneName;
    protected RequiredFieldValidator rfvTurfZoneName;
    protected RegularExpressionValidator regTurfZoneName;
    protected TextBox txtTurfZoneDescription;
    protected RequiredFieldValidator rfvTurfZoneDescription;
    protected RegularExpressionValidator regTurfZoneDescription;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnTurfZoneID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewTurfZone");
      if (this.Request.QueryString["TurfZoneID"] != null)
      {
        AddUpdateTurfZone.fTurfZoneID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["TurfZoneID"].ToString()));
        this.h1Title.InnerText = "Edit Turf Zone";
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
      }
      else
      {
        this.h1Title.InnerText = "Add Turf Zone";
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateTurfZone.fTurfZoneID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        if (AddUpdateTurfZone.fTurfZoneID > 0L)
          this.GetTurfZoneDetails(TurfZoneMgmt.GetTurfZoneDetailByID(Convert.ToInt64(AddUpdateTurfZone.fTurfZoneID)));
      }
      this.txtTurfZoneName.Focus();
    }

    protected void GetTurfZoneDetails(TurfZoneBE objTurfZoneBE)
    {
      this.txtTurfZoneName.Text = objTurfZoneBE.Name;
      this.txtTurfZoneDescription.Text = Convert.ToString(objTurfZoneBE.Description);
      this.chkIsActive.Checked = objTurfZoneBE.IsActive;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      TurfZoneBE turfZoneBe = new TurfZoneBE();
      turfZoneBe.TurfZoneID = AddUpdateTurfZone.fTurfZoneID <= 0L ? 0L : AddUpdateTurfZone.fTurfZoneID;
      turfZoneBe.Name = this.txtTurfZoneName.Text.Trim();
      turfZoneBe.Description = this.txtTurfZoneDescription.Text.Trim();
      turfZoneBe.IsActive = this.chkIsActive.Checked;
      turfZoneBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      turfZoneBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      if (TurfZoneMgmt.AddUpdateTurfZone(turfZoneBe) > 0L)
      {
        if (turfZoneBe.TurfZoneID > 0L)
          this.Session["TurfZoneAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) "Turf Zone");
        else if (turfZoneBe.TurfZoneID == 0L)
          this.Session["TurfZoneAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) "Turf Zone");
        this.Response.Redirect("~/Admin/ViewTurfZone.aspx");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Turf Zone"), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvTurfZoneName, true, (object) this.txtTurfZoneName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTurfZoneName, Regex.Title, true, (object) this.txtTurfZoneName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTurfZoneDescription, true, (object) this.txtTurfZoneDescription, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTurfZoneDescription, Regex.Description, true, (object) this.txtTurfZoneDescription, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
