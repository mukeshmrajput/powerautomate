﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateNews
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.NewsManagement;
using Entity.Common.NewsManagement;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateNews : Page
  {
    public int rowCount = 0;
    public long fNewsID = 0;
    public long UserId;
    public string NewsOriginalImagePath = ConfigurationManager.AppSettings[nameof (NewsOriginalImagePath)];
    public string NewsThumbImagePath = ConfigurationManager.AppSettings[nameof (NewsThumbImagePath)];
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected TextBox txtTitle;
    protected RequiredFieldValidator rfvTitle;
    protected RegularExpressionValidator regTitle;
    protected TextBox txtURL;
    protected RegularExpressionValidator regURL;
    protected TextBox txtNews;
    protected FileUpload fldNews;
    protected HtmlAnchor lnkNewsImage;
    protected HtmlAnchor lnkNewsThumb;
    protected Image ImgThumb;
    protected Button btnNewsDelete;
    protected HiddenField hdndivNews;
    protected HiddenField hdnNewsDoc;
    protected HiddenField hdnNewsCancel;
    protected HiddenField hdnNewsName;
    protected HiddenField hdnUploadType;
    protected HiddenField hdnDocName;
    protected HtmlGenericControl divDescription;
    protected RadEditor redBody;
    protected RequiredFieldValidator rfvDescription;
    protected RadDatePicker txtNewsReleasedDate;
    protected RequiredFieldValidator rfvReleasedDate;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liNewsManagement");
      this.txtTitle.Focus();
      this.ValidationExpression();
      ((WebControl) this.txtNewsReleasedDate).Attributes.Add("readonly", "readonly");
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.Request.QueryString["NewsID"] != null)
        this.fNewsID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["NewsID"].ToString()));
      if (!this.IsPostBack)
      {
        if (this.Request.QueryString["NewsID"] != null)
        {
          this.h1Title.InnerText = "Edit News";
          this.btnSubmit.Text = "Update";
          this.btnSubmit.ToolTip = "Update";
          this.fNewsID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["NewsID"].ToString()));
          if (this.Session["UpdateMsg"] != null)
            this.Session["UpdateMsg"] = (object) null;
          this.FillData(this.fNewsID);
        }
        else
        {
          this.h1Title.InnerText = "Add News";
          RadDateTimePicker radDateTimePicker = new RadDateTimePicker();
          this.txtNewsReleasedDate.MinDate = DateTime.Today;
          this.txtNewsReleasedDate.SelectedDate = new DateTime?(DateTime.Now);
          this.btnSubmit.Text = "Save";
          this.btnSubmit.ToolTip = "Save";
        }
      }
      this.txtTitle.Focus();
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvTitle, true, (object) this.txtTitle, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTitle, Regex.NewsTitle, true, (object) this.txtTitle, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvDescription, true, (object) this.redBody, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regURL, Regex.URL, true, (object) this.txtURL, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvReleasedDate, true, (object) this.txtNewsReleasedDate, this.strValidationTurfGrp);
      this.fldNews.Attributes.Add("OnChange", "return UploadFileSelect('" + this.fldNews.ClientID + "','" + this.txtNews.ClientID + "', this, 'news');");
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }

    protected void FillData(long NewsID)
    {
      NewsBE newsBe = new NewsBE();
      NewsBE newsDetailByNewsId = NewsMgmt.GetNewsDetailByNewsID(NewsID);
      if (newsDetailByNewsId == null)
        return;
      this.txtTitle.Text = newsDetailByNewsId.Title;
      this.txtURL.Text = newsDetailByNewsId.URL_Link;
      this.redBody.Content = newsDetailByNewsId.Description;
      this.chkIsActive.Checked = newsDetailByNewsId.IsActive;
      this.txtNewsReleasedDate.SelectedDate = new DateTime?(newsDetailByNewsId.Date);
      this.hdnDocName.Value = Convert.ToString(newsDetailByNewsId.Image);
      if (!string.IsNullOrEmpty(newsDetailByNewsId.Image))
      {
        this.hdnNewsDoc.Value = "block";
        this.hdndivNews.Value = "none";
        this.hdnNewsCancel.Value = "block";
        this.hdnNewsName.Value = newsDetailByNewsId.Image;
        this.lnkNewsThumb.HRef = ConfigurationManager.AppSettings["LivePath"] + this.NewsOriginalImagePath + newsDetailByNewsId.Image;
        this.ImgThumb.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.NewsThumbImagePath + newsDetailByNewsId.Image;
        this.lnkNewsImage.Visible = false;
        this.lnkNewsThumb.Visible = true;
      }
    }

    private bool ImageValidationMessage()
    {
      string str = this.fldNews.FileName.Substring(this.fldNews.FileName.LastIndexOf(".") + 1).ToLower();
      str = string.Empty;
      string lower = this.fldNews.FileName.Substring(this.fldNews.FileName.LastIndexOf(".") + 1).ToLower();
      if (Regex.UploadImage.Contains(lower) && !string.IsNullOrEmpty(lower))
      {
        if (this.fldNews.FileContent.Length > 2097152L)
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "News"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      else
      {
        if (string.IsNullOrEmpty(lower) && string.IsNullOrEmpty(this.hdnNewsName.Value))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "News"), (Enums.NotificationType) 2, false), true);
          return false;
        }
        if (!string.IsNullOrEmpty(lower))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "News"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      return true;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.ImageValidationMessage())
        return;
      NewsBE newsBe = new NewsBE();
      newsBe.CreatedBy = Convert.ToInt64(this.UserId);
      newsBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      newsBe.NewsID = this.fNewsID <= 0L ? 0L : this.fNewsID;
      newsBe.Title = this.txtTitle.Text.Trim();
      newsBe.URL_Link = this.txtURL.Text.Trim();
      newsBe.IsActive = this.chkIsActive.Checked;
      newsBe.Description = this.redBody.Content.Trim();
      newsBe.Date = Convert.ToDateTime((object) this.txtNewsReleasedDate.SelectedDate);
      string empty = string.Empty;
      if (!string.IsNullOrEmpty(this.fldNews.FileName))
      {
        if (this.fldNews.FileName.Length > 0)
        {
          string[] strArray = this.fldNews.FileName.Split('\\');
          string FileName = UtilityFunctions.ChangeFileName(strArray[strArray.Length - 1].ToString());
          string extension = Path.GetExtension(this.fldNews.FileName);
          if (extension == ".jpeg" || extension == ".png" || extension == ".jpg" || extension == ".bmp" || extension == ".gif")
          {
            this.fldNews.SaveAs(this.Server.MapPath("~/") + this.NewsOriginalImagePath + FileName);
            Resizer.FixedSize(FileName, this.fldNews, this.NewsThumbImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["NewsThumbImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["NewsThumbImageHeight"]));
          }
          else
            this.fldNews.SaveAs(this.Server.MapPath("~/") + this.NewsOriginalImagePath + FileName);
          newsBe.Image = FileName;
          if (!string.IsNullOrEmpty(this.hdnNewsName.Value))
          {
            FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.NewsOriginalImagePath + this.hdnNewsName.Value);
            if (fileInfo.Exists)
              fileInfo.Delete();
          }
        }
      }
      else
        newsBe.Image = this.hdnDocName.Value;
      newsBe.IsActive = this.chkIsActive.Checked;
      if (NewsMgmt.AddUpdateNews(newsBe) == -1L)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "News"), (Enums.NotificationType) 2, false), true);
      }
      else
      {
        if (this.fNewsID > 0L)
          this.Session[nameof (AddUpdateNews)] = (object) string.Format(Messages.UpdateSuccess, (object) "News");
        else
          this.Session[nameof (AddUpdateNews)] = (object) string.Format(Messages.AddSuccess, (object) "News");
        this.Response.Redirect("~/Admin/ViewNews.aspx");
      }
    }

    protected void btnNewsDelete_Click(object sender, EventArgs e)
    {
      NewsMgmt.DeleteNewsImageById(this.fNewsID);
      FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.NewsOriginalImagePath + this.hdnNewsName.Value);
      if (!fileInfo.Exists)
        return;
      fileInfo.Delete();
      this.hdnNewsDoc.Value = "none";
      this.hdndivNews.Value = "block";
      this.hdnNewsCancel.Value = "none";
      this.hdnNewsName.Value = "none";
      this.fldNews.Dispose();
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) Messages.NewsImage), (Enums.NotificationType) 1), true);
    }
  }
}
