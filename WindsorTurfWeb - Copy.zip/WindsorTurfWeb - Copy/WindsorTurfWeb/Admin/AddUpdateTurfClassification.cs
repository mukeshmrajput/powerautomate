﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateTurfClassification
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.TurfProductManagement.TurfClassifications;
using Entity.Common.StockManagement.TurfProductManagement.TurfClassifications;
using Entity.Response.StockManagement.TurfProductManagement.TurfClassifications;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateTurfClassification : Page
  {
    public static long fTurfClassificationID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtClassificationName;
    protected RequiredFieldValidator rfvClassificationName;
    protected RegularExpressionValidator regClassificationName;
    protected TextBox txtClassificationDesc;
    protected RequiredFieldValidator rfvClassificationDesc;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnQuantityPriceID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewTurfClassification");
      if (this.Request.QueryString[QueryStrings.TurfClassificationID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strAddTurfClassification;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        AddUpdateTurfClassification.fTurfClassificationID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.TurfClassificationID].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddTurfClassification;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateTurfClassification.fTurfClassificationID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        if (AddUpdateTurfClassification.fTurfClassificationID > 0L)
          this.GetTurfClassificationDetails(TurfClassificationMgmt.GetTurfClassificationInfoByID(Convert.ToInt64(AddUpdateTurfClassification.fTurfClassificationID)));
      }
      this.txtClassificationName.Focus();
    }

    protected void GetTurfClassificationDetails(
      TurfClassificationResponseBE objTurfClassificationResponseBE)
    {
      this.txtClassificationName.Text = Convert.ToString(objTurfClassificationResponseBE.Name);
      this.txtClassificationDesc.Text = Convert.ToString(objTurfClassificationResponseBE.Description);
      this.chkIsActive.Checked = Convert.ToBoolean(objTurfClassificationResponseBE.IsActive);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      TurfClassificationsBE classificationsBe = new TurfClassificationsBE();
      classificationsBe.TurfClassificationID = AddUpdateTurfClassification.fTurfClassificationID <= 0L ? 0L : AddUpdateTurfClassification.fTurfClassificationID;
      classificationsBe.Name = this.txtClassificationName.Text.Trim();
      classificationsBe.Description = this.txtClassificationDesc.Text.Trim();
      classificationsBe.IsActive = this.chkIsActive.Checked;
      classificationsBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      classificationsBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      long num = TurfClassificationMgmt.AddUpdateTurfClassifications(classificationsBe);
      if (num > 0L)
      {
        if (classificationsBe.TurfClassificationID > 0L)
          this.Session["TurfClassificationAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddTurfClassification);
        else if (classificationsBe.TurfClassificationID == 0L)
          this.Session["TurfClassificationAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddTurfClassification);
        this.Response.Redirect("~/Admin/ViewTurfClassifications.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) PageName.strAddTurfClassification), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvClassificationName, true, (object) this.txtClassificationName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regClassificationName, Regex.Title, true, (object) this.txtClassificationName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvClassificationDesc, true, (object) this.txtClassificationDesc, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
