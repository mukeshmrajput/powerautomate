﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewNews
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.NewsManagement;
using Entity.Request.NewsManagement;
using Entity.Response.NewsManagement;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewNews : Page
  {
    public long UserId;
    private NewsRequestBE objRequest = new NewsRequestBE();
    protected HtmlGenericControl H1Title;
    protected RadGrid grdNews;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendupdateStatus;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liNewsManagement");
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["AddUpdateNews"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["AddUpdateNews"]), (Enums.NotificationType) 1), true);
        this.Session["AddUpdateNews"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<NewsResponseBE> newsResponseBeList = new List<NewsResponseBE>();
      List<NewsResponseBE> allNews = NewsMgmt.GetAllNews();
      this.grdNews.VirtualItemCount = allNews.Count<NewsResponseBE>();
      ((BaseDataBoundControl) this.grdNews).DataSource = (object) allNews;
      ((Control) this.grdNews).DataBind();
      if (allNews.Count<NewsResponseBE>() == 0)
        this.grdNews.AllowFilteringByColumn = false;
      ViewNews.SetPaggingText(this.grdNews, "Paging");
    }

    protected void grdNews_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdNews.MasterTableView.Items).Count == 0)
      {
        this.grdNews.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdNews.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdNews.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdNews.PagerStyle.AlwaysVisible = true;
      }
      this.grdNews.Rebind();
      ViewNews.SetPaggingText(this.grdNews, "Paging");
    }

    protected void grdNews_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdNews_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdNews_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdNews_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        NewsMgmt.DeleteNews(((CommandEventArgs) e).CommandArgument.ToString(), Convert.ToInt64(Convert.ToInt64(this.UserId)), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) "News"), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdNews.Rebind();
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) "News") + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewNews.aspx");

    protected void btnIsActive_Click(object sender, EventArgs e)
    {
      string str1 = "";
      string str2 = "";
      foreach (GridDataItem gridDataItem in (GridItemCollection) this.grdNews.Items)
      {
        CheckBox control1 = (CheckBox) ((Control) gridDataItem).FindControl("chkIsActive");
        HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnNewsID");
        if (control1 != null)
        {
          str1 = str1 + control2.Value.ToString() + ",";
          str2 = str2 + control1.Checked.ToString() + ",";
        }
      }
      NewsMgmt.UpdateNewsStatus(str1.TrimEnd(','), str2.TrimEnd(','), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateStatusSuccess, (object) "News"), (Enums.NotificationType) 1), true);
    }

    protected void grdNews_ItemDataBound(object sender, GridItemEventArgs e)
    {
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
