﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.UserControl.NonTurfProductStockSubMenu
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using Helper;
using System;
using System.Web.UI.HtmlControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin.UserControl
{
  public class NonTurfProductStockSubMenu : System.Web.UI.UserControl
  {
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liViewNonTurfClassification;
    protected HtmlAnchor aViewNonTurfClassification;
    protected HtmlGenericControl liViewNonTurfProduct;
    protected HtmlAnchor aViewNonTurfProduct;
    protected HtmlGenericControl liViewNonTurfStockAvailable;
    protected HtmlAnchor aViewNonTurfStockAvailable;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.aViewNonTurfClassification.HRef = "~/Admin/ViewNonTurfClassifications.aspx";
      this.aViewNonTurfClassification.Title = PageName.strViewNonTurfClassification;
      this.aViewNonTurfClassification.InnerText = PageName.strViewNonTurfClassification;
      this.aViewNonTurfProduct.HRef = "~/Admin/ViewNonTurfProduct.aspx";
      this.aViewNonTurfProduct.Title = PageName.strViewNonTurfProduct;
      this.aViewNonTurfProduct.InnerText = PageName.strViewNonTurfProduct;
      this.aViewNonTurfStockAvailable.HRef = "~/Admin/ViewNonTurfStockAvailable.aspx";
      this.aViewNonTurfStockAvailable.Title = PageName.strViewNonTurfStockAvailable;
      this.aViewNonTurfStockAvailable.InnerText = PageName.strViewNonTurfStockAvailable;
      UtilityFunctions.SetUserModuleAccess(this.divTab);
      if (string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) || Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3))) != 1L)
        return;
      this.liViewNonTurfStockAvailable.Visible = false;
    }

    public bool SubMenuNonTurfClassification
    {
      set => this.aViewNonTurfClassification.Attributes["class"] = "active";
    }

    public bool SubMenuNonTurfProduct
    {
      set => this.aViewNonTurfProduct.Attributes["class"] = "active";
    }

    public bool SubMenuNonTurfStockAvailable
    {
      set => this.aViewNonTurfStockAvailable.Attributes["class"] = "active";
    }
  }
}
