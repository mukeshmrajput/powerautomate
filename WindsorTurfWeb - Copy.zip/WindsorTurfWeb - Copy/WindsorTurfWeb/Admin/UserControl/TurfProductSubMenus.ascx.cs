﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.UserControl.TurfProductSubMenus
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Web.UI.HtmlControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin.UserControl
{
  public class TurfProductSubMenus : System.Web.UI.UserControl
  {
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liViewTurfRange;
    protected HtmlAnchor aViewTurfRange;
    protected HtmlGenericControl liViewTurfZone;
    protected HtmlAnchor aViewTurfZone;
    protected HtmlGenericControl liViewTurfPrice;
    protected HtmlAnchor aViewTurfPrice;
    protected HtmlGenericControl liViewServiceRegion;
    protected HtmlAnchor aViewServiceRegion;
    protected HtmlGenericControl liViewServiceFees;
    protected HtmlAnchor aViewServiceFees;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.aViewTurfRange.HRef = "~/Admin/ViewTurfRange.aspx";
      this.aViewTurfRange.Title = "View Turf Range(s)";
      this.aViewTurfRange.InnerText = "View Turf Range(s)";
      this.aViewTurfPrice.HRef = "~/Admin/ViewTurfPrice.aspx";
      this.aViewTurfPrice.Title = "View Turf Price(s)";
      this.aViewTurfPrice.InnerText = "View Turf Price(s)";
      this.aViewTurfZone.HRef = "~/Admin/ViewTurfZone.aspx";
      this.aViewTurfZone.Title = "View Turf Zone(s)";
      this.aViewTurfZone.InnerText = "View Turf Zone(s)";
      this.aViewServiceRegion.HRef = "~/Admin/ViewServiceRegion.aspx";
      this.aViewServiceRegion.Title = "View Service Region(s)";
      this.aViewServiceRegion.InnerText = "View Service Region(s)";
      this.aViewServiceFees.HRef = "~/Admin/ViewServiceFees.aspx";
      this.aViewServiceFees.Title = PageName.strViewServiceFees;
      this.aViewServiceFees.InnerText = PageName.strViewServiceFees;
      UtilityFunctions.SetUserModuleAccess(this.divTab);
    }

    public bool SubMenuTurfRange
    {
      set => this.aViewTurfRange.Attributes["class"] = "active";
    }

    public bool SubMenuTurfZone
    {
      set => this.aViewTurfZone.Attributes["class"] = "active";
    }

    public bool SubMenuTurfPrice
    {
      set => this.aViewTurfPrice.Attributes["class"] = "active";
    }

    public bool SubMenuServiceRegion
    {
      set => this.aViewServiceRegion.Attributes["class"] = "active";
    }

    public bool SubMenuServiceFees
    {
      set => this.aViewServiceFees.Attributes["class"] = "active";
    }
  }
}
