﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.UserControl.ProductPricingSubMenus
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Web.UI.HtmlControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin.UserControl
{
  public class ProductPricingSubMenus : System.Web.UI.UserControl
  {
    protected HtmlGenericControl divSubProductPricing;
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liTurfPricingandServiceFees;
    protected HtmlAnchor aTurfPricingandServiceFees;
    protected HtmlGenericControl liNonTurfProductpricingandDeliveryfees;
    protected HtmlAnchor aNonTurfProductpricingandDeliveryfees;
    protected HtmlGenericControl liViewDeliveryRegion;
    protected HtmlAnchor aViewDeliveryRegion;
    protected HtmlGenericControl liViewDeliveryPrice;
    protected HtmlAnchor aViewDeliveryPrice;
    protected HtmlGenericControl liPickUpEditor;
    protected HtmlAnchor aPickUpEditor;
    protected HtmlGenericControl liHearAboutUs;
    protected HtmlAnchor aHearAboutUs;
    protected HtmlGenericControl liPaymentEditor;
    protected HtmlAnchor aPaymentEditor;
    protected HtmlGenericControl liCommercialPartnerAccounts;
    protected HtmlAnchor aCommercialPartnerAccounts;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.aTurfPricingandServiceFees.HRef = "~/Admin/ViewTurfRange.aspx";
      this.aTurfPricingandServiceFees.Title = PageName.strTurfPricingandServiceFees;
      this.aTurfPricingandServiceFees.InnerText = PageName.strTurfPricingandServiceFees;
      this.aNonTurfProductpricingandDeliveryfees.HRef = "~/Admin/ViewQuantityRanges.aspx";
      this.aNonTurfProductpricingandDeliveryfees.Title = PageName.strNonTurfProductpricingandDeliveryfees;
      this.aNonTurfProductpricingandDeliveryfees.InnerText = PageName.strNonTurfProductpricingandDeliveryfees;
      this.aPickUpEditor.HRef = "~/Admin/ViewPickUpDetails.aspx";
      this.aPickUpEditor.Title = "View PickUp Detail(s)";
      this.aPickUpEditor.InnerText = "View PickUp Detail(s)";
      this.aHearAboutUs.HRef = "~/Admin/ViewHearAboutUs.aspx";
      this.aHearAboutUs.Title = "View Hear About Us";
      this.aHearAboutUs.InnerText = "View Hear About Us";
      this.aPaymentEditor.HRef = "~/Admin/ViewPaymentType.aspx";
      this.aPaymentEditor.Title = PageName.strViewPaymentType;
      this.aPaymentEditor.InnerText = PageName.strViewPaymentType;
      this.aCommercialPartnerAccounts.HRef = "~/Admin/ViewAccountDetail.aspx";
      this.aCommercialPartnerAccounts.Title = PageName.strViewAccount;
      this.aCommercialPartnerAccounts.InnerText = PageName.strViewAccount;
      this.aViewDeliveryRegion.HRef = "~/Admin/ViewDeliveryRegion.aspx";
      this.aViewDeliveryRegion.Title = PageName.strViewDeliveryRegion;
      this.aViewDeliveryRegion.InnerText = PageName.strViewDeliveryRegion;
      this.aViewDeliveryPrice.HRef = "~/Admin/ViewDeliveryPrice.aspx";
      this.aViewDeliveryPrice.Title = PageName.strViewDeliveryPrice;
      this.aViewDeliveryPrice.InnerText = PageName.strViewDeliveryPrice;
      UtilityFunctions.SetUserModuleAccess(this.divTab);
    }

    public bool SubMenuTurfPricingandServiceFees
    {
      set => this.aTurfPricingandServiceFees.Attributes["class"] = "active";
    }

    public bool SubMenuNonTurfProductpricingandDeliveryfees
    {
      set => this.aNonTurfProductpricingandDeliveryfees.Attributes["class"] = "active";
    }

    public bool SubMenuPickUpEditor
    {
      set => this.aPickUpEditor.Attributes["class"] = "active";
    }

    public bool SubMenuHearAboutUs
    {
      set => this.aHearAboutUs.Attributes["class"] = "active";
    }

    public bool SubMenuPaymentEditor
    {
      set => this.aPaymentEditor.Attributes["class"] = "active";
    }

    public bool SubMenuCommercialPartnerAccounts
    {
      set => this.aCommercialPartnerAccounts.Attributes["class"] = "active";
    }

    public bool SubMenuDeliveryRegion
    {
      set => this.aViewDeliveryRegion.Attributes["class"] = "active";
    }

    public bool SubMenuDeliveryPrice
    {
      set => this.aViewDeliveryPrice.Attributes["class"] = "active";
    }
  }
}
