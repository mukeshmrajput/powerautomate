﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.UserControl.TurfProductStockSubMenu
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using Helper;
using System;
using System.Web.UI.HtmlControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin.UserControl
{
  public class TurfProductStockSubMenu : System.Web.UI.UserControl
  {
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liViewTurfClassification;
    protected HtmlAnchor aViewTurfClassification;
    protected HtmlGenericControl liViewTurfProduct;
    protected HtmlAnchor aViewTurfProduct;
    protected HtmlGenericControl liViewTurfStockAvailable;
    protected HtmlAnchor aViewTurfStockAvailable;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.aViewTurfClassification.HRef = "~/Admin/ViewTurfClassifications.aspx";
      this.aViewTurfClassification.Title = PageName.strViewTurfClassification;
      this.aViewTurfClassification.InnerText = PageName.strViewTurfClassification;
      this.aViewTurfProduct.HRef = "~/Admin/ViewTurfProduct.aspx";
      this.aViewTurfProduct.Title = PageName.strViewTurfProduct;
      this.aViewTurfProduct.InnerText = PageName.strViewTurfProduct;
      this.aViewTurfStockAvailable.HRef = "~/Admin/ViewTurfStockAvailable.aspx";
      this.aViewTurfStockAvailable.Title = PageName.strViewTurfStockAvailable;
      this.aViewTurfStockAvailable.InnerText = PageName.strViewTurfStockAvailable;
      UtilityFunctions.SetUserModuleAccess(this.divTab);
      if (string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) || Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3))) != 1L)
        return;
      this.liViewTurfStockAvailable.Visible = false;
    }

    public bool SubMenuTurfClassification
    {
      set => this.aViewTurfClassification.Attributes["class"] = "active";
    }

    public bool SubMenuTurfProduct
    {
      set => this.aViewTurfProduct.Attributes["class"] = "active";
    }

    public bool SubMenuTurfStockAvailable
    {
      set => this.aViewTurfStockAvailable.Attributes["class"] = "active";
    }
  }
}
