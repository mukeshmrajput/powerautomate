﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.UserControl.StockManagementSubMenus
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Web.UI.HtmlControls;

namespace WindsorTurfWeb.Admin.UserControl
{
  public class StockManagementSubMenus : System.Web.UI.UserControl
  {
    protected HtmlGenericControl divSubProductPricing;
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liTurfProductStockManagement;
    protected HtmlAnchor aTurfProductStockManagement;
    protected HtmlGenericControl liNonTurfProductStockManagement;
    protected HtmlAnchor aNonTurfProductStockManagement;

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    public bool SubMenuTurfProductStockManagement
    {
      set => this.aTurfProductStockManagement.Attributes["class"] = "active";
    }

    public bool SubMenuNonTurfProductStockManagement
    {
      set => this.aNonTurfProductStockManagement.Attributes["class"] = "active";
    }
  }
}
