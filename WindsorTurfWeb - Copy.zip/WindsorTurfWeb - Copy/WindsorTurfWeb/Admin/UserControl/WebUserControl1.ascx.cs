﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.UserControl.WebUserControl1
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using Helper;
using System;
using System.Data;
using System.Web;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin.UserControl
{
  public class WebUserControl1 : System.Web.UI.UserControl
  {
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liShop;
    protected HtmlGenericControl liTurfDescription;
    protected HtmlGenericControl liCheckout;
    protected HtmlGenericControl liRetailPurchase;
    protected HtmlGenericControl liConfirmPayment;
    protected HtmlGenericControl divOrderforUser;
    protected Label lblOrderFor;
    protected HtmlAnchor aAdminCheckoutPage;
    protected Label ltradmin_cart;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.IsPostBack)
        return;
      this.aAdminCheckoutPage.HRef = "~/Admin/AdminCheckoutPage.aspx";
      if (this.Session["dtAdminCART"] == null)
      {
        this.ltradmin_cart.Text = "Cart (0)";
        this.ltradmin_cart.ToolTip = "Cart (0)";
      }
      else
      {
        Label ltradminCart1 = this.ltradmin_cart;
        int count = ((DataTable) this.Session["dtAdminCART"]).Rows.Count;
        string str1 = "Cart (" + count.ToString() + ")";
        ltradminCart1.Text = str1;
        Label ltradminCart2 = this.ltradmin_cart;
        count = ((DataTable) this.Session["dtAdminCART"]).Rows.Count;
        string str2 = "Cart (" + count.ToString() + ")";
        ltradminCart2.ToolTip = str2;
      }
      if (this.Session["PlaceOrderType"] != null)
      {
        string str = HttpContext.Current.Session["PlaceOrderType"].ToString();
        if (str == ((Enums.PersonType) 6).ToString())
          this.lblOrderFor.Text = PageName.strUserTypeNameR.ToString();
        else if (str == ((Enums.PersonType) 5).ToString())
          this.lblOrderFor.Text = PageName.strUserTypeNameCC.ToString();
        else if (str == ((Enums.PersonType) 4).ToString())
          this.lblOrderFor.Text = PageName.strUserTypeNameCP.ToString();
      }
      else
        this.divOrderforUser.Visible = false;
    }

    public bool SubMenuliShop
    {
      set => this.liShop.Attributes["class"] = "active";
    }

    public bool SubMenuliTurfDescription
    {
      set => this.liTurfDescription.Attributes["class"] = "active";
    }

    public bool SubMenuliCheckout
    {
      set => this.liCheckout.Attributes["class"] = "active";
    }

    public bool SubMenuliRetailPurchase
    {
      set => this.liRetailPurchase.Attributes["class"] = "active";
    }

    public bool SubMenuliConfirmPayment
    {
      set => this.liConfirmPayment.Attributes["class"] = "active";
    }
  }
}
