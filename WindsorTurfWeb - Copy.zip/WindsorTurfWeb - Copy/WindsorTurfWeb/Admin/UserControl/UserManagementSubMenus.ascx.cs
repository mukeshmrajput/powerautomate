﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.UserControl.UserManagementSubMenus
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Web.UI.HtmlControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin.UserControl
{
  public class UserManagementSubMenus : System.Web.UI.UserControl
  {
    protected HtmlGenericControl divSubProductPricing;
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liAdminUsers;
    protected HtmlAnchor aViewAdminUsers;
    protected HtmlGenericControl liCommercialPartnerUsers;
    protected HtmlAnchor aViewCommercialPartnerUsers;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.aViewAdminUsers.HRef = "~/Admin/ViewUser.aspx";
      this.aViewAdminUsers.Title = "View Admin User(s)";
      this.aViewAdminUsers.InnerText = "View Admin User(s)";
      this.aViewCommercialPartnerUsers.HRef = "~/Admin/ViewCommercialPartnerUser.aspx";
      this.aViewCommercialPartnerUsers.Title = "View Commercial Partner(s)";
      this.aViewCommercialPartnerUsers.InnerText = "View Commercial Partner(s)";
      UtilityFunctions.SetUserModuleAccess(this.divTab);
    }

    public bool SubMenuAdminUser
    {
      set => this.aViewAdminUsers.Attributes["class"] = "active";
    }

    public bool SubMenuCommercialPartnerUser
    {
      set => this.aViewCommercialPartnerUsers.Attributes["class"] = "active";
    }
  }
}
