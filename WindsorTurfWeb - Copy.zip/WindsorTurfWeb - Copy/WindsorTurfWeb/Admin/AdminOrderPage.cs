﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AdminOrderPage
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class AdminOrderPage : Page
  {
    private double quan;
    private double total;
    private double subtotal;
    private double netQty;
    private double price;
    private DataTable _dtTurfList = new DataTable();
    private DataTable _dtTurfCareList = new DataTable();
    private DataTable _dtAdminCART = new DataTable();
    public string HeaderImagePath = ConfigurationManager.AppSettings["ImagePath"];
    protected HtmlGenericControl divTab;
    protected WebUserControl1 AdminPurchaseProcess1;
    protected Literal ltrTurfList;
    protected DropDownList ddlTurfList;
    protected HtmlGenericControl divNoTurfList;
    protected Label lblNoTurfList;
    protected HtmlGenericControl divTurfList;
    protected Repeater rptTurfList;
    protected Literal ltrTurfCareList;
    protected DropDownList ddlTurfCareList;
    protected HtmlGenericControl divNoTurfCareList;
    protected Label lblNoTurfCareList;
    protected HtmlGenericControl divTurfCareList;
    protected Repeater rptTurfCareList;
    protected HtmlGenericControl divLegends;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divButtons;
    protected ImageButton BtnAddtoCart;
    protected HiddenField hdnOriginalQuantityEdit;
    protected HiddenField hdnOriginalPriceEdit;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (!this.IsPostBack)
      {
        this.ltrTurfList.Text = "Turf Zone";
        BindDropDown.BindTurfZoneForShopPage((ListControl) this.ddlTurfList);
        this.BindFinalTurfProducts();
        this.ltrTurfCareList.Text = PageName.strAddQuantityZone;
        BindDropDown.BindQuantityZoneForShopPage((ListControl) this.ddlTurfCareList);
        this.BindFinalNonTurfProducts();
        this.SetCartValue();
      }
      this.BtnAddtoCart.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.HeaderImagePath + "add-to-cart.png";
    }

    protected void BindFinalTurfProducts()
    {
      List<TurfProductResponseBE> forOrderPageAdmin = TurfProductMgmt.GetAllTurfProductsForOrderPageAdmin(Convert.ToInt64(this.ddlTurfList.SelectedValue), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
      if ((DataTable) this.Session["dtAdminCART"] != null)
      {
        List<TurfProductResponseBE> productResponseBeList = new List<TurfProductResponseBE>();
        List<TurfProductResponseBE> list1 = ((DataTable) this.Session["dtAdminCART"]).Rows.Cast<DataRow>().Select<DataRow, TurfProductResponseBE>((System.Func<DataRow, TurfProductResponseBE>) (row => new TurfProductResponseBE()
        {
          TurfProductID = Convert.ToInt64(row["TurfProductID"]),
          OrderNo = Convert.ToInt32(row["OrderNo"]),
          TurfClassificationID = (long) Convert.ToInt32(row["TurfClassificationID"]),
          TurfName = Convert.ToString(row["TurfName"]),
          Price = Convert.ToDecimal(row["Price"]),
          Quantity = Convert.ToDecimal(row["Quantity"]),
          MainImage = Convert.ToString(row["MainImage"]),
          Type = Convert.ToInt32(row["Type"]),
          ProductType = Convert.ToInt32(row["ProductType"]),
          TurfLinkURL = Convert.ToString(row["TurfLinkURL"]),
          PageName = Convert.ToString(row["PageName"]),
          Description = Convert.ToString(row["Description"]),
          StockStatus = Convert.ToBoolean(row["StockStatus"]),
          TurfType = Convert.ToString(row["TurfType"]),
          TurfZoneID = Convert.ToInt64(row["TurfZoneID"])
        })).ToList<TurfProductResponseBE>();
        foreach (TurfProductResponseBE productResponseBe1 in forOrderPageAdmin)
        {
          TurfProductResponseBE list = productResponseBe1;
          if (list1.Where<TurfProductResponseBE>((System.Func<TurfProductResponseBE, bool>) (x => x.TurfProductID == list.TurfProductID && x.TurfType == list.TurfType)).ToList<TurfProductResponseBE>().Count > 0)
          {
            TurfProductResponseBE productResponseBe2 = list1.Where<TurfProductResponseBE>((System.Func<TurfProductResponseBE, bool>) (x => x.TurfProductID == list.TurfProductID && x.TurfType == list.TurfType)).FirstOrDefault<TurfProductResponseBE>();
            list.Price = productResponseBe2.Price;
            list.Quantity = productResponseBe2.Quantity;
          }
        }
      }
      if (forOrderPageAdmin.Count > 0)
      {
        this.rptTurfList.DataSource = (object) forOrderPageAdmin;
        this.rptTurfList.DataBind();
        this.divNoTurfList.Style.Add("display", "none");
        this.lblNoTurfList.Text = string.Empty;
        this.Session["dtTurfList"] = (object) (this._dtTurfList = UtilityFunctions.ConvertToDataTable<TurfProductResponseBE>((IList<TurfProductResponseBE>) forOrderPageAdmin));
        ((Label) this.rptTurfList.Controls[this.rptTurfList.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtTurfList, (DataTable) this.Session["dtTurfList"]);
      }
      else
      {
        this.rptTurfList.DataSource = (object) null;
        this.rptTurfList.DataBind();
        this.divNoTurfList.Style.Add("display", "block");
        this.lblNoTurfList.Text = string.Format(Messages.NoRecordFound, (object) "Turf Product");
        this.divNoTurfList.Style.Add("color", UtilityFunctions.SetMessageColor(0));
      }
    }

    protected void rptTurfList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.AlternatingItem && e.Item.ItemType != ListItemType.Item)
        return;
      HtmlTableRow control = (HtmlTableRow) e.Item.FindControl("rptTurfListTr");
      if (!Convert.ToBoolean(((HiddenField) e.Item.FindControl("hdn_StockStatus")).Value))
      {
        control.Attributes.Add("class", "selected");
        e.Item.FindControl("btn_edit").Visible = false;
      }
    }

    protected void rptTurfList_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
      RepeaterItem repeaterItem = e.Item;
      if (e.CommandName == "edit")
      {
        ((TextBox) repeaterItem.FindControl("txt_quan")).Text = ((Label) repeaterItem.FindControl("lbl_quan")).Text.ToString();
        ((TextBox) repeaterItem.FindControl("txt_price")).Text = ((Label) repeaterItem.FindControl("lbl_unitprice")).Text.ToString();
        this.netQty = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString());
        this.price = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_price")).Text.ToString());
        this.hdnOriginalQuantityEdit.Value = this.netQty.ToString();
        this.hdnOriginalPriceEdit.Value = this.price.ToString();
        repeaterItem.FindControl("lbl_quan").Visible = false;
        repeaterItem.FindControl("lbl_unitprice").Visible = false;
        repeaterItem.FindControl("txt_quan").Visible = true;
        repeaterItem.FindControl("txt_price").Visible = true;
        repeaterItem.FindControl("spnQuanStar").Visible = true;
        repeaterItem.FindControl("spnPriceStar").Visible = true;
        repeaterItem.FindControl("ibtnCalculateArea").Visible = true;
        repeaterItem.FindControl("btn_Update").Visible = true;
        repeaterItem.FindControl("btn_edit").Visible = false;
        repeaterItem.FindControl("btn_cancel").Visible = true;
        this._dtTurfList = (DataTable) this.Session["dtTurfList"];
        ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:block");
        if (this._dtTurfList != null)
        {
          for (int index = 0; index < this._dtTurfList.Rows.Count; ++index)
          {
            if (((HiddenField) repeaterItem.FindControl("hdn_OrdNo")).Value.ToString() == this._dtTurfList.Rows[index]["OrderNo"].ToString())
            {
              ((WebControl) repeaterItem.FindControl("reg_qty")).Enabled = false;
              ((WebControl) repeaterItem.FindControl("rgval_qty")).Enabled = true;
              ((WebControl) repeaterItem.FindControl("reg_price")).Enabled = false;
              ((WebControl) repeaterItem.FindControl("rgval_price")).Enabled = true;
            }
          }
        }
      }
      if (e.CommandName == "cancel")
      {
        repeaterItem.FindControl("lbl_quan").Visible = true;
        repeaterItem.FindControl("lbl_unitprice").Visible = true;
        repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
        repeaterItem.FindControl("txt_quan").Visible = false;
        repeaterItem.FindControl("txt_price").Visible = false;
        repeaterItem.FindControl("spnQuanStar").Visible = false;
        repeaterItem.FindControl("spnPriceStar").Visible = false;
        repeaterItem.FindControl("btn_Update").Visible = false;
        repeaterItem.FindControl("btn_edit").Visible = true;
        repeaterItem.FindControl("btn_cancel").Visible = false;
        ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:none");
      }
      if (e.CommandName == "calculate")
      {
        TextBox control1 = (TextBox) e.Item.FindControl("txt_quan");
        Label control2 = (Label) e.Item.FindControl("lbl_unitprice");
        Label control3 = (Label) e.Item.FindControl("lbl_subtotal");
        LinkButton control4 = (LinkButton) repeaterItem.FindControl("ibtnCalculateArea");
        ((HtmlAnchor) repeaterItem.FindControl("aCalculateArea")).HRef = "GetAreaValue.aspx?txtTO=" + control1.Text + "&lblprice=" + control2.Text + "&lblsub=" + control3.Text;
      }
      if (!(e.CommandName == "update"))
        return;
      ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:none");
      this._dtTurfList = (DataTable) this.Session["dtTurfList"];
      if (this._dtTurfList != null)
      {
        for (int index = 0; index < this._dtTurfList.Rows.Count; ++index)
        {
          if (((HiddenField) repeaterItem.FindControl("hdn_OrdNo")).Value.ToString() == this._dtTurfList.Rows[index]["OrderNo"].ToString())
          {
            if (((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString() == "" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "0" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "0.00" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "00" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "01" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "02" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "03" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "04" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "05" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "06" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "07" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "08" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "09")
              return;
            this.quan = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString());
            this.subtotal = Convert.ToDouble(((Label) repeaterItem.FindControl("lbl_unitprice")).Text.ToString());
            double num = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_Price")).Text.ToString());
            if (num > 0.0)
            {
              this.total = this.quan * num;
              ((Label) repeaterItem.FindControl("lbl_subtotal")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.total);
              repeaterItem.FindControl("lbl_quan").Visible = true;
              repeaterItem.FindControl("lbl_unitprice").Visible = true;
              ((Label) repeaterItem.FindControl("lbl_quan")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.quan);
              ((Label) repeaterItem.FindControl("lbl_unitprice")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) num);
              repeaterItem.FindControl("txt_quan").Visible = false;
              repeaterItem.FindControl("txt_price").Visible = false;
              repeaterItem.FindControl("btn_Update").Visible = false;
              repeaterItem.FindControl("btn_edit").Visible = true;
              repeaterItem.FindControl("btn_cancel").Visible = false;
              repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
              repeaterItem.FindControl("spnQuanStar").Visible = false;
              repeaterItem.FindControl("spnPriceStar").Visible = false;
              this._dtTurfList.Rows[index].BeginEdit();
              this._dtTurfList.Rows[index]["Quantity"] = (object) ((Label) repeaterItem.FindControl("lbl_quan")).Text;
              this._dtTurfList.Rows[index]["Price"] = (object) ((Label) repeaterItem.FindControl("lbl_unitprice")).Text;
              this._dtTurfList.AcceptChanges();
              IEnumerable<string> strings = (IEnumerable<string>) this._dtTurfList.AsEnumerable().Select<DataRow, string>((System.Func<DataRow, string>) (dt => dt.Field<string>("TurfName")));
            }
            else
            {
              repeaterItem.FindControl("lbl_quan").Visible = true;
              repeaterItem.FindControl("lbl_unitprice").Visible = true;
              repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
              repeaterItem.FindControl("txt_quan").Visible = false;
              repeaterItem.FindControl("btn_Update").Visible = false;
              repeaterItem.FindControl("btn_edit").Visible = true;
              repeaterItem.FindControl("btn_cancel").Visible = false;
              ((Label) repeaterItem.FindControl("lbl_quan")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.hdnOriginalQuantityEdit.Value);
              ((Label) repeaterItem.FindControl("lbl_unitprice")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.hdnOriginalPriceEdit.Value);
              System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format("Turf Price is not defined for this Area size."), (Enums.NotificationType) 2), true);
            }
          }
        }
      }
      this.Session["dtTurfList"] = (object) this._dtTurfList;
      ((Label) this.rptTurfList.Controls[this.rptTurfList.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtTurfList, (DataTable) this.Session["dtTurfList"]);
      this.SetCartValue();
    }

    protected void ddlTurfList_SelectedIndexChanged(object sender, EventArgs e) => this.BindFinalTurfProducts();

    protected void BindFinalNonTurfProducts()
    {
      List<NonTurfProductResponseBE> productsForOrderPage = NonTurfProductMgmt.GetAllNonTurfProductsForOrderPage(Convert.ToInt64(this.ddlTurfCareList.SelectedValue), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
      if ((DataTable) this.Session["dtAdminCART"] != null)
      {
        List<NonTurfProductResponseBE> productResponseBeList = new List<NonTurfProductResponseBE>();
        List<NonTurfProductResponseBE> list1 = ((DataTable) this.Session["dtAdminCART"]).Rows.Cast<DataRow>().Select<DataRow, NonTurfProductResponseBE>((System.Func<DataRow, NonTurfProductResponseBE>) (row => new NonTurfProductResponseBE()
        {
          TurfProductID = Convert.ToInt64(row["TurfProductID"]),
          OrderNo = (int) Convert.ToInt16(row["OrderNo"]),
          TurfClassificationID = (long) Convert.ToInt32(row["TurfClassificationID"]),
          TurfName = Convert.ToString(row["TurfName"]),
          Price = Convert.ToDecimal(row["Price"]),
          Quantity = Convert.ToDecimal(row["Quantity"]),
          MainImage = Convert.ToString(row["MainImage"]),
          Type = Convert.ToInt32(row["Type"]),
          ProductType = Convert.ToInt32(row["ProductType"]),
          NonTurfLinkURL = Convert.ToString(row["NonTurfLinkURL"]),
          PageName = Convert.ToString(row["PageName"]),
          Description = Convert.ToString(row["Description"]),
          StockStatus = Convert.ToBoolean(row["StockStatus"]),
          TurfType = Convert.ToString(row["TurfType"]),
          TurfZoneID = Convert.ToInt64(row["TurfZoneID"])
        })).ToList<NonTurfProductResponseBE>();
        foreach (NonTurfProductResponseBE productResponseBe1 in productsForOrderPage)
        {
          NonTurfProductResponseBE list = productResponseBe1;
          if (list1.Where<NonTurfProductResponseBE>((System.Func<NonTurfProductResponseBE, bool>) (x => x.TurfProductID == list.TurfProductID && x.TurfType == list.TurfType)).ToList<NonTurfProductResponseBE>().Count > 0)
          {
            NonTurfProductResponseBE productResponseBe2 = list1.Where<NonTurfProductResponseBE>((System.Func<NonTurfProductResponseBE, bool>) (x => x.TurfProductID == list.TurfProductID && x.TurfType == list.TurfType)).FirstOrDefault<NonTurfProductResponseBE>();
            list.Price = productResponseBe2.Price;
            list.Quantity = productResponseBe2.Quantity;
          }
        }
      }
      if (productsForOrderPage.Count > 0)
      {
        this.rptTurfCareList.DataSource = (object) productsForOrderPage;
        this.rptTurfCareList.DataBind();
        this.divNoTurfCareList.Style.Add("display", "none");
        this.lblNoTurfCareList.Text = string.Empty;
        this.Session["dtTurfCareList"] = (object) (this._dtTurfCareList = UtilityFunctions.ConvertToDataTable<NonTurfProductResponseBE>((IList<NonTurfProductResponseBE>) productsForOrderPage));
        ((Label) this.rptTurfCareList.Controls[this.rptTurfCareList.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtTurfCareList, (DataTable) this.Session["dtTurfCareList"]);
      }
      else
      {
        this.rptTurfCareList.DataSource = (object) null;
        this.rptTurfCareList.DataBind();
        this.divNoTurfCareList.Style.Add("display", "block");
        this.lblNoTurfCareList.Text = string.Format(Messages.NoRecordFound, (object) "Non-Turf Product");
        this.divNoTurfCareList.Style.Add("color", UtilityFunctions.SetMessageColor(0));
      }
    }

    protected void rptTurfCareList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.AlternatingItem && e.Item.ItemType != ListItemType.Item)
        return;
      HtmlTableRow control = (HtmlTableRow) e.Item.FindControl("rptTurfCareListTr");
      if (!Convert.ToBoolean(((HiddenField) e.Item.FindControl("hdn_StockStatus")).Value))
      {
        control.Attributes.Add("class", "selected");
        e.Item.FindControl("btn_edit").Visible = false;
      }
    }

    protected void ddlTurfCareList_SelectedIndexChanged(object sender, EventArgs e) => this.BindFinalNonTurfProducts();

    protected void rptTurfCareList_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
      RepeaterItem repeaterItem = e.Item;
      if (e.CommandName == "edit")
      {
        ((TextBox) repeaterItem.FindControl("txt_quan")).Text = ((Label) repeaterItem.FindControl("lbl_quan")).Text.ToString();
        ((TextBox) repeaterItem.FindControl("txt_price")).Text = ((Label) repeaterItem.FindControl("lbl_unitprice")).Text.ToString();
        this.netQty = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString());
        this.price = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_price")).Text.ToString());
        this.hdnOriginalQuantityEdit.Value = this.netQty.ToString();
        this.hdnOriginalPriceEdit.Value = this.price.ToString();
        repeaterItem.FindControl("lbl_quan").Visible = false;
        repeaterItem.FindControl("lbl_unitprice").Visible = false;
        repeaterItem.FindControl("txt_quan").Visible = true;
        repeaterItem.FindControl("txt_price").Visible = true;
        repeaterItem.FindControl("spnQuanStar").Visible = true;
        repeaterItem.FindControl("spnPriceStar").Visible = true;
        repeaterItem.FindControl("ibtnCalculateArea").Visible = true;
        repeaterItem.FindControl("btn_Update").Visible = true;
        repeaterItem.FindControl("btn_edit").Visible = false;
        repeaterItem.FindControl("btn_cancel").Visible = true;
        this._dtTurfCareList = (DataTable) this.Session["dtTurfCareList"];
        ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:block");
        if (this._dtTurfCareList != null)
        {
          for (int index = 0; index < this._dtTurfCareList.Rows.Count; ++index)
          {
            if (((HiddenField) repeaterItem.FindControl("hdn_OrdNo")).Value.ToString() == this._dtTurfCareList.Rows[index]["OrderNo"].ToString())
            {
              ((WebControl) repeaterItem.FindControl("reg_qty")).Enabled = false;
              ((WebControl) repeaterItem.FindControl("rgval_qty")).Enabled = true;
              ((WebControl) repeaterItem.FindControl("reg_price")).Enabled = false;
              ((WebControl) repeaterItem.FindControl("rgval_price")).Enabled = true;
            }
          }
        }
      }
      if (e.CommandName == "cancel")
      {
        repeaterItem.FindControl("lbl_quan").Visible = true;
        repeaterItem.FindControl("lbl_unitprice").Visible = true;
        repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
        repeaterItem.FindControl("txt_quan").Visible = false;
        repeaterItem.FindControl("txt_price").Visible = false;
        repeaterItem.FindControl("spnQuanStar").Visible = false;
        repeaterItem.FindControl("spnPriceStar").Visible = false;
        repeaterItem.FindControl("btn_Update").Visible = false;
        repeaterItem.FindControl("btn_edit").Visible = true;
        repeaterItem.FindControl("btn_cancel").Visible = false;
        ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:none");
      }
      if (e.CommandName == "calculate")
      {
        TextBox control1 = (TextBox) e.Item.FindControl("txt_quan");
        Label control2 = (Label) e.Item.FindControl("lbl_unitprice");
        Label control3 = (Label) e.Item.FindControl("lbl_subtotal");
        LinkButton control4 = (LinkButton) repeaterItem.FindControl("ibtnCalculateArea");
        ((HtmlAnchor) repeaterItem.FindControl("aCalculateArea")).HRef = "GetAreaValue.aspx?txtTO=" + control1.Text + "&lblprice=" + control2.Text + "&lblsub=" + control3.Text;
      }
      if (!(e.CommandName == "update"))
        return;
      ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:none");
      this._dtTurfCareList = (DataTable) this.Session["dtTurfCareList"];
      if (this._dtTurfCareList != null)
      {
        for (int index = 0; index < this._dtTurfCareList.Rows.Count; ++index)
        {
          if (((HiddenField) repeaterItem.FindControl("hdn_OrdNo")).Value.ToString() == this._dtTurfCareList.Rows[index]["OrderNo"].ToString())
          {
            if (((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString() == "" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "0" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "0.00" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "00" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "01" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "02" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "03" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "04" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "05" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "06" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "07" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "08" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "09")
              return;
            this.quan = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString());
            this.subtotal = Convert.ToDouble(((Label) repeaterItem.FindControl("lbl_unitprice")).Text.ToString());
            double num = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_Price")).Text.ToString());
            if (num > 0.0)
            {
              this.total = this.quan * num;
              ((Label) repeaterItem.FindControl("lbl_subtotal")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.total);
              repeaterItem.FindControl("lbl_quan").Visible = true;
              repeaterItem.FindControl("lbl_unitprice").Visible = true;
              ((Label) repeaterItem.FindControl("lbl_quan")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.quan);
              ((Label) repeaterItem.FindControl("lbl_unitprice")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) num);
              repeaterItem.FindControl("txt_quan").Visible = false;
              repeaterItem.FindControl("txt_price").Visible = false;
              repeaterItem.FindControl("btn_Update").Visible = false;
              repeaterItem.FindControl("btn_edit").Visible = true;
              repeaterItem.FindControl("btn_cancel").Visible = false;
              repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
              repeaterItem.FindControl("spnQuanStar").Visible = false;
              repeaterItem.FindControl("spnPriceStar").Visible = false;
              this._dtTurfCareList.Rows[index].BeginEdit();
              this._dtTurfCareList.Rows[index]["Quantity"] = (object) ((Label) repeaterItem.FindControl("lbl_quan")).Text;
              this._dtTurfCareList.Rows[index]["Price"] = (object) ((Label) repeaterItem.FindControl("lbl_unitprice")).Text;
              this._dtTurfCareList.AcceptChanges();
              IEnumerable<string> strings = (IEnumerable<string>) this._dtTurfCareList.AsEnumerable().Select<DataRow, string>((System.Func<DataRow, string>) (dt => dt.Field<string>("TurfName")));
            }
            else
            {
              repeaterItem.FindControl("lbl_quan").Visible = true;
              repeaterItem.FindControl("lbl_unitprice").Visible = true;
              repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
              repeaterItem.FindControl("txt_quan").Visible = false;
              repeaterItem.FindControl("btn_Update").Visible = false;
              repeaterItem.FindControl("btn_edit").Visible = true;
              repeaterItem.FindControl("btn_cancel").Visible = false;
              ((Label) repeaterItem.FindControl("lbl_quan")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.hdnOriginalQuantityEdit.Value);
              ((Label) repeaterItem.FindControl("lbl_unitprice")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.hdnOriginalPriceEdit.Value);
              System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format("Turf Price is not defined for this Area size."), (Enums.NotificationType) 2), true);
            }
          }
        }
      }
      this.Session["dtTurfCareList"] = (object) this._dtTurfCareList;
      ((Label) this.rptTurfCareList.Controls[this.rptTurfCareList.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtTurfCareList, (DataTable) this.Session["dtTurfCareList"]);
      this.SetCartValue();
    }

    private void SetCartValue()
    {
      int num1 = 0;
      int num2 = 0;
      this._dtTurfCareList = (DataTable) this.Session["dtTurfCareList"];
      this._dtTurfList = (DataTable) this.Session["dtTurfList"];
      if (this._dtTurfCareList != null && this._dtTurfCareList.Rows.Count > 0)
        num1 = ((IEnumerable<DataRow>) this._dtTurfCareList.Select("Quantity <> '0.00'")).Count<DataRow>();
      if (this._dtTurfList != null && this._dtTurfList.Rows.Count > 0)
        num2 = ((IEnumerable<DataRow>) this._dtTurfList.Select("Quantity <> '0.00'")).Count<DataRow>();
      int num3 = num1 + num2;
      Label control = (Label) this.AdminPurchaseProcess1.FindControl("ltradmin_cart");
      control.Text = "Cart (" + num3.ToString() + ")";
      control.ToolTip = "Cart (" + num3.ToString() + ")";
    }

    protected void BtnAddtoCart_Click(object sender, ImageClickEventArgs e)
    {
      if ((DataTable) this.Session["dtTurfList"] == null || (DataTable) this.Session["dtTurfCareList"] == null)
        return;
      this._dtAdminCART.Merge((DataTable) this.Session["dtTurfList"]);
      this._dtAdminCART.Merge((DataTable) this.Session["dtTurfCareList"]);
      if (this._dtAdminCART.Rows.Count > 0)
      {
        foreach (DataRow row in this._dtAdminCART.Select("Quantity = '0.00'"))
          this._dtAdminCART.Rows.Remove(row);
        this.Session["dtAdminCART"] = (object) this._dtAdminCART;
        if (this._dtAdminCART.Rows.Count > 0)
        {
          this.SetCartValue(this._dtAdminCART);
          this.Response.Redirect("~/Admin/AdminCheckoutPage.aspx");
        }
        else
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format("Area size is not defined."), (Enums.NotificationType) 2), true);
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format("Area size is not defined."), (Enums.NotificationType) 2), true);
    }

    protected void SetCartValue(DataTable dtAdminCART)
    {
      Label control = (Label) this.AdminPurchaseProcess1.FindControl("ltradmin_cart");
      control.Text = "Cart (" + dtAdminCART.Rows.Count.ToString() + ")";
      control.ToolTip = "Cart (" + dtAdminCART.Rows.Count.ToString() + ")";
    }
  }
}
