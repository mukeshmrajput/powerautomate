﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateDeliveryPrice
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.NonTurfProductPricing.DeliveryPrices;
using Entity.Common.ProductPricing.NonTurfProductPricing.DeliveryPrice;
using Entity.Response.ProductPricing.NonTurfProductPricing.DeliveryPrice;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateDeliveryPrice : Page
  {
    public static long fDeliveryPriceID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected DropDownList ddlDeliveryRegion;
    protected RequiredFieldValidator rfvDeliveryRegion;
    protected DropDownList ddlQuantityRange;
    protected RequiredFieldValidator rfvQuantityRange;
    protected TextBox txtRetailDeliveryFee;
    protected RequiredFieldValidator rfvRetailDeliveryFee;
    protected RegularExpressionValidator regRetailDeliveryFee;
    protected TextBox txtTradeDeliveryFee;
    protected RequiredFieldValidator rfvTradeDeliveryFee;
    protected RegularExpressionValidator regTradeDeliveryFee;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnDeliveryPriceID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewDeliveryPrice");
      if (this.Request.QueryString[QueryStrings.DeliveryPriceID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strAddDeliveryPrice;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        AddUpdateDeliveryPrice.fDeliveryPriceID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.DeliveryPriceID].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddDeliveryPrice;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateDeliveryPrice.fDeliveryPriceID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.BindDropdown();
        this.ValidationExpression();
        if (AddUpdateDeliveryPrice.fDeliveryPriceID > 0L)
          this.GetDeliveryPriceDetails(DeliveryPriceMgmt.GetDeliveryPriceDetailByID(Convert.ToInt64(AddUpdateDeliveryPrice.fDeliveryPriceID)));
      }
      this.ddlDeliveryRegion.Focus();
    }

    protected void GetDeliveryPriceDetails(DeliveryPriceResponseBE objDeliveryPriceBE)
    {
      this.ddlQuantityRange.SelectedValue = Convert.ToString(objDeliveryPriceBE.QuantityRangeID);
      this.ddlDeliveryRegion.SelectedValue = Convert.ToString(objDeliveryPriceBE.DeliveryRegionID);
      this.txtRetailDeliveryFee.Text = Convert.ToString(objDeliveryPriceBE.RetailDeliveryFees);
      this.txtTradeDeliveryFee.Text = Convert.ToString(objDeliveryPriceBE.TradeDeliveryFees);
      this.chkIsActive.Checked = Convert.ToBoolean(objDeliveryPriceBE.IsActive);
    }

    protected void BindDropdown()
    {
      BindDropDown.BindDeliveryRegion((ListControl) this.ddlDeliveryRegion);
      BindDropDown.BindQuantityRange((ListControl) this.ddlQuantityRange);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      DeliveryPriceBE deliveryPriceBe = new DeliveryPriceBE();
      deliveryPriceBe.DeliveryPriceID = AddUpdateDeliveryPrice.fDeliveryPriceID <= 0L ? 0L : AddUpdateDeliveryPrice.fDeliveryPriceID;
      deliveryPriceBe.DeliveryRegionID = Convert.ToInt64(this.ddlDeliveryRegion.SelectedValue);
      deliveryPriceBe.QuantityRangeID = Convert.ToInt64(this.ddlQuantityRange.SelectedValue);
      deliveryPriceBe.RetailDeliveryFees = Convert.ToDecimal(this.txtRetailDeliveryFee.Text.Trim());
      deliveryPriceBe.TradeDeliveryFees = Convert.ToDecimal(this.txtTradeDeliveryFee.Text.Trim());
      deliveryPriceBe.IsActive = this.chkIsActive.Checked;
      deliveryPriceBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      deliveryPriceBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      long num = DeliveryPriceMgmt.AddUpdateDeliveryPrice(deliveryPriceBe);
      if (num > 0L)
      {
        if (deliveryPriceBe.DeliveryPriceID > 0L)
          this.Session["DeliveryPriceAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddDeliveryPrice);
        else if (deliveryPriceBe.DeliveryPriceID == 0L)
          this.Session["DeliveryPriceAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddDeliveryPrice);
        this.Response.Redirect("~/Admin/ViewDeliveryPrice.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Service Region"), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorDropdown(this.rfvDeliveryRegion, true, (object) this.ddlDeliveryRegion, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvQuantityRange, true, (object) this.ddlQuantityRange, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvRetailDeliveryFee, true, (object) this.txtRetailDeliveryFee, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regRetailDeliveryFee, Regex.AmountPrice, true, (object) this.txtRetailDeliveryFee, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTradeDeliveryFee, true, (object) this.txtTradeDeliveryFee, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTradeDeliveryFee, Regex.AmountPrice, true, (object) this.txtTradeDeliveryFee, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
