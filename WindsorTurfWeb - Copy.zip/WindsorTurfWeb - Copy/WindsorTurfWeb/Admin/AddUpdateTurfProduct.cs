﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateTurfProduct
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Common.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateTurfProduct : Page
  {
    public int rowCount = 0;
    public long fTurfProductID = 0;
    public long UserId;
    public string TurfOriginalImagePath = ConfigurationManager.AppSettings[nameof (TurfOriginalImagePath)];
    public string TurfThumbImagePath = ConfigurationManager.AppSettings[nameof (TurfThumbImagePath)];
    public string TurfShopPageImagePath = ConfigurationManager.AppSettings[nameof (TurfShopPageImagePath)];
    public string TurfContentPageImagePath = ConfigurationManager.AppSettings[nameof (TurfContentPageImagePath)];
    public string TurfCartPageImagePath = ConfigurationManager.AppSettings[nameof (TurfCartPageImagePath)];
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected TextBox txtTurfName;
    protected RequiredFieldValidator rfvTurfName;
    protected RegularExpressionValidator regTurfName;
    protected TextBox txtTurfPageName;
    protected RequiredFieldValidator rfvTurfPageName;
    protected RegularExpressionValidator regTurfPageName;
    protected DropDownList ddlTurfClassification;
    protected RequiredFieldValidator rfvTurfClassification;
    protected TextBox txtimgTurf;
    protected FileUpload fldTurf;
    protected HtmlAnchor lnkTurfImage;
    protected HtmlAnchor lnkTurfThumb;
    protected System.Web.UI.WebControls.Image ImgThumb;
    protected Button btnTurfImageDelete;
    protected RequiredFieldValidator rfvTurfImage;
    protected HiddenField hdnDivTurfImage;
    protected HiddenField hdnTurfImageDoc;
    protected HiddenField hdnTurfImageCancel;
    protected HiddenField hdnTurfImageName;
    protected HiddenField hdnUploadType;
    protected HiddenField hdnDocName;
    protected HtmlGenericControl divDescription;
    protected RadEditor redBodyDescription;
    protected RequiredFieldValidator rfvDescription;
    protected HtmlGenericControl divUses;
    protected RadEditor redBodyUses;
    protected RequiredFieldValidator rfvUses;
    protected HtmlGenericControl divMaintenance;
    protected RadEditor redBodyMaintenance;
    protected RequiredFieldValidator rfvMaintenance;
    protected HtmlGenericControl divCharacteristics;
    protected RadEditor redBodyCharacteristics;
    protected RequiredFieldValidator rfvCharacteristics;
    protected TextBox txtPageTitle;
    protected RequiredFieldValidator rfvPageTitle;
    protected RegularExpressionValidator regPageTitle;
    protected TextBox txtMetaDescription;
    protected RequiredFieldValidator rfvMetaDescription;
    protected RegularExpressionValidator regMetaDescription;
    protected TextBox txtMetaKeywords;
    protected RequiredFieldValidator rfvMetaKeywords;
    protected RegularExpressionValidator regMetaKeywords;
    protected CheckBox chkIsActive;
    protected CheckBox chkIsStockAvailable;
    protected Button btnSubmit;
    protected Button btnCancel;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewTurfProduct");
      this.txtTurfName.Focus();
      if (this.Request.QueryString[QueryStrings.TurfProductID] != null)
        this.fTurfProductID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.TurfProductID].ToString()));
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.Page.IsPostBack)
        return;
      this.ValidationExpression();
      this.BindDropdown();
      if (this.Request.QueryString[QueryStrings.TurfProductID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strAddTurfProduct;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        this.fTurfProductID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.TurfProductID].ToString()));
        this.FillData(TurfProductMgmt.GetTurfProductDetailByID(Convert.ToInt64(this.fTurfProductID)));
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddTurfProduct;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
      }
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvTurfName, true, (object) this.txtTurfName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTurfName, Regex.Title, true, (object) this.txtTurfName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTurfPageName, true, (object) this.txtTurfPageName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTurfPageName, Regex.Title, true, (object) this.txtTurfPageName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvTurfClassification, true, (object) this.ddlTurfClassification, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvDescription, true, (object) this.redBodyDescription, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvUses, true, (object) this.redBodyUses, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvMaintenance, true, (object) this.redBodyMaintenance, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvCharacteristics, true, (object) this.redBodyCharacteristics, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvPageTitle, true, (object) this.txtPageTitle, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regPageTitle, Regex.Title, true, (object) this.txtPageTitle, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvMetaDescription, true, (object) this.txtMetaDescription, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regMetaDescription, Regex.MetaKeyword, true, (object) this.txtTurfName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvMetaKeywords, true, (object) this.txtMetaKeywords, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regMetaKeywords, Regex.MetaKeyword, true, (object) this.txtMetaKeywords, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTurfImage, true, (object) this.txtimgTurf, this.strValidationTurfGrp);
      this.fldTurf.Attributes.Add("OnChange", "return UploadFileSelect('" + this.fldTurf.ClientID + "','" + this.txtimgTurf.ClientID + "', this, 'turf product');");
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }

    protected void FillData(TurfProductResponseBE objTurfProduct)
    {
      if (objTurfProduct == null)
        return;
      this.txtTurfName.Text = objTurfProduct.TurfName;
      this.txtTurfPageName.Text = objTurfProduct.TurfLinkURL.ToString().Replace("-", " ").Replace("Turf_Type_", "").Replace("%%%", "'");
      this.txtPageTitle.Text = objTurfProduct.PageTitle;
      this.txtMetaKeywords.Text = objTurfProduct.MetaKeyword;
      this.txtMetaDescription.Text = objTurfProduct.MetaDescription;
      this.ddlTurfClassification.SelectedValue = Convert.ToString(objTurfProduct.TurfClassificationID);
      this.redBodyUses.Content = objTurfProduct.Uses;
      this.redBodyMaintenance.Content = objTurfProduct.Maintenance;
      this.redBodyCharacteristics.Content = objTurfProduct.Characteristics;
      this.redBodyDescription.Content = objTurfProduct.Description;
      this.chkIsActive.Checked = Convert.ToBoolean(objTurfProduct.IsActive);
      if (!string.IsNullOrEmpty(objTurfProduct.MainImage) && objTurfProduct.MainImage != "none")
      {
        this.hdnTurfImageDoc.Value = "block";
        this.hdnDivTurfImage.Value = "none";
        this.hdnTurfImageCancel.Value = "block";
        this.hdnTurfImageName.Value = objTurfProduct.MainImage;
        this.lnkTurfImage.HRef = ConfigurationManager.AppSettings["LivePath"] + this.TurfOriginalImagePath + objTurfProduct.MainImage;
        this.lnkTurfImage.Target = "_blank";
        this.ImgThumb.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.TurfOriginalImagePath + objTurfProduct.MainImage;
        this.lnkTurfThumb.HRef = ConfigurationManager.AppSettings["LivePath"] + this.TurfOriginalImagePath + objTurfProduct.MainImage;
        this.lnkTurfThumb.Visible = true;
        this.rfvTurfImage.Enabled = false;
      }
      else
      {
        this.hdnTurfImageDoc.Value = "none";
        this.hdnDivTurfImage.Value = "block";
        this.hdnTurfImageCancel.Value = "none";
        this.hdnTurfImageName.Value = "";
        this.rfvTurfImage.Enabled = true;
      }
    }

    protected void BindDropdown() => BindDropDown.GetAllTurfClassificationForDropDown((ListControl) this.ddlTurfClassification);

    private bool ImageValidationMessage()
    {
      string str = this.fldTurf.FileName.Substring(this.fldTurf.FileName.LastIndexOf(".") + 1).ToLower();
      str = string.Empty;
      string lower = this.fldTurf.FileName.Substring(this.fldTurf.FileName.LastIndexOf(".") + 1).ToLower();
      if (Regex.UploadImage.Contains(lower) && !string.IsNullOrEmpty(lower))
      {
        if (this.fldTurf.FileContent.Length > 2097152L)
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "News"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      else
      {
        if (string.IsNullOrEmpty(lower) && string.IsNullOrEmpty(this.hdnTurfImageName.Value))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "News"), (Enums.NotificationType) 2, false), true);
          return false;
        }
        if (!string.IsNullOrEmpty(lower))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "News"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      return true;
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewTurfProduct.aspx");

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid || !this.ImageValidationMessage())
        return;
      TurfProductBE turfProductBe = new TurfProductBE();
      turfProductBe.CreatedBy = Convert.ToInt64(this.UserId);
      turfProductBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      turfProductBe.TurfProductID = this.fTurfProductID <= 0L ? 0L : this.fTurfProductID;
      turfProductBe.TurfName = this.txtTurfName.Text.Trim();
      turfProductBe.TurfLinkURL = this.txtTurfPageName.Text.Replace(" ", "-").Replace("'", "%%%");
      turfProductBe.TurfClassificationID = Convert.ToInt64(this.ddlTurfClassification.SelectedValue);
      turfProductBe.IsActive = this.chkIsActive.Checked;
      turfProductBe.IsStockAvailable = this.chkIsStockAvailable.Checked;
      turfProductBe.Description = this.redBodyDescription.Content.Trim();
      turfProductBe.Uses = this.redBodyUses.Content.Trim();
      turfProductBe.Maintenance = this.redBodyMaintenance.Content.Trim();
      turfProductBe.Characteristics = this.redBodyCharacteristics.Content.Trim();
      turfProductBe.PageTitle = this.txtPageTitle.Text.Trim();
      turfProductBe.MetaDescription = this.txtMetaDescription.Text.Trim();
      turfProductBe.MetaKeyword = this.txtMetaKeywords.Text.Trim();
      string empty = string.Empty;
      if (!string.IsNullOrEmpty(this.fldTurf.FileName))
      {
        if (this.fldTurf.FileName.Length > 0)
        {
          string[] strArray = this.fldTurf.FileName.Split('\\');
          string FileName = UtilityFunctions.ChangeFileName(strArray[strArray.Length - 1].ToString());
          string extension = Path.GetExtension(this.fldTurf.FileName);
          if (extension == ".jpeg" || extension == ".JPEG" || extension == ".png" || extension == ".PNG" || extension == ".jpg" || extension == ".JPG" || extension == ".bmp" || extension == ".BMP" || extension == ".gif" || extension == ".GIF")
          {
            System.Drawing.Image image = System.Drawing.Image.FromStream(this.fldTurf.PostedFile.InputStream);
            int height = image.Height;
            int width = image.Width;
            this.fldTurf.SaveAs(this.Server.MapPath("~/") + this.TurfOriginalImagePath + FileName);
            Resizer.FixedSize(FileName, this.fldTurf, this.TurfThumbImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["TurfThumbImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["TurfThumbImageHeight"]));
            Resizer.FixedSize(FileName, this.fldTurf, this.TurfShopPageImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["TurfShopPageImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["TurfShopPageImageHeight"]));
            Resizer.FixedSize(FileName, this.fldTurf, this.TurfCartPageImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["TurfCartPageImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["TurfCartPageImageHeight"]));
            Resizer.FixedSize(FileName, this.fldTurf, this.TurfContentPageImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["TurfContentPageImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["TurfContentPageImageHeight"]));
          }
          else
            this.fldTurf.SaveAs(this.Server.MapPath("~/") + this.TurfOriginalImagePath + FileName);
          turfProductBe.MainImage = FileName;
          if (!string.IsNullOrEmpty(this.hdnTurfImageName.Value))
          {
            FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.TurfOriginalImagePath + this.hdnTurfImageName.Value);
            if (fileInfo.Exists)
              fileInfo.Delete();
          }
        }
      }
      else
        turfProductBe.MainImage = this.hdnTurfImageName.Value;
      turfProductBe.IsActive = this.chkIsActive.Checked;
      long num = TurfProductMgmt.AddUpdateTurfProduct(turfProductBe);
      if (num > 0L)
      {
        if (this.fTurfProductID > 0L)
          this.Session["TurfProductAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddTurfProduct);
        else
          this.Session["TurfProductAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddTurfProduct);
        this.Response.Redirect("~/Admin/ViewTurfProduct.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Turf Name"), (Enums.NotificationType) 2, false), true);
    }

    protected void btnTurfImageDelete_Click(object sender, EventArgs e)
    {
      FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.TurfOriginalImagePath + this.hdnTurfImageName.Value);
      if (!fileInfo.Exists)
        return;
      fileInfo.Delete();
      TurfProductMgmt.DeleteTurfImageByID(this.fTurfProductID);
      this.hdnTurfImageDoc.Value = "none";
      this.hdnDivTurfImage.Value = "block";
      this.hdnTurfImageCancel.Value = "none";
      this.hdnTurfImageName.Value = "none";
      this.rfvTurfImage.Enabled = true;
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) "Product Image"), (Enums.NotificationType) 1), true);
    }
  }
}
