﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AdminMaster
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using AjaxControlToolkit;
using Helper;
using System;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class AdminMaster : MasterPage
  {
    protected ContentPlaceHolder head;
    protected HtmlForm form1;
    protected ToolkitScriptManager ToolkitScriptManager1;
    protected Literal ltrUserName;
    protected HtmlGenericControl dvSettings;
    protected HtmlAnchor aTopSettings;
    protected LinkButton lnkLogOut;
    protected HtmlGenericControl divMainMenus;
    protected HtmlAnchor aDashboard;
    protected HtmlGenericControl liPageManagement;
    protected HtmlAnchor aPageManagement;
    protected HtmlGenericControl LiBannerManagement;
    protected HtmlAnchor aBannerManagement;
    protected HtmlGenericControl liUserManagement;
    protected HtmlAnchor aUserManagement;
    protected HtmlGenericControl liNewsManagement;
    protected HtmlAnchor aNewsManagement;
    protected HtmlGenericControl liTurfProductManagement;
    protected HtmlAnchor aTurfProductManagement;
    protected HtmlGenericControl liProductPricing;
    protected HtmlAnchor aProductPricing;
    protected HtmlGenericControl liCommercialRegistrationApproval;
    protected HtmlAnchor aCommercialPartner;
    protected HtmlGenericControl liNewsletterList;
    protected HtmlAnchor aNewsletterList;
    protected HtmlGenericControl liCausalCommercialPurchaseDetail;
    protected HtmlAnchor aCausalCommercialPurchaseDetail;
    protected HtmlGenericControl liOrdersPaymentConfirmation;
    protected HtmlAnchor aOrdersPaymentConfirmation;
    protected HtmlGenericControl liQuoteDetail;
    protected HtmlAnchor aQuoteDetail;
    protected HtmlGenericControl liGalleryManagement;
    protected HtmlAnchor aGalleryManagement;
    protected HtmlGenericControl liTestimonials;
    protected HtmlAnchor aTestimonials;
    protected ContentPlaceHolder ContentPlaceHolder1;
    protected AdminLoadingCntrl AdminLoadingCntrl1;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.aTopSettings.HRef = "~/Admin/SiteConfiguration.aspx";
      this.ltrUserName.Text = "Welcome: <span class='themecolor'>" + PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 2)) + "</span>";
      if (string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))))
        return;
      Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)));
      UtilityFunctions.SetUserModuleAccess(this.divMainMenus);
    }

    protected void lnkLogOut_Click(object sender, EventArgs e)
    {
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))))
        Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      Guid.NewGuid().ToString();
      FormsAuthentication.SignOut();
      this.Session.Clear();
      this.Session.Abandon();
      this.Response.Redirect("~/Admin/Default.aspx", false);
    }
  }
}
