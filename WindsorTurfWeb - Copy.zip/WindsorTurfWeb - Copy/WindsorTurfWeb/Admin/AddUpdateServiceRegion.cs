﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateServiceRegion
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.TurfProductPricing.ServiceRegions;
using Entity.Common.ProductPricing.TurfProductPricing.ServiceRegions;
using Entity.Response.ProductPricing.TurfProductPricing.ServiceRegions;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateServiceRegion : Page
  {
    private long fServiceRegionID = 0;
    public string strValidationTurfGrp = "addGroup";
    protected HtmlGenericControl h1Title;
    protected TextBox txtRegionName;
    protected RequiredFieldValidator rfvRegionName;
    protected RegularExpressionValidator regRegionName;
    protected DropDownList ddlTurfZone;
    protected RequiredFieldValidator rfvTurfZone;
    protected CheckBox chkIsActive;
    protected Repeater rptPostCodeRanges;
    protected Button btnSubmit;
    protected HiddenField hdnServiceRegionID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewServiceRegion");
      this.ValidationExpression();
      if (!string.IsNullOrEmpty(this.Request.QueryString["ServiceRegionID"]))
      {
        this.fServiceRegionID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["ServiceRegionID"]));
        this.hdnServiceRegionID.Value = Convert.ToString(this.Request.QueryString["ServiceRegionID"]);
      }
      if (this.Page.IsPostBack)
        return;
      BindDropDown.BindTurfZone((ListControl) this.ddlTurfZone);
      if (this.fServiceRegionID > 0L)
      {
        this.h1Title.InnerText = "Edit Service Region";
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        ServiceRegionResponseBE regionResponseBe = new ServiceRegionResponseBE();
        this.GetServiceRegionDetails(ServiceRegionMgmt.GetServiceRegionDetailByID(this.fServiceRegionID));
      }
      else
      {
        this.BindDefaultRows();
        this.h1Title.InnerText = "Add Service Region";
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
      }
      if (!string.IsNullOrEmpty(this.Request.QueryString["ServiceRegionID"]))
      {
        for (int index = 1; index < Convert.ToInt32(this.rptPostCodeRanges.Items.Count); ++index)
        {
          TextBox control1 = (TextBox) this.rptPostCodeRanges.Items[index - 1].FindControl("txtRangeEndIndex");
          TextBox control2 = (TextBox) this.rptPostCodeRanges.Items[index - 1].FindControl("txtRangeName");
          CompareValidator control3 = (CompareValidator) this.rptPostCodeRanges.Items[index].FindControl("cmpEndStartIndex");
          control3.ValueToCompare = control1.Text;
          control3.ErrorMessage = "Start Index must be greater than from " + control2.Text + " End Index";
        }
      }
    }

    private void ValidationExpression()
    {
      this.rfvRegionName.ErrorMessage = string.Format(Validation.Required);
      this.regRegionName.ValidationExpression = Regex.Title;
      this.rfvTurfZone.ErrorMessage = string.Format(Validation.Required);
      this.regRegionName.ErrorMessage = string.Format(Validation.Invalid1);
    }

    private void GetServiceRegionDetails(ServiceRegionResponseBE objServiceRegionResponse)
    {
      if (objServiceRegionResponse.ServiceRegionID <= 0L)
        return;
      HiddenField hdnServiceRegionId = this.hdnServiceRegionID;
      long num = objServiceRegionResponse.ServiceRegionID;
      string str1 = num.ToString();
      hdnServiceRegionId.Value = str1;
      this.txtRegionName.Text = objServiceRegionResponse.ServiceRegionName;
      List<ServiceRegionRangeInfo> serviceRegionRangeInfoList = new List<ServiceRegionRangeInfo>();
      this.rptPostCodeRanges.DataSource = (object) ServiceRegionMgmt.GetServiceRegionRangeDetailByID(Convert.ToInt64(objServiceRegionResponse.ServiceRegionID));
      this.rptPostCodeRanges.DataBind();
      DropDownList ddlTurfZone = this.ddlTurfZone;
      num = objServiceRegionResponse.TurfZoneID;
      string str2 = num.ToString();
      ddlTurfZone.SelectedValue = str2;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      ServiceRegionBE serviceRegionBe = new ServiceRegionBE();
      serviceRegionBe.ServiceRegionID = this.fServiceRegionID <= 0L ? 0L : this.fServiceRegionID;
      serviceRegionBe.ServiceRegionName = this.txtRegionName.Text.Trim();
      serviceRegionBe.TurfZoneID = Convert.ToInt64(this.ddlTurfZone.SelectedValue);
      serviceRegionBe.IsActive = this.chkIsActive.Checked;
      serviceRegionBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      serviceRegionBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      DataTable dtRange = new DataTable();
      if (this.rptPostCodeRanges.Items.Count > 0)
      {
        dtRange = this.AddColumns(dtRange);
        for (int index = 0; index < this.rptPostCodeRanges.Items.Count; ++index)
        {
          DataRow row = dtRange.NewRow();
          row["RangeName"] = (object) (this.rptPostCodeRanges.Items[index].FindControl("txtRangeName") as TextBox).Text;
          row["RangeStartIndex"] = (object) Convert.ToDecimal((this.rptPostCodeRanges.Items[index].FindControl("txtRangeStartIndex") as TextBox).Text);
          row["RangeEndIndex"] = (object) (this.rptPostCodeRanges.Items[index].FindControl("txtRangeEndIndex") as TextBox).Text;
          dtRange.Rows.Add(row);
        }
      }
      serviceRegionBe.dtServiceRegionRange = dtRange;
      if (ServiceRegionMgmt.AddUpdateServiceRegion(serviceRegionBe) > 0L)
      {
        if (serviceRegionBe.ServiceRegionID > 0L)
          this.Session["ServiceRegionAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) "Service Region");
        else if (serviceRegionBe.ServiceRegionID == 0L)
          this.Session["ServiceRegionAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) "Service Region");
        this.Response.Redirect("~/Admin/ViewServiceRegion.aspx");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Service Region"), (Enums.NotificationType) 2, false), true);
    }

    protected void rptPostCodeRanges_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.AlternatingItem && e.Item.ItemType != ListItemType.Item)
        return;
      Button control1 = e.Item.FindControl("btnrptAddRow") as Button;
      Button control2 = e.Item.FindControl("btnrptRemoveRow") as Button;
      if (e.Item.ItemIndex == 0)
      {
        control1.Visible = true;
        control2.Visible = false;
      }
      else
      {
        control1.Visible = false;
        control2.Visible = true;
        control2.CommandArgument = e.Item.ItemIndex.ToString();
      }
      if (this.rptPostCodeRanges.Items.Count == 10)
        control1.Visible = false;
      RequiredFieldValidator control3 = e.Item.FindControl("rfvRangeStartIndex") as RequiredFieldValidator;
      RequiredFieldValidator control4 = e.Item.FindControl("rfvRangeEndIndex") as RequiredFieldValidator;
      RequiredFieldValidator control5 = e.Item.FindControl("rfvRangeName") as RequiredFieldValidator;
      control3.ErrorMessage = string.Format(Validation.Required);
      control4.ErrorMessage = string.Format(Validation.Required);
      control5.ErrorMessage = string.Format(Validation.Required);
      TextBox control6 = e.Item.FindControl("txtRangeName") as TextBox;
      string script1 = "$(document).ready(function () { $('#" + control6.ClientID.ToString() + "').watermark('Range Name'); });";
      System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, typeof (string), control6.ClientID.ToString(), script1, true);
      TextBox control7 = e.Item.FindControl("txtRangeStartIndex") as TextBox;
      AttributeCollection attributes1 = control7.Attributes;
      int itemIndex = e.Item.ItemIndex;
      string str1 = "javascript:RangeCheck('1','" + itemIndex.ToString() + "')";
      attributes1.Add("onBlur", str1);
      string script2 = "$(document).ready(function () { $('#" + control7.ClientID.ToString() + "').watermark('Start Index'); });";
      System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, typeof (string), control7.ClientID.ToString(), script2, true);
      TextBox control8 = e.Item.FindControl("txtRangeEndIndex") as TextBox;
      AttributeCollection attributes2 = control8.Attributes;
      itemIndex = e.Item.ItemIndex;
      string str2 = "javascript:RangeCheck('2','" + itemIndex.ToString() + "')";
      attributes2.Add("onBlur", str2);
      string script3 = "$(document).ready(function () { $('#" + control8.ClientID.ToString() + "').watermark('End Index'); });";
      System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, typeof (string), control8.ClientID.ToString(), script3, true);
      CompareValidator control9 = (CompareValidator) e.Item.FindControl("cmpEndStartIndex");
      int num = 0;
      if (control9 != null)
        control9.ValueToCompare = num.ToString();
    }

    protected void rptPostCodeRanges_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
      if (!(e.CommandName == "btnrptRemoveRow"))
        return;
      this.RemoveRow(Convert.ToInt32(e.CommandArgument.ToString()));
    }

    protected void btnrptAddRow_Click(object sender, EventArgs e)
    {
      DataTable dataTable = this.BindDatatable(this.AddColumns(new DataTable()));
      if (dataTable.Rows.Count < 10)
      {
        DataRow row = dataTable.NewRow();
        row["RangeName"] = (object) string.Empty;
        row["RangeStartIndex"] = (object) string.Empty;
        row["RangeEndIndex"] = (object) string.Empty;
        dataTable.Rows.Add(row);
        this.rptPostCodeRanges.DataSource = (object) dataTable;
        this.rptPostCodeRanges.DataBind();
      }
      if (!string.IsNullOrEmpty(this.Request.QueryString["ServiceRegionID"]))
        return;
      for (int index = 1; index < Convert.ToInt32(this.rptPostCodeRanges.Items.Count); ++index)
      {
        TextBox control1 = (TextBox) this.rptPostCodeRanges.Items[index - 1].FindControl("txtRangeEndIndex");
        TextBox control2 = (TextBox) this.rptPostCodeRanges.Items[index - 1].FindControl("txtRangeName");
        CompareValidator control3 = (CompareValidator) this.rptPostCodeRanges.Items[index].FindControl("cmpEndStartIndex");
        if (!string.IsNullOrEmpty(control1.Text))
        {
          control3.ValueToCompare = control1.Text;
          control3.ErrorMessage = "Start Index must be greater than from " + control2.Text + " End Index";
        }
      }
    }

    private void BindDefaultRows()
    {
      DataTable dataTable = new DataTable("ServiceRegionRangeInfo");
      dataTable.Columns.Add(new DataColumn("RangeName", typeof (string)));
      dataTable.Columns.Add(new DataColumn("RangeStartIndex", typeof (string)));
      dataTable.Columns.Add(new DataColumn("RangeEndIndex", typeof (string)));
      for (int index = 1; index < 2; ++index)
      {
        DataRow row = dataTable.NewRow();
        row["RangeName"] = (object) string.Empty;
        row["RangeStartIndex"] = (object) string.Empty;
        row["RangeEndIndex"] = (object) string.Empty;
        dataTable.Rows.Add(row);
      }
      this.rptPostCodeRanges.DataSource = (object) dataTable;
      this.rptPostCodeRanges.DataBind();
    }

    private void RemoveRow(int index)
    {
      DataTable dataTable = this.BindDatatable(this.AddColumns(new DataTable()));
      if (dataTable.Rows.Count == 1)
        return;
      dataTable.Rows.RemoveAt(index);
      this.rptPostCodeRanges.DataSource = (object) dataTable;
      this.rptPostCodeRanges.DataBind();
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) PageName.strPostCodeRange), (Enums.NotificationType) 1), true);
    }

    private DataTable BindDatatable(DataTable dt)
    {
      foreach (RepeaterItem repeaterItem in this.rptPostCodeRanges.Items)
      {
        if (repeaterItem.ItemType == ListItemType.AlternatingItem || repeaterItem.ItemType == ListItemType.Item)
        {
          DataRow row = dt.NewRow();
          dt.Rows.Add(row);
          TextBox control1 = (TextBox) repeaterItem.FindControl("txtRangeName");
          TextBox control2 = (TextBox) repeaterItem.FindControl("txtRangeStartIndex");
          TextBox control3 = (TextBox) repeaterItem.FindControl("txtRangeEndIndex");
          if (!string.IsNullOrEmpty(control1.Text) && !string.IsNullOrEmpty(control2.Text) && !string.IsNullOrEmpty(control3.Text))
          {
            dt.Rows[repeaterItem.ItemIndex]["RangeName"] = (object) control1.Text.Trim();
            dt.Rows[repeaterItem.ItemIndex]["RangeStartIndex"] = (object) Convert.ToInt32(control2.Text.Trim());
            dt.Rows[repeaterItem.ItemIndex]["RangeEndIndex"] = (object) Convert.ToInt32(control3.Text.Trim());
          }
          else
          {
            dt.Rows[repeaterItem.ItemIndex]["RangeName"] = (object) "";
            dt.Rows[repeaterItem.ItemIndex]["RangeStartIndex"] = (object) "";
            dt.Rows[repeaterItem.ItemIndex]["RangeEndIndex"] = (object) "";
          }
        }
      }
      return dt;
    }

    private void AddRow()
    {
      DataTable dataTable = this.AddColumns(new DataTable());
      DataRow row = dataTable.NewRow();
      row["RangeName"] = (object) string.Empty;
      row["RangeStartIndex"] = (object) string.Empty;
      row["RangeEndIndex"] = (object) string.Empty;
      dataTable.Rows.Add(row);
      this.rptPostCodeRanges.DataSource = (object) dataTable;
      this.rptPostCodeRanges.DataBind();
    }

    private DataTable AddColumns(DataTable dtRange)
    {
      dtRange.Columns.Add(new DataColumn("RangeName", typeof (string)));
      dtRange.Columns.Add(new DataColumn("RangeStartIndex", typeof (string)));
      dtRange.Columns.Add(new DataColumn("RangeEndIndex", typeof (string)));
      return dtRange;
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) PageName.strPostCodeRange) + "')";
  }
}
