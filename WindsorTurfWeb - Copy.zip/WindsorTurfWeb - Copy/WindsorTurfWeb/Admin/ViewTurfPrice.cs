﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewTurfPrice
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.TurfProductPricing.TurfPricing;
using Entity.Request.ProductPricing.TurfProductPricing.TurfPricing;
using Entity.Response.ProductPricing.TurfProductPricing.TurfPricing;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewTurfPrice : Page
  {
    public long UserId;
    private TurfPriceListRequest objTurfPriceListRequest = new TurfPriceListRequest();
    protected ProductPricingSubMenus ProductPricingSubMenus1;
    protected HtmlGenericControl H1Title;
    protected TurfProductSubMenus TurfProductSubMenus1;
    protected RadGrid grdTurfPrice;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendupdateStatus;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewTurfPrice");
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["TurfPriceAddUpdate"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["TurfPriceAddUpdate"]), (Enums.NotificationType) 1), true);
        this.Session["TurfPriceAddUpdate"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<TurfPriceResponseBE> turfPriceResponseBeList = new List<TurfPriceResponseBE>();
      List<TurfPriceResponseBE> allTurfPrice = TurfPriceMgmt.GetAllTurfPrice();
      this.grdTurfPrice.VirtualItemCount = allTurfPrice.Count<TurfPriceResponseBE>();
      ((BaseDataBoundControl) this.grdTurfPrice).DataSource = (object) allTurfPrice;
      ((Control) this.grdTurfPrice).DataBind();
      if (allTurfPrice.Count<TurfPriceResponseBE>() == 0)
        this.grdTurfPrice.AllowFilteringByColumn = false;
      ViewTurfPrice.SetPaggingText(this.grdTurfPrice, "Paging");
    }

    protected void grdTurfPrice_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdTurfPrice.MasterTableView.Items).Count == 0)
      {
        this.grdTurfPrice.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdTurfPrice.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdTurfPrice.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdTurfPrice.PagerStyle.AlwaysVisible = true;
      }
      this.grdTurfPrice.Rebind();
      ViewTurfPrice.SetPaggingText(this.grdTurfPrice, "Paging");
    }

    protected void grdTurfPrice_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdTurfPrice_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdTurfPrice_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdTurfPrice_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        TurfPriceMgmt.DeleteAllTurfPrice(((CommandEventArgs) e).CommandArgument.ToString(), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) "Turf Price"), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdTurfPrice.Rebind();
    }

    protected void grdTurfPrice_ItemDataBound(object sender, GridItemEventArgs e)
    {
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) "Turf Price") + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewTurfPrice.aspx");

    protected void btnIsActive_Click(object sender, EventArgs e)
    {
      string str1 = "";
      string str2 = "";
      foreach (GridDataItem gridDataItem in (GridItemCollection) this.grdTurfPrice.Items)
      {
        CheckBox control1 = (CheckBox) ((Control) gridDataItem).FindControl("chkIsActive");
        HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnTurfPriceID");
        if (control1 != null)
        {
          str1 = str1 + control2.Value.ToString() + ",";
          str2 = str2 + control1.Checked.ToString() + ",";
        }
      }
      TurfPriceMgmt.UpdateTurfPriceStatus(str1.TrimEnd(','), str2.TrimEnd(','), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateStatusSuccess, (object) "Turf Price Status"), (Enums.NotificationType) 1), true);
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
