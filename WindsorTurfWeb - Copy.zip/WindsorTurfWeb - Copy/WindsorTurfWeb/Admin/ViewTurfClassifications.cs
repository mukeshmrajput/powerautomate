﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewTurfClassifications
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.TurfProductManagement.TurfClassifications;
using Entity.Response.StockManagement.TurfProductManagement.TurfClassifications;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewTurfClassifications : Page
  {
    public long UserId;
    protected StockManagementSubMenus StockManagementSubMenus1;
    protected HtmlGenericControl H1Title;
    protected TurfProductStockSubMenu TurfProductStockSubMenu1;
    protected HtmlGenericControl divUserAccess;
    protected HtmlGenericControl divData;
    protected RadGrid grdClassification;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendupdateStatus;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.SetUserModuleAccessOnPage(this.divUserAccess, this.divData, "liViewTurfClassification");
      UtilityFunctions.CheckAccessOfLoginUser();
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["TurfClassificationAddUpdate"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["TurfClassificationAddUpdate"]), (Enums.NotificationType) 1), true);
        this.Session["TurfClassificationAddUpdate"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<TurfClassificationResponseBE> classificationResponseBeList = new List<TurfClassificationResponseBE>();
      List<TurfClassificationResponseBE> turfClassification = TurfClassificationMgmt.GetAllTurfClassification();
      this.grdClassification.VirtualItemCount = turfClassification.Count<TurfClassificationResponseBE>();
      ((BaseDataBoundControl) this.grdClassification).DataSource = (object) turfClassification;
      ((Control) this.grdClassification).DataBind();
      if (turfClassification.Count<TurfClassificationResponseBE>() == 0)
        this.grdClassification.AllowFilteringByColumn = false;
      ViewTurfClassifications.SetPaggingText(this.grdClassification, "Paging");
    }

    protected void grdClassification_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdClassification.MasterTableView.Items).Count == 0)
      {
        this.grdClassification.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdClassification.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdClassification.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdClassification.PagerStyle.AlwaysVisible = true;
      }
      this.grdClassification.Rebind();
      ViewTurfClassifications.SetPaggingText(this.grdClassification, "Paging");
    }

    protected void grdClassification_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdClassification_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdClassification_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdClassification_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        TurfClassificationMgmt.DeleteAllTurfClassification(Convert.ToInt64(((CommandEventArgs) e).CommandArgument.ToString()), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) PageName.strAddTurfClassification), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdClassification.Rebind();
    }

    protected void grdClassification_ItemDataBound(object sender, GridItemEventArgs e)
    {
      if (e.Item.ItemType != 7 && e.Item.ItemType != 1)
        return;
      HiddenField control1 = (HiddenField) ((Control) e.Item).FindControl("hdnTurfClassificationID");
      LinkButton control2 = (LinkButton) ((Control) e.Item).FindControl("lnkDelete");
      if (TurfClassificationMgmt.CheckforTurfClassificationExists(Convert.ToInt64(control1.Value)) > 0)
      {
        control2.Enabled = false;
        control2.CssClass = "deactive_delete_icongrid";
        control2.OnClientClick = UtilityFunctions.GetNotification(string.Format("You cannot delete this classification as its associated with Turf Product."), (Enums.NotificationType) 2, false);
      }
      else
      {
        control2.Enabled = true;
        control2.CssClass = "delete_icongrid";
        control2.Attributes.Add("onclick", ViewTurfClassifications.SetDeleteConfirmation());
      }
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) PageName.strAddTurfClassification) + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewTurfClassifications.aspx");

    protected void btnIsActive_Click(object sender, EventArgs e)
    {
      string str1 = "";
      string str2 = "";
      foreach (GridDataItem gridDataItem in (GridItemCollection) this.grdClassification.Items)
      {
        CheckBox control1 = (CheckBox) ((Control) gridDataItem).FindControl("chkIsActive");
        HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnTurfClassificationID");
        if (control1 != null)
        {
          str1 = str1 + control2.Value.ToString() + ",";
          str2 = str2 + control1.Checked.ToString() + ",";
        }
      }
      TurfClassificationMgmt.UpdateTurfClassificationStatus(str1.TrimEnd(','), str2.TrimEnd(','), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateStatusSuccess, (object) PageName.strAddTurfClassification), (Enums.NotificationType) 1), true);
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
