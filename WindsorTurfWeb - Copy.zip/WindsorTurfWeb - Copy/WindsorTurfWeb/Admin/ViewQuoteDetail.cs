﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewQuoteDetail
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.QuoteDetail;
using Entity.Common.QuoteDetail;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewQuoteDetail : Page
  {
    protected HtmlGenericControl H1Title;
    protected TextBox txtSearch;
    protected DropDownList ddlPaymentStatus;
    protected Button btnSearch;
    protected Button btnViewAll;
    protected RadGrid grdQuoteDetail;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendView;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liQuoteDetail");
      if (this.IsPostBack)
        return;
      this.BindDropdown();
      this.BindGrid();
    }

    private void BindGrid()
    {
      string str = this.txtSearch.Text.Trim();
      long int64 = Convert.ToInt64(this.ddlPaymentStatus.SelectedValue);
      if (this.txtSearch.Text.Trim() != "" || int64 == -1L || int64 == 1L || int64 == 2L || int64 == 0L)
      {
        List<QuoteDetailBE> quoteDetailBeList = new List<QuoteDetailBE>();
        List<QuoteDetailBE> byPaymentStatusId = QuoteDetailMgmt.GetQuoteDetailForAllCommecialPartnerByPaymentStatusID(int64, str);
        this.grdQuoteDetail.VirtualItemCount = byPaymentStatusId.Count<QuoteDetailBE>();
        ((BaseDataBoundControl) this.grdQuoteDetail).DataSource = (object) byPaymentStatusId;
        ((Control) this.grdQuoteDetail).DataBind();
        if (byPaymentStatusId.Count<QuoteDetailBE>() == 0)
          this.grdQuoteDetail.AllowFilteringByColumn = false;
        ViewQuoteDetail.SetPaggingText(this.grdQuoteDetail, "Paging");
      }
      else
      {
        List<QuoteDetailBE> quoteDetailBeList = new List<QuoteDetailBE>();
        List<QuoteDetailBE> commecialPartner = QuoteDetailMgmt.GetQuoteDetailForAllCommecialPartner();
        this.grdQuoteDetail.VirtualItemCount = commecialPartner.Count<QuoteDetailBE>();
        ((BaseDataBoundControl) this.grdQuoteDetail).DataSource = (object) commecialPartner;
        ((Control) this.grdQuoteDetail).DataBind();
        if (commecialPartner.Count<QuoteDetailBE>() == 0)
          this.grdQuoteDetail.AllowFilteringByColumn = false;
        ViewQuoteDetail.SetPaggingText(this.grdQuoteDetail, "Paging");
      }
    }

    protected void grdQuoteDetail_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdQuoteDetail.MasterTableView.Items).Count == 0)
      {
        this.grdQuoteDetail.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdQuoteDetail.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdQuoteDetail.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdQuoteDetail.PagerStyle.AlwaysVisible = true;
      }
      this.grdQuoteDetail.Rebind();
      ViewQuoteDetail.SetPaggingText(this.grdQuoteDetail, "Paging");
    }

    protected void grdQuoteDetail_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdQuoteDetail_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdQuoteDetail_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdQuoteDetail_ItemCommand(object sender, GridCommandEventArgs e)
    {
      this.BindGrid();
      this.grdQuoteDetail.Rebind();
    }

    protected void grdQuoteDetail_ItemDataBound(object sender, GridItemEventArgs e)
    {
      if (e.Item.ItemType != 7 && e.Item.ItemType != 1)
        return;
      Label control1 = (Label) ((Control) e.Item).FindControl("lblQuoteStatus");
      LinkButton control2 = (LinkButton) ((Control) e.Item).FindControl("lnkQuoteID");
      if (control1.Text == "Success")
      {
        control1.Text = "Completed";
        control2.Enabled = false;
        control1.Style.Add("color", "green");
      }
      else
        control1.Style.Add("color", "red");
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewQuoteDetailPopUp.aspx");

    protected void lnkQuoteID_Click(object sender, EventArgs e)
    {
      this.Session["QuoteDetailID"] = (object) ((LinkButton) sender).CommandArgument;
      this.Response.Redirect("/retail-purchase-detail");
    }

    protected void BindDropdown() => BindDropDown.GetPaymentStatusForDropDown((ListControl) this.ddlPaymentStatus);

    protected void ddlPaymentStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
      string str = this.txtSearch.Text.Trim();
      long int64 = Convert.ToInt64(this.ddlPaymentStatus.SelectedValue);
      List<QuoteDetailBE> quoteDetailBeList = new List<QuoteDetailBE>();
      List<QuoteDetailBE> byPaymentStatusId = QuoteDetailMgmt.GetQuoteDetailForAllCommecialPartnerByPaymentStatusID(int64, str);
      this.grdQuoteDetail.VirtualItemCount = byPaymentStatusId.Count<QuoteDetailBE>();
      ((BaseDataBoundControl) this.grdQuoteDetail).DataSource = (object) byPaymentStatusId;
      ((Control) this.grdQuoteDetail).DataBind();
      if (byPaymentStatusId.Count<QuoteDetailBE>() == 0)
        this.grdQuoteDetail.AllowFilteringByColumn = false;
      ViewQuoteDetail.SetPaggingText(this.grdQuoteDetail, "Paging");
    }

    protected void btnViewAll_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewQuoteDetail.aspx");
  }
}
