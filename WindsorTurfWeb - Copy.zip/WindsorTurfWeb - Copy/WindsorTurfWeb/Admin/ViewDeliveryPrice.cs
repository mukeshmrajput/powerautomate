﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewDeliveryPrice
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.NonTurfProductPricing.DeliveryPrices;
using Entity.Response.ProductPricing.NonTurfProductPricing.DeliveryPrice;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewDeliveryPrice : Page
  {
    private long UserId;
    protected ProductPricingSubMenus ProductPricingSubMenus1;
    protected HtmlGenericControl H1Title;
    protected RadGrid grdDeliveryPrice;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendupdateStatus;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewDeliveryPrice");
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)));
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["DeliveryPriceAddUpdate"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["DeliveryPriceAddUpdate"]), (Enums.NotificationType) 1), true);
        this.Session["DeliveryPriceAddUpdate"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<DeliveryPriceResponseBE> deliveryPriceResponseBeList = new List<DeliveryPriceResponseBE>();
      List<DeliveryPriceResponseBE> deliveryPriceList = DeliveryPriceMgmt.GetAllDeliveryPriceList();
      this.grdDeliveryPrice.VirtualItemCount = deliveryPriceList.Count<DeliveryPriceResponseBE>();
      ((BaseDataBoundControl) this.grdDeliveryPrice).DataSource = (object) deliveryPriceList;
      ((Control) this.grdDeliveryPrice).DataBind();
      if (deliveryPriceList.Count<DeliveryPriceResponseBE>() == 0)
        this.grdDeliveryPrice.AllowFilteringByColumn = false;
      ViewDeliveryPrice.SetPaggingText(this.grdDeliveryPrice, "Paging");
    }

    protected void grdDeliveryPrice_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdDeliveryPrice.MasterTableView.Items).Count == 0)
      {
        this.grdDeliveryPrice.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdDeliveryPrice.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdDeliveryPrice.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdDeliveryPrice.PagerStyle.AlwaysVisible = true;
      }
      this.grdDeliveryPrice.Rebind();
      ViewDeliveryPrice.SetPaggingText(this.grdDeliveryPrice, "Paging");
    }

    protected void grdDeliveryPrice_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdDeliveryPrice_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdDeliveryPrice_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdDeliveryPrice_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        DeliveryPriceMgmt.DeleteAllDeliveryPrice(((CommandEventArgs) e).CommandArgument.ToString(), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) PageName.strAddDeliveryPrice), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdDeliveryPrice.Rebind();
    }

    protected void grdDeliveryPrice_ItemDataBound(object sender, GridItemEventArgs e)
    {
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) PageName.strAddDeliveryPrice) + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewDeliveryPrice.aspx");

    protected void btnIsActive_Click(object sender, EventArgs e)
    {
      string str1 = "";
      string str2 = "";
      foreach (GridDataItem gridDataItem in (GridItemCollection) this.grdDeliveryPrice.Items)
      {
        CheckBox control1 = (CheckBox) ((Control) gridDataItem).FindControl("chkIsActive");
        HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnDeliveryPriceID");
        if (control1 != null)
        {
          str1 = str1 + control2.Value.ToString() + ",";
          str2 = str2 + control1.Checked.ToString() + ",";
        }
      }
      DeliveryPriceMgmt.UpdateDeliveryPriceStatus(str1.TrimEnd(','), str2.TrimEnd(','), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateStatusSuccess, (object) PageName.strAddDeliveryPrice), (Enums.NotificationType) 1), true);
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
