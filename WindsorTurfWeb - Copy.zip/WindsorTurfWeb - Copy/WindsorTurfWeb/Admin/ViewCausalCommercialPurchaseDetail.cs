﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewCausalCommercialPurchaseDetail
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CausalCommercialPurchaseDetail;
using Entity.Common.CausalCommercialPurchaseDetail;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewCausalCommercialPurchaseDetail : Page
  {
    private long UserId;
    protected HtmlGenericControl H1Title;
    protected RadGrid grdPurchaseDetail;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendView;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))))
        return;
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (!this.IsPostBack)
        this.BindGrid();
    }

    private void BindGrid()
    {
      List<CausalCommercialPurchaseDetailBE> purchaseDetailBeList = new List<CausalCommercialPurchaseDetailBE>();
      List<CausalCommercialPurchaseDetailBE> userPurchaseDetail = CausalCommercialPurchaseDetailMgmt.GetAllCausalCommercialUserPurchaseDetail();
      this.grdPurchaseDetail.VirtualItemCount = userPurchaseDetail.Count<CausalCommercialPurchaseDetailBE>();
      ((BaseDataBoundControl) this.grdPurchaseDetail).DataSource = (object) userPurchaseDetail;
      ((Control) this.grdPurchaseDetail).DataBind();
      if (userPurchaseDetail.Count<CausalCommercialPurchaseDetailBE>() == 0)
        this.grdPurchaseDetail.AllowFilteringByColumn = false;
      ViewCausalCommercialPurchaseDetail.SetPaggingText(this.grdPurchaseDetail, "Paging");
    }

    protected void grdPurchaseDetail_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdPurchaseDetail.MasterTableView.Items).Count == 0)
      {
        this.grdPurchaseDetail.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdPurchaseDetail.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdPurchaseDetail.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdPurchaseDetail.PagerStyle.AlwaysVisible = true;
      }
      this.grdPurchaseDetail.Rebind();
      ViewCausalCommercialPurchaseDetail.SetPaggingText(this.grdPurchaseDetail, "Paging");
    }

    protected void grdPurchaseDetail_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdPurchaseDetail_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdPurchaseDetail_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdPurchaseDetail_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        CausalCommercialPurchaseDetailMgmt.DeleteCasualCommercialPartnerDetail(((CommandEventArgs) e).CommandArgument.ToString(), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) PageName.strCausalCommercialDetail), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdPurchaseDetail.Rebind();
    }

    protected void grdPurchaseDetail_ItemDataBound(object sender, GridItemEventArgs e)
    {
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewCausalCommercialPurchaseDetail.aspx");

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) PageName.strCausalCommercialDetail) + "')";
  }
}
