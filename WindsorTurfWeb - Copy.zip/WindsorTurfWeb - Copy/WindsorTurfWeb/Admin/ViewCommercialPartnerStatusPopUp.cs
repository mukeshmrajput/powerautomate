﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewCommercialPartnerStatusPopUp
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using BLL.UserManagement;
using Entity.Common.CommercialPartner;
using Entity.Common.UserManagement;
using Entity.Response.CommercialPartner;
using Helper;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class ViewCommercialPartnerStatusPopUp : Page
  {
    private long fCommercialPartnerID = 0;
    protected HtmlForm form1;
    protected HtmlGenericControl h1Title;
    protected Literal lblBusinessName;
    protected Literal lblABN;
    protected Literal lblFirstName;
    protected Literal lblLastName;
    protected Literal lblEmail;
    protected Literal ltrTelephone;
    protected Literal ltrFax;
    protected Literal ltrMobile;
    protected Literal ltrAddress1;
    protected Literal ltrAddress2;
    protected Literal ltrSuburb;
    protected Literal ltrState;
    protected Literal ltrPostalCode;
    protected RadioButtonList rblUserStatus;
    protected Button btnUpdate;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.Request.QueryString[QueryStrings.CommercialPartnerID] != null)
        this.fCommercialPartnerID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.CommercialPartnerID].ToString()));
      if (this.IsPostBack || this.fCommercialPartnerID <= 0L)
        return;
      this.FillAllData(CommercialPartnerMgmt.GetCommercialPartnerDetailByCommercialPartnerIDForApproval(this.fCommercialPartnerID));
    }

    protected void FillAllData(CommercialPartnerResponseBE obj)
    {
      if (obj == null)
        return;
      this.lblBusinessName.Text = obj.BusinessName;
      this.lblFirstName.Text = obj.FirstName;
      this.lblLastName.Text = obj.LastName;
      this.lblEmail.Text = obj.Email;
      this.lblABN.Text = obj.CompanyABN;
      this.ltrTelephone.Text = string.IsNullOrEmpty(obj.Telephone) ? "-" : obj.Telephone;
      this.ltrFax.Text = string.IsNullOrEmpty(obj.Fax) ? "-" : obj.Fax;
      this.ltrMobile.Text = string.IsNullOrEmpty(obj.Mobile) ? "-" : obj.Mobile;
      this.ltrAddress1.Text = string.IsNullOrEmpty(obj.Address1) ? "-" : obj.Address1;
      this.ltrAddress2.Text = string.IsNullOrEmpty(obj.Address2) ? "-" : obj.Address2;
      this.ltrSuburb.Text = string.IsNullOrEmpty(obj.Suburb) ? "-" : obj.Suburb;
      this.ltrState.Text = string.IsNullOrEmpty(obj.StateName) ? "-" : obj.StateName;
      this.ltrPostalCode.Text = string.IsNullOrEmpty(obj.PostCode) ? "-" : obj.PostCode;
      string strUserStatusID = "";
      long num;
      if (obj.UserStatusID == Convert.ToInt64((object) (Enums.UserStatus) 4))
        strUserStatusID = Convert.ToString(Convert.ToInt64((object) (Enums.UserStatus) 2));
      else if (obj.UserStatusID == Convert.ToInt64((object) (Enums.UserStatus) 3))
        strUserStatusID = Convert.ToString(Convert.ToInt64((object) (Enums.UserStatus) 4));
      else if (obj.UserStatusID == Convert.ToInt64((object) (Enums.UserStatus) 2))
      {
        string str1 = Convert.ToInt64((object) (Enums.UserStatus) 4).ToString();
        num = Convert.ToInt64((object) (Enums.UserStatus) 3);
        string str2 = num.ToString();
        strUserStatusID = Convert.ToString(str1 + "," + str2);
      }
      else if (obj.UserStatusID == Convert.ToInt64((object) (Enums.UserStatus) 1))
      {
        string str3 = Convert.ToInt64((object) (Enums.UserStatus) 4).ToString();
        num = Convert.ToInt64((object) (Enums.UserStatus) 3);
        string str4 = num.ToString();
        strUserStatusID = Convert.ToString(str3 + "," + str4);
      }
      BindDropDown.BindUserStatus((ListControl) this.rblUserStatus, strUserStatusID);
      RadioButtonList rblUserStatus = this.rblUserStatus;
      num = obj.UserStatusID;
      string str = num.ToString();
      rblUserStatus.SelectedValue = str;
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
      CommercialPartnerMgmt.UpdateCommercialPartnerStatusByAdmin(new CommercialPartnerBE()
      {
        CommercialPartnerID = this.fCommercialPartnerID,
        UserStatusID = Convert.ToInt64(this.rblUserStatus.SelectedValue),
        ModifiedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))),
        ModifiedByIP = HttpContext.Current.Request.UserHostAddress,
        UserTypeID = Convert.ToInt64((object) (Enums.UserType) 4)
      });
      UserBE userInfoByEid = UserMgmt.GetUserInfoByEId(this.lblEmail.Text);
      if (Convert.ToInt64(this.rblUserStatus.SelectedValue) == Convert.ToInt64((object) (Enums.UserStatus) 1))
        Mail.CommercialPartnerApproval(this.lblEmail.Text.Trim(), this.lblFirstName.Text + " " + this.lblLastName.Text, userInfoByEid.LoginMasterID);
      this.Session["CommercialPartnerApproval"] = (object) PageName.strCommercialPartnerApproval;
      System.Web.UI.ScriptManager.RegisterStartupScript((Page) this, typeof (string), "Saved", "parent.fancyboxclose();window.parent.location = 'ViewCommercialPartnerApproval.aspx';", true);
    }
  }
}
