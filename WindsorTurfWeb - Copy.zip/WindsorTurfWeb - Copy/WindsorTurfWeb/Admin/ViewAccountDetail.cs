﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewAccountDetail
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PaymentOptions.AccountDetail;
using Entity.Response.PaymentOptions.AccountDetail;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewAccountDetail : Page
  {
    public long UserId;
    protected ProductPricingSubMenus ProductPricingSubMenus1;
    protected HtmlGenericControl H1Title;
    protected RadGrid grdAccountDetail;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendupdateStatus;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["AccountDetailAddUpdate"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["AccountDetailAddUpdate"]), (Enums.NotificationType) 1), true);
        this.Session["AccountDetailAddUpdate"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<AccountDetailResponseBE> detailResponseBeList = new List<AccountDetailResponseBE>();
      List<AccountDetailResponseBE> allAccountDetail = AccountDetailMgmt.GetAllAccountDetail();
      this.grdAccountDetail.VirtualItemCount = allAccountDetail.Count<AccountDetailResponseBE>();
      ((BaseDataBoundControl) this.grdAccountDetail).DataSource = (object) allAccountDetail;
      ((Control) this.grdAccountDetail).DataBind();
      if (allAccountDetail.Count<AccountDetailResponseBE>() == 0)
        this.grdAccountDetail.AllowFilteringByColumn = false;
      ViewAccountDetail.SetPaggingText(this.grdAccountDetail, "Paging");
    }

    protected void grdAccountDetail_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdAccountDetail.MasterTableView.Items).Count == 0)
      {
        this.grdAccountDetail.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdAccountDetail.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdAccountDetail.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdAccountDetail.PagerStyle.AlwaysVisible = true;
      }
      this.grdAccountDetail.Rebind();
      ViewAccountDetail.SetPaggingText(this.grdAccountDetail, "Paging");
    }

    protected void grdAccountDetail_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdAccountDetail_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdAccountDetail_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdAccountDetail_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        AccountDetailMgmt.DeleteAllAccountDetail(((CommandEventArgs) e).CommandArgument.ToString(), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) PageName.strAddAcount), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdAccountDetail.Rebind();
    }

    protected void grdAccountDetail_ItemDataBound(object sender, GridItemEventArgs e)
    {
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) PageName.strAddAcount) + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewAccountDetail.aspx");

    protected void btnIsActive_Click(object sender, EventArgs e)
    {
      string str1 = "";
      string str2 = "";
      foreach (GridDataItem gridDataItem in (GridItemCollection) this.grdAccountDetail.Items)
      {
        CheckBox control1 = (CheckBox) ((Control) gridDataItem).FindControl("chkIsActive");
        HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnAccountDetailID");
        if (control1 != null)
        {
          str1 = str1 + control2.Value.ToString() + ",";
          str2 = str2 + control1.Checked.ToString() + ",";
        }
      }
      AccountDetailMgmt.UpdateAccountDetailStatus(str1.TrimEnd(','), str2.TrimEnd(','), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateStatusSuccess, (object) PageName.strAddAcount), (Enums.NotificationType) 1), true);
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
