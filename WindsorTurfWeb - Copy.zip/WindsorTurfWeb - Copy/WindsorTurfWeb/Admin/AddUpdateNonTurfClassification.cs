﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateNonTurfClassification
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfClassifications;
using Entity.Common.StockManagement.NonTurfProductManagement.NonTurfClassifications;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfClassifications;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateNonTurfClassification : Page
  {
    public static long fNonTurfClassificationID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtClassificationName;
    protected RequiredFieldValidator rfvClassificationName;
    protected RegularExpressionValidator regClassificationName;
    protected TextBox txtClassificationDesc;
    protected RequiredFieldValidator rfvClassificationDesc;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnQuantityPriceID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewNonTurfClassification");
      if (this.Request.QueryString[QueryStrings.NonTurfClassificationID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strAddNonTurfClassification;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        AddUpdateNonTurfClassification.fNonTurfClassificationID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.NonTurfClassificationID].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddNonTurfClassification;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateNonTurfClassification.fNonTurfClassificationID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        if (AddUpdateNonTurfClassification.fNonTurfClassificationID > 0L)
          this.GetDeliveryPriceDetails(NonTurfClassificationMgmt.GetNonTurfClassificationInfoByID(Convert.ToInt64(AddUpdateNonTurfClassification.fNonTurfClassificationID)));
      }
      this.txtClassificationName.Focus();
    }

    protected void GetDeliveryPriceDetails(
      NonTurfClassificationBE objTurfClassificationResponseBE)
    {
      this.txtClassificationName.Text = Convert.ToString(objTurfClassificationResponseBE.Name);
      this.txtClassificationDesc.Text = Convert.ToString(objTurfClassificationResponseBE.Description);
      this.chkIsActive.Checked = Convert.ToBoolean(objTurfClassificationResponseBE.IsActive);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      NonTurfClassificationBE classificationBe = new NonTurfClassificationBE();
      classificationBe.NonTurfClassificationID = AddUpdateNonTurfClassification.fNonTurfClassificationID <= 0L ? 0L : AddUpdateNonTurfClassification.fNonTurfClassificationID;
      classificationBe.Name = this.txtClassificationName.Text.Trim();
      classificationBe.Description = this.txtClassificationDesc.Text.Trim();
      classificationBe.IsActive = this.chkIsActive.Checked;
      classificationBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      classificationBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      long num = NonTurfClassificationMgmt.AddUpdateTurfClassifications(classificationBe);
      if (num > 0L)
      {
        if (classificationBe.NonTurfClassificationID > 0L)
          this.Session["NonTurfClassificationAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddNonTurfClassification);
        else if (classificationBe.NonTurfClassificationID == 0L)
          this.Session["NonTurfClassificationAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddNonTurfClassification);
        this.Response.Redirect("~/Admin/ViewNonTurfClassifications.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) PageName.strAddNonTurfClassification), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewNonTurfClassifications.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvClassificationName, true, (object) this.txtClassificationName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regClassificationName, Regex.Title, true, (object) this.txtClassificationName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvClassificationDesc, true, (object) this.txtClassificationDesc, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
