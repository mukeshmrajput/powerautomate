﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewPageManagement
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PageManagement;
using Entity.Response.PageManagement;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class ViewPageManagement : Page
  {
    private long UserId;
    protected HtmlGenericControl H1Title;
    protected RadGrid grdPageManagement;
    protected HtmlTable tableLegend;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["PageManagementAddUpdate"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["PageManagementAddUpdate"]), (Enums.NotificationType) 1), true);
        this.Session["PageManagementAddUpdate"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<PageManagementResponseBE> listOfAllPages = PageManagementMgmt.GetListOfAllPages(0L);
      this.grdPageManagement.VirtualItemCount = listOfAllPages.Count<PageManagementResponseBE>();
      ((BaseDataBoundControl) this.grdPageManagement).DataSource = (object) listOfAllPages;
      ((Control) this.grdPageManagement).DataBind();
      if (listOfAllPages.Count<PageManagementResponseBE>() == 0)
        this.grdPageManagement.AllowFilteringByColumn = false;
      ViewPageManagement.SetPaggingText(this.grdPageManagement, "Paging");
    }

    protected void grdPageManagement_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdPageManagement.MasterTableView.Items).Count == 0)
      {
        this.grdPageManagement.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdPageManagement.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdPageManagement.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdPageManagement.PagerStyle.AlwaysVisible = true;
      }
      this.grdPageManagement.Rebind();
      ViewPageManagement.SetPaggingText(this.grdPageManagement, "Paging");
    }

    protected void grdPageManagement_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdPageManagement_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdPageManagement_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdPageManagement_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        PageManagementMgmt.DeletePage(Convert.ToInt64(((CommandEventArgs) e).CommandArgument.ToString()), Convert.ToInt64(Convert.ToInt64(this.UserId)), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) "Page"), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdPageManagement.Rebind();
    }

    protected void grdPageManagement_ItemDataBound(object sender, GridItemEventArgs e)
    {
      if (e.Item.ItemType != 7 && e.Item.ItemType != 1 || !(e.Item is GridDataItem))
        return;
      GridDataItem gridDataItem = (GridDataItem) e.Item;
      HtmlAnchor control1 = (HtmlAnchor) ((Control) gridDataItem).FindControl("aEdita");
      HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnPageManagementID");
      HiddenField control3 = (HiddenField) ((Control) gridDataItem).FindControl("hdnIsEditable");
      HiddenField control4 = (HiddenField) ((Control) gridDataItem).FindControl("hdnHasChild");
      HiddenField control5 = (HiddenField) ((Control) gridDataItem).FindControl("hdnIsStatic");
      long int64 = Convert.ToInt64(DataBinder.Eval(e.Item.DataItem, "PageManagementID"));
      LinkButton control6 = (LinkButton) ((Control) gridDataItem).FindControl("lnkDelete");
      if (Convert.ToInt64(control2.Value) == 1L)
      {
        control1.Attributes.Add("class", "edit_icongridf");
      }
      else
      {
        control1.HRef = "~/Admin/PageManagementEdit.aspx?" + QueryStrings.PageManagementID + "=" + Encryption.EncryptQueryString(int64.ToString());
        control1.Attributes.Add("class", "edit_icongrid");
      }
      if (control3 != null && !Convert.ToBoolean(control3.Value))
      {
        control1.HRef = "#";
        control1.Attributes.Remove("class");
      }
      if (control4 != null && control5 != null)
      {
        if (Convert.ToInt32(control4.Value) == 0)
        {
          if (control6 != null)
          {
            if (Convert.ToBoolean(control5.Value))
              control6.Attributes.Remove("class");
            else
              control6.Attributes.Add("class", "delete_icongrid");
          }
        }
        else
          control6?.Attributes.Remove("class");
      }
    }

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewPageManagement.aspx");

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) "Page") + "')";
  }
}
