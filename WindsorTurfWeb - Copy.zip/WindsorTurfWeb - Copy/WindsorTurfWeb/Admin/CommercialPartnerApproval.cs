﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.CommercialPartnerApproval
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using Entity.Response.CommercialPartner;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class CommercialPartnerApproval : Page
  {
    public long UserId;
    protected HtmlGenericControl H1Title;
    protected TextBox txtSearch;
    protected DropDownList ddlUserStatus;
    protected Button btnSearch;
    protected Button btnViewAll;
    protected RadGrid grdCommercialPartnerApproval;
    protected HtmlTable tableLegend;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))))
        this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liCommercialRegistrationApproval");
      if (this.Session[nameof (CommercialPartnerApproval)] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateSuccess, (object) PageName.strApprovalStatus), (Enums.NotificationType) 1), true);
        this.Session[nameof (CommercialPartnerApproval)] = (object) null;
      }
      if (this.IsPostBack)
        return;
      BindDropDown.BindUserStatus((ListControl) this.ddlUserStatus, string.Empty);
      this.BindGrid();
    }

    private void BindGrid()
    {
      long int64 = Convert.ToInt64(this.ddlUserStatus.SelectedValue);
      string str = this.txtSearch.Text.Trim();
      if (this.txtSearch.Text.Trim() != "" || int64 == 1L || int64 == 2L || int64 == 3L || int64 == 4L)
      {
        List<CommercialPartnerResponseBE> partnerResponseBeList = new List<CommercialPartnerResponseBE>();
        List<CommercialPartnerResponseBE> approvalByUserStatus = CommercialPartnerMgmt.GetAllCommercialPartnersForApprovalByUserStatus(int64, str);
        this.grdCommercialPartnerApproval.VirtualItemCount = approvalByUserStatus.Count<CommercialPartnerResponseBE>();
        ((BaseDataBoundControl) this.grdCommercialPartnerApproval).DataSource = (object) approvalByUserStatus;
        ((Control) this.grdCommercialPartnerApproval).DataBind();
        if (approvalByUserStatus.Count<CommercialPartnerResponseBE>() == 0)
          this.grdCommercialPartnerApproval.AllowFilteringByColumn = false;
        CommercialPartnerApproval.SetPaggingText(this.grdCommercialPartnerApproval, "Paging");
      }
      else
      {
        List<CommercialPartnerResponseBE> partnerResponseBeList = new List<CommercialPartnerResponseBE>();
        List<CommercialPartnerResponseBE> partnersForApproval = CommercialPartnerMgmt.GetAllCommercialPartnersForApproval();
        this.grdCommercialPartnerApproval.VirtualItemCount = partnersForApproval.Count<CommercialPartnerResponseBE>();
        ((BaseDataBoundControl) this.grdCommercialPartnerApproval).DataSource = (object) partnersForApproval;
        ((Control) this.grdCommercialPartnerApproval).DataBind();
        if (partnersForApproval.Count<CommercialPartnerResponseBE>() == 0)
          this.grdCommercialPartnerApproval.AllowFilteringByColumn = false;
        CommercialPartnerApproval.SetPaggingText(this.grdCommercialPartnerApproval, "Paging");
      }
    }

    protected void grdCommercialPartnerApproval_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdCommercialPartnerApproval.MasterTableView.Items).Count == 0)
      {
        this.grdCommercialPartnerApproval.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdCommercialPartnerApproval.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdCommercialPartnerApproval.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdCommercialPartnerApproval.PagerStyle.AlwaysVisible = true;
      }
      this.grdCommercialPartnerApproval.Rebind();
      CommercialPartnerApproval.SetPaggingText(this.grdCommercialPartnerApproval, "Paging");
    }

    protected void grdCommercialPartnerApproval_SortCommand(
      object sender,
      GridSortCommandEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdCommercialPartnerApproval_PageSizeChanged(
      object sender,
      GridPageSizeChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdCommercialPartnerApproval_PageIndexChanged(
      object sender,
      GridPageChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdCommercialPartnerApproval_ItemDataBound(object sender, GridItemEventArgs e)
    {
      if (e.Item.ItemType != 7 && e.Item.ItemType != 1 || !(e.Item is GridDataItem))
        return;
      GridDataItem gridDataItem = (GridDataItem) e.Item;
      HtmlAnchor control1 = (HtmlAnchor) ((Control) gridDataItem).FindControl("aUserStatusName");
      HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnUserStatusID");
      if (Convert.ToInt64(control2.Value) == Convert.ToInt64((object) (Enums.UserStatus) 1))
        control1.Style.Add("color", "#009634");
      else if (Convert.ToInt64(control2.Value) == Convert.ToInt64((object) (Enums.UserStatus) 3))
        control1.Style.Add("color", "0000FF");
      else if (Convert.ToInt64(control2.Value) == Convert.ToInt64((object) (Enums.UserStatus) 2))
        control1.Style.Add("color", "#FF0000");
      else if (Convert.ToInt64(control2.Value) == Convert.ToInt64((object) (Enums.UserStatus) 4))
        control1.Style.Add("color", "#FF6600");
    }

    protected void grdCommercialPartnerApproval_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        CommercialPartnerMgmt.DeleteAllCommercialPartner(((CommandEventArgs) e).CommandArgument.ToString(), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) PageName.strCommercialPartnerDetail), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdCommercialPartnerApproval.Rebind();
    }

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewCommercialPartnerApproval.aspx");

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) PageName.strCommercialPartnerDetail) + "')";

    protected void ddlUserStatus_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
      long int64 = Convert.ToInt64(this.ddlUserStatus.SelectedValue);
      string str = this.txtSearch.Text.Trim();
      List<CommercialPartnerResponseBE> partnerResponseBeList = new List<CommercialPartnerResponseBE>();
      List<CommercialPartnerResponseBE> approvalByUserStatus = CommercialPartnerMgmt.GetAllCommercialPartnersForApprovalByUserStatus(int64, str);
      this.grdCommercialPartnerApproval.VirtualItemCount = approvalByUserStatus.Count<CommercialPartnerResponseBE>();
      ((BaseDataBoundControl) this.grdCommercialPartnerApproval).DataSource = (object) approvalByUserStatus;
      ((Control) this.grdCommercialPartnerApproval).DataBind();
      if (approvalByUserStatus.Count<CommercialPartnerResponseBE>() == 0)
        this.grdCommercialPartnerApproval.AllowFilteringByColumn = false;
      CommercialPartnerApproval.SetPaggingText(this.grdCommercialPartnerApproval, "Paging");
    }

    protected void btnViewAll_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewCommercialPartnerApproval.aspx");
  }
}
