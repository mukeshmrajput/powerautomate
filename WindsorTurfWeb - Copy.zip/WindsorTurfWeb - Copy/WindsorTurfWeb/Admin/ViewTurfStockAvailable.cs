﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewTurfStockAvailable
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.TurfProductManagement.TurfStockAvailable;
using Entity.Response.StockManagement.TurfProductManagement.TurfStockAvailable;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewTurfStockAvailable : Page
  {
    private long UserId;
    protected StockManagementSubMenus StockManagementSubMenus1;
    protected HtmlGenericControl H1Title;
    protected TurfProductStockSubMenu TurfProductStockSubMenu1;
    protected RadGrid grdTurfStockAvailable;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendupdateStatus;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewTurfStockAvailable");
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["TurfStockAvailableAddUpdate"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["TurfStockAvailableAddUpdate"]), (Enums.NotificationType) 1), true);
        this.Session["TurfStockAvailableAddUpdate"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<TurfStockAvailableResponseBE> availableResponseBeList = new List<TurfStockAvailableResponseBE>();
      List<TurfStockAvailableResponseBE> turfStockAvailable = TurfStockAvailableMgmt.GetAllTurfStockAvailable();
      this.grdTurfStockAvailable.VirtualItemCount = turfStockAvailable.Count<TurfStockAvailableResponseBE>();
      ((BaseDataBoundControl) this.grdTurfStockAvailable).DataSource = (object) turfStockAvailable;
      ((Control) this.grdTurfStockAvailable).DataBind();
      if (turfStockAvailable.Count<TurfStockAvailableResponseBE>() == 0)
        this.grdTurfStockAvailable.AllowFilteringByColumn = false;
      ViewTurfStockAvailable.SetPaggingText(this.grdTurfStockAvailable, "Paging");
    }

    protected void grdTurfStockAvailable_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdTurfStockAvailable.MasterTableView.Items).Count == 0)
      {
        this.grdTurfStockAvailable.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdTurfStockAvailable.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdTurfStockAvailable.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdTurfStockAvailable.PagerStyle.AlwaysVisible = true;
      }
      this.grdTurfStockAvailable.Rebind();
      ViewTurfStockAvailable.SetPaggingText(this.grdTurfStockAvailable, "Paging");
    }

    protected void grdTurfStockAvailable_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdTurfStockAvailable_PageSizeChanged(
      object sender,
      GridPageSizeChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdTurfStockAvailable_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdTurfStockAvailable_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        TurfStockAvailableMgmt.DeleteAllTurfStockAvailable(Convert.ToInt64(((CommandEventArgs) e).CommandArgument.ToString()), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) PageName.strAddTurfStockAvailable), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdTurfStockAvailable.Rebind();
    }

    protected void grdTurfStockAvailable_ItemDataBound(object sender, GridItemEventArgs e)
    {
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) PageName.strAddTurfStockAvailable) + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewTurfStockAvailable.aspx");

    protected void btnIsActive_Click(object sender, EventArgs e)
    {
      string str1 = "";
      string str2 = "";
      foreach (GridDataItem gridDataItem in (GridItemCollection) this.grdTurfStockAvailable.Items)
      {
        CheckBox control1 = (CheckBox) ((Control) gridDataItem).FindControl("chkIsActive");
        HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnTurfStockAvailableID");
        if (control1 != null)
        {
          str1 = str1 + control2.Value.ToString() + ",";
          str2 = str2 + control1.Checked.ToString() + ",";
        }
      }
      TurfStockAvailableMgmt.UpdateTurfStockAvailableStatus(str1.TrimEnd(','), str2.TrimEnd(','), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateStatusSuccess, (object) PageName.strAddTurfStockAvailable), (Enums.NotificationType) 1), true);
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
