﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewNonTurfStockAvailable
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfStockAvailable;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfStockAvailable;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewNonTurfStockAvailable : Page
  {
    private long UserId;
    protected StockManagementSubMenus StockManagementSubMenus1;
    protected HtmlGenericControl H1Title;
    protected NonTurfProductStockSubMenu NonTurfProductStockSubMenu1;
    protected RadGrid grdNonTurfStockAvailable;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendupdateStatus;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewNonTurfStockAvailable");
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["NonTurfStockAvailableAddUpdate"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["NonTurfStockAvailableAddUpdate"]), (Enums.NotificationType) 1), true);
        this.Session["NonTurfStockAvailableAddUpdate"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<NonTurfStockAvailableResponseBE> availableResponseBeList = new List<NonTurfStockAvailableResponseBE>();
      List<NonTurfStockAvailableResponseBE> turfStockAvailable = NonTurfStockAvailableMgmt.GetAllNonTurfStockAvailable();
      this.grdNonTurfStockAvailable.VirtualItemCount = turfStockAvailable.Count<NonTurfStockAvailableResponseBE>();
      ((BaseDataBoundControl) this.grdNonTurfStockAvailable).DataSource = (object) turfStockAvailable;
      ((Control) this.grdNonTurfStockAvailable).DataBind();
      if (turfStockAvailable.Count<NonTurfStockAvailableResponseBE>() == 0)
        this.grdNonTurfStockAvailable.AllowFilteringByColumn = false;
      ViewNonTurfStockAvailable.SetPaggingText(this.grdNonTurfStockAvailable, "Paging");
    }

    protected void grdNonTurfStockAvailable_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdNonTurfStockAvailable.MasterTableView.Items).Count == 0)
      {
        this.grdNonTurfStockAvailable.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdNonTurfStockAvailable.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdNonTurfStockAvailable.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdNonTurfStockAvailable.PagerStyle.AlwaysVisible = true;
      }
      this.grdNonTurfStockAvailable.Rebind();
      ViewNonTurfStockAvailable.SetPaggingText(this.grdNonTurfStockAvailable, "Paging");
    }

    protected void grdNonTurfStockAvailable_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdNonTurfStockAvailable_PageSizeChanged(
      object sender,
      GridPageSizeChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdNonTurfStockAvailable_PageIndexChanged(
      object sender,
      GridPageChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdNonTurfStockAvailable_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        NonTurfStockAvailableMgmt.DeleteAllNonTurfStockAvailable(Convert.ToInt64(((CommandEventArgs) e).CommandArgument.ToString()), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) PageName.strAddNonTurfStockAvailable), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdNonTurfStockAvailable.Rebind();
    }

    protected void grdNonTurfStockAvailable_ItemDataBound(object sender, GridItemEventArgs e)
    {
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) PageName.strAddNonTurfStockAvailable) + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewNonTurfStockAvailable.aspx");

    protected void btnIsActive_Click(object sender, EventArgs e)
    {
      string str1 = "";
      string str2 = "";
      foreach (GridDataItem gridDataItem in (GridItemCollection) this.grdNonTurfStockAvailable.Items)
      {
        CheckBox control1 = (CheckBox) ((Control) gridDataItem).FindControl("chkIsActive");
        HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnNonTurfProductName");
        if (control1 != null)
        {
          str1 = str1 + control2.Value.ToString() + ",";
          str2 = str2 + control1.Checked.ToString() + ",";
        }
      }
      NonTurfStockAvailableMgmt.UpdateNonTurfStockAvailableStatus(str1.TrimEnd(','), str2.TrimEnd(','), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateStatusSuccess, (object) PageName.strAddNonTurfStockAvailable), (Enums.NotificationType) 1), true);
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
