﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateBanner
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.BannerManagement;
using Entity.Request.BannerManagement;
using Entity.Response.BannerManagement;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateBanner : Page
  {
    public int rowCount = 0;
    public long fBannerID = 0;
    public long UserId;
    public string BannerOriginalImagePath = ConfigurationManager.AppSettings[nameof (BannerOriginalImagePath)];
    public string BannerThumbImagePath = ConfigurationManager.AppSettings[nameof (BannerThumbImagePath)];
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected TextBox txtTitle;
    protected RequiredFieldValidator rfvTitle;
    protected RegularExpressionValidator regTitle;
    protected TextBox txtBanner;
    protected FileUpload fldBanner;
    protected HtmlAnchor lnkBannerImage;
    protected HtmlAnchor lnkBannerThumb;
    protected Image ImgThumb;
    protected Button btnBannerDelete;
    protected RequiredFieldValidator rfvBannerImage;
    protected HiddenField hdndivBanner;
    protected HiddenField hdnBannerDoc;
    protected HiddenField hdnBannerCancel;
    protected HiddenField hdnBannerName;
    protected HiddenField hdnUploadType;
    protected HiddenField hdnDocName;
    protected TextBox txtBannerText;
    protected RequiredFieldValidator rfvBannerText;
    protected RegularExpressionValidator regBannerText;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("LiBannerManagement");
      this.txtTitle.Focus();
      this.ValidationExpression();
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.Request.QueryString["BannerManagementId"] != null)
        this.fBannerID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["BannerManagementId"].ToString()));
      if (!this.IsPostBack)
      {
        if (this.Request.QueryString["BannerManagementId"] != null)
        {
          this.h1Title.InnerText = "Edit Banner";
          this.btnSubmit.Text = "Update";
          this.btnSubmit.ToolTip = "Update";
          this.fBannerID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["BannerManagementId"].ToString()));
          if (this.Session["UpdateMsg"] != null)
            this.Session["UpdateMsg"] = (object) null;
          this.FillData(this.fBannerID);
        }
        else
        {
          if (BannerMgmt.GetTotalBannerCount() == 5L)
          {
            this.Session["BannerCount"] = (object) string.Format(Messages.MaxBannerAllowed, (object) "5");
            this.Response.Redirect("~/Admin/ViewBanner.aspx");
          }
          this.h1Title.InnerText = "Add Banner";
          this.btnSubmit.Text = "Save";
          this.btnSubmit.ToolTip = "Save";
        }
      }
      this.txtTitle.Focus();
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvTitle, true, (object) this.txtTitle, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTitle, Regex.NewsTitle, true, (object) this.txtTitle, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvBannerImage, true, (object) this.txtBanner, this.strValidationTurfGrp);
      this.fldBanner.Attributes.Add("OnChange", "return UploadFileSelect('" + this.fldBanner.ClientID + "','" + this.txtBanner.ClientID + "', this, 'banner');");
      Validations.SetRequiredFieldValidator(this.rfvBannerText, true, (object) this.txtBannerText, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regBannerText, Regex.NewsTitle, true, (object) this.txtBannerText, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }

    protected void FillData(long BannerID)
    {
      BannerResponse bannerResponse = new BannerResponse();
      BannerResponse bannerById = BannerMgmt.GetBannerByID(BannerID);
      if (bannerById == null)
        return;
      this.txtTitle.Text = bannerById.BannerTitle;
      this.txtBannerText.Text = bannerById.BannerText;
      this.chkIsActive.Checked = bannerById.IsActive;
      this.hdnDocName.Value = Convert.ToString(bannerById.BannerImage);
      if (!string.IsNullOrEmpty(bannerById.BannerImage))
      {
        this.hdnBannerDoc.Value = "block";
        this.hdndivBanner.Value = "none";
        this.hdnBannerCancel.Value = "block";
        this.hdnBannerName.Value = bannerById.BannerImage;
        this.lnkBannerThumb.HRef = ConfigurationManager.AppSettings["LivePath"] + this.BannerOriginalImagePath + bannerById.BannerImage;
        this.ImgThumb.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.BannerThumbImagePath + bannerById.BannerImage;
        this.lnkBannerImage.Visible = false;
        this.lnkBannerThumb.Visible = true;
        this.rfvBannerImage.Enabled = false;
      }
      else
        this.rfvBannerImage.Enabled = true;
    }

    private bool ImageValidationMessage()
    {
      string str = this.fldBanner.FileName.Substring(this.fldBanner.FileName.LastIndexOf(".") + 1).ToLower();
      str = string.Empty;
      string lower = this.fldBanner.FileName.Substring(this.fldBanner.FileName.LastIndexOf(".") + 1).ToLower();
      if (Regex.UploadImage.Contains(lower) && !string.IsNullOrEmpty(lower))
      {
        if (this.fldBanner.FileContent.Length > 2097152L)
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "Banner"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      else
      {
        if (string.IsNullOrEmpty(lower) && string.IsNullOrEmpty(this.hdnBannerName.Value))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "Banner"), (Enums.NotificationType) 2, false), true);
          return false;
        }
        if (!string.IsNullOrEmpty(lower))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "Banner"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      return true;
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.ImageValidationMessage())
        return;
      BannerRequest bannerRequest = new BannerRequest();
      if (this.fBannerID > 0L)
      {
        bannerRequest.ModifiedBy = Convert.ToInt64(this.UserId);
        bannerRequest.ModifiedByIP = HttpContext.Current.Request.UserHostAddress;
        bannerRequest.BannerManagementId = this.fBannerID;
      }
      else
      {
        bannerRequest.CreatedBy = Convert.ToInt64(this.UserId);
        bannerRequest.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
        bannerRequest.BannerManagementId = 0L;
      }
      bannerRequest.BannerTitle = this.txtTitle.Text.Trim();
      bannerRequest.BannerText = this.txtBannerText.Text.Trim();
      bannerRequest.IsActive = this.chkIsActive.Checked;
      string empty = string.Empty;
      FileUpload fileUpload = new FileUpload();
      FileUpload fldBanner = this.fldBanner;
      if (!string.IsNullOrEmpty(fldBanner.FileName))
      {
        if (fldBanner.FileName.Length > 0)
        {
          UtilityFunctions.CreateDirectory(this.Server.MapPath("~/") + this.BannerOriginalImagePath);
          UtilityFunctions.CreateDirectory(this.Server.MapPath("~/") + this.BannerThumbImagePath);
          string[] strArray = fldBanner.FileName.Split('\\');
          string FileName = UtilityFunctions.ChangeFileName(strArray[strArray.Length - 1].ToString());
          string extension = Path.GetExtension(fldBanner.FileName);
          if (extension == ".jpeg" || extension == ".png" || extension == ".jpg" || extension == ".bmp" || extension == ".gif")
          {
            fldBanner.SaveAs(this.Server.MapPath("~/") + this.BannerOriginalImagePath + FileName);
            Resizer.FixedSize(FileName, fldBanner, this.BannerThumbImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["BannerThumbImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["BannerThumbImageHeight"]));
          }
          else
            fldBanner.SaveAs(this.Server.MapPath("~/") + this.BannerOriginalImagePath + FileName);
          bannerRequest.BannerImage = FileName;
          if (!string.IsNullOrEmpty(this.hdnBannerName.Value))
          {
            FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.BannerOriginalImagePath + this.hdnBannerName.Value);
            if (fileInfo.Exists)
              fileInfo.Delete();
          }
        }
      }
      else
        bannerRequest.BannerImage = this.hdnDocName.Value;
      if (BannerMgmt.AddEditBanner(bannerRequest) == -1L)
      {
        if (this.fBannerID == 0L)
        {
          this.txtBanner.Text = "";
          this.Session["fldBanner"] = (object) null;
        }
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Banner Title"), (Enums.NotificationType) 2, false), true);
      }
      else
      {
        if (this.fBannerID > 0L)
          this.Session[nameof (AddUpdateBanner)] = (object) string.Format(Messages.UpdateSuccess, (object) "Banner");
        else
          this.Session[nameof (AddUpdateBanner)] = (object) string.Format(Messages.AddSuccess, (object) "Banner");
        this.Response.Redirect("~/Admin/ViewBanner.aspx");
      }
    }

    protected void btnBannerDelete_Click(object sender, EventArgs e)
    {
      BannerMgmt.DeleteBannerImageById(this.fBannerID);
      FileInfo fileInfo1 = new FileInfo(this.Server.MapPath("~/") + this.BannerOriginalImagePath + this.hdnBannerName.Value);
      if (!fileInfo1.Exists)
        return;
      fileInfo1.Delete();
      FileInfo fileInfo2 = new FileInfo(this.Server.MapPath("~/") + this.BannerThumbImagePath + this.hdnBannerName.Value);
      if (fileInfo2.Exists)
        fileInfo2.Delete();
      this.hdnBannerDoc.Value = "none";
      this.hdndivBanner.Value = "block";
      this.hdnBannerCancel.Value = "none";
      this.hdnBannerName.Value = "none";
      this.fldBanner.Dispose();
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) Messages.BannerImage), (Enums.NotificationType) 1), true);
    }
  }
}
