﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewGallerys
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.GalleryManagement;
using Entity.Common.GalleryManagement;
using Entity.Response.GalleryManagement;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewGallerys : Page
  {
    public long UserId;
    public string GalleryOriginalImagePath = ConfigurationManager.AppSettings[nameof (GalleryOriginalImagePath)];
    public string GalleryThumbImagePath = ConfigurationManager.AppSettings[nameof (GalleryThumbImagePath)];
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HiddenField hdnCount;
    protected HtmlGenericControl H1Title;
    protected RadGrid grdGallery;
    protected HtmlTable tableLegend;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liGalleryManagement");
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["AddUpdateGallery"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["AddUpdateGallery"]), (Enums.NotificationType) 1), true);
        this.Session["AddUpdateGallery"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<GalleryResponseBE> galleryResponseBeList = new List<GalleryResponseBE>();
      List<GalleryResponseBE> allGallery = GalleryMgmt.GetAllGallery();
      this.grdGallery.VirtualItemCount = allGallery.Count<GalleryResponseBE>();
      this.hdnCount.Value = allGallery.Count<GalleryResponseBE>().ToString();
      ((BaseDataBoundControl) this.grdGallery).DataSource = (object) allGallery;
      ((Control) this.grdGallery).DataBind();
      if (allGallery.Count<GalleryResponseBE>() != 0)
        return;
      this.grdGallery.AllowFilteringByColumn = false;
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }

    protected void grdGallery_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdGallery.MasterTableView.Items).Count == 0)
      {
        this.grdGallery.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdGallery.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdGallery.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdGallery.PagerStyle.AlwaysVisible = true;
      }
      this.grdGallery.Rebind();
      ViewGallerys.SetPaggingText(this.grdGallery, "Paging");
    }

    protected void grdGallery_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdGallery_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdGallery_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdGallery_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        GalleryBE detailBgalleryId = GalleryMgmt.GetGalleryDetailBGalleryID(Convert.ToInt64(((CommandEventArgs) e).CommandArgument.ToString()));
        if (!string.IsNullOrEmpty(detailBgalleryId.Image))
        {
          FileInfo fileInfo1 = new FileInfo(this.Server.MapPath("~/") + this.GalleryOriginalImagePath + detailBgalleryId.Image);
          if (fileInfo1.Exists)
            fileInfo1.Delete();
          FileInfo fileInfo2 = new FileInfo(this.Server.MapPath("~/") + this.GalleryThumbImagePath + detailBgalleryId.Image);
          if (fileInfo2.Exists)
            fileInfo2.Delete();
        }
        GalleryMgmt.DeleteGallery(((CommandEventArgs) e).CommandArgument.ToString());
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) "Gallery"), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdGallery.Rebind();
    }

    protected void grdGallery_ItemDataBound(object sender, GridItemEventArgs e)
    {
      if (e.Item.ItemType != 7 && e.Item.ItemType != 1)
        return;
      HtmlAnchor control = (HtmlAnchor) ((Control) e.Item).FindControl("a_view");
      string str = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "Image"));
      if (!string.IsNullOrEmpty(str))
      {
        if (control != null)
        {
          control.HRef = ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["GalleryOriginalImagePath"] + str;
          control.InnerHtml = "<img src=\"../Content/Panels/images/image_icon.png\" alt=\"View Image\" title=\"View Image\" style=\"border: none;\" />";
          control.Attributes.Add("class", "highslide");
          control.Attributes.Add("onclick", "return hs.expand(this);");
          control.Style.Add("margin", "5px auto 0 auto");
        }
      }
      else if (control != null)
      {
        control.HRef = "#";
        control.InnerHtml = "-";
        control.Style.Add("margin", "0px 0px 0 14px");
      }
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) "Gallery") + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewGallerys.aspx");
  }
}
