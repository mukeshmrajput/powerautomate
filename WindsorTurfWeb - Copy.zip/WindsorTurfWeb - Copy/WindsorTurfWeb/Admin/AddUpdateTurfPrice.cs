﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateTurfPrice
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.TurfProductPricing.TurfPricing;
using Entity.Common.ProductPricing.TurfProductPricing.TurfPricing;
using Entity.Response.ProductPricing.TurfProductPricing.TurfPricing;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateTurfPrice : Page
  {
    public static long fTurfPriceID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected DropDownList ddlTurfProduct;
    protected RequiredFieldValidator rfvTurfProduct;
    protected DropDownList ddlTurfZone;
    protected RequiredFieldValidator rfvTurfZone;
    protected DropDownList ddlTurfRange;
    protected RequiredFieldValidator rfvTurfRange;
    protected TextBox txtRetailPrice;
    protected RequiredFieldValidator rfvRetailPrice;
    protected RegularExpressionValidator regRetailPrice;
    protected TextBox txtTradePrice;
    protected RequiredFieldValidator rfvTradePrice;
    protected RegularExpressionValidator regTradePrice;
    protected TextBox txtCausalTradePrice;
    protected RequiredFieldValidator rfvCausalTradePrice;
    protected RegularExpressionValidator regCausalTradePrice;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnTurfPriceID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewTurfPrice");
      if (this.Request.QueryString["TurfPriceID"] != null)
      {
        AddUpdateTurfPrice.fTurfPriceID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["TurfPriceID"].ToString()));
        this.h1Title.InnerText = "Edit Turf Price";
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
      }
      else
      {
        this.h1Title.InnerText = "Add Turf Price";
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateTurfPrice.fTurfPriceID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.BindDropdown();
        this.ValidationExpression();
        if (AddUpdateTurfPrice.fTurfPriceID > 0L)
          this.GetTurfPriceDetails(TurfPriceMgmt.GetTurfPriceDetailByID(Convert.ToInt64(AddUpdateTurfPrice.fTurfPriceID)));
      }
      this.ddlTurfProduct.Focus();
    }

    protected void GetTurfPriceDetails(TurfPriceResponseBE objTurfPriceResponseBE)
    {
      this.ddlTurfProduct.SelectedValue = Convert.ToString(objTurfPriceResponseBE.TurfProductID);
      this.ddlTurfRange.SelectedValue = Convert.ToString(objTurfPriceResponseBE.TurfRangeID);
      this.ddlTurfZone.SelectedValue = Convert.ToString(objTurfPriceResponseBE.TurfZoneID);
      this.txtRetailPrice.Text = Convert.ToString(objTurfPriceResponseBE.RetailPrice);
      this.txtTradePrice.Text = Convert.ToString(objTurfPriceResponseBE.TradePrice);
      this.txtCausalTradePrice.Text = Convert.ToString(objTurfPriceResponseBE.CausalTradePrice);
      this.chkIsActive.Checked = Convert.ToBoolean(objTurfPriceResponseBE.IsActive);
    }

    protected void BindDropdown()
    {
      BindDropDown.BindTurfProduct((ListControl) this.ddlTurfProduct);
      BindDropDown.BindTurfZone((ListControl) this.ddlTurfZone);
      BindDropDown.BindTurfRange((ListControl) this.ddlTurfRange);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      TurfPriceBE turfPriceBe = new TurfPriceBE();
      turfPriceBe.TurfPriceID = AddUpdateTurfPrice.fTurfPriceID <= 0L ? 0L : AddUpdateTurfPrice.fTurfPriceID;
      turfPriceBe.TurfProductID = Convert.ToInt64(this.ddlTurfProduct.SelectedValue);
      turfPriceBe.TurfZoneID = Convert.ToInt64(this.ddlTurfZone.SelectedValue);
      turfPriceBe.TurfRangeID = Convert.ToInt64(this.ddlTurfRange.SelectedValue);
      turfPriceBe.RetailPrice = Convert.ToDecimal(this.txtRetailPrice.Text.Trim());
      turfPriceBe.TradePrice = Convert.ToDecimal(this.txtTradePrice.Text.Trim());
      turfPriceBe.CausalTradePrice = Convert.ToDecimal(this.txtCausalTradePrice.Text.Trim());
      turfPriceBe.IsActive = this.chkIsActive.Checked;
      turfPriceBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      turfPriceBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      if (TurfPriceMgmt.AddUpdateTurfPrice(turfPriceBe) > 0L)
      {
        if (turfPriceBe.TurfPriceID > 0L)
          this.Session["TurfPriceAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) "Turf Price");
        else if (turfPriceBe.TurfPriceID == 0L)
          this.Session["TurfPriceAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) "Turf Price");
        this.Response.Redirect("~/Admin/ViewTurfPrice.aspx");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.TurfProductExists.ToString()), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorDropdown(this.rfvTurfZone, true, (object) this.ddlTurfZone, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvTurfRange, true, (object) this.ddlTurfRange, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvTurfProduct, true, (object) this.ddlTurfProduct, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvRetailPrice, true, (object) this.txtRetailPrice, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regRetailPrice, Regex.NumbersWithDotOnly, true, (object) this.txtRetailPrice, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTradePrice, true, (object) this.txtTradePrice, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTradePrice, Regex.NumbersWithDotOnly, true, (object) this.txtTradePrice, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvCausalTradePrice, true, (object) this.txtCausalTradePrice, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regCausalTradePrice, Regex.NumbersWithDotOnly, true, (object) this.txtCausalTradePrice, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
