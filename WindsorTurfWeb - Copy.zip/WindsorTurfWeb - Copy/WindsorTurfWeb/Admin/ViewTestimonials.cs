﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewTestimonials
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Testimonials;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewTestimonials : Page
  {
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HiddenField hdnCount;
    protected HtmlGenericControl H1Title;
    protected RadGrid grdTestimonials;
    protected HtmlTable tableLegend;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liTestimonials");
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["AddUpdateTestimonials"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["AddUpdateTestimonials"]), (Enums.NotificationType) 1), true);
        this.Session["AddUpdateTestimonials"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<Entity.Common.Testimonials.Testimonials> testimonialsList = new List<Entity.Common.Testimonials.Testimonials>();
      List<Entity.Common.Testimonials.Testimonials> testimonialsForAdmin = TestimonialsMgmt.GetTestimonialsForAdmin();
      this.grdTestimonials.VirtualItemCount = testimonialsForAdmin.Count<Entity.Common.Testimonials.Testimonials>();
      this.hdnCount.Value = testimonialsForAdmin.Count<Entity.Common.Testimonials.Testimonials>().ToString();
      ((BaseDataBoundControl) this.grdTestimonials).DataSource = (object) testimonialsForAdmin;
      ((Control) this.grdTestimonials).DataBind();
      if (testimonialsForAdmin.Count<Entity.Common.Testimonials.Testimonials>() != 0)
        return;
      this.grdTestimonials.AllowFilteringByColumn = false;
    }

    protected void grdTestimonials_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdTestimonials.MasterTableView.Items).Count == 0)
      {
        this.grdTestimonials.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdTestimonials.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdTestimonials.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdTestimonials.PagerStyle.AlwaysVisible = true;
      }
      this.grdTestimonials.Rebind();
      ViewTestimonials.SetPaggingText(this.grdTestimonials, "Paging");
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }

    protected void grdTestimonials_SortCommand(object sender, EventArgs e) => this.BindGrid();

    protected void grdTestimonials_PageSizeChanged(object sender, EventArgs e) => this.BindGrid();

    protected void grdTestimonials_PageIndexChanged(object sender, EventArgs e) => this.BindGrid();

    protected void grdTestimonials_ItemCommand(object sender, EventArgs e) => this.BindGrid();

    protected void grdTestimonials_ItemDataBound(object sender, EventArgs e)
    {
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) "Testimonials") + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewTestimonials.aspx");
  }
}
