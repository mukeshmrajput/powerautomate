﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.Default
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Login;
using BLL.UserManagement;
using Entity.Common.Request;
using Entity.Common.Response;
using Entity.Common.UserManagement;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class Default : Page
  {
    protected HtmlForm form1;
    protected System.Web.UI.ScriptManager SManager;
    protected HtmlGenericControl divMsg;
    protected Literal ltrlMsg;
    protected TextBox txtUserName;
    protected RequiredFieldValidator reqUsername;
    protected RegularExpressionValidator regUsername;
    protected TextBox txtPassword;
    protected RequiredFieldValidator reqPassqord;
    protected RegularExpressionValidator regPassword;
    protected Button btnLogin;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Title = UtilityFunctions.AdminPageTitle("Login");
      this.Page.Form.DefaultButton = this.btnLogin.UniqueID;
      this.Page.Form.DefaultFocus = this.txtUserName.UniqueID;
      if (this.GetCommercialPartnerInactiveStatus() == "Inactive")
      {
        FormsAuthentication.SignOut();
        this.Session.Clear();
        if (this.Request.Cookies[".Frontendcookie"] != null)
          this.Response.Cookies.Add(new HttpCookie(".Frontendcookie")
          {
            Expires = DateTime.Now.AddDays(-1.0)
          });
        this.Session["InactivateAdminUser"] = (object) "InactivateAdminUser";
        this.Response.Redirect("~/Admin/Default.aspx");
      }
      if (this.Session["InactivateAdminUser"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.InactiveMsg.ToString()), (Enums.NotificationType) 2, false), true);
        this.Session["InactivateAdminUser"] = (object) null;
        this.Session.Abandon();
      }
      if (!this.IsPostBack)
      {
        this.txtUserName.Focus();
        this.ValidationIntialization();
      }
      this.divMsg.Visible = false;
      this.ltrlMsg.Text = string.Empty;
    }

    private void ValidationIntialization()
    {
      this.reqUsername.ErrorMessage = string.Format(Validation.RequiredFieldTextbox, (object) "Email");
      this.reqPassqord.ErrorMessage = string.Format(Validation.RequiredFieldTextbox, (object) "Password");
      this.regUsername.ErrorMessage = string.Format(Validation.Invalid, (object) "Email");
      this.regPassword.ErrorMessage = string.Format(Validation.Invalid, (object) "Password");
      this.regUsername.ValidationExpression = Regex.Email;
      this.regPassword.ValidationExpression = Regex.Password;
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
      string url = "";
      string str1 = Convert.ToString((object) this.Request.UrlReferrer);
      if (str1.IndexOf('=') > 0)
        url = str1.Substring(str1.IndexOf('=')).TrimStart('=');
      HttpContext current = HttpContext.Current;
      AuthenticateUserRequest authenticateUserRequest = new AuthenticateUserRequest();
      authenticateUserRequest.UserLoginEmail = this.txtUserName.Text.Trim();
      authenticateUserRequest.UserPassword = Encryption.EncryptQueryString(this.txtPassword.Text.Trim());
      authenticateUserRequest.LoginIP = this.Request.UserHostAddress;
      authenticateUserRequest.Browser = current.Request.Browser.Browser + " " + current.Request.Browser.Version;
      List<AuthenticateUserResponse> authenticateUserResponseList1 = new List<AuthenticateUserResponse>();
      List<AuthenticateUserResponse> authenticateUserResponseList2 = AuthenticateUserMgmt.AuthenticateUser(authenticateUserRequest);
      if (!this.IsValid)
        return;
      try
      {
        if (authenticateUserResponseList2.Count > 0)
        {
          string str2 = Guid.NewGuid().ToString();
          string[] strArray = new string[11];
          long num = authenticateUserResponseList2[0].LoginMasterID;
          strArray[0] = num.ToString();
          strArray[1] = ",";
          strArray[2] = authenticateUserResponseList2[0].Email;
          strArray[3] = ",";
          strArray[4] = authenticateUserResponseList2[0].UserName;
          strArray[5] = ",";
          num = authenticateUserResponseList2[0].UserTypeID;
          strArray[6] = num.ToString();
          strArray[7] = ",";
          num = authenticateUserResponseList2[0].ProfileID;
          strArray[8] = num.ToString();
          strArray[9] = ",";
          strArray[10] = str2.ToString();
          FormsAuthentication.SetAuthCookie(string.Concat(strArray), true, FormsAuthentication.FormsCookiePath);
          if (authenticateUserResponseList2[0].LoginMasterID == 0L)
          {
            this.divMsg.Visible = true;
            this.ltrlMsg.Text = Validation.InvalidEmailPassword;
            this.txtUserName.Focus();
          }
          else if (!string.IsNullOrEmpty(url))
            this.Response.Redirect(url);
          else
            this.Response.Redirect("~/Admin/Welcome.aspx");
        }
        else
        {
          this.divMsg.Visible = true;
          this.ltrlMsg.Text = Validation.InvalidEmailPassword;
          this.txtUserName.Focus();
        }
      }
      catch (Exception ex)
      {
        this.divMsg.Visible = true;
        this.ltrlMsg.Text = Validation.InvalidEmailPassword;
        this.txtUserName.Focus();
      }
    }

    protected string GetCommercialPartnerInactiveStatus()
    {
      string partnerInactiveStatus = string.Empty;
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
      {
        UserBE userInfoById = UserMgmt.GetUserInfoById(Convert.ToInt64(Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)))));
        if (userInfoById != null && !userInfoById.IsActive)
          partnerInactiveStatus = "Inactive";
      }
      return partnerInactiveStatus;
    }
  }
}
