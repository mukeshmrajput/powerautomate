﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateAccountDetail
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PaymentOptions.AccountDetail;
using BLL.PurchaseOrderDetail;
using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Common.PaymentOptions.AccountDetail;
using Entity.Common.PurchaseOrderDetail;
using Entity.Response.PaymentOptions.AccountDetail;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateAccountDetail : Page
  {
    public static long fAccountDetailID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    public long LoginMasterID;
    protected HtmlGenericControl h1Title;
    protected DropDownList ddlCommercialPartner;
    protected RequiredFieldValidator rfvCommercialPartner;
    protected DropDownList ddlAmountApproved;
    protected TextBox txtAccountMinimumAmount;
    protected RequiredFieldValidator rfvAccountMinimumAmount;
    protected RegularExpressionValidator regAccountMinimumAmount;
    protected TextBox txtAccountMaximumAmount;
    protected RequiredFieldValidator rfvAccountMaximumAmount;
    protected RegularExpressionValidator regAccountMaximumAmount;
    protected HtmlGenericControl divPriceDetail;
    protected Repeater rptTurfProductTradePrice;
    protected Repeater rptNonTurfProductTradePrice;
    protected HtmlGenericControl DivUnpaidAmount;
    protected TextBox txtUnpaidAmount;
    protected CheckBox chkIsActive;
    protected HtmlTable DivTable;
    protected RadGrid grdOrderProcessingPurchaseDetail;
    protected HtmlTable tableLegend;
    protected Button btnSubmit;
    protected HiddenField hdnDeliveryPriceID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liAccountDetail");
      if (this.Request.QueryString[QueryStrings.AccountDetailID] != null)
      {
        AddUpdateAccountDetail.fAccountDetailID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.AccountDetailID].ToString()));
        this.h1Title.InnerText = "Edit " + PageName.strAddAcount;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddAcount;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateAccountDetail.fAccountDetailID = 0L;
        ((Control) this.grdOrderProcessingPurchaseDetail).Visible = false;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        BindDropDown.BindGetCommercialPartner((ListControl) this.ddlCommercialPartner);
        if (AddUpdateAccountDetail.fAccountDetailID > 0L)
          this.GetCommercialPartnerDetails(AccountDetailMgmt.GetAccountDetailByID(Convert.ToInt64(AddUpdateAccountDetail.fAccountDetailID)));
      }
      this.ddlCommercialPartner.Focus();
    }

    protected void GetCommercialPartnerDetails(AccountDetailResponseBE objAccountDetailBE)
    {
      AddUpdateAccountDetail.fAccountDetailID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.AccountDetailID].ToString()));
      List<TurfProductResponseBE> productResponseBeList = new List<TurfProductResponseBE>();
      List<TurfProductResponseBE> commercialPartner = TurfProductMgmt.GetAccountProductDetailsByCommercialPartner(Convert.ToInt64(AddUpdateAccountDetail.fAccountDetailID));
      this.rptTurfProductTradePrice.DataSource = (object) commercialPartner.Where<TurfProductResponseBE>((System.Func<TurfProductResponseBE, bool>) (m => m.TurfType == "Turf")).ToList<TurfProductResponseBE>();
      this.rptTurfProductTradePrice.DataBind();
      this.rptNonTurfProductTradePrice.DataSource = (object) commercialPartner.Where<TurfProductResponseBE>((System.Func<TurfProductResponseBE, bool>) (m => m.TurfType == "NonTurf")).ToList<TurfProductResponseBE>();
      this.rptNonTurfProductTradePrice.DataBind();
      List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
      purchaseOrderDetailBeList = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetail();
      this.ddlCommercialPartner.SelectedValue = Convert.ToString(objAccountDetailBE.UserID);
      if (objAccountDetailBE.IsAmountApproved)
      {
        this.ddlAmountApproved.SelectedValue = "1";
        this.divPriceDetail.Visible = true;
      }
      else if (!objAccountDetailBE.IsAmountApproved)
        this.ddlAmountApproved.SelectedValue = "0";
      this.txtAccountMinimumAmount.Text = Convert.ToString(objAccountDetailBE.MinimumAmount);
      this.txtAccountMaximumAmount.Text = Convert.ToString(objAccountDetailBE.MaximumAmount);
      this.chkIsActive.Checked = objAccountDetailBE.IsActive;
      this.ddlCommercialPartner.Enabled = false;
      this.DivUnpaidAmount.Visible = true;
      this.DivTable.Visible = true;
      long userId = objAccountDetailBE.UserID;
      this.txtUnpaidAmount.Text = Convert.ToString(AccountDetailMgmt.GetUnpaidAmountTotalByLoginMasterID(Convert.ToInt64(userId)).UnpaidAmountTotal);
      this.BindGrid(userId);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      AccountDetailBE accountDetailBe = new AccountDetailBE();
      accountDetailBe.AccountDetailID = AddUpdateAccountDetail.fAccountDetailID <= 0L ? 0L : AddUpdateAccountDetail.fAccountDetailID;
      accountDetailBe.IsAmountApproved = Convert.ToBoolean(Convert.ToInt32(this.ddlAmountApproved.SelectedValue));
      accountDetailBe.UserID = Convert.ToInt64(this.ddlCommercialPartner.SelectedValue);
      accountDetailBe.MinimumAmount = Convert.ToDecimal(this.txtAccountMinimumAmount.Text.Trim());
      accountDetailBe.MaximumAmount = Convert.ToDecimal(this.txtAccountMaximumAmount.Text.Trim());
      accountDetailBe.IsActive = this.chkIsActive.Checked;
      accountDetailBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      accountDetailBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      DataTable dataTable = this.AddColumns(new DataTable());
      if (this.rptTurfProductTradePrice.Items.Count > 0)
      {
        for (int index = 0; index < this.rptTurfProductTradePrice.Items.Count; ++index)
        {
          DataRow row = dataTable.NewRow();
          row["TurfProductID"] = (object) (this.rptTurfProductTradePrice.Items[index].FindControl("hdnTurfProductID") as HiddenField).Value;
          row["TurfName"] = (object) Convert.ToString((this.rptTurfProductTradePrice.Items[index].FindControl("lblTurfName") as Label).Text);
          row["TurfType"] = (object) "Turf";
          row["DefaultTradePriceofProduct"] = (object) Convert.ToDecimal((this.rptTurfProductTradePrice.Items[index].FindControl("lblTurfDefaultTradePrice") as Label).Text);
          row["NewTradePriceofProduct"] = (object) Convert.ToDecimal((this.rptTurfProductTradePrice.Items[index].FindControl("txtTurfNewTradePrice") as TextBox).Text);
          dataTable.Rows.Add(row);
        }
      }
      if (this.rptNonTurfProductTradePrice.Items.Count > 0)
      {
        for (int index = 0; index < this.rptNonTurfProductTradePrice.Items.Count; ++index)
        {
          DataRow row = dataTable.NewRow();
          row["TurfProductID"] = (object) (this.rptNonTurfProductTradePrice.Items[index].FindControl("hdnNonTurfProductID") as HiddenField).Value;
          row["TurfName"] = (object) Convert.ToString((this.rptNonTurfProductTradePrice.Items[index].FindControl("lblNonTurfName") as Label).Text);
          row["TurfType"] = (object) "NonTurf";
          row["DefaultTradePriceofProduct"] = (object) Convert.ToDecimal((this.rptNonTurfProductTradePrice.Items[index].FindControl("lblNonTurfDefaultTradePrice") as Label).Text);
          row["NewTradePriceofProduct"] = (object) Convert.ToDecimal((this.rptNonTurfProductTradePrice.Items[index].FindControl("txtNonTurfNewTradePrice") as TextBox).Text);
          dataTable.Rows.Add(row);
        }
      }
      accountDetailBe.dtAccountProductDetailByCommercialPartner = dataTable;
      if (AccountDetailMgmt.AddUpdateAccountDetail(accountDetailBe) > 0L)
      {
        if (accountDetailBe.AccountDetailID > 0L)
          this.Session["AccountDetailAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddAcount);
        else if (accountDetailBe.AccountDetailID == 0L)
          this.Session["AccountDetailAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddAcount);
        this.Response.Redirect("~/Admin/ViewAccountDetail.aspx");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) PageName.strAddAcount), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      this.rfvAccountMinimumAmount.ErrorMessage = string.Format(Validation.Required);
      this.regAccountMinimumAmount.ValidationExpression = Regex.AmountPrice;
      this.regAccountMinimumAmount.ErrorMessage = string.Format(Validation.Invalid1);
      this.rfvAccountMaximumAmount.ErrorMessage = string.Format(Validation.Required);
      this.regAccountMaximumAmount.ValidationExpression = Regex.AmountPrice;
      this.regAccountMaximumAmount.ErrorMessage = string.Format(Validation.Invalid1);
      this.rfvCommercialPartner.ErrorMessage = string.Format(Validation.Required);
    }

    protected void ddlAmountApproved_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.ddlAmountApproved.SelectedValue == "1")
      {
        this.divPriceDetail.Visible = true;
        this.BindTradePriceDetailByProduct();
      }
      else
        this.divPriceDetail.Visible = false;
    }

    protected void BindTradePriceDetailByProduct()
    {
      List<TurfProductResponseBE> tradePriceByProduct1 = TurfProductMgmt.GetTurfProductsDefaultTradePriceByProduct();
      if (tradePriceByProduct1 != null)
      {
        this.rptTurfProductTradePrice.DataSource = (object) tradePriceByProduct1;
        this.rptTurfProductTradePrice.DataBind();
      }
      else
      {
        this.rptTurfProductTradePrice.DataSource = (object) null;
        this.rptTurfProductTradePrice.DataBind();
      }
      List<NonTurfProductResponseBE> tradePriceByProduct2 = NonTurfProductMgmt.GetNonTurfProductsDefaultTradePriceByProduct();
      if (tradePriceByProduct2 != null)
      {
        this.rptNonTurfProductTradePrice.DataSource = (object) tradePriceByProduct2;
        this.rptNonTurfProductTradePrice.DataBind();
      }
      else
      {
        this.rptNonTurfProductTradePrice.DataSource = (object) null;
        this.rptNonTurfProductTradePrice.DataBind();
      }
    }

    protected void rptNonTurfProductTradePrice_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        (e.Item.FindControl("rfvNonTurfNewTradePrice") as RequiredFieldValidator).ErrorMessage = string.Format(Validation.Required);
      if (AddUpdateAccountDetail.fAccountDetailID > 0L || e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      Label control = (Label) e.Item.FindControl("lblNonTurfDefaultTradePrice");
      ((TextBox) e.Item.FindControl("txtNonTurfNewTradePrice")).Text = control.Text;
    }

    protected void rptTurfProductTradePrice_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        (e.Item.FindControl("rfvTurfNewTradePrice") as RequiredFieldValidator).ErrorMessage = string.Format(Validation.Required);
      if (AddUpdateAccountDetail.fAccountDetailID > 0L || e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      Label control = (Label) e.Item.FindControl("lblTurfDefaultTradePrice");
      ((TextBox) e.Item.FindControl("txtTurfNewTradePrice")).Text = control.Text;
    }

    private DataTable AddColumns(DataTable dtRange)
    {
      dtRange.Columns.Add(new DataColumn("TurfProductID", typeof (long)));
      dtRange.Columns.Add(new DataColumn("TurfName", typeof (string)));
      dtRange.Columns.Add(new DataColumn("TurfType", typeof (string)));
      dtRange.Columns.Add(new DataColumn("DefaultTradePriceofProduct", typeof (Decimal)));
      dtRange.Columns.Add(new DataColumn("NewTradePriceofProduct", typeof (Decimal)));
      return dtRange;
    }

    private void BindGrid(long LoginMasterID)
    {
      List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
      List<PurchaseOrderDetailBE> totalByLoginMasterId = PurchaseOrderDetailMgmt.GetAllUnpaidAmountTotalByLoginMasterID(LoginMasterID);
      this.grdOrderProcessingPurchaseDetail.VirtualItemCount = totalByLoginMasterId.Count<PurchaseOrderDetailBE>();
      ((BaseDataBoundControl) this.grdOrderProcessingPurchaseDetail).DataSource = (object) totalByLoginMasterId;
      ((Control) this.grdOrderProcessingPurchaseDetail).DataBind();
      if (totalByLoginMasterId.Count<PurchaseOrderDetailBE>() == 0)
        this.grdOrderProcessingPurchaseDetail.AllowFilteringByColumn = false;
      AddUpdateAccountDetail.SetPaggingText(this.grdOrderProcessingPurchaseDetail, "Paging");
    }

    protected void grdOrderProcessingPurchaseDetail_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdOrderProcessingPurchaseDetail.MasterTableView.Items).Count == 0)
      {
        this.grdOrderProcessingPurchaseDetail.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdOrderProcessingPurchaseDetail.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdOrderProcessingPurchaseDetail.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdOrderProcessingPurchaseDetail.PagerStyle.AlwaysVisible = true;
      }
      this.grdOrderProcessingPurchaseDetail.Rebind();
      AddUpdateAccountDetail.SetPaggingText(this.grdOrderProcessingPurchaseDetail, "Paging");
    }

    protected void grdOrderProcessingPurchaseDetail_SortCommand(
      object sender,
      GridSortCommandEventArgs e)
    {
      this.LoginMasterID = AccountDetailMgmt.GetAccountDetailByID(Convert.ToInt64(AddUpdateAccountDetail.fAccountDetailID)).UserID;
      this.BindGrid(this.LoginMasterID);
    }

    protected void grdOrderProcessingPurchaseDetail_PageSizeChanged(
      object sender,
      GridPageSizeChangedEventArgs e)
    {
      this.LoginMasterID = AccountDetailMgmt.GetAccountDetailByID(Convert.ToInt64(AddUpdateAccountDetail.fAccountDetailID)).UserID;
      this.BindGrid(this.LoginMasterID);
    }

    protected void grdOrderProcessingPurchaseDetail_PageIndexChanged(
      object sender,
      GridPageChangedEventArgs e)
    {
      this.LoginMasterID = AccountDetailMgmt.GetAccountDetailByID(Convert.ToInt64(AddUpdateAccountDetail.fAccountDetailID)).UserID;
      this.BindGrid(this.LoginMasterID);
    }

    protected void grdOrderProcessingPurchaseDetail_ItemCommand(
      object sender,
      GridCommandEventArgs e)
    {
      this.LoginMasterID = AccountDetailMgmt.GetAccountDetailByID(Convert.ToInt64(AddUpdateAccountDetail.fAccountDetailID)).UserID;
      this.BindGrid(this.LoginMasterID);
      this.grdOrderProcessingPurchaseDetail.Rebind();
    }

    protected void grdOrderProcessingPurchaseDetail_ItemDataBound(
      object sender,
      GridItemEventArgs e)
    {
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
