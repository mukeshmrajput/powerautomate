﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewTurfProductDetails
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class ViewTurfProductDetails : Page
  {
    private long TurfProductID = 0;
    protected HtmlHead Head1;
    protected HtmlForm form1;
    protected HtmlGenericControl h1Title;
    protected Literal lblTurfName;
    protected Literal lblDescription;
    protected Literal lblUses;
    protected Literal lblMaintenance;
    protected Literal lblCharacteristics;
    protected Literal lblTurfClassification;
    protected CheckBox ChkStatus;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.Request.QueryString[QueryStrings.TurfProductID] != null)
        this.TurfProductID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.TurfProductID].ToString()));
      if (this.IsPostBack || this.TurfProductID <= 0L)
        return;
      this.FillAllData(TurfProductMgmt.GetTurfProductDetailByID(this.TurfProductID));
    }

    protected void FillAllData(TurfProductResponseBE obj)
    {
      if (obj == null)
        return;
      this.lblTurfName.Text = obj.TurfName;
      this.lblDescription.Text = obj.Description;
      this.lblUses.Text = obj.Uses;
      this.lblMaintenance.Text = obj.Maintenance;
      this.lblCharacteristics.Text = obj.Characteristics;
      this.lblTurfClassification.Text = obj.TurfClassificationName;
      this.ChkStatus.Checked = obj.IsActive;
    }
  }
}
