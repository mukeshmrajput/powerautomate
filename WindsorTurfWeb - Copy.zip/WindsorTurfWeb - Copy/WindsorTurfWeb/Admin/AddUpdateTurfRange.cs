﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateTurfRange
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.TurfProductPricing.TurfRanges;
using Entity.Common.ProductPricing.TurfProductPricing.TurfRanges;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateTurfRange : Page
  {
    public static long fTurfRangeID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtTurfRangeTitle;
    protected RequiredFieldValidator rfvTurfRangeTitle;
    protected RegularExpressionValidator regTurfRangeTitle;
    protected TextBox txtStartIndex;
    protected RequiredFieldValidator rfvStartIndex;
    protected TextBox txtEndIndex;
    protected RequiredFieldValidator rfvEndIndex;
    protected CompareValidator cmpStartEndIndex;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnTurfRangeID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewTurfRange");
      if (this.Request.QueryString["TurfRangeID"] != null)
      {
        AddUpdateTurfRange.fTurfRangeID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["TurfRangeID"].ToString()));
        this.h1Title.InnerText = "Edit Turf Range";
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
      }
      else
      {
        this.h1Title.InnerText = "Add Turf Range";
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateTurfRange.fTurfRangeID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        if (AddUpdateTurfRange.fTurfRangeID > 0L)
          this.GetTurfRangeDetails(TurfRangeMgmt.GetTurfRangeDetailByID(Convert.ToInt64(AddUpdateTurfRange.fTurfRangeID)));
      }
      this.txtTurfRangeTitle.Focus();
    }

    protected void GetTurfRangeDetails(TurfRangeBE objTurfRangeBE)
    {
      this.txtTurfRangeTitle.Text = objTurfRangeBE.Title;
      this.txtStartIndex.Text = Convert.ToString(objTurfRangeBE.StartIndex);
      this.txtEndIndex.Text = Convert.ToString(objTurfRangeBE.EndIndex);
      this.chkIsActive.Checked = objTurfRangeBE.IsActive;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      TurfRangeBE turfRangeBe = new TurfRangeBE();
      turfRangeBe.TurfRangeID = AddUpdateTurfRange.fTurfRangeID <= 0L ? 0L : AddUpdateTurfRange.fTurfRangeID;
      turfRangeBe.Title = this.txtTurfRangeTitle.Text.Trim();
      turfRangeBe.StartIndex = Convert.ToInt32(this.txtStartIndex.Text.Trim());
      turfRangeBe.EndIndex = Convert.ToInt32(this.txtEndIndex.Text.Trim());
      turfRangeBe.IsActive = this.chkIsActive.Checked;
      turfRangeBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      turfRangeBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      if (TurfRangeMgmt.AddUpdateTurfRange(turfRangeBe) > 0L)
      {
        if (turfRangeBe.TurfRangeID > 0L)
          this.Session["TurfRangeAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) "Turf Range");
        else if (turfRangeBe.TurfRangeID == 0L)
          this.Session["TurfRangeAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) "Turf Range");
        this.Response.Redirect("~/Admin/ViewTurfRange.aspx");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Turf Range"), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvTurfRangeTitle, true, (object) this.txtTurfRangeTitle, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTurfRangeTitle, Regex.Subject, true, (object) this.txtTurfRangeTitle, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvStartIndex, true, (object) this.txtStartIndex, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvEndIndex, true, (object) this.txtEndIndex, this.strValidationTurfGrp);
      this.cmpStartEndIndex.ValidationGroup = this.strValidationTurfGrp;
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
