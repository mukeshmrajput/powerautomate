﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateGallery
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.GalleryManagement;
using Entity.Common.GalleryManagement;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateGallery : Page
  {
    public long fGalleryMgmntID = 0;
    public long UserId;
    public string GalleryOriginalImagePath = ConfigurationManager.AppSettings[nameof (GalleryOriginalImagePath)];
    public string GalleryThumbImagePath = ConfigurationManager.AppSettings[nameof (GalleryThumbImagePath)];
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected TextBox txtTitle;
    protected RequiredFieldValidator rfvTitle;
    protected RegularExpressionValidator regTitle;
    protected TextBox txtGallery;
    protected FileUpload fldGallery;
    protected HtmlAnchor lnkGallaryImage;
    protected HtmlAnchor lnkGalleryThumb;
    protected Image ImgThumb;
    protected Button btnGalleryDelete;
    protected HiddenField hdndivGallery;
    protected HiddenField hdnGalleryDoc;
    protected HiddenField hdnGalleryCancel;
    protected HiddenField hdnGalleryName;
    protected HiddenField hdnUploadType;
    protected HiddenField hdnDocName;
    protected RequiredFieldValidator rfvImage;
    protected TextBox txtGalleryDesc;
    protected RequiredFieldValidator rfvDescription;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liGalleryManagement");
      this.txtTitle.Focus();
      this.ValidationExpression();
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      this.fGalleryMgmntID = 0L;
      if (this.Request.QueryString["GalleryMgmntID"] != null)
        this.fGalleryMgmntID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["GalleryMgmntID"].ToString()));
      if (!this.IsPostBack)
      {
        if (this.Request.QueryString["GalleryMgmntID"] != null)
        {
          this.h1Title.InnerText = "Edit Gallery";
          this.btnSubmit.Text = "Update";
          this.btnSubmit.ToolTip = "Update";
          this.fGalleryMgmntID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["GalleryMgmntID"].ToString()));
          if (this.Session["UpdateMsg"] != null)
            this.Session["UpdateMsg"] = (object) null;
          this.FillData(this.fGalleryMgmntID);
        }
        else
        {
          this.h1Title.InnerText = "Add Gallery";
          RadDateTimePicker radDateTimePicker = new RadDateTimePicker();
          this.btnSubmit.Text = "Save";
          this.btnSubmit.ToolTip = "Save";
        }
      }
      this.txtGalleryDesc.Attributes["maxlength"] = "375";
      this.txtTitle.Focus();
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvTitle, true, (object) this.txtTitle, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTitle, Regex.NewsTitle, true, (object) this.txtTitle, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvDescription, true, (object) this.txtGalleryDesc, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvImage, true, (object) this.fldGallery, this.strValidationTurfGrp);
      this.fldGallery.Attributes.Add("OnChange", "return UploadFileSelect('" + this.fldGallery.ClientID + "','" + this.txtGallery.ClientID + "', this, 'Gallery');");
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }

    protected void FillData(long GalleryMgmntID)
    {
      GalleryBE galleryBe = new GalleryBE();
      GalleryBE detailBgalleryId = GalleryMgmt.GetGalleryDetailBGalleryID(GalleryMgmntID);
      if (detailBgalleryId == null)
        return;
      this.txtTitle.Text = detailBgalleryId.Title;
      this.txtGalleryDesc.Text = detailBgalleryId.Description;
      this.chkIsActive.Checked = detailBgalleryId.RoleOur;
      this.hdnDocName.Value = Convert.ToString(detailBgalleryId.Image);
      if (!string.IsNullOrEmpty(detailBgalleryId.Image))
      {
        this.hdnGalleryDoc.Value = "block";
        this.hdndivGallery.Value = "none";
        this.hdnGalleryCancel.Value = "block";
        this.hdnGalleryName.Value = detailBgalleryId.Image;
        this.lnkGalleryThumb.HRef = ConfigurationManager.AppSettings["LivePath"] + this.GalleryOriginalImagePath + detailBgalleryId.Image;
        this.ImgThumb.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.GalleryThumbImagePath + detailBgalleryId.Image;
        this.lnkGalleryThumb.Visible = false;
        this.lnkGalleryThumb.Visible = true;
        this.rfvImage.Enabled = false;
      }
      else
        this.rfvImage.Enabled = true;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (this.GetData() > 12)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.GalleryImageUpladed, (object) "Gallery"), (Enums.NotificationType) 2, false), true);
      }
      else
      {
        GalleryBE galleryBe = new GalleryBE();
        galleryBe.CreatedBy = Convert.ToInt64(this.UserId);
        galleryBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
        galleryBe.GalleryMgmntID = this.fGalleryMgmntID <= 0L ? 0L : this.fGalleryMgmntID;
        galleryBe.Title = this.txtTitle.Text.Trim();
        galleryBe.RoleOur = this.chkIsActive.Checked;
        galleryBe.Description = this.txtGalleryDesc.Text.Trim();
        string empty = string.Empty;
        if (!string.IsNullOrEmpty(this.fldGallery.FileName))
        {
          if (this.fldGallery.FileName.Length > 0)
          {
            string[] strArray = this.fldGallery.FileName.Split('\\');
            string FileName = UtilityFunctions.ChangeFileName(strArray[strArray.Length - 1].ToString());
            string extension = Path.GetExtension(this.fldGallery.FileName);
            if (extension.ToLower() == ".jpeg" || extension.ToLower() == ".png" || extension.ToLower() == ".jpg" || extension.ToLower() == ".bmp" || extension.ToLower() == ".gif")
            {
              this.fldGallery.SaveAs(this.Server.MapPath("~/") + this.GalleryOriginalImagePath + FileName);
              Resizer.FixedSize(FileName, this.fldGallery, this.GalleryThumbImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["GalleryThumbImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["GalleryThumbImageHeight"]));
              Resizer.FixedSize(FileName, this.fldGallery, this.GalleryThumbImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["TurfShopPageImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["TurfShopPageImageHeight"]));
            }
            else
              this.fldGallery.SaveAs(this.Server.MapPath("~/") + this.GalleryOriginalImagePath + FileName);
            galleryBe.Image = FileName;
            if (!string.IsNullOrEmpty(this.hdnGalleryName.Value))
            {
              FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.GalleryThumbImagePath + this.hdnGalleryName.Value);
              if (fileInfo.Exists)
                fileInfo.Delete();
            }
          }
        }
        else
          galleryBe.Image = this.hdnDocName.Value;
        galleryBe.RoleOur = this.chkIsActive.Checked;
        if (GalleryMgmt.AddUpdateGallery(galleryBe) == -1L)
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Gallery"), (Enums.NotificationType) 2, false), true);
        }
        else
        {
          if (this.fGalleryMgmntID > 0L)
            this.Session[nameof (AddUpdateGallery)] = (object) string.Format(Messages.UpdateSuccess, (object) "Gallery");
          else
            this.Session[nameof (AddUpdateGallery)] = (object) string.Format(Messages.AddSuccess, (object) "Gallery");
          this.Response.Redirect("~/Admin/ViewGallerys.aspx");
        }
      }
    }

    [WebMethod(EnableSession = true)]
    [ScriptMethod]
    public int GetData() => GalleryMgmt.GetAllMaxRecord();

    protected void btnGalleryDelete_Click(object sender, EventArgs e)
    {
      GalleryMgmt.DeleteNewsImageById(this.fGalleryMgmntID);
      FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.GalleryOriginalImagePath + this.hdnGalleryName.Value);
      if (!fileInfo.Exists)
        return;
      fileInfo.Delete();
      this.hdnGalleryDoc.Value = "none";
      this.hdndivGallery.Value = "block";
      this.hdnGalleryCancel.Value = "none";
      this.hdnGalleryName.Value = "none";
      this.fldGallery.Dispose();
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) Messages.GalleryImage), (Enums.NotificationType) 1), true);
    }
  }
}
