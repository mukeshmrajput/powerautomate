﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateQuantityZone
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.NonTurfProductPricing.QuantityZone;
using Entity.Common.ProductPricing.NonTurfProductPricing.QuantityZone;
using Entity.Response.ProductPricing.NonTurfProductPricing.QuantityZone;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateQuantityZone : Page
  {
    public static long fQuantityZoneID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtQuantityZoneName;
    protected RequiredFieldValidator rfvQuantityZoneName;
    protected RegularExpressionValidator regQuantityZoneName;
    protected TextBox txtQuantityZoneDescription;
    protected RequiredFieldValidator rfvQuantityZoneDescription;
    protected RegularExpressionValidator regQuantityZoneDescription;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnQuantityZoneID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewQuantityZone");
      if (this.Request.QueryString[QueryStrings.QuantityZoneID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strAddQuantityZone;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        AddUpdateQuantityZone.fQuantityZoneID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.QuantityZoneID].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddQuantityZone;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateQuantityZone.fQuantityZoneID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        if (AddUpdateQuantityZone.fQuantityZoneID > 0L)
          this.GetTurfZoneDetails(QuantityZoneMgmt.GetQuantityZoneDetailByID(Convert.ToInt64(AddUpdateQuantityZone.fQuantityZoneID)));
      }
      this.txtQuantityZoneName.Focus();
    }

    protected void GetTurfZoneDetails(QuantityZoneResponseBE objQuantityZoneResponseBE)
    {
      this.txtQuantityZoneName.Text = objQuantityZoneResponseBE.Name;
      this.txtQuantityZoneDescription.Text = Convert.ToString(objQuantityZoneResponseBE.Description);
      this.chkIsActive.Checked = objQuantityZoneResponseBE.IsActive;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      QuantityZoneBE quantityZoneBe = new QuantityZoneBE();
      quantityZoneBe.QuantityZoneID = AddUpdateQuantityZone.fQuantityZoneID <= 0L ? 0L : AddUpdateQuantityZone.fQuantityZoneID;
      quantityZoneBe.Name = this.txtQuantityZoneName.Text.Trim();
      quantityZoneBe.Description = this.txtQuantityZoneDescription.Text.Trim();
      quantityZoneBe.IsActive = this.chkIsActive.Checked;
      quantityZoneBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      quantityZoneBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      if (QuantityZoneMgmt.AddUpdateQuantityZone(quantityZoneBe) > 0L)
      {
        if (quantityZoneBe.QuantityZoneID > 0L)
          this.Session["QuantityZoneAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddQuantityZone);
        else if (quantityZoneBe.QuantityZoneID == 0L)
          this.Session["QuantityZoneAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddQuantityZone);
        this.Response.Redirect("~/Admin/ViewQuantityZone.aspx");
      }
      else
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) PageName.strAddQuantityZone), (Enums.NotificationType) 2, false), true);
        this.txtQuantityZoneName.Focus();
      }
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvQuantityZoneName, true, (object) this.txtQuantityZoneName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regQuantityZoneName, Regex.Title, true, (object) this.txtQuantityZoneName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvQuantityZoneDescription, true, (object) this.txtQuantityZoneDescription, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regQuantityZoneDescription, Regex.Description, true, (object) this.txtQuantityZoneDescription, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
