﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ChangePassword
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Miscellaneous;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class ChangePassword : Page
  {
    public string strValidationPassword = "ValidationPassword";
    protected UpdatePanel pnlUpdate;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liGeneralSettings;
    protected LinkButton lnkGeneralSettings;
    protected HtmlGenericControl liChgPassword;
    protected LinkButton lnkChgPassword;
    protected HtmlGenericControl dvChangePassword;
    protected TextBox txtCurrentPassword;
    protected RequiredFieldValidator rfvCurrentPassword;
    protected RegularExpressionValidator regCurrentPassword;
    protected TextBox txtNewPassword;
    protected RequiredFieldValidator rfvNewPassword;
    protected RegularExpressionValidator regNewPassword;
    protected TextBox txtConfirmPassword;
    protected RequiredFieldValidator rfvConfirmPassword;
    protected CompareValidator cmptxtConfPwd;
    protected Button btnSubmit;
    protected Button btnCancel;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (!this.IsPostBack)
      {
        this.ValidationIntialization();
        this.txtCurrentPassword.Focus();
      }
      this.Page.Form.DefaultButton = this.btnSubmit.UniqueID;
    }

    private void ValidationIntialization()
    {
      Validations.SetRequiredFieldValidator(this.rfvCurrentPassword, true, (object) this.txtCurrentPassword, this.strValidationPassword);
      Validations.SetRegularExpressionValidator(this.regCurrentPassword, Regex.Password, true, (object) this.txtCurrentPassword, this.strValidationPassword);
      Validations.SetRequiredFieldValidator(this.rfvNewPassword, true, (object) this.txtNewPassword, this.strValidationPassword);
      Validations.SetRegularExpressionValidator(this.regNewPassword, Regex.Password, true, (object) this.txtNewPassword, this.strValidationPassword);
      Validations.SetRequiredFieldValidator(this.rfvConfirmPassword, true, (object) this.txtConfirmPassword, this.strValidationPassword);
      Validations.SetCompareFieldValidator(this.cmptxtConfPwd, true, (object) this.txtConfirmPassword, (object) this.txtNewPassword, this.strValidationPassword);
      this.btnSubmit.ValidationGroup = this.strValidationPassword;
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.IsValid)
        return;
      if (this.txtNewPassword.Text.Trim() == this.txtConfirmPassword.Text.Trim())
      {
        int num = ChangePasswordMgmt.UpdateAdminPassword(new Entity.Common.Miscellaneous.ChangePassword()
        {
          UserLoginId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))),
          NewsPassword = Encryption.EncryptQueryString(this.txtNewPassword.Text.Trim()),
          CurrentPassword = Encryption.EncryptQueryString(this.txtCurrentPassword.Text.Trim()),
          UpdatedByIP = HttpContext.Current.Request.UserHostAddress
        });
        Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)));
        if ((long) num == Convert.ToInt64((object) (Enums.ResponseType) 2))
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.YouHaveSuccessfullyChangedYourPassword, (object) Messages.Password), (Enums.NotificationType) 1), true);
        else
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Messages.CurrentPasswordNotMatch, (Enums.NotificationType) 2), true);
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Messages.NewPassAndConfirmPassNotMatch, (Enums.NotificationType) 2), true);
    }

    protected void lnkChgPassword_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ChangePassword.aspx");

    protected void lnkGeneralSettings_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/SiteConfiguration.aspx");
  }
}
