﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateNonTurfStockAvailable
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfStockAvailable;
using Entity.Common.StockManagement.NonTurfProductManagement.NonTurfStockAvailable;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfStockAvailable;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateNonTurfStockAvailable : Page
  {
    public static long fNonTurfStockAvailableID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtNonTurfStockName;
    protected RequiredFieldValidator rfvNonTurfStockName;
    protected RegularExpressionValidator regNonTurfStockName;
    protected DropDownList ddlNonTurfProduct;
    protected RequiredFieldValidator rfvNonTurfProduct;
    protected TextBox txtNonTurfStockDesc;
    protected RequiredFieldValidator rfvNonTurfStockDesc;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnQuantityPriceID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewNonTurfStockAvailable");
      if (this.Request.QueryString[QueryStrings.NonTurfStockAvailableID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strAddNonTurfStockAvailable;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        AddUpdateNonTurfStockAvailable.fNonTurfStockAvailableID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.NonTurfStockAvailableID].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddNonTurfStockAvailable;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateNonTurfStockAvailable.fNonTurfStockAvailableID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        this.BindDropdown();
        if (AddUpdateNonTurfStockAvailable.fNonTurfStockAvailableID > 0L)
          this.GetNonTurfStockDetails(NonTurfStockAvailableMgmt.GetNonTurfStockAvailableDetailByID(Convert.ToInt64(AddUpdateNonTurfStockAvailable.fNonTurfStockAvailableID)));
      }
      this.txtNonTurfStockName.Focus();
    }

    protected void GetNonTurfStockDetails(
      NonTurfStockAvailableResponseBE objNonTurfStockAvailableResponseBE)
    {
      this.txtNonTurfStockName.Text = Convert.ToString(objNonTurfStockAvailableResponseBE.Name);
      this.txtNonTurfStockDesc.Text = Convert.ToString(objNonTurfStockAvailableResponseBE.Description);
      this.ddlNonTurfProduct.SelectedValue = Convert.ToString(objNonTurfStockAvailableResponseBE.NonTurfProductID);
      this.chkIsActive.Checked = Convert.ToBoolean(objNonTurfStockAvailableResponseBE.IsActive);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      NonTurfStockAvailableBE stockAvailableBe = new NonTurfStockAvailableBE();
      stockAvailableBe.NonTurfStockAvailableID = AddUpdateNonTurfStockAvailable.fNonTurfStockAvailableID <= 0L ? 0L : AddUpdateNonTurfStockAvailable.fNonTurfStockAvailableID;
      stockAvailableBe.Name = this.txtNonTurfStockName.Text.Trim();
      stockAvailableBe.Description = this.txtNonTurfStockDesc.Text.Trim();
      stockAvailableBe.NonTurfProductID = Convert.ToInt64(this.ddlNonTurfProduct.SelectedValue);
      stockAvailableBe.IsActive = this.chkIsActive.Checked;
      stockAvailableBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      stockAvailableBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      long num = NonTurfStockAvailableMgmt.AddUpdateNonTurfStockAvailable(stockAvailableBe);
      if (num > 0L)
      {
        if (stockAvailableBe.NonTurfStockAvailableID > 0L)
          this.Session["NonTurfStockAvailableAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddNonTurfStockAvailable);
        else if (stockAvailableBe.NonTurfStockAvailableID == 0L)
          this.Session["NonTurfStockAvailableAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddNonTurfStockAvailable);
        this.Response.Redirect("~/Admin/ViewNonTurfStockAvailable.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) PageName.strAddNonTurfStockAvailable), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewNonTurfStockAvailable.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvNonTurfStockName, true, (object) this.txtNonTurfStockName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regNonTurfStockName, Regex.Title, true, (object) this.txtNonTurfStockName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvNonTurfStockDesc, true, (object) this.txtNonTurfStockDesc, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvNonTurfProduct, true, (object) this.ddlNonTurfProduct, "-1", this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }

    protected void BindDropdown() => BindDropDown.BindTurfProduct((ListControl) this.ddlNonTurfProduct);
  }
}
