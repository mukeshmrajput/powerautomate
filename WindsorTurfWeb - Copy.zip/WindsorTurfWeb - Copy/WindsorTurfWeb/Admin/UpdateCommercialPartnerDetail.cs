﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.UpdateCommercialPartnerDetail
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using Entity.Common.CommercialPartner;
using Entity.Response.CommercialPartner;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class UpdateCommercialPartnerDetail : Page
  {
    public static string EncryptedPwd = "";
    public static string appenddate = "";
    public static string appenddatetime = "";
    public string HeaderImagePath = ConfigurationManager.AppSettings[nameof (HeaderImagePath)];
    public string strValidationUserGrp = "ValGrpCommercial";
    public long fCommercialPartnerID = 0;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected TextBox txtBusinessName;
    protected RequiredFieldValidator rfvBusinessName;
    protected RegularExpressionValidator regBusinessName;
    protected TextBox txtCompanyABN;
    protected RequiredFieldValidator rfvCompanyABN;
    protected CustomValidator cvalCompanyABN;
    protected TextBox txtFirstName;
    protected RequiredFieldValidator rfvFirstName;
    protected RegularExpressionValidator regFirstName;
    protected TextBox txtLastName;
    protected RequiredFieldValidator rfvLastName;
    protected RegularExpressionValidator regLastName;
    protected TextBox txtEmail;
    protected RequiredFieldValidator rfvEmail;
    protected RegularExpressionValidator regEmail;
    protected TextBox txtTelephone;
    protected RequiredFieldValidator rfvTelephone;
    protected TextBox txtFax;
    protected TextBox txtMobileNumber;
    protected TextBox txtAddressLine1;
    protected RequiredFieldValidator rfvAddressLine1;
    protected RegularExpressionValidator regAddressLine1;
    protected TextBox txtAddressLine2;
    protected RegularExpressionValidator regAddressLine2;
    protected TextBox txtSuburb;
    protected RequiredFieldValidator rfvSuburb;
    protected RegularExpressionValidator regSuburb;
    protected DropDownList ddlState;
    protected RequiredFieldValidator rfvState;
    protected TextBox txtPostcode;
    protected RequiredFieldValidator rfvPostcode;
    protected RegularExpressionValidator regPostcode;
    protected Button btnSubmit;
    protected HiddenField hdnUserId;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liCommercialPartnerUsers");
      if (this.Request.QueryString[QueryStrings.CommercialPartnerID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strCommercialPartner;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        this.fCommercialPartnerID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.CommercialPartnerID].ToString()));
      }
      if (this.IsPostBack)
        return;
      BindDropDown.BindAllStates((ListControl) this.ddlState);
      this.ValidationExpression();
      this.txtEmail.Attributes.Add("readonly", "readonly");
      this.txtCompanyABN.Attributes.Add("readonly", "readonly");
      if (this.fCommercialPartnerID > 0L)
        this.GetCommercialPartnerDetail(CommercialPartnerMgmt.GetCommercialPartnerDetailByCommercialPartnerID(Convert.ToInt64(this.fCommercialPartnerID)));
    }

    protected void GetCommercialPartnerDetail(
      CommercialPartnerResponseBE objCommercialPartnerResponse)
    {
      if (objCommercialPartnerResponse == null)
        return;
      this.txtBusinessName.Text = objCommercialPartnerResponse.BusinessName.Trim();
      this.txtCompanyABN.Text = objCommercialPartnerResponse.CompanyABN.Trim();
      this.txtEmail.Text = objCommercialPartnerResponse.Email.Trim();
      this.txtFirstName.Text = objCommercialPartnerResponse.FirstName.Trim();
      this.txtLastName.Text = objCommercialPartnerResponse.LastName.Trim();
      this.txtAddressLine1.Text = objCommercialPartnerResponse.Address1.Trim();
      this.txtAddressLine2.Text = objCommercialPartnerResponse.Address2.Trim();
      this.txtTelephone.Text = objCommercialPartnerResponse.Telephone.Trim();
      this.txtFax.Text = objCommercialPartnerResponse.Fax.Trim();
      this.txtMobileNumber.Text = objCommercialPartnerResponse.Mobile.Trim();
      this.txtSuburb.Text = objCommercialPartnerResponse.Suburb.Trim();
      this.ddlState.SelectedValue = Convert.ToString(objCommercialPartnerResponse.StateMasterID);
      this.txtPostcode.Text = objCommercialPartnerResponse.PostCode.Trim();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (CommercialPartnerMgmt.AddUpdateCommercialPartner(new CommercialPartnerBE()
      {
        CommercialPartnerID = this.fCommercialPartnerID,
        FirstName = this.txtFirstName.Text,
        LastName = this.txtLastName.Text,
        Email = this.txtEmail.Text,
        Telephone = this.txtTelephone.Text,
        Mobile = this.txtMobileNumber.Text,
        Address1 = this.txtAddressLine1.Text,
        Address2 = this.txtAddressLine2.Text,
        Suburb = this.txtSuburb.Text,
        StateMasterID = Convert.ToInt64(this.ddlState.SelectedValue),
        PostCode = this.txtPostcode.Text,
        CompanyABN = this.txtCompanyABN.Text,
        BusinessName = this.txtBusinessName.Text,
        CreatedBy = 0L,
        CreatedByIP = HttpContext.Current.Request.UserHostAddress,
        UserTypeID = Convert.ToInt64((object) (Enums.PersonType) 4),
        UserStatusID = Convert.ToInt64((object) (Enums.UserStatus) 4)
      }) <= 0L)
        return;
      this.Session["CommercialPartnerAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strCommercialPartner);
      this.Response.Redirect("~/Admin/ViewCommercialPartnerUser.aspx");
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvBusinessName, true, (object) this.txtBusinessName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regBusinessName, Regex.Title, true, (object) this.txtBusinessName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvCompanyABN, true, (object) this.txtCompanyABN, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvFirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regFirstName, Regex.FirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvLastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regLastName, Regex.LastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvEmail, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regEmail, Regex.Email, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvTelephone, true, (object) this.txtTelephone, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvPostcode, true, (object) this.txtPostcode, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regPostcode, Regex.ZipCode, true, (object) this.txtPostcode, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvAddressLine1, true, (object) this.txtAddressLine1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regAddressLine1, Regex.Address, true, (object) this.txtAddressLine1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regAddressLine2, Regex.Address, true, (object) this.txtAddressLine2, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvState, true, (object) this.ddlState, "-1", this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvSuburb, true, (object) this.txtSuburb, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regSuburb, Regex.Address, true, (object) this.txtSuburb, this.strValidationUserGrp);
      this.btnSubmit.ValidationGroup = this.strValidationUserGrp;
    }
  }
}
