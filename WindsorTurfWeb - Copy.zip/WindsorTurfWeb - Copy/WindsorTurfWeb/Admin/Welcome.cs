﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.Welcome
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PurchaseOrderDetail;
using BLL.UserManagement;
using Entity.Common.PurchaseOrderDetail;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class Welcome : Page
  {
    public string CompletedOrderedPickUpInvoicePath = ConfigurationManager.AppSettings[nameof (CompletedOrderedPickUpInvoicePath)];
    public string CompletedOrderedDeliveryInvoicePath = ConfigurationManager.AppSettings[nameof (CompletedOrderedDeliveryInvoicePath)];
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liResidential;
    protected LinkButton aResidentials;
    protected HtmlGenericControl liCausalCommercial;
    protected LinkButton aCausalCommercial;
    protected HtmlGenericControl liCommercialPartner;
    protected LinkButton aCommercialPartner;
    protected HtmlGenericControl liCommercialRegistrationApproval;
    protected LinkButton aCommercialRegistration;
    protected HtmlGenericControl div1;
    protected RadGrid grdDeliveryOrderProcessingPurchaseDetail;
    protected HtmlGenericControl div2;
    protected RadGrid grdPickUpOrderProcessingPurchaseDetail;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Session["UserAccessPageName"] != null && !string.IsNullOrEmpty(this.Session["UserAccessPageName"].ToString()))
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UserAccessMessageForPage.ToString(), (object) this.Session["UserAccessPageName"].ToString()), (Enums.NotificationType) 2, false), true);
        this.Session["UserAccessPageName"] = (object) null;
      }
      UtilityFunctions.CheckAccessOfLoginUser();
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
        UserMgmt.GetUserTypeByUserTypeID(Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3))));
      this.aResidentials.ToolTip = PageName.strResidential;
      this.aResidentials.Text = PageName.strResidential;
      this.aCausalCommercial.ToolTip = PageName.strCausalCommercial;
      this.aCausalCommercial.Text = PageName.strCausalCommercial;
      this.aCommercialPartner.ToolTip = PageName.strCommercialPartners;
      this.aCommercialPartner.Text = PageName.strCommercialPartners;
      this.aCommercialRegistration.ToolTip = PageName.strCommercialPartner;
      this.aCommercialRegistration.Text = PageName.strCommercialPartner;
      UtilityFunctions.SetUserModuleAccess(this.divTab);
      if (this.Session["OrderStatus"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["OrderStatus"]), (Enums.NotificationType) 1), true);
        this.Session["OrderStatus"] = (object) null;
      }
      if (this.IsPostBack)
        return;
      this.BindDashboardItems();
    }

    protected void aResidentials_Click(object sender, EventArgs e)
    {
      this.Session["PlaceOrderType"] = (object) (Enums.PersonType) 6;
      this.Response.Redirect("~/Admin/AdminOrderPage.aspx");
    }

    protected void aCausalCommercial_Click(object sender, EventArgs e)
    {
      this.Session["PlaceOrderType"] = (object) (Enums.PersonType) 5;
      this.Response.Redirect("~/Admin/AdminOrderPage.aspx");
    }

    protected void aCommercialPartner_Click(object sender, EventArgs e)
    {
      this.Session["PlaceOrderType"] = (object) (Enums.PersonType) 4;
      this.Response.Redirect("~/Admin/AdminOrderPage.aspx");
    }

    protected void aCommercialRegistration_Click(object sender, EventArgs e)
    {
      this.Session["CommercialRegistration"] = (object) (Enums.PersonType) 1;
      this.Response.Redirect("/commercial-registration");
    }

    protected void BindDashboardItems()
    {
      DateTime dateTime = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd"));
      DateTime dtTo = dateTime.AddDays((double) Convert.ToInt32(ConfigurationManager.AppSettings["DashboardDateDaysAdd"]));
      this.BindDeliveryData(dateTime, dtTo);
      this.BindPickUpData(dateTime, dtTo);
    }

    protected void BindDeliveryData(DateTime dtFrom, DateTime dtTo)
    {
      List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
      List<PurchaseOrderDetailBE> detailAdminDashboard = PurchaseOrderDetailMgmt.GetAllDeliveryOrderProcessingPurchaseDetail_AdminDashboard(dtFrom, dtTo);
      this.grdDeliveryOrderProcessingPurchaseDetail.VirtualItemCount = detailAdminDashboard.Count<PurchaseOrderDetailBE>();
      ((BaseDataBoundControl) this.grdDeliveryOrderProcessingPurchaseDetail).DataSource = (object) detailAdminDashboard;
      ((Control) this.grdDeliveryOrderProcessingPurchaseDetail).DataBind();
      if (detailAdminDashboard.Count<PurchaseOrderDetailBE>() != 0)
        return;
      this.grdDeliveryOrderProcessingPurchaseDetail.AllowFilteringByColumn = false;
    }

    protected void BindPickUpData(DateTime dtFrom, DateTime dtTo)
    {
      List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
      List<PurchaseOrderDetailBE> detailAdminDashboard = PurchaseOrderDetailMgmt.GetAllPickUpOrderProcessingPurchaseDetail_AdminDashboard(dtFrom, dtTo);
      this.grdPickUpOrderProcessingPurchaseDetail.VirtualItemCount = detailAdminDashboard.Count<PurchaseOrderDetailBE>();
      ((BaseDataBoundControl) this.grdPickUpOrderProcessingPurchaseDetail).DataSource = (object) detailAdminDashboard;
      ((Control) this.grdPickUpOrderProcessingPurchaseDetail).DataBind();
      if (detailAdminDashboard.Count<PurchaseOrderDetailBE>() != 0)
        return;
      this.grdPickUpOrderProcessingPurchaseDetail.AllowFilteringByColumn = false;
    }

    protected void grdDeliveryOrderProcessingPurchaseDetail_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdDeliveryOrderProcessingPurchaseDetail.MasterTableView.Items).Count == 0)
      {
        this.grdDeliveryOrderProcessingPurchaseDetail.ShowFooter = false;
        this.grdDeliveryOrderProcessingPurchaseDetail.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdDeliveryOrderProcessingPurchaseDetail.ShowFooter = true;
        this.grdDeliveryOrderProcessingPurchaseDetail.PagerStyle.AlwaysVisible = true;
      }
      this.grdDeliveryOrderProcessingPurchaseDetail.Rebind();
      Welcome.SetPaggingText(this.grdDeliveryOrderProcessingPurchaseDetail, "Paging");
    }

    protected void grdDeliveryOrderProcessingPurchaseDetail_SortCommand(
      object sender,
      GridSortCommandEventArgs e)
    {
      this.BindDashboardItems();
    }

    protected void grdDeliveryOrderProcessingPurchaseDetail_PageSizeChanged(
      object sender,
      GridPageSizeChangedEventArgs e)
    {
      this.BindDashboardItems();
    }

    protected void grdDeliveryOrderProcessingPurchaseDetail_PageIndexChanged(
      object sender,
      GridPageChangedEventArgs e)
    {
      this.BindDashboardItems();
    }

    protected void grdDeliveryOrderProcessingPurchaseDetail_ItemCommand(
      object sender,
      GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "DownloadInvoice")
      {
        HiddenField control = (HiddenField) ((Control) e.Item).FindControl("hdnPDFInvoiceFileName");
        string str = this.CompletedOrderedDeliveryInvoicePath.ToString();
        ((CommandEventArgs) e).CommandArgument.ToString();
        string path1 = this.Server.MapPath("~") + str;
        string address = this.Server.MapPath("~") + str + control.Value;
        if (System.IO.File.Exists(Path.Combine(path1, control.Value)))
        {
          byte[] buffer = new WebClient().DownloadData(address);
          this.Response.ContentType = "application/pdf";
          this.Response.AddHeader("content-length", buffer.Length.ToString());
          this.Response.BinaryWrite(buffer);
          this.Response.Flush();
          this.Response.End();
        }
      }
      this.BindDashboardItems();
      this.grdDeliveryOrderProcessingPurchaseDetail.Rebind();
    }

    protected void grdDeliveryOrderProcessingPurchaseDetail_ItemDataBound(
      object sender,
      GridItemEventArgs e)
    {
      if (e.Item.ItemType != 7 && e.Item.ItemType != 1)
        return;
      HiddenField control1 = (HiddenField) ((Control) e.Item).FindControl("hdnPDFInvoiceFileName");
      LinkButton control2 = (LinkButton) ((Control) e.Item).FindControl("lnkDeliveryDownloadInvoice");
      if (string.IsNullOrEmpty(control1.Value))
      {
        control2.Enabled = false;
      }
      else
      {
        control2.Enabled = true;
        control2.Attributes.Add("class", "DownloadPDF_icongrid");
      }
    }

    protected void grdPickUpOrderProcessingPurchaseDetail_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdPickUpOrderProcessingPurchaseDetail.MasterTableView.Items).Count == 0)
      {
        this.grdPickUpOrderProcessingPurchaseDetail.ShowFooter = false;
        this.grdPickUpOrderProcessingPurchaseDetail.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdPickUpOrderProcessingPurchaseDetail.ShowFooter = true;
        this.grdPickUpOrderProcessingPurchaseDetail.PagerStyle.AlwaysVisible = true;
      }
      this.grdPickUpOrderProcessingPurchaseDetail.Rebind();
      Welcome.SetPaggingText(this.grdPickUpOrderProcessingPurchaseDetail, "Paging");
    }

    protected void grdPickUpOrderProcessingPurchaseDetail_SortCommand(
      object sender,
      GridSortCommandEventArgs e)
    {
      this.BindDashboardItems();
    }

    protected void grdPickUpOrderProcessingPurchaseDetail_PageSizeChanged(
      object sender,
      GridPageSizeChangedEventArgs e)
    {
      this.BindDashboardItems();
    }

    protected void grdPickUpOrderProcessingPurchaseDetail_PageIndexChanged(
      object sender,
      GridPageChangedEventArgs e)
    {
      this.BindDashboardItems();
    }

    protected void grdPickUpOrderProcessingPurchaseDetail_ItemCommand(
      object sender,
      GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "DownloadInvoice")
      {
        HiddenField control = (HiddenField) ((Control) e.Item).FindControl("hdnPDFInvoiceFileName");
        string str = this.CompletedOrderedPickUpInvoicePath.ToString();
        ((CommandEventArgs) e).CommandArgument.ToString();
        string path1 = this.Server.MapPath("~") + str;
        string address = this.Server.MapPath("~") + str + control.Value;
        if (System.IO.File.Exists(Path.Combine(path1, control.Value)))
        {
          byte[] buffer = new WebClient().DownloadData(address);
          this.Response.ContentType = "application/pdf";
          this.Response.AddHeader("content-length", buffer.Length.ToString());
          this.Response.BinaryWrite(buffer);
          this.Response.Flush();
          this.Response.End();
        }
      }
      this.BindDashboardItems();
      this.grdDeliveryOrderProcessingPurchaseDetail.Rebind();
    }

    protected void grdPickUpOrderProcessingPurchaseDetail_ItemDataBound(
      object sender,
      GridItemEventArgs e)
    {
      if (e.Item.ItemType != 7 && e.Item.ItemType != 1)
        return;
      HiddenField control1 = (HiddenField) ((Control) e.Item).FindControl("hdnPDFInvoiceFileName");
      LinkButton control2 = (LinkButton) ((Control) e.Item).FindControl("lnkPickUpDownloadInvoice");
      if (string.IsNullOrEmpty(control1.Value))
      {
        control2.Enabled = false;
      }
      else
      {
        control2.Enabled = true;
        control2.Attributes.Add("class", "DownloadPDF_icongrid");
      }
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }

    protected void btnDeliveryClearFilter_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    protected void btnPickUpClearFilter_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");
  }
}
