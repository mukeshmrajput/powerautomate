﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdatePaymentType
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PaymentOptions.PaymentType;
using Entity.Common.PaymentOptions.PaymentType;
using Entity.Response.PaymentOptions.PaymentType;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdatePaymentType : Page
  {
    public static long fPaymentTypeID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtPaymentTypeName;
    protected RequiredFieldValidator rfvPaymentTypeName;
    protected RegularExpressionValidator regPaymentTypeName;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnPaymentTypeID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liPaymentType");
      if (!string.IsNullOrEmpty(this.Request.QueryString[QueryStrings.PaymentTypeID]))
      {
        AddUpdatePaymentType.fPaymentTypeID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.PaymentTypeID].ToString()));
        this.h1Title.InnerText = "Edit " + PageName.strAddPaymentType;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddPaymentType;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdatePaymentType.fPaymentTypeID = 0L;
      }
      this.txtPaymentTypeName.Attributes.Add("readonly", "readonly");
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        if (AddUpdatePaymentType.fPaymentTypeID > 0L)
          this.GetHearAboutUsDetails(PaymentTypeMgmt.GetPaymentTypeDetailByID(Convert.ToInt64(AddUpdatePaymentType.fPaymentTypeID)));
      }
      this.txtPaymentTypeName.Focus();
    }

    protected void GetHearAboutUsDetails(PaymentTypeResponseBE objPaymentTypeBE)
    {
      this.txtPaymentTypeName.Text = objPaymentTypeBE.PaymentTypeName;
      this.chkIsActive.Checked = objPaymentTypeBE.IsActive;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      PaymentTypeBE paymentTypeBe = new PaymentTypeBE();
      paymentTypeBe.PaymentTypeID = AddUpdatePaymentType.fPaymentTypeID <= 0L ? 0L : AddUpdatePaymentType.fPaymentTypeID;
      paymentTypeBe.PaymentTypeName = this.txtPaymentTypeName.Text.Trim();
      paymentTypeBe.IsActive = this.chkIsActive.Checked;
      paymentTypeBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      paymentTypeBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      long num = PaymentTypeMgmt.AddUpdatePaymentType(paymentTypeBe);
      if (num > 0L)
      {
        if (paymentTypeBe.PaymentTypeID > 0L)
          this.Session["PaymentTypeAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddPaymentType);
        else if (paymentTypeBe.PaymentTypeID == 0L)
          this.Session["PaymentTypeAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddPaymentType);
        this.Response.Redirect("~/Admin/ViewPaymentType.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) PageName.strAddPaymentType), (Enums.NotificationType) 2, false), true);
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvPaymentTypeName, true, (object) this.txtPaymentTypeName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regPaymentTypeName, Regex.Titles, true, (object) this.txtPaymentTypeName, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
