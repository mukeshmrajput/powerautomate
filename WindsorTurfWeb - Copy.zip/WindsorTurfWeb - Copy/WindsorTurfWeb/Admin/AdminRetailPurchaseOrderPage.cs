﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AdminRetailPurchaseOrderPage
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using BLL.PaymentOptions.PaymentType;
using BLL.PickUpEditor;
using BLL.RetailPurchaseDetail;
using Entity.Common.Response;
using Entity.Common.RetailPurchaseDetail;
using Entity.Response.CommercialPartner;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class AdminRetailPurchaseOrderPage : Page
  {
    public static int productQty = 0;
    private DataTable _dtAdminCART = new DataTable();
    private double quan;
    private double total;
    private double subtotal;
    private double netQty;
    private string str = "";
    private string _productid;
    public int s = 0;
    public string strValidationUserGrp = "ValGrpCommercial";
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HtmlGenericControl divTab;
    protected WebUserControl1 AdminPurchaseProcess1;
    protected HtmlGenericControl spnAstrickNotice;
    protected HtmlGenericControl divContinueShopBtn;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected Button btnContShopping;
    protected HtmlGenericControl divMainRetailDetail;
    protected Repeater grdCart;
    protected HtmlGenericControl divRetailPurchase;
    protected HtmlGenericControl divCommercialPartner;
    protected DropDownList ddlCommercialPartnerID;
    protected RequiredFieldValidator rfvCommercialPartnerID;
    protected TextBox txtEmail;
    protected RequiredFieldValidator rfvEmail;
    protected RegularExpressionValidator regEmail;
    protected RadioButtonList rdlPickUpDetails;
    protected HtmlGenericControl divDeliveryRegion;
    protected RadioButtonList rdlOrderUnderCompany;
    protected HtmlGenericControl divPickUp;
    protected RadioButtonList rdlPickUpPoint;
    protected RadioButtonList rdlPaymentOption;
    protected DropDownList ddlHearAboutUs;
    protected RequiredFieldValidator rfvHearAboutUs;
    protected HtmlGenericControl divDeliveryInstructions;
    protected TextBox txtDeliveryInstructions;
    protected RegularExpressionValidator regDeliveryInstructions;
    protected HtmlGenericControl divPickUpAddress;
    protected HtmlGenericControl DivBusinessNamePickUp;
    protected TextBox txtBusinessName;
    protected HtmlGenericControl spnBusinessName;
    protected RequiredFieldValidator rfvBusinessName;
    protected RegularExpressionValidator regBusinessName;
    protected HtmlGenericControl DivABNPickUp;
    protected TextBox txtCompanyABN;
    protected RequiredFieldValidator rfvCompanyABN;
    protected CustomValidator cvalCompanyABN;
    protected TextBox txtFirstName;
    protected RequiredFieldValidator rfvFirstName;
    protected RegularExpressionValidator regFirstName;
    protected TextBox txtLastName;
    protected RequiredFieldValidator rfvLastName;
    protected RegularExpressionValidator regLastName;
    protected TextBox txtContactNumber;
    protected RequiredFieldValidator rfvTelephone;
    protected TextBox txtFax;
    protected TextBox txtAddressLine1;
    protected RequiredFieldValidator rfvAddressLine1;
    protected RegularExpressionValidator regAddressLine1;
    protected TextBox txtAddressLine2;
    protected RegularExpressionValidator regAddressLine2;
    protected TextBox txtSuburb;
    protected RequiredFieldValidator rfvSuburb;
    protected RegularExpressionValidator regSuburb;
    protected DropDownList ddlState;
    protected RequiredFieldValidator rfvState;
    protected TextBox txtPostcode;
    protected RequiredFieldValidator rfvPostcode;
    protected RegularExpressionValidator regPostcode;
    protected HtmlGenericControl divDeliveryAddress;
    protected HtmlGenericControl DivBusinessNameDelivery;
    protected TextBox txtBillingBusinessName;
    protected RequiredFieldValidator rfvBillingBusinessName;
    protected RegularExpressionValidator regBillingBusinessName;
    protected HtmlGenericControl DivABNDelivery;
    protected TextBox txtBillingCompanyABN;
    protected RequiredFieldValidator rfvBillingCompanyABN;
    protected CustomValidator cvalBillingCompanyABN;
    protected TextBox txtBillingFirstName;
    protected RequiredFieldValidator rfvBillingFirstName;
    protected RegularExpressionValidator regBillingFirstName;
    protected TextBox txtBillingLastName;
    protected RequiredFieldValidator rfvBillingLastName;
    protected RegularExpressionValidator regBillingLastName;
    protected TextBox txtBillingAddressLine1;
    protected RequiredFieldValidator rfvBillingAddressLine1;
    protected RegularExpressionValidator regBillingAddressLine1;
    protected TextBox txtBillingAddressLine2;
    protected RegularExpressionValidator regBillingAddressLine2;
    protected TextBox txtBillingSuburb;
    protected RequiredFieldValidator rfvBillingSuburb;
    protected RegularExpressionValidator regBillingSuburb;
    protected DropDownList ddlBillingstate;
    protected RequiredFieldValidator rfvBillingState;
    protected TextBox txtBillingPostcode;
    protected RequiredFieldValidator rfvBillingPostcode;
    protected RegularExpressionValidator regBillingPostcode;
    protected TextBox txtBillingHomePhone;
    protected RequiredFieldValidator rfvBillingTelephone;
    protected HtmlGenericControl divSameBillingAddress;
    protected CheckBox chkSameBillingAddress;
    protected HtmlGenericControl DivBusinessNameDeliveryshipping;
    protected TextBox txtShippingBusinessName;
    protected RequiredFieldValidator rfvShippingBusinessName;
    protected RegularExpressionValidator regShippingBusinessName;
    protected HtmlGenericControl DivABNDeliveryshipping;
    protected TextBox txtShippingCompnayABN;
    protected RequiredFieldValidator rfvShippingCompnayABN;
    protected CustomValidator cmvShippingCompnayABN;
    protected TextBox txtShippingFirstName;
    protected RequiredFieldValidator rfvShippingFirstName;
    protected RegularExpressionValidator regShippingFirstName;
    protected TextBox txtShippingLastName;
    protected RequiredFieldValidator rfvShippingLastName;
    protected RegularExpressionValidator regShippingLastName;
    protected TextBox txtShippingAddress1;
    protected RequiredFieldValidator rfvShippingAddress1;
    protected RegularExpressionValidator regShippingAddress1;
    protected TextBox txtShippingAddress2;
    protected RegularExpressionValidator regShippingAddress2;
    protected TextBox txtShippingSuburb;
    protected RequiredFieldValidator rfvShippingSuburb;
    protected RegularExpressionValidator regShippingSuburb;
    protected DropDownList ddlShippingState;
    protected RequiredFieldValidator rfvShippingState;
    protected TextBox txtShippingPostcode;
    protected RequiredFieldValidator rfvShippingPostcode;
    protected RegularExpressionValidator regShippingPostcode;
    protected TextBox txtShippingHomePhone;
    protected RequiredFieldValidator rfvShippingHomePhone;
    protected HtmlGenericControl divButtons;
    protected Button btnBack;
    protected Button btnContinue;
    protected HiddenField hdnPlaceOrderUserType;
    protected HiddenField hdnQuoteDetailID;
    protected HiddenField hdnNewTurfType;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.Session["dtAdminCART"] != null)
      {
        DataTable dataTable = (DataTable) this.Session["dtAdminCART"];
      }
      if (this.IsPostBack)
        return;
      if (this.Session["PlaceOrderType"] != null && !string.IsNullOrEmpty(this.Session["PlaceOrderType"].ToString()))
        this.hdnPlaceOrderUserType.Value = Convert.ToString(this.Session["PlaceOrderType"]);
      this.btnContShopping.Text = PageName.strBtnDashboardName;
      this.btnContShopping.ToolTip = PageName.strBtnDashboardName;
      if (this.rdlPickUpDetails.SelectedValue == "1")
      {
        this.divDeliveryRegion.Visible = false;
        this.divPickUp.Visible = true;
        this.divDeliveryAddress.Visible = false;
        this.divPickUpAddress.Visible = true;
        this.divDeliveryInstructions.Visible = false;
      }
      if (this.hdnPlaceOrderUserType.Value == ((Enums.PersonType) 6).ToString())
      {
        this.rdlOrderUnderCompany.SelectedValue = "2";
        this.rdlOrderUnderCompany.Enabled = false;
      }
      else if (this.hdnPlaceOrderUserType.Value == ((Enums.PersonType) 5).ToString())
      {
        this.rdlOrderUnderCompany.SelectedValue = "1";
        this.rdlOrderUnderCompany.Enabled = false;
        this.DivBusinessNamePickUp.Visible = true;
        this.DivABNPickUp.Visible = true;
        this.DivBusinessNameDelivery.Visible = true;
        this.DivABNDelivery.Visible = true;
        this.DivBusinessNameDeliveryshipping.Visible = true;
        this.DivABNDeliveryshipping.Visible = true;
      }
      else if (this.hdnPlaceOrderUserType.Value == ((Enums.PersonType) 4).ToString())
      {
        BindDropDown.BindCommercialPartnerUsers((ListControl) this.ddlCommercialPartnerID);
        this.divCommercialPartner.Visible = true;
      }
      this.ValidationExpression();
      this.BindRepeter();
      this.BindDropdown();
      this.txtEmail.Focus();
    }

    protected void FillCommercialPartnerData(long LoginUserMasterID)
    {
      CommercialPartnerResponseBE detailByLoginMasterId = CommercialPartnerMgmt.GetCommercialPartnerDetailByLoginMasterID(LoginUserMasterID);
      if (detailByLoginMasterId == null)
        return;
      this.rdlOrderUnderCompany.SelectedValue = "1";
      this.rdlOrderUnderCompany.Enabled = false;
      this.DivBusinessNamePickUp.Visible = true;
      this.DivABNPickUp.Visible = true;
      this.DivBusinessNameDelivery.Visible = true;
      this.DivABNDelivery.Visible = true;
      this.DivBusinessNameDeliveryshipping.Visible = true;
      this.DivABNDeliveryshipping.Visible = true;
      if (this.rdlPickUpDetails.SelectedValue == "1")
      {
        this.txtEmail.Text = string.Empty;
        this.txtBillingBusinessName.Text = string.Empty;
        this.txtBillingCompanyABN.Text = string.Empty;
        this.txtBillingFirstName.Text = string.Empty;
        this.txtBillingLastName.Text = string.Empty;
        this.txtBillingAddressLine1.Text = string.Empty;
        this.txtBillingAddressLine2.Text = string.Empty;
        this.txtBillingSuburb.Text = string.Empty;
        this.ddlBillingstate.ClearSelection();
        this.txtBillingPostcode.Text = string.Empty;
        this.txtBillingHomePhone.Text = string.Empty;
        this.chkSameBillingAddress.Checked = false;
        this.txtShippingBusinessName.Text = string.Empty;
        this.txtShippingCompnayABN.Text = string.Empty;
        this.txtShippingFirstName.Text = string.Empty;
        this.txtShippingLastName.Text = string.Empty;
        this.txtShippingAddress1.Text = string.Empty;
        this.txtShippingAddress2.Text = string.Empty;
        this.txtShippingSuburb.Text = string.Empty;
        this.ddlShippingState.ClearSelection();
        this.txtShippingPostcode.Text = string.Empty;
        this.txtShippingHomePhone.Text = string.Empty;
        this.txtEmail.Text = detailByLoginMasterId.Email;
        this.txtBusinessName.Text = detailByLoginMasterId.BusinessName;
        this.txtCompanyABN.Text = detailByLoginMasterId.CompanyABN;
        this.txtFirstName.Text = detailByLoginMasterId.FirstName;
        this.txtLastName.Text = detailByLoginMasterId.LastName;
        this.txtAddressLine1.Text = detailByLoginMasterId.Address1;
        this.txtAddressLine2.Text = detailByLoginMasterId.Address2;
        this.txtSuburb.Text = detailByLoginMasterId.Suburb;
        this.ddlState.SelectedValue = detailByLoginMasterId.StateMasterID.ToString();
        this.txtPostcode.Text = detailByLoginMasterId.PostCode;
        this.txtContactNumber.Text = detailByLoginMasterId.Telephone;
      }
      else if (this.rdlPickUpDetails.SelectedValue == "2")
      {
        this.txtBusinessName.Text = string.Empty;
        this.txtCompanyABN.Text = string.Empty;
        this.txtFirstName.Text = string.Empty;
        this.txtLastName.Text = string.Empty;
        this.txtAddressLine1.Text = string.Empty;
        this.txtAddressLine2.Text = string.Empty;
        this.txtSuburb.Text = string.Empty;
        this.ddlState.ClearSelection();
        this.txtPostcode.Text = string.Empty;
        this.txtContactNumber.Text = string.Empty;
        this.txtEmail.Text = detailByLoginMasterId.Email;
        this.txtBillingBusinessName.Text = detailByLoginMasterId.BusinessName;
        this.txtBillingCompanyABN.Text = detailByLoginMasterId.CompanyABN;
        this.txtBillingFirstName.Text = detailByLoginMasterId.FirstName;
        this.txtBillingLastName.Text = detailByLoginMasterId.LastName;
        this.txtBillingAddressLine1.Text = detailByLoginMasterId.Address1;
        this.txtBillingAddressLine2.Text = detailByLoginMasterId.Address2;
        this.txtBillingSuburb.Text = detailByLoginMasterId.Suburb;
        DropDownList ddlBillingstate = this.ddlBillingstate;
        long stateMasterId = detailByLoginMasterId.StateMasterID;
        string str1 = stateMasterId.ToString();
        ddlBillingstate.SelectedValue = str1;
        this.txtBillingPostcode.Text = detailByLoginMasterId.PostCode;
        this.txtBillingHomePhone.Text = detailByLoginMasterId.Telephone;
        this.chkSameBillingAddress.Checked = true;
        this.divSameBillingAddress.Visible = true;
        this.txtShippingBusinessName.Text = detailByLoginMasterId.BusinessName;
        this.txtShippingCompnayABN.Text = detailByLoginMasterId.CompanyABN;
        this.txtShippingFirstName.Text = detailByLoginMasterId.FirstName;
        this.txtShippingLastName.Text = detailByLoginMasterId.LastName;
        this.txtShippingAddress1.Text = detailByLoginMasterId.Address1;
        this.txtShippingAddress2.Text = detailByLoginMasterId.Address2;
        this.txtShippingSuburb.Text = detailByLoginMasterId.Suburb;
        DropDownList ddlShippingState = this.ddlShippingState;
        stateMasterId = detailByLoginMasterId.StateMasterID;
        string str2 = stateMasterId.ToString();
        ddlShippingState.SelectedValue = str2;
        this.txtShippingPostcode.Text = detailByLoginMasterId.PostCode;
        this.txtShippingHomePhone.Text = detailByLoginMasterId.Telephone;
      }
    }

    protected void BindDropdown()
    {
      BindDropDown.BindAllStates((ListControl) this.ddlState);
      BindDropDown.BindAllStates((ListControl) this.ddlBillingstate);
      BindDropDown.BindAllStates((ListControl) this.ddlShippingState);
      BindDropDown.BindHearAboutUs((ListControl) this.ddlHearAboutUs);
      List<PaymentTypeResponse> source = PaymentTypeMgmt.GetPaymentOptions();
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
      {
        IEnumerable<string> strTypes = ((IEnumerable<string>) (Convert.ToString((object) (Enums.PaymentTypes) 4) + "," + Convert.ToString((object) (Enums.PaymentTypes) 5)).Split(',')).Select<string, string>((System.Func<string, string>) (str => Convert.ToString(str)));
        source = source.Where<PaymentTypeResponse>((System.Func<PaymentTypeResponse, bool>) (m => !strTypes.Contains<string>(m.PaymentTypeName.Replace(" ", "")))).ToList<PaymentTypeResponse>();
      }
      this.rdlPaymentOption.DataSource = (object) source;
      this.rdlPaymentOption.DataTextField = "PaymentTypeName";
      this.rdlPaymentOption.DataValueField = "PaymentTypeID";
      this.rdlPaymentOption.DataBind();
      this.rdlPaymentOption.SelectedValue = this.rdlPaymentOption.Items[0].Value;
      Convert.ToInt64(this.rdlOrderUnderCompany.SelectedValue);
      this.rdlPickUpPoint.DataSource = (object) PickUpDetailMgmt.GetPickUpDetailsForFront(Convert.ToInt64(this.rdlOrderUnderCompany.SelectedValue) != 1L ? Convert.ToInt64((object) (Enums.UserTypeID) 1) : Convert.ToInt64((object) (Enums.UserTypeID) 2));
      this.rdlPickUpPoint.DataTextField = "PickUpAddress";
      this.rdlPickUpPoint.DataValueField = "PickUpDetailID";
      this.rdlPickUpPoint.DataBind();
      this.rdlPickUpPoint.SelectedValue = this.rdlPickUpPoint.Items[0].Value;
    }

    public void BindRepeter()
    {
      if (this.Session["dtAdminCART"] != null)
      {
        this._dtAdminCART = (DataTable) this.Session["dtAdminCART"];
        if (this._dtAdminCART.Rows.Count > 0)
        {
          this._dtAdminCART = UtilityFunctions.ReverseRowsInDataTable(this._dtAdminCART);
          this.grdCart.DataSource = (object) this._dtAdminCART;
          this.grdCart.DataBind();
        }
        else if (this._dtAdminCART.Rows.Count == 0)
        {
          this.grdCart.DataSource = (object) this._dtAdminCART;
          this.grdCart.DataBind();
          this.grdCart.Visible = false;
          this.NoRecordValidation();
        }
        ((Label) this.grdCart.Controls[this.grdCart.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtAdminCART, (DataTable) this.Session["dtAdminCART"]);
      }
      else
        this.NoRecordValidation();
    }

    private void NoRecordValidation()
    {
      this.spnMsg.Visible = true;
      this.divContinueShopBtn.Visible = true;
      this.lblMsg.Text = string.Format(Messages.ShoppingCartEmpty);
      this.spnAstrickNotice.Visible = this.divMainRetailDetail.Visible = false;
      this.divButtons.Visible = false;
      this.spnMsg.Style.Add("color", UtilityFunctions.SetMessageColor(0));
      UtilityFunctions.SetAdminCartEmptyMessage(this.Page, this._dtAdminCART, (System.Web.UI.UserControl) this.AdminPurchaseProcess1);
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvBillingBusinessName, true, (object) this.txtBillingBusinessName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regBillingBusinessName, Regex.Title, true, (object) this.txtBillingBusinessName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvShippingBusinessName, true, (object) this.txtShippingBusinessName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regShippingBusinessName, Regex.Title, true, (object) this.txtShippingBusinessName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvBillingCompanyABN, true, (object) this.txtBillingCompanyABN, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvShippingCompnayABN, true, (object) this.txtShippingCompnayABN, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvBillingFirstName, true, (object) this.txtBillingFirstName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regBillingFirstName, Regex.FirstName, true, (object) this.txtBillingFirstName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvShippingFirstName, true, (object) this.txtShippingFirstName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regShippingFirstName, Regex.FirstName, true, (object) this.txtShippingFirstName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvBillingLastName, true, (object) this.txtBillingLastName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regBillingLastName, Regex.LastName, true, (object) this.txtBillingLastName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvShippingLastName, true, (object) this.txtShippingLastName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regShippingLastName, Regex.LastName, true, (object) this.txtShippingLastName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvEmail, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regEmail, Regex.Email, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvBillingTelephone, true, (object) this.txtBillingHomePhone, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvShippingHomePhone, true, (object) this.txtShippingHomePhone, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvBillingPostcode, true, (object) this.txtBillingPostcode, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regBillingPostcode, Regex.ZipCode, true, (object) this.txtBillingPostcode, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvShippingPostcode, true, (object) this.txtShippingPostcode, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regShippingPostcode, Regex.ZipCode, true, (object) this.txtShippingPostcode, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvBillingAddressLine1, true, (object) this.txtBillingAddressLine1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regBillingAddressLine1, Regex.Address, true, (object) this.txtBillingAddressLine1, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvShippingAddress1, true, (object) this.txtShippingAddress1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regShippingAddress1, Regex.Address, true, (object) this.txtShippingAddress1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regBillingAddressLine2, Regex.Address, true, (object) this.txtBillingAddressLine2, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regShippingAddress2, Regex.Address, true, (object) this.txtShippingAddress2, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvBillingState, true, (object) this.ddlBillingstate, "-1", this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvShippingState, true, (object) this.ddlShippingState, "-1", this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvBillingSuburb, true, (object) this.txtBillingSuburb, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regBillingSuburb, Regex.Address, true, (object) this.txtBillingSuburb, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvShippingSuburb, true, (object) this.txtShippingSuburb, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regShippingSuburb, Regex.Address, true, (object) this.txtShippingSuburb, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvHearAboutUs, true, (object) this.ddlHearAboutUs, "-1", this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regDeliveryInstructions, Regex.Address, true, (object) this.txtDeliveryInstructions, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regBusinessName, Regex.Title, true, (object) this.txtBusinessName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvCompanyABN, true, (object) this.txtCompanyABN, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvFirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regFirstName, Regex.FirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvLastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regLastName, Regex.LastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvEmail, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regEmail, Regex.Email, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvTelephone, true, (object) this.txtContactNumber, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvPostcode, true, (object) this.txtPostcode, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regPostcode, Regex.ZipCode, true, (object) this.txtPostcode, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvAddressLine1, true, (object) this.txtAddressLine1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regAddressLine1, Regex.Address, true, (object) this.txtAddressLine1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regAddressLine2, Regex.Address, true, (object) this.txtAddressLine2, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvState, true, (object) this.ddlState, "-1", this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvSuburb, true, (object) this.txtSuburb, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regSuburb, Regex.Address, true, (object) this.txtSuburb, this.strValidationUserGrp);
      if (this.rdlOrderUnderCompany.SelectedValue == "1")
      {
        this.spnBusinessName.Visible = true;
        Validations.SetRequiredFieldValidator(this.rfvBusinessName, true, (object) this.txtBusinessName, this.strValidationUserGrp);
      }
      else
        this.spnBusinessName.Visible = false;
      if (this.hdnPlaceOrderUserType.Value == ((Enums.PersonType) 4).ToString())
        Validations.SetRequiredFieldValidatorDropdown(this.rfvCommercialPartnerID, true, (object) this.ddlCommercialPartnerID, "-1", this.strValidationUserGrp);
      this.btnContinue.ValidationGroup = this.strValidationUserGrp;
    }

    protected void btnBack_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/AdminCheckoutPage.aspx");

    protected void btnContinue_Click(object sender, EventArgs e)
    {
      RetailPurchaseDetailBE purchaseDetailBe = new RetailPurchaseDetailBE();
      purchaseDetailBe.EmailAddress = this.txtEmail.Text.Trim();
      purchaseDetailBe.PickUpDetailID = (long) Convert.ToInt32(this.rdlPickUpDetails.SelectedValue);
      purchaseDetailBe.PaymentTypeID = Convert.ToInt64(this.rdlPaymentOption.SelectedValue);
      purchaseDetailBe.HearAboutUsID = Convert.ToInt64(this.ddlHearAboutUs.SelectedValue);
      purchaseDetailBe.PickUpAtID = 0;
      this.Session["adminSelectedPickUpDetails"] = (object) this.rdlPickUpDetails.SelectedValue;
      purchaseDetailBe.objBillingDetail.IsOrderUnderCompany = Convert.ToInt32(this.rdlOrderUnderCompany.SelectedValue);
      if (this.rdlPickUpDetails.SelectedValue == "1")
      {
        purchaseDetailBe.PickUpPointID = Convert.ToInt32(this.rdlPickUpPoint.SelectedValue);
        purchaseDetailBe.objBillingDetail.BillingFirstName = this.txtFirstName.Text;
        purchaseDetailBe.objBillingDetail.BillingLastName = this.txtLastName.Text;
        purchaseDetailBe.objBillingDetail.BillingBusinessName = this.txtBusinessName.Text;
        purchaseDetailBe.objBillingDetail.BillingCompanyABN = this.txtCompanyABN.Text;
        purchaseDetailBe.objBillingDetail.BillingAddressLine1 = this.txtAddressLine1.Text;
        purchaseDetailBe.objBillingDetail.BillingAddressLine2 = this.txtAddressLine2.Text;
        purchaseDetailBe.objBillingDetail.BillingSuburb = this.txtSuburb.Text;
        purchaseDetailBe.objBillingDetail.BillingStateMasterID = this.ddlState.SelectedValue;
        purchaseDetailBe.objBillingDetail.BillingPostcode = this.txtPostcode.Text;
        purchaseDetailBe.objBillingDetail.BillingHomePhone = this.txtContactNumber.Text;
        this.Session["adminValidPostcode"] = (object) purchaseDetailBe.objBillingDetail.BillingPostcode;
      }
      else if (this.rdlPickUpDetails.SelectedValue == "2")
      {
        purchaseDetailBe.objBillingDetail.BillingFirstName = this.txtBillingFirstName.Text;
        purchaseDetailBe.objBillingDetail.BillingLastName = this.txtBillingLastName.Text;
        purchaseDetailBe.objBillingDetail.BillingBusinessName = this.txtBillingBusinessName.Text;
        purchaseDetailBe.objBillingDetail.BillingCompanyABN = this.txtBillingCompanyABN.Text;
        purchaseDetailBe.objBillingDetail.BillingAddressLine1 = this.txtBillingAddressLine1.Text;
        purchaseDetailBe.objBillingDetail.BillingAddressLine2 = this.txtBillingAddressLine2.Text;
        purchaseDetailBe.objBillingDetail.BillingSuburb = this.txtBillingSuburb.Text;
        purchaseDetailBe.objBillingDetail.BillingStateMasterID = this.ddlBillingstate.SelectedValue;
        purchaseDetailBe.objBillingDetail.BillingPostcode = this.txtBillingPostcode.Text;
        purchaseDetailBe.objBillingDetail.BillingHomePhone = this.txtBillingHomePhone.Text;
        purchaseDetailBe.objShippingDetail.ShippingFirstName = this.txtShippingFirstName.Text;
        purchaseDetailBe.objShippingDetail.ShippingLastName = this.txtShippingLastName.Text;
        purchaseDetailBe.objShippingDetail.ShippingBusinessName = this.txtShippingBusinessName.Text;
        purchaseDetailBe.objShippingDetail.ShippingCompanyABN = this.txtShippingCompnayABN.Text;
        purchaseDetailBe.objShippingDetail.ShippingAddressLine1 = this.txtShippingAddress1.Text;
        purchaseDetailBe.objShippingDetail.ShippingAddressLine2 = this.txtShippingAddress2.Text;
        purchaseDetailBe.objShippingDetail.ShippingSuburb = this.txtShippingSuburb.Text;
        purchaseDetailBe.objShippingDetail.ShippingStateMasterID = this.ddlShippingState.SelectedValue;
        purchaseDetailBe.objShippingDetail.ShippingPostcode = this.txtShippingPostcode.Text;
        purchaseDetailBe.objShippingDetail.ShippingHomePhone = this.txtShippingHomePhone.Text;
        purchaseDetailBe.objBillingDetail.DeliveryInstructions = this.txtDeliveryInstructions.Text;
        this.Session["adminValidPostcode"] = (object) purchaseDetailBe.objShippingDetail.ShippingPostcode;
      }
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
      {
        if (this.hdnPlaceOrderUserType.Value == ((Enums.PersonType) 6).ToString())
          purchaseDetailBe.UserTypeID = (long) Convert.ToInt32((object) (Enums.UserType) 6);
        else if (this.hdnPlaceOrderUserType.Value == ((Enums.PersonType) 5).ToString())
          purchaseDetailBe.UserTypeID = (long) Convert.ToInt32((object) (Enums.UserType) 5);
        else if (this.hdnPlaceOrderUserType.Value == ((Enums.PersonType) 4).ToString())
        {
          purchaseDetailBe.UserTypeID = (long) Convert.ToInt32((object) (Enums.UserType) 4);
          purchaseDetailBe.CommercialPartnerID = Convert.ToInt64(this.ddlCommercialPartnerID.SelectedValue);
        }
        else if (this.rdlOrderUnderCompany.SelectedValue == "1")
          purchaseDetailBe.UserTypeID = (long) Convert.ToInt32((object) (Enums.UserType) 5);
        else if (this.rdlOrderUnderCompany.SelectedValue == "2")
          purchaseDetailBe.UserTypeID = (long) Convert.ToInt32((object) (Enums.UserType) 6);
        purchaseDetailBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      }
      purchaseDetailBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      long num = RetailPurchaseDetailMgmt.AddUpdateRetailPurchaseDetail(purchaseDetailBe);
      if (num <= 0L)
        return;
      this.Session["strAdminRetailPurchaseOrderID"] = (object) num;
      this.Session["adminSelectedPaymentType"] = (object) purchaseDetailBe.PaymentTypeID;
      this.Response.Redirect("~/Admin/AdminConfirmPaymentPage.aspx");
    }

    protected void rdlPickUpDetails_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.rdlPickUpDetails.SelectedValue == "1")
      {
        this.divDeliveryRegion.Visible = false;
        this.divPickUp.Visible = true;
        this.divPickUpAddress.Visible = true;
        this.divDeliveryAddress.Visible = false;
        this.divDeliveryInstructions.Visible = false;
        this.divSameBillingAddress.Visible = false;
      }
      else if (this.rdlPickUpDetails.SelectedValue == "2")
      {
        this.divDeliveryRegion.Visible = true;
        this.divPickUp.Visible = false;
        this.divDeliveryAddress.Visible = true;
        this.divPickUpAddress.Visible = false;
        this.divDeliveryInstructions.Visible = true;
        this.divSameBillingAddress.Visible = true;
        if (this.hdnPlaceOrderUserType.Value == ((Enums.PersonType) 4).ToString() && Convert.ToInt32(this.ddlCommercialPartnerID.SelectedValue) > 0)
        {
          CommercialPartnerResponseBE commercialPartnerId = CommercialPartnerMgmt.GetCommercialPartnerDetailByCommercialPartnerID(Convert.ToInt64(this.ddlCommercialPartnerID.SelectedValue));
          if (commercialPartnerId != null)
          {
            this.txtBusinessName.Text = string.Empty;
            this.txtCompanyABN.Text = string.Empty;
            this.txtFirstName.Text = string.Empty;
            this.txtLastName.Text = string.Empty;
            this.txtAddressLine1.Text = string.Empty;
            this.txtAddressLine2.Text = string.Empty;
            this.txtSuburb.Text = string.Empty;
            this.ddlState.ClearSelection();
            this.txtPostcode.Text = string.Empty;
            this.txtContactNumber.Text = string.Empty;
            this.txtEmail.Text = commercialPartnerId.Email;
            this.txtBillingBusinessName.Text = commercialPartnerId.BusinessName;
            this.txtBillingCompanyABN.Text = commercialPartnerId.CompanyABN;
            this.txtBillingFirstName.Text = commercialPartnerId.FirstName;
            this.txtBillingLastName.Text = commercialPartnerId.LastName;
            this.txtBillingAddressLine1.Text = commercialPartnerId.Address1;
            this.txtBillingAddressLine2.Text = commercialPartnerId.Address2;
            this.txtBillingSuburb.Text = commercialPartnerId.Suburb;
            DropDownList ddlBillingstate = this.ddlBillingstate;
            long stateMasterId = commercialPartnerId.StateMasterID;
            string str1 = stateMasterId.ToString();
            ddlBillingstate.SelectedValue = str1;
            this.txtBillingPostcode.Text = commercialPartnerId.PostCode;
            this.txtBillingHomePhone.Text = commercialPartnerId.Telephone;
            this.chkSameBillingAddress.Checked = true;
            this.divSameBillingAddress.Visible = true;
            this.txtShippingBusinessName.Text = commercialPartnerId.BusinessName;
            this.txtShippingCompnayABN.Text = commercialPartnerId.CompanyABN;
            this.txtShippingFirstName.Text = commercialPartnerId.FirstName;
            this.txtShippingLastName.Text = commercialPartnerId.LastName;
            this.txtShippingAddress1.Text = commercialPartnerId.Address1;
            this.txtShippingAddress2.Text = commercialPartnerId.Address2;
            this.txtShippingSuburb.Text = commercialPartnerId.Suburb;
            DropDownList ddlShippingState = this.ddlShippingState;
            stateMasterId = commercialPartnerId.StateMasterID;
            string str2 = stateMasterId.ToString();
            ddlShippingState.SelectedValue = str2;
            this.txtShippingPostcode.Text = commercialPartnerId.PostCode;
            this.txtShippingHomePhone.Text = commercialPartnerId.Telephone;
          }
        }
      }
      this.txtEmail.Focus();
      string str3 = this.hdnPlaceOrderUserType.Value;
      Enums.PersonType personType = (Enums.PersonType) 6;
      string str4 = personType.ToString();
      if (str3 == str4)
      {
        this.rdlOrderUnderCompany.SelectedValue = "2";
        this.rdlOrderUnderCompany.Enabled = false;
      }
      else
      {
        string str5 = this.hdnPlaceOrderUserType.Value;
        personType = (Enums.PersonType) 5;
        string str6 = personType.ToString();
        if (!(str5 == str6))
          return;
        this.rdlOrderUnderCompany.SelectedValue = "1";
        this.rdlOrderUnderCompany.Enabled = false;
      }
    }

    protected void rdlOrderUnderCompany_SelectedIndexChanged(object sender, EventArgs e)
    {
      Convert.ToInt64(this.rdlOrderUnderCompany.SelectedValue);
      this.rdlPickUpPoint.DataSource = (object) PickUpDetailMgmt.GetPickUpDetailsForFront(Convert.ToInt64(this.rdlOrderUnderCompany.SelectedValue) != 1L ? Convert.ToInt64((object) (Enums.UserTypeID) 1) : Convert.ToInt64((object) (Enums.UserTypeID) 2));
      this.rdlPickUpPoint.DataTextField = "PickUpAddress";
      this.rdlPickUpPoint.DataValueField = "PickUpDetailID";
      this.rdlPickUpPoint.DataBind();
      this.rdlPickUpPoint.SelectedValue = this.rdlPickUpPoint.Items[0].Value;
      this.rdlPickUpDetails_SelectedIndexChanged(sender, e);
      if (this.rdlOrderUnderCompany.SelectedValue == "1")
      {
        this.DivBusinessNamePickUp.Visible = true;
        this.DivABNPickUp.Visible = true;
        this.DivBusinessNameDelivery.Visible = true;
        this.DivABNDelivery.Visible = true;
        this.DivBusinessNameDeliveryshipping.Visible = true;
        this.DivABNDeliveryshipping.Visible = true;
      }
      else
      {
        this.DivBusinessNamePickUp.Visible = false;
        this.DivABNPickUp.Visible = false;
        this.DivBusinessNameDelivery.Visible = false;
        this.DivABNDelivery.Visible = false;
        this.DivBusinessNameDeliveryshipping.Visible = false;
        this.DivABNDeliveryshipping.Visible = false;
      }
    }

    protected void btnContShopping_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    protected void ddlCommercialPartnerID_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.ddlCommercialPartnerID.SelectedIndex <= 0)
        return;
      CommercialPartnerResponseBE commercialPartnerId = CommercialPartnerMgmt.GetCommercialPartnerDetailByCommercialPartnerID(Convert.ToInt64(this.ddlCommercialPartnerID.SelectedValue));
      if (commercialPartnerId != null)
      {
        if (commercialPartnerId.IsAmountApproved)
        {
          List<PaymentTypeResponse> paymentOptions = PaymentTypeMgmt.GetPaymentOptions();
          IEnumerable<string> strTypes = ((IEnumerable<string>) Convert.ToString((object) (Enums.PaymentTypes) 5).Split(',')).Select<string, string>((System.Func<string, string>) (str => Convert.ToString(str)));
          this.rdlPaymentOption.DataSource = (object) paymentOptions.Where<PaymentTypeResponse>((System.Func<PaymentTypeResponse, bool>) (m => !strTypes.Contains<string>(m.PaymentTypeName.Replace(" ", "")))).ToList<PaymentTypeResponse>();
          this.rdlPaymentOption.DataTextField = "PaymentTypeName";
          this.rdlPaymentOption.DataValueField = "PaymentTypeID";
          this.rdlPaymentOption.DataBind();
          this.rdlPaymentOption.SelectedValue = this.rdlPaymentOption.Items[0].Value;
        }
        else
        {
          List<PaymentTypeResponse> paymentOptions = PaymentTypeMgmt.GetPaymentOptions();
          IEnumerable<string> strTypes = ((IEnumerable<string>) (Convert.ToString((object) (Enums.PaymentTypes) 4) + "," + Convert.ToString((object) (Enums.PaymentTypes) 5)).Split(',')).Select<string, string>((System.Func<string, string>) (str => Convert.ToString(str)));
          this.rdlPaymentOption.DataSource = (object) paymentOptions.Where<PaymentTypeResponse>((System.Func<PaymentTypeResponse, bool>) (m => !strTypes.Contains<string>(m.PaymentTypeName.Replace(" ", "")))).ToList<PaymentTypeResponse>();
          this.rdlPaymentOption.DataTextField = "PaymentTypeName";
          this.rdlPaymentOption.DataValueField = "PaymentTypeID";
          this.rdlPaymentOption.DataBind();
          this.rdlPaymentOption.SelectedValue = this.rdlPaymentOption.Items[0].Value;
        }
        this.FillCommercialPartnerData(Convert.ToInt64(commercialPartnerId.LoginMasterID));
      }
    }
  }
}
