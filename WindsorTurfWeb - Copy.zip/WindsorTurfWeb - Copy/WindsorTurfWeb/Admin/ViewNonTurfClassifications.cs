﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewNonTurfClassifications
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfClassifications;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfClassifications;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewNonTurfClassifications : Page
  {
    private long UserId;
    protected StockManagementSubMenus StockManagementSubMenus1;
    protected HtmlGenericControl H1Title;
    protected NonTurfProductStockSubMenu NonTurfProductStockSubMenu1;
    protected HtmlGenericControl divUserAccess;
    protected HtmlGenericControl divData;
    protected RadGrid grdNonTurClassification;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divlegendupdateStatus;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.SetUserModuleAccessOnPage(this.divUserAccess, this.divData, "liViewNonTurfClassification");
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["NonTurfClassificationAddUpdate"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["NonTurfClassificationAddUpdate"]), (Enums.NotificationType) 1), true);
        this.Session["NonTurfClassificationAddUpdate"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<NonTurfClassificationBE> classificationBeList = new List<NonTurfClassificationBE>();
      List<NonTurfClassificationBE> turfClassification = NonTurfClassificationMgmt.GetAllNonTurfClassification();
      this.grdNonTurClassification.VirtualItemCount = turfClassification.Count<NonTurfClassificationBE>();
      ((BaseDataBoundControl) this.grdNonTurClassification).DataSource = (object) turfClassification;
      ((Control) this.grdNonTurClassification).DataBind();
      if (turfClassification.Count<NonTurfClassificationBE>() == 0)
        this.grdNonTurClassification.AllowFilteringByColumn = false;
      ViewNonTurfClassifications.SetPaggingText(this.grdNonTurClassification, "Paging");
    }

    protected void grdNonTurClassification_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdNonTurClassification.MasterTableView.Items).Count == 0)
      {
        this.grdNonTurClassification.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdNonTurClassification.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdNonTurClassification.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdNonTurClassification.PagerStyle.AlwaysVisible = true;
      }
      this.grdNonTurClassification.Rebind();
      ViewNonTurfClassifications.SetPaggingText(this.grdNonTurClassification, "Paging");
    }

    protected void grdNonTurClassification_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdNonTurClassification_PageSizeChanged(
      object sender,
      GridPageSizeChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdNonTurClassification_PageIndexChanged(
      object sender,
      GridPageChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdNonTurClassification_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        NonTurfClassificationMgmt.DeleteAllNonTurfClassification(Convert.ToInt64(((CommandEventArgs) e).CommandArgument.ToString()), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) PageName.strAddNonTurfClassification), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdNonTurClassification.Rebind();
    }

    protected void grdNonTurClassification_ItemDataBound(object sender, GridItemEventArgs e)
    {
      if (e.Item.ItemType != 7 && e.Item.ItemType != 1)
        return;
      HiddenField control1 = (HiddenField) ((Control) e.Item).FindControl("hdnNonTurfClassificationID");
      LinkButton control2 = (LinkButton) ((Control) e.Item).FindControl("lnkDelete");
      if (NonTurfClassificationMgmt.CheckforNonTurfClassificationExists(Convert.ToInt64(control1.Value)) > 0)
      {
        control2.Enabled = false;
        control2.CssClass = "deactive_delete_icongrid";
        control2.OnClientClick = UtilityFunctions.GetNotification(string.Format("You cannot delete this classification as its associated with Non-Turf Product."), (Enums.NotificationType) 2, false);
      }
      else
      {
        control2.Enabled = true;
        control2.CssClass = "delete_icongrid";
        control2.Attributes.Add("onclick", ViewNonTurfClassifications.SetDeleteConfirmation());
      }
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) PageName.strAddNonTurfClassification) + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewNonTurfClassifications.aspx");

    protected void btnIsActive_Click(object sender, EventArgs e)
    {
      string str1 = "";
      string str2 = "";
      foreach (GridDataItem gridDataItem in (GridItemCollection) this.grdNonTurClassification.Items)
      {
        CheckBox control1 = (CheckBox) ((Control) gridDataItem).FindControl("chkIsActive");
        HiddenField control2 = (HiddenField) ((Control) gridDataItem).FindControl("hdnNonTurfClassificationID");
        if (control1 != null)
        {
          str1 = str1 + control2.Value.ToString() + ",";
          str2 = str2 + control1.Checked.ToString() + ",";
        }
      }
      NonTurfClassificationMgmt.UpdateNonTurfClassificationStatus(str1.TrimEnd(','), str2.TrimEnd(','), Convert.ToInt64(this.UserId), HttpContext.Current.Request.UserHostAddress);
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateStatusSuccess, (object) PageName.strAddNonTurfClassification), (Enums.NotificationType) 1), true);
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
