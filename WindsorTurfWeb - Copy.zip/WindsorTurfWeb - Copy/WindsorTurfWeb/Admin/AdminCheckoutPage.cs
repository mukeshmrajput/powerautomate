﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AdminCheckoutPage
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class AdminCheckoutPage : Page
  {
    public static int productQty = 0;
    private DataTable _dtAdminCART = new DataTable();
    private double quan;
    private double total;
    private double subtotal;
    private double netQty;
    private string str = "";
    private string _productid;
    public int s = 0;
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HtmlGenericControl divTab;
    protected WebUserControl1 AdminPurchaseProcess1;
    protected HtmlGenericControl divContinueShopBtn;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected Button btnContShopping;
    protected HtmlGenericControl divShoppingCartDetail;
    protected Literal ltr_countPrd;
    protected Button btnEmptyBag;
    protected Repeater grdCart;
    protected HtmlGenericControl divLegends;
    protected HtmlTable tableLegend;
    protected HtmlGenericControl divButtons;
    protected Button btnContinueShopping;
    protected Button btnCheckOut;
    protected HiddenField hdnOriginalQuantityEdit;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Session["dtAdminCART"] != null)
      {
        DataTable dataTable = (DataTable) this.Session["dtAdminCART"];
      }
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.IsPostBack)
        return;
      this.BindRepeter();
      this.btnContinueShopping.Text = PageName.strBtnShopName;
      this.btnContinueShopping.ToolTip = PageName.strBtnShopName;
      this.btnContShopping.Text = PageName.strBtnDashboardName;
      this.btnContShopping.ToolTip = PageName.strBtnDashboardName;
    }

    public string GetId()
    {
      if (this.Session["dtAdminCART"] == null)
        return this.str;
      ++this.s;
      this.str = Convert.ToString(this.s);
      return this.str;
    }

    public void BindRepeter()
    {
      if (this.Session["dtAdminCART"] != null)
      {
        this._dtAdminCART = (DataTable) this.Session["dtAdminCART"];
        if (this._dtAdminCART.Rows.Count > 0)
        {
          this.divShoppingCartDetail.Visible = true;
          this.divContinueShopBtn.Visible = false;
          this._dtAdminCART = UtilityFunctions.ReverseRowsInDataTable(this._dtAdminCART);
          this.grdCart.DataSource = (object) this._dtAdminCART;
          this.grdCart.DataBind();
          this.ltr_countPrd.Text = ((DataTable) this.Session["dtAdminCART"]).Rows.Count.ToString();
          this.ltr_countPrd.Text = "Total No. of Product(s) : " + this.ltr_countPrd.Text;
        }
        else if (this._dtAdminCART.Rows.Count == 0)
        {
          this.grdCart.DataSource = (object) this._dtAdminCART;
          this.grdCart.DataBind();
          this.grdCart.Visible = false;
          this.ltr_countPrd.Text = "0";
          this.DisplayCartEmptyMessage();
          UtilityFunctions.SetAdminCartEmptyMessage(this.Page, this._dtAdminCART, (System.Web.UI.UserControl) this.AdminPurchaseProcess1);
        }
        this.SetCartValue(this._dtAdminCART);
        ((Label) this.grdCart.Controls[this.grdCart.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtAdminCART, (DataTable) this.Session["dtAdminCART"]);
      }
      else
      {
        this.DisplayCartEmptyMessage();
        UtilityFunctions.SetAdminCartEmptyMessage(this.Page, this._dtAdminCART, (System.Web.UI.UserControl) this.AdminPurchaseProcess1);
      }
    }

    protected void btnEmptyBag_Click(object sender, EventArgs e)
    {
      if (this.Session["dtAdminCART"] == null)
        return;
      this._dtAdminCART = (DataTable) this.Session["dtAdminCART"];
      UtilityFunctions.SetAdminCartEmptyMessage(this.Page, this._dtAdminCART, (System.Web.UI.UserControl) this.AdminPurchaseProcess1);
      this.DisplayCartEmptyMessage();
    }

    protected void btnContinueShopping_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/AdminOrderPage.aspx");

    protected void btnCheckOut_Click(object sender, EventArgs e)
    {
      Control control = this.grdCart.Controls[this.grdCart.Controls.Count - 1].Controls[0];
      if (this.Session["dtAdminCART"] != null)
      {
        if (((DataTable) this.Session["dtAdminCART"]).Rows.Count <= 0)
          return;
        this.Response.Redirect("~/Admin/AdminRetailPurchaseOrderPage.aspx");
      }
      else
      {
        this.DisplayCartEmptyMessage();
        UtilityFunctions.SetAdminCartEmptyMessage(this.Page, this._dtAdminCART, (System.Web.UI.UserControl) this.AdminPurchaseProcess1);
      }
    }

    protected void btnContShopping_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    protected void DisplayCartEmptyMessage()
    {
      this.spnMsg.Visible = true;
      this.lblMsg.Text = string.Format(Messages.ShoppingCartEmpty);
      this.divContinueShopBtn.Visible = true;
      this.divShoppingCartDetail.Visible = false;
      this.divButtons.Visible = false;
      this.divLegends.Visible = false;
      this.spnMsg.Style.Add("color", UtilityFunctions.SetMessageColor(0));
    }

    protected void grdCart_ItemCommand(object sender, RepeaterCommandEventArgs e)
    {
      RepeaterItem repeaterItem = e.Item;
      if (e.CommandName == "delete")
      {
        this._dtAdminCART = (DataTable) this.Session["dtAdminCART"];
        this._productid = e.CommandArgument.ToString();
        DataView dataView = new DataView(this._dtAdminCART);
        dataView.RowFilter = "OrderNo ='" + this._productid + "' ";
        string str = string.Empty;
        if (dataView.Count > 0)
        {
          str = dataView[0]["TurfName"].ToString().Trim();
          dataView[0].Delete();
          this._dtAdminCART.AcceptChanges();
        }
        this.BindRepeter();
        if (this.grdCart.Items.Count > 0)
        {
          this.divContinueShopBtn.Visible = false;
          this.divShoppingCartDetail.Visible = true;
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ProductRemovedFromCart, (object) str.ToString()), (Enums.NotificationType) 1), true);
        }
        ((Label) this.grdCart.Controls[this.grdCart.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtAdminCART, (DataTable) this.Session["dtAdminCART"]);
      }
      if (e.CommandName == "edit")
      {
        ((TextBox) repeaterItem.FindControl("txt_quan")).Text = ((Label) repeaterItem.FindControl("lbl_quan")).Text.ToString();
        this.netQty = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString());
        this.hdnOriginalQuantityEdit.Value = this.netQty.ToString();
        repeaterItem.FindControl("lbl_quan").Visible = false;
        repeaterItem.FindControl("txt_quan").Visible = true;
        repeaterItem.FindControl("spnQuanStar").Visible = true;
        repeaterItem.FindControl("ibtnCalculateArea").Visible = true;
        repeaterItem.FindControl("btn_Update").Visible = true;
        repeaterItem.FindControl("btn_edit").Visible = false;
        repeaterItem.FindControl("btn_cancel").Visible = true;
        this._dtAdminCART = (DataTable) this.Session["dtAdminCART"];
        ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:block");
        if (this._dtAdminCART != null)
        {
          for (int index = 0; index < this._dtAdminCART.Rows.Count; ++index)
          {
            if (((HiddenField) repeaterItem.FindControl("hdn_OrdNo")).Value.ToString() == this._dtAdminCART.Rows[index]["OrderNo"].ToString())
            {
              if (this._dtAdminCART.Rows[index]["Type"].ToString() == "0")
              {
                ((WebControl) repeaterItem.FindControl("reg_qty")).Enabled = false;
                ((WebControl) repeaterItem.FindControl("rgval_qty")).Enabled = true;
              }
              else
              {
                ((WebControl) repeaterItem.FindControl("reg_qty")).Enabled = true;
                ((WebControl) repeaterItem.FindControl("rgval_qty")).Enabled = false;
              }
            }
          }
        }
      }
      if (e.CommandName == "cancel")
      {
        repeaterItem.FindControl("lbl_quan").Visible = true;
        repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
        repeaterItem.FindControl("txt_quan").Visible = false;
        repeaterItem.FindControl("spnQuanStar").Visible = false;
        repeaterItem.FindControl("btn_Update").Visible = false;
        repeaterItem.FindControl("btn_edit").Visible = true;
        repeaterItem.FindControl("btn_cancel").Visible = false;
        this.Response.Redirect("~/Admin/AdminCheckoutPage.aspx");
      }
      if (e.CommandName == "calculate")
      {
        TextBox control1 = (TextBox) e.Item.FindControl("txt_quan");
        Label control2 = (Label) e.Item.FindControl("lbl_unitprice");
        Label control3 = (Label) e.Item.FindControl("lbl_subtotal");
        LinkButton control4 = (LinkButton) repeaterItem.FindControl("ibtnCalculateArea");
        ((HtmlAnchor) repeaterItem.FindControl("aCalculateArea")).HRef = "GetAreaValue.aspx?txtTO=" + control1.Text + "&lblprice=" + control2.Text + "&lblsub=" + control3.Text;
      }
      if (!(e.CommandName == "update"))
        return;
      ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:none");
      this._dtAdminCART = (DataTable) this.Session["dtAdminCART"];
      if (this.spnMsg.Visible)
      {
        this.spnMsg.Visible = false;
        this.lblMsg.Text = string.Empty;
      }
      if (this._dtAdminCART == null)
      {
        this.DisplayCartEmptyMessage();
        UtilityFunctions.SetAdminCartEmptyMessage(this.Page, this._dtAdminCART, (System.Web.UI.UserControl) this.AdminPurchaseProcess1);
      }
      if (this._dtAdminCART != null)
      {
        for (int index = 0; index < this._dtAdminCART.Rows.Count; ++index)
        {
          if (((HiddenField) repeaterItem.FindControl("hdn_OrdNo")).Value.ToString() == this._dtAdminCART.Rows[index]["OrderNo"].ToString())
          {
            if (((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString() == "" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "0" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "0.00" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "00" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "01" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "02" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "03" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "04" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "05" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "06" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "07" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "08" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "09")
              return;
            this.quan = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString());
            this.subtotal = Convert.ToDouble(((Label) repeaterItem.FindControl("lbl_unitprice")).Text.ToString());
            double subtotal = this.subtotal;
            if (subtotal > 0.0)
            {
              this.total = this.quan * this.subtotal;
              ((Label) repeaterItem.FindControl("lbl_subtotal")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.total);
              repeaterItem.FindControl("lbl_quan").Visible = true;
              ((Label) repeaterItem.FindControl("lbl_quan")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.quan);
              ((Label) repeaterItem.FindControl("lbl_unitprice")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) subtotal);
              repeaterItem.FindControl("txt_quan").Visible = false;
              repeaterItem.FindControl("btn_Update").Visible = false;
              repeaterItem.FindControl("btn_edit").Visible = true;
              repeaterItem.FindControl("btn_cancel").Visible = false;
              repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
              repeaterItem.FindControl("spnQuanStar").Visible = false;
              this._dtAdminCART.Rows[index].BeginEdit();
              this._dtAdminCART.Rows[index]["Quantity"] = (object) ((Label) repeaterItem.FindControl("lbl_quan")).Text;
              this._dtAdminCART.Rows[index]["Price"] = (object) ((Label) repeaterItem.FindControl("lbl_unitprice")).Text;
              this._dtAdminCART.AcceptChanges();
              foreach (string str in (IEnumerable<string>) this._dtAdminCART.AsEnumerable().Select<DataRow, string>((System.Func<DataRow, string>) (dt => dt.Field<string>("TurfName"))))
              {
                this.lblMsg.Text = string.Format(Messages.UpdateSuccess, (object) str.ToString());
                this.divContinueShopBtn.Visible = false;
                this.divShoppingCartDetail.Visible = true;
                System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateSuccess, (object) str.ToString()), (Enums.NotificationType) 1), true);
              }
            }
            else
            {
              repeaterItem.FindControl("lbl_quan").Visible = true;
              repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
              repeaterItem.FindControl("txt_quan").Visible = false;
              repeaterItem.FindControl("btn_Update").Visible = false;
              repeaterItem.FindControl("btn_edit").Visible = true;
              repeaterItem.FindControl("btn_cancel").Visible = false;
              ((Label) repeaterItem.FindControl("lbl_quan")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.hdnOriginalQuantityEdit.Value);
              System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format("Turf Price is not defined for this Area size."), (Enums.NotificationType) 2), true);
            }
          }
        }
      }
      ((Label) this.grdCart.Controls[this.grdCart.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtAdminCART, (DataTable) this.Session["dtAdminCART"]);
    }

    protected void grdCart_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item)
        return;
      LinkButton control1 = (LinkButton) e.Item.FindControl("ibtnCalculateArea");
      TextBox control2 = (TextBox) e.Item.FindControl("txt_quan");
    }

    protected void SetCartValue(DataTable dtAdminCART)
    {
      Label control = (Label) this.AdminPurchaseProcess1.FindControl("ltradmin_cart");
      control.Text = "Cart (" + dtAdminCART.Rows.Count.ToString() + ")";
      control.ToolTip = "Cart (" + dtAdminCART.Rows.Count.ToString() + ")";
    }
  }
}
