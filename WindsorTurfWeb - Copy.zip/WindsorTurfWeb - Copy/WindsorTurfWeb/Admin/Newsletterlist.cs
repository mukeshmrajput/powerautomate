﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.Newsletterlist
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Newsletter;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class Newsletterlist : Page
  {
    protected HtmlGenericControl divTab;
    protected HtmlAnchor aAddUpdateUser;
    protected Button btnAdd;
    protected RadGrid grdNews;
    protected HtmlTable tableLegend;
    protected Button btnExporting;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liNewsletterList");
      if (this.Session["AddNewsletter"] != null && Convert.ToString(this.Session["AddNewsletter"]) != "")
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AddSuccess, (object) "Email Address"), (Enums.NotificationType) 1), true);
        this.Session["AddNewsletter"] = (object) null;
      }
      if (this.IsPostBack)
        return;
      this.BindGrid();
    }

    private void BindGrid()
    {
      List<Entity.Common.Newsletter.Newsletter> allNewsletter = NewsletterMgmt.GetAllNewsletter();
      this.grdNews.VirtualItemCount = allNewsletter.Count<Entity.Common.Newsletter.Newsletter>();
      ((BaseDataBoundControl) this.grdNews).DataSource = (object) allNewsletter;
      ((Control) this.grdNews).DataBind();
      Newsletterlist.SetPaggingText(this.grdNews, "Paging");
    }

    protected void grdNews_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdNews_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdNews_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdNews_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        NewsletterMgmt.DeleteNewsletterId(Convert.ToInt64(((CommandEventArgs) e).CommandArgument));
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) "Newsletter"), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdNews.Rebind();
    }

    protected void grdNews_ItemDataBound(object sender, GridItemEventArgs e)
    {
    }

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/Newsletterlist.aspx");

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) "Newsletter") + "')";

    protected void grdNews_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdNews.MasterTableView.Items).Count == 0)
      {
        this.grdNews.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdNews.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdNews.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdNews.PagerStyle.AlwaysVisible = true;
      }
      this.grdNews.Rebind();
      Newsletterlist.SetPaggingText(this.grdNews, "Paging");
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }

    protected void btnExporting_Click(object sender, EventArgs e) => this.CreateCSV(UtilityFunctions.ConvertToDataTable<Entity.Common.Newsletter.Newsletter>((IList<Entity.Common.Newsletter.Newsletter>) NewsletterMgmt.GetAllNewsletter()));

    public void CreateCSV(DataTable dt)
    {
      dt.Columns.Remove("NewsletterID");
      dt.Columns.Remove("IsDeleted");
      string str1 = string.Empty;
      foreach (DataColumn column in (InternalDataCollectionBase) dt.Columns)
        str1 = str1 + column.ColumnName + ",";
      string str2 = str1 + "\r\n";
      foreach (DataRow row in (InternalDataCollectionBase) dt.Rows)
      {
        foreach (DataColumn column in (InternalDataCollectionBase) dt.Columns)
          str2 = str2 + row[column.ColumnName].ToString().Replace(",", ";") + ",";
        str2 += "\r\n";
      }
      this.Response.Clear();
      this.Response.Buffer = true;
      this.Response.AddHeader("content-disposition", "attachment;filename=Newsletterlist.csv");
      this.Response.Charset = "";
      this.Response.ContentType = "application/text";
      this.Response.Output.Write(str2);
      this.Response.Flush();
      this.Response.End();
    }

    protected void btnAdd_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/AddNewsletter.aspx");
  }
}
