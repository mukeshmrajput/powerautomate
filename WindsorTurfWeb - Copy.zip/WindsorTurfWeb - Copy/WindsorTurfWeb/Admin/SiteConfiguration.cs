﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.SiteConfiguration
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Miscellaneous;
using Entity.Common.Miscellaneous;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class SiteConfiguration : Page
  {
    public string strValidationSetting = "ValidationSetting";
    protected UpdatePanel pnlUpdate;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl liGeneralSettings;
    protected LinkButton lnkGeneralSettings;
    protected HtmlGenericControl liChgPassword;
    protected LinkButton lnkChgPassword;
    protected TextBox txtFromName;
    protected RequiredFieldValidator rfvFromName;
    protected RegularExpressionValidator regFromName;
    protected TextBox txtLoginEmail;
    protected RequiredFieldValidator rfvLoginEmail;
    protected RegularExpressionValidator regLoginEmail;
    protected TextBox txtFromEmail;
    protected RequiredFieldValidator rfvFromEmail;
    protected RegularExpressionValidator regFromEmail;
    protected TextBox txtToEmail;
    protected RequiredFieldValidator rfvToEmail;
    protected RegularExpressionValidator regToEmail;
    protected TextBox txtCcEmail;
    protected RegularExpressionValidator regCcEmail;
    protected TextBox txtBccEmail;
    protected RegularExpressionValidator regBccEmail;
    protected TextBox txtGoogleAnalytic;
    protected TextBox txtGST;
    protected RequiredFieldValidator rfvGST;
    protected RegularExpressionValidator regGST;
    protected TextBox txtDeleveryDays;
    protected RequiredFieldValidator rfvDelDays;
    protected RegularExpressionValidator regDelDays;
    protected Button btnSubmit;
    protected Button btnCancel;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.IsPostBack)
        return;
      this.GetSiteConfiguration();
      this.ValidationIntialization();
      this.txtFromName.Focus();
    }

    private void ValidationIntialization()
    {
      Validations.SetRequiredFieldValidator(this.rfvFromName, true, (object) this.txtFromName, this.strValidationSetting);
      Validations.SetRegularExpressionValidator(this.regFromName, Regex.Name, true, (object) this.txtFromName, this.strValidationSetting);
      Validations.SetRequiredFieldValidator(this.rfvLoginEmail, true, (object) this.txtLoginEmail, this.strValidationSetting);
      Validations.SetRegularExpressionValidator(this.regLoginEmail, Regex.Email, true, (object) this.txtLoginEmail, this.strValidationSetting);
      Validations.SetRequiredFieldValidator(this.rfvFromEmail, true, (object) this.txtFromEmail, this.strValidationSetting);
      Validations.SetRegularExpressionValidator(this.regFromEmail, Regex.Email, true, (object) this.txtFromEmail, this.strValidationSetting);
      Validations.SetRequiredFieldValidator(this.rfvToEmail, true, (object) this.txtToEmail, this.strValidationSetting);
      Validations.SetRegularExpressionValidator(this.regToEmail, Regex.Email, true, (object) this.txtToEmail, this.strValidationSetting);
      Validations.SetRegularExpressionValidator(this.regCcEmail, Regex.MultipleEmailWithSemiColonSeparted, true, (object) this.txtCcEmail, this.strValidationSetting);
      Validations.SetRegularExpressionValidator(this.regBccEmail, Regex.MultipleEmailWithSemiColonSeparted, true, (object) this.txtBccEmail, this.strValidationSetting);
      Validations.SetRequiredFieldValidator(this.rfvGST, true, (object) this.txtGST, this.strValidationSetting);
      Validations.SetRegularExpressionValidator(this.regGST, Regex.GST, true, (object) this.txtGST, this.strValidationSetting);
      Validations.SetRegularExpressionValidator(this.regDelDays, Regex.OnlyNumbers, true, (object) this.txtDeleveryDays, this.strValidationSetting);
      Validations.SetRequiredFieldValidator(this.rfvDelDays, true, (object) this.txtDeleveryDays, this.strValidationSetting);
      this.btnSubmit.ValidationGroup = this.strValidationSetting;
    }

    private void GetSiteConfiguration()
    {
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      this.txtLoginEmail.Text = siteConfiguration.LoginEmail;
      this.txtFromName.Text = siteConfiguration.FromName;
      this.txtFromEmail.Text = siteConfiguration.FromEmail;
      this.txtToEmail.Text = siteConfiguration.ToEmail;
      this.txtBccEmail.Text = siteConfiguration.BccEmail;
      this.txtCcEmail.Text = siteConfiguration.CcEmail;
      this.txtGoogleAnalytic.Text = siteConfiguration.GoogleAnalyticScript;
      this.txtGST.Text = siteConfiguration.GST.ToString();
      this.txtDeleveryDays.Text = siteConfiguration.DeliveryDays.ToString();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.IsValid)
        return;
      long num = (long) SiteConfigurationMgmt.UpdateSiteConfiguration(new SiteConfiguration()
      {
        LoginEmail = this.txtLoginEmail.Text.Trim(),
        FromName = this.txtFromName.Text.Trim(),
        FromEmail = this.txtFromEmail.Text.Trim(),
        ToEmail = this.txtToEmail.Text.Trim(),
        BccEmail = this.txtBccEmail.Text.Trim(),
        CcEmail = this.txtCcEmail.Text.Trim(),
        GoogleAnalyticScript = this.txtGoogleAnalytic.Text.Trim(),
        GST = Convert.ToDecimal(this.txtGST.Text.Trim()),
        DeliveryDays = Convert.ToInt32(this.txtDeleveryDays.Text.Trim()),
        ModifiedDate = DateTime.UtcNow,
        ModifiedByIP = HttpContext.Current.Request.UserHostAddress
      });
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateSuccess, (object) "Settings"), (Enums.NotificationType) 1), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    protected void lnkChgPassword_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ChangePassword.aspx");

    protected void lnkGeneralSettings_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/SiteConfiguration.aspx");
  }
}
