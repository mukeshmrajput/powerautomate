﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateQuantityRanges
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.NonTurfProductPricing.QuantityRanges;
using Entity.Common.ProductPricing.NonTurfProductPricing.QuantityRanges;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateQuantityRanges : Page
  {
    public static long fQuantityRangeID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtQuantityRangeTitle;
    protected RequiredFieldValidator rfvQuantityRangeTitle;
    protected RegularExpressionValidator regQuantityRangeTitle;
    protected TextBox txtStartIndex;
    protected RequiredFieldValidator rfvStartIndex;
    protected TextBox txtEndIndex;
    protected RequiredFieldValidator rfvEndIndex;
    protected CompareValidator cmpStartEndIndex;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnQuantityRangeID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewQuantityRange");
      if (this.Request.QueryString[QueryStrings.QuantityRangeID] != null)
      {
        AddUpdateQuantityRanges.fQuantityRangeID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.QuantityRangeID].ToString()));
        this.h1Title.InnerText = "Edit " + PageName.strAddQuantityRange;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddQuantityRange;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateQuantityRanges.fQuantityRangeID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        if (AddUpdateQuantityRanges.fQuantityRangeID > 0L)
          this.GetQuantityRangeDetails(QuantityRangeMgmt.GetQuantityRangeDetailByID(Convert.ToInt64(AddUpdateQuantityRanges.fQuantityRangeID)));
      }
      this.txtQuantityRangeTitle.Focus();
    }

    protected void GetQuantityRangeDetails(QuantityRangeBE objQuantityRangeBE)
    {
      this.txtQuantityRangeTitle.Text = objQuantityRangeBE.Title;
      this.txtStartIndex.Text = Convert.ToString(objQuantityRangeBE.StartIndex);
      this.txtEndIndex.Text = Convert.ToString(objQuantityRangeBE.EndIndex);
      this.chkIsActive.Checked = objQuantityRangeBE.IsActive;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      QuantityRangeBE quantityRangeBe = new QuantityRangeBE();
      quantityRangeBe.QuantityRangeID = AddUpdateQuantityRanges.fQuantityRangeID <= 0L ? 0L : AddUpdateQuantityRanges.fQuantityRangeID;
      quantityRangeBe.Title = this.txtQuantityRangeTitle.Text.Trim();
      quantityRangeBe.StartIndex = Convert.ToInt32(this.txtStartIndex.Text.Trim());
      quantityRangeBe.EndIndex = Convert.ToInt32(this.txtEndIndex.Text.Trim());
      quantityRangeBe.IsActive = this.chkIsActive.Checked;
      quantityRangeBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      quantityRangeBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      if (QuantityRangeMgmt.AddUpdateQuantityRanges(quantityRangeBe) > 0L)
      {
        if (quantityRangeBe.QuantityRangeID > 0L)
          this.Session["QuantityRangeAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddQuantityRange);
        else if (quantityRangeBe.QuantityRangeID == 0L)
          this.Session["QuantityRangeAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddQuantityRange);
        this.Response.Redirect("~/Admin/ViewQuantityRanges.aspx");
      }
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvQuantityRangeTitle, true, (object) this.txtQuantityRangeTitle, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regQuantityRangeTitle, Regex.Subject, true, (object) this.txtQuantityRangeTitle, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvStartIndex, true, (object) this.txtStartIndex, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvEndIndex, true, (object) this.txtEndIndex, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
