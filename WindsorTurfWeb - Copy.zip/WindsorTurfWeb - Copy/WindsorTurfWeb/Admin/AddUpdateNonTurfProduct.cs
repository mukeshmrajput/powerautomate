﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateNonTurfProduct
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Common.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateNonTurfProduct : Page
  {
    public int rowCount = 0;
    public long fNonTurfProductID = 0;
    public long UserId;
    public string TurfOriginalImagePath = ConfigurationManager.AppSettings[nameof (TurfOriginalImagePath)];
    public string TurfThumbImagePath = ConfigurationManager.AppSettings[nameof (TurfThumbImagePath)];
    public string TurfShopPageImagePath = ConfigurationManager.AppSettings[nameof (TurfShopPageImagePath)];
    public string TurfContentPageImagePath = ConfigurationManager.AppSettings[nameof (TurfContentPageImagePath)];
    public string TurfCartPageImagePath = ConfigurationManager.AppSettings[nameof (TurfCartPageImagePath)];
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected TextBox txtTurfName;
    protected RequiredFieldValidator rfvTurfName;
    protected RegularExpressionValidator regTurfName;
    protected TextBox txtTurfPageName;
    protected RequiredFieldValidator rfvTurfPageName;
    protected RegularExpressionValidator regTurfPageName;
    protected DropDownList ddlTurfClassification;
    protected RequiredFieldValidator rfvTurfClassification;
    protected TextBox txtimgTurf;
    protected FileUpload fldTurf;
    protected HtmlAnchor lnkTurfImage;
    protected HtmlAnchor lnkTurfThumb;
    protected System.Web.UI.WebControls.Image ImgThumb;
    protected Button btnTurfImageDelete;
    protected RequiredFieldValidator rfvTurfImage;
    protected HiddenField hdnDivTurfImage;
    protected HiddenField hdnTurfImageDoc;
    protected HiddenField hdnTurfImageCancel;
    protected HiddenField hdnTurfImageName;
    protected HiddenField hdnUploadType;
    protected HiddenField hdnDocName;
    protected HtmlGenericControl divDescription;
    protected RadEditor redBodyDescription;
    protected RequiredFieldValidator rfvDescription;
    protected HtmlGenericControl divUses;
    protected RadEditor redBodyUses;
    protected RequiredFieldValidator rfvUses;
    protected HtmlGenericControl divMaintenance;
    protected RadEditor redBodyMaintenance;
    protected RequiredFieldValidator rfvMaintenance;
    protected HtmlGenericControl divCharacteristics;
    protected RadEditor redBodyCharacteristics;
    protected RequiredFieldValidator rfvCharacteristics;
    protected TextBox txtPageTitle;
    protected RequiredFieldValidator rfvPageTitle;
    protected RegularExpressionValidator regPageTitle;
    protected TextBox txtMetaDescription;
    protected RequiredFieldValidator rfvMetaDescription;
    protected RegularExpressionValidator regMetaDescription;
    protected TextBox txtMetaKeywords;
    protected RequiredFieldValidator rfvMetaKeywords;
    protected RegularExpressionValidator regMetaKeywords;
    protected CheckBox chkIsActive;
    protected CheckBox chkIsStockAvailable;
    protected Button btnSubmit;
    protected Button btnCancel;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewNonTurfProduct");
      if (this.Request.QueryString[QueryStrings.NonTurfProductID] != null)
        this.fNonTurfProductID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.NonTurfProductID].ToString()));
      this.txtTurfName.Focus();
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (!this.Page.IsPostBack)
      {
        this.BindDropdown();
        this.ValidationExpression();
        if (this.Request.QueryString[QueryStrings.NonTurfProductID] != null)
        {
          this.h1Title.InnerText = "Edit " + PageName.strAddNonTurfProduct;
          this.btnSubmit.Text = "Update";
          this.btnSubmit.ToolTip = "Update";
          this.fNonTurfProductID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.NonTurfProductID].ToString()));
          this.FillData(NonTurfProductMgmt.GetNonTurfProductDetailByID(Convert.ToInt64(this.fNonTurfProductID)));
        }
        else
        {
          this.h1Title.InnerText = "Add " + PageName.strAddNonTurfProduct;
          this.btnSubmit.Text = "Save";
          this.btnSubmit.ToolTip = "Save";
        }
      }
      this.txtTurfName.Focus();
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvTurfName, true, (object) this.txtTurfName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTurfName, Regex.Title, true, (object) this.txtTurfName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTurfPageName, true, (object) this.txtTurfPageName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTurfPageName, Regex.Title, true, (object) this.txtTurfPageName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvTurfClassification, true, (object) this.ddlTurfClassification, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvDescription, true, (object) this.redBodyDescription, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvUses, true, (object) this.redBodyUses, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvMaintenance, true, (object) this.redBodyMaintenance, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvCharacteristics, true, (object) this.redBodyCharacteristics, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvPageTitle, true, (object) this.txtPageTitle, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regPageTitle, Regex.Title, true, (object) this.txtPageTitle, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvMetaDescription, true, (object) this.txtMetaDescription, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regMetaDescription, Regex.MetaKeyword, true, (object) this.txtTurfName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvMetaKeywords, true, (object) this.txtMetaKeywords, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regMetaKeywords, Regex.MetaKeyword, true, (object) this.txtMetaKeywords, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTurfImage, true, (object) this.txtimgTurf, this.strValidationTurfGrp);
      this.fldTurf.Attributes.Add("OnChange", "return UploadFileSelect('" + this.fldTurf.ClientID + "','" + this.txtimgTurf.ClientID + "', this, 'turf product');");
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }

    protected void BindDropdown() => BindDropDown.GetAllNonTurfClassificationForDropDown((ListControl) this.ddlTurfClassification);

    protected void FillData(NonTurfProductResponseBE objTurfProduct)
    {
      if (objTurfProduct == null)
        return;
      this.txtTurfName.Text = objTurfProduct.NonTurfName;
      this.txtTurfPageName.Text = objTurfProduct.NonTurfLinkURL.ToString().Replace("-", " ").Replace("Turf_Type_", "");
      this.txtPageTitle.Text = objTurfProduct.PageTitle;
      this.txtMetaKeywords.Text = objTurfProduct.MetaKeyword;
      this.txtMetaDescription.Text = objTurfProduct.MetaDescription;
      this.ddlTurfClassification.SelectedValue = Convert.ToString(objTurfProduct.NonTurfClassificationID);
      this.redBodyUses.Content = objTurfProduct.Uses;
      this.redBodyMaintenance.Content = objTurfProduct.Maintenance;
      this.redBodyCharacteristics.Content = objTurfProduct.Characteristics;
      this.redBodyDescription.Content = objTurfProduct.Description;
      this.chkIsActive.Checked = Convert.ToBoolean(objTurfProduct.IsActive);
      this.chkIsStockAvailable.Checked = Convert.ToBoolean(objTurfProduct.IsStockAvailable);
      if (!string.IsNullOrEmpty(objTurfProduct.MainImage) && objTurfProduct.MainImage != "none")
      {
        this.hdnTurfImageDoc.Value = "block";
        this.hdnDivTurfImage.Value = "none";
        this.hdnTurfImageCancel.Value = "block";
        this.hdnTurfImageName.Value = objTurfProduct.MainImage;
        this.lnkTurfImage.HRef = ConfigurationManager.AppSettings["LivePath"] + this.TurfOriginalImagePath + objTurfProduct.MainImage;
        this.lnkTurfImage.Target = "_blank";
        this.ImgThumb.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.TurfOriginalImagePath + objTurfProduct.MainImage;
        this.lnkTurfThumb.HRef = ConfigurationManager.AppSettings["LivePath"] + this.TurfOriginalImagePath + objTurfProduct.MainImage;
        this.lnkTurfThumb.Visible = true;
        this.rfvTurfImage.Enabled = false;
      }
      else
        this.rfvTurfImage.Enabled = true;
    }

    private bool ImageValidationMessage()
    {
      string str = this.fldTurf.FileName.Substring(this.fldTurf.FileName.LastIndexOf(".") + 1).ToLower();
      str = string.Empty;
      string lower = this.fldTurf.FileName.Substring(this.fldTurf.FileName.LastIndexOf(".") + 1).ToLower();
      if (Regex.UploadImage.Contains(lower) && !string.IsNullOrEmpty(lower))
      {
        if (this.fldTurf.FileContent.Length > 2097152L)
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "News"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      else
      {
        if (string.IsNullOrEmpty(lower) && string.IsNullOrEmpty(this.hdnTurfImageName.Value))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "News"), (Enums.NotificationType) 2, false), true);
          return false;
        }
        if (!string.IsNullOrEmpty(lower))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.ImageTypeOrImageSizeInvalid, (object) "News"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      return true;
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewNonTurfProduct.aspx");

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid || !this.ImageValidationMessage())
        return;
      NonTurfProductBE nonTurfProductBe = new NonTurfProductBE();
      nonTurfProductBe.CreatedBy = Convert.ToInt64(this.UserId);
      nonTurfProductBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      nonTurfProductBe.NonTurfProductID = this.fNonTurfProductID <= 0L ? 0L : this.fNonTurfProductID;
      nonTurfProductBe.NonTurfName = this.txtTurfName.Text.Trim();
      nonTurfProductBe.NonTurfLinkURL = this.txtTurfPageName.Text.Replace(" ", "-");
      nonTurfProductBe.NonTurfClassificationID = Convert.ToInt64(this.ddlTurfClassification.SelectedValue);
      nonTurfProductBe.IsActive = this.chkIsActive.Checked;
      nonTurfProductBe.IsStockAvailable = this.chkIsStockAvailable.Checked;
      nonTurfProductBe.Description = this.redBodyDescription.Content.Trim();
      nonTurfProductBe.Uses = this.redBodyUses.Content.Trim();
      nonTurfProductBe.Maintenance = this.redBodyMaintenance.Content.Trim();
      nonTurfProductBe.Characteristics = this.redBodyCharacteristics.Content.Trim();
      nonTurfProductBe.PageTitle = this.txtPageTitle.Text.Trim();
      nonTurfProductBe.MetaDescription = this.txtMetaDescription.Text.Trim();
      nonTurfProductBe.MetaKeyword = this.txtMetaKeywords.Text.Trim();
      string empty = string.Empty;
      if (!string.IsNullOrEmpty(this.fldTurf.FileName))
      {
        if (this.fldTurf.FileName.Length > 0)
        {
          string[] strArray = this.fldTurf.FileName.Split('\\');
          string FileName = UtilityFunctions.ChangeFileName(strArray[strArray.Length - 1].ToString());
          string extension = Path.GetExtension(this.fldTurf.FileName);
          if (extension == ".jpeg" || extension == ".JPEG" || extension == ".png" || extension == ".PNG" || extension == ".jpg" || extension == ".JPG" || extension == ".bmp" || extension == ".BMP" || extension == ".gif" || extension == ".GIF")
          {
            System.Drawing.Image image = System.Drawing.Image.FromStream(this.fldTurf.PostedFile.InputStream);
            int height = image.Height;
            int width = image.Width;
            this.fldTurf.SaveAs(this.Server.MapPath("~/") + this.TurfOriginalImagePath + FileName);
            Resizer.FixedSize(FileName, this.fldTurf, this.TurfThumbImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["TurfThumbImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["TurfThumbImageHeight"]));
            Resizer.FixedSize(FileName, this.fldTurf, this.TurfShopPageImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["TurfShopPageImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["TurfShopPageImageHeight"]));
            Resizer.FixedSize(FileName, this.fldTurf, this.TurfCartPageImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["TurfCartPageImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["TurfCartPageImageHeight"]));
            Resizer.FixedSize(FileName, this.fldTurf, this.TurfContentPageImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["TurfContentPageImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["TurfContentPageImageHeight"]));
          }
          else
            this.fldTurf.SaveAs(this.Server.MapPath("~/") + this.TurfOriginalImagePath + FileName);
          nonTurfProductBe.MainImage = FileName;
          if (!string.IsNullOrEmpty(this.hdnTurfImageName.Value))
          {
            FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.TurfOriginalImagePath + this.hdnTurfImageName.Value);
            if (fileInfo.Exists)
              fileInfo.Delete();
          }
        }
      }
      else
        nonTurfProductBe.MainImage = this.hdnTurfImageName.Value;
      nonTurfProductBe.IsActive = this.chkIsActive.Checked;
      long num = NonTurfProductMgmt.AddUpdateNonTurfProduct(nonTurfProductBe);
      if (num > 0L)
      {
        if (this.fNonTurfProductID > 0L)
          this.Session["NonTurfProductIDAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddNonTurfProduct);
        else
          this.Session["NonTurfProductIDAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddNonTurfProduct);
        this.Response.Redirect("~/Admin/ViewNonTurfProduct.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) PageName.strAddNonTurfProductName), (Enums.NotificationType) 2, false), true);
    }

    protected void btnTurfImageDelete_Click(object sender, EventArgs e)
    {
      FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.TurfOriginalImagePath + this.hdnTurfImageName.Value);
      if (!fileInfo.Exists)
        return;
      fileInfo.Delete();
      NonTurfProductMgmt.DeleteNonTurfImageById(this.fNonTurfProductID);
      this.hdnTurfImageDoc.Value = "none";
      this.hdnDivTurfImage.Value = "block";
      this.hdnTurfImageCancel.Value = "none";
      this.hdnTurfImageName.Value = "none";
      this.rfvTurfImage.Enabled = true;
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) "Product Image"), (Enums.NotificationType) 1), true);
    }
  }
}
