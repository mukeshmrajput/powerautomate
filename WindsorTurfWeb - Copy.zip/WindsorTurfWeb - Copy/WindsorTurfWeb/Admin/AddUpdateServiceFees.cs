﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateServiceFees
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.TurfProductPricing.ServiceFees;
using Entity.Common.ProductPricing.TurfProductPricing.ServiceFees;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateServiceFees : Page
  {
    public static long fServiceFeesID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected DropDownList ddlServiceRegion;
    protected RequiredFieldValidator rfvServiceRegion;
    protected DropDownList ddlTurfRange;
    protected RequiredFieldValidator rfvTurfRange;
    protected TextBox txtRetailServiceFee;
    protected RequiredFieldValidator rfvRetailServiceFee;
    protected RegularExpressionValidator regRetailServiceFee;
    protected TextBox txtTradeServiceFee;
    protected RequiredFieldValidator rfvTradeServiceFee;
    protected RegularExpressionValidator regTradeServiceFee;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnServiceFeesID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewServiceFees");
      if (this.Request.QueryString[QueryStrings.ServiceFeesID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strAddServiceFees;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        AddUpdateServiceFees.fServiceFeesID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.ServiceFeesID].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddServiceFees;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateServiceFees.fServiceFeesID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.BindDropdown();
        this.ValidationExpression();
        if (AddUpdateServiceFees.fServiceFeesID > 0L)
          this.GetServiceFeesDetails(ServiceFeesMgmt.GetServiceFeesDetailByID(Convert.ToInt64(AddUpdateServiceFees.fServiceFeesID)));
      }
      this.ddlServiceRegion.Focus();
    }

    protected void GetServiceFeesDetails(ServiceFeesBE objServiceFeesBE)
    {
      this.ddlTurfRange.SelectedValue = Convert.ToString(objServiceFeesBE.TurfRangeID);
      this.ddlServiceRegion.SelectedValue = Convert.ToString(objServiceFeesBE.ServiceRegionID);
      this.txtRetailServiceFee.Text = Convert.ToString(objServiceFeesBE.RetailServiceFees);
      this.txtTradeServiceFee.Text = Convert.ToString(objServiceFeesBE.TradeServiceFees);
      this.chkIsActive.Checked = Convert.ToBoolean(objServiceFeesBE.IsActive);
    }

    protected void BindDropdown()
    {
      BindDropDown.BindServiceRegion((ListControl) this.ddlServiceRegion);
      BindDropDown.BindTurfRange((ListControl) this.ddlTurfRange);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      ServiceFeesBE serviceFeesBe = new ServiceFeesBE();
      if (AddUpdateServiceFees.fServiceFeesID > 0L)
        serviceFeesBe.ServiceFeesID = AddUpdateServiceFees.fServiceFeesID;
      else
        serviceFeesBe.ServiceRegionID = 0L;
      serviceFeesBe.ServiceRegionID = Convert.ToInt64(this.ddlServiceRegion.SelectedValue);
      serviceFeesBe.TurfRangeID = Convert.ToInt64(this.ddlTurfRange.SelectedValue);
      serviceFeesBe.RetailServiceFees = Convert.ToDecimal(this.txtRetailServiceFee.Text.Trim());
      serviceFeesBe.TradeServiceFees = Convert.ToDecimal(this.txtTradeServiceFee.Text.Trim());
      serviceFeesBe.IsActive = this.chkIsActive.Checked;
      serviceFeesBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      serviceFeesBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      long num = ServiceFeesMgmt.AddUpdateServiceFees(serviceFeesBe);
      if (num > 0L)
      {
        if (serviceFeesBe.ServiceFeesID > 0L)
          this.Session["ServiceFeesAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddServiceFees);
        else if (serviceFeesBe.ServiceFeesID == 0L)
          this.Session["ServiceFeesAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddServiceFees);
        this.Response.Redirect("~/Admin/ViewServiceFees.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Service Region"), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorDropdown(this.rfvServiceRegion, true, (object) this.ddlServiceRegion, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvTurfRange, true, (object) this.ddlTurfRange, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvRetailServiceFee, true, (object) this.txtRetailServiceFee, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regRetailServiceFee, Regex.NumbersWithDotOnly, true, (object) this.txtRetailServiceFee, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTradeServiceFee, true, (object) this.txtTradeServiceFee, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTradeServiceFee, Regex.NumbersWithDotOnly, true, (object) this.txtTradeServiceFee, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
