﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AdminShopPage
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Common.Response;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AdminShopPage : Page
  {
    protected HtmlGenericControl divTab;
    protected WebUserControl1 AdminPurchaseProcess1;
    protected HtmlGenericControl divMainShopData;
    protected HtmlGenericControl divTurfClassification;
    protected Repeater rptTurfClassification;
    protected HtmlGenericControl divNonTurfClassification;
    protected Repeater rptNonTurfClassification;
    protected Literal ltrTurfZone;
    protected HiddenField hdnTurfClassificationID;
    protected HiddenField hdnTurfType;
    protected DropDownList ddlTurfZone;
    protected HtmlGenericControl divNoProducts;
    protected Label lblNoProductFound;
    protected HtmlGenericControl divProductDetails;
    protected HtmlGenericControl divTurfProducts;
    protected DataList dlTurfProducts;
    protected HtmlGenericControl divNonTurfProducts;
    protected DataList dlNonTurfProducts;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.Session["dtAdminCART"] != null)
      {
        DataTable dataTable = (DataTable) this.Session["dtAdminCART"];
      }
      if (this.IsPostBack)
        return;
      this.BindTurfNonTurfClassification();
    }

    protected void BindTurfProducts(long TurfClassificationID)
    {
      this.ltrTurfZone.Text = "Turf Zone";
      BindDropDown.BindTurfZoneForShopPage((ListControl) this.ddlTurfZone);
      this.hdnTurfClassificationID.Value = Convert.ToString(TurfClassificationID);
      this.hdnTurfType.Value = ((Enums.TurfProductType) 1).ToString();
      this.BindFinalTurfProducts(TurfClassificationID, Convert.ToInt64(this.ddlTurfZone.SelectedValue));
    }

    protected void BindFinalTurfProducts(long TurfClassificationID, long TurfZoneID)
    {
      List<TurfProductResponseBE> forShopPageAdmin = TurfProductMgmt.GetAllTurfProductsForShopPageAdmin(TurfClassificationID, TurfZoneID, UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
      if (forShopPageAdmin.Count > 0)
      {
        this.dlTurfProducts.DataSource = (object) forShopPageAdmin;
        this.dlTurfProducts.DataBind();
        this.divTurfProducts.Visible = true;
        this.divNonTurfProducts.Visible = false;
        this.divProductDetails.Visible = true;
        this.divNoProducts.Style.Add("display", "none");
        this.lblNoProductFound.Text = string.Empty;
      }
      else
      {
        this.dlTurfProducts.DataSource = (object) null;
        this.dlTurfProducts.DataBind();
        this.divProductDetails.Visible = false;
        this.divNoProducts.Style.Add("display", "block");
        this.lblNoProductFound.Text = string.Format(Messages.NoRecordFound, (object) "Turf Product");
        this.divNoProducts.Style.Add("color", UtilityFunctions.SetMessageColor(0));
      }
    }

    protected void BindNonTurfProducts(long NonTurfClassificationID)
    {
      this.ltrTurfZone.Text = PageName.strAddQuantityZone;
      BindDropDown.BindQuantityZoneForShopPage((ListControl) this.ddlTurfZone);
      this.hdnTurfClassificationID.Value = Convert.ToString(NonTurfClassificationID);
      this.hdnTurfType.Value = ((Enums.TurfProductType) 2).ToString();
      this.BindFinalNonTurfProducts(NonTurfClassificationID, Convert.ToInt64(this.ddlTurfZone.SelectedValue));
    }

    protected void BindFinalNonTurfProducts(long NonTurfClassificationID, long TurfZoneID)
    {
      List<NonTurfProductResponseBE> productsForShopPage = NonTurfProductMgmt.GetAllNonTurfProductsForShopPage(NonTurfClassificationID, TurfZoneID, UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
      if (productsForShopPage.Count > 0)
      {
        this.dlNonTurfProducts.DataSource = (object) productsForShopPage;
        this.dlNonTurfProducts.DataBind();
        this.divNonTurfProducts.Visible = true;
        this.divTurfProducts.Visible = false;
        this.divProductDetails.Visible = true;
        this.divNoProducts.Style.Add("display", "none");
        this.lblNoProductFound.Text = string.Empty;
      }
      else
      {
        this.dlNonTurfProducts.DataSource = (object) null;
        this.dlNonTurfProducts.DataBind();
        this.divProductDetails.Visible = false;
        this.divNoProducts.Style.Add("display", "block");
        this.lblNoProductFound.Text = string.Format(Messages.NoRecordFound, (object) "Non-Turf Product");
        this.divNoProducts.Style.Add("color", UtilityFunctions.SetMessageColor(0));
      }
    }

    protected void BindTurfNonTurfClassification()
    {
      List<TurfProductResponse> classificationForDropDown1 = TurfProductMgmt.GetAllTurfClassificationForDropDown();
      if (classificationForDropDown1.Count > 0)
      {
        this.rptTurfClassification.DataSource = (object) classificationForDropDown1;
        this.rptTurfClassification.DataBind();
        this.BindTurfProducts(classificationForDropDown1[0].TurfClassificationID);
      }
      else
      {
        this.divTurfClassification.Visible = false;
        this.rptTurfClassification.DataSource = (object) null;
        this.rptTurfClassification.DataBind();
      }
      List<NonTurfProductResponse> classificationForDropDown2 = NonTurfProductMgmt.GetAllNonTurfClassificationForDropDown();
      if (classificationForDropDown2.Count > 0)
      {
        this.rptNonTurfClassification.DataSource = (object) classificationForDropDown2;
        this.rptNonTurfClassification.DataBind();
        if (classificationForDropDown1.Count == 0)
          this.BindNonTurfProducts(classificationForDropDown2[0].NonTurfClassificationID);
      }
      else
      {
        this.divNonTurfClassification.Visible = false;
        this.rptNonTurfClassification.DataSource = (object) null;
        this.rptNonTurfClassification.DataBind();
      }
      if (classificationForDropDown1.Count != 0 || classificationForDropDown2.Count != 0)
        return;
      this.divMainShopData.Visible = false;
    }

    protected void dlTurfProducts_ItemDataBound(object sender, DataListItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      Literal control1 = (Literal) e.Item.FindControl("ltrDescription");
      control1.Text = control1.Text.Replace("</p>", "");
      control1.Text = control1.Text.Replace("<p>", "");
      HiddenField control2 = (HiddenField) e.Item.FindControl("hdnTurfPageName");
      HiddenField control3 = (HiddenField) e.Item.FindControl("hdnTurfProductID");
      HtmlAnchor control4 = (HtmlAnchor) e.Item.FindControl("aTurfProductLink");
      HiddenField control5 = (HiddenField) e.Item.FindControl("hdnTurfStockStatus");
      HtmlGenericControl control6 = (HtmlGenericControl) e.Item.FindControl("divvmproduct");
      if (control5.Value == "False")
      {
        control4.InnerHtml = "Read More";
        control6.Attributes.Add("class", "vmproduct_box css3 notAvailble");
      }
      control4.HRef = "~/Admin/AdminTurfDescriptionPage.aspx?" + QueryStrings.TurfID + "=" + control2.Value + "$Turf_" + Encryption.EncryptQueryString(this.ddlTurfZone.SelectedValue) + "_" + Encryption.EncryptQueryString(control3.Value);
    }

    protected void InactiveAllTurfClassificationMenus()
    {
      if (this.rptTurfClassification.Items.Count > 0)
      {
        foreach (Control control in this.rptTurfClassification.Items)
          ((WebControl) control.FindControl("lnkTurfName")).Attributes.Add("class", "Inactive");
      }
      if (this.rptNonTurfClassification.Items.Count <= 0)
        return;
      foreach (Control control in this.rptNonTurfClassification.Items)
        ((WebControl) control.FindControl("lnkNonTurfName")).Attributes.Add("class", "Inactive");
    }

    protected void lnkTurfName_Click(object sender, EventArgs e)
    {
      this.InactiveAllTurfClassificationMenus();
      LinkButton linkButton = (LinkButton) sender;
      long int64 = Convert.ToInt64(linkButton.CommandArgument);
      linkButton.Attributes.Add("class", "active");
      this.BindTurfProducts(int64);
    }

    protected void lnkNonTurfName_Click(object sender, EventArgs e)
    {
      this.InactiveAllTurfClassificationMenus();
      LinkButton linkButton = (LinkButton) sender;
      long int64 = Convert.ToInt64(linkButton.CommandArgument);
      linkButton.Attributes.Add("class", "active");
      this.BindNonTurfProducts(int64);
    }

    protected void dlNonTurfProducts_ItemDataBound(object sender, DataListItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      Literal control1 = (Literal) e.Item.FindControl("ltrDescription");
      control1.Text = control1.Text.Replace("</p>", "");
      control1.Text = control1.Text.Replace("<p>", "");
      HiddenField control2 = (HiddenField) e.Item.FindControl("hdnNonTurfPageName");
      HiddenField control3 = (HiddenField) e.Item.FindControl("hdnNonTurfProductID");
      HtmlAnchor control4 = (HtmlAnchor) e.Item.FindControl("aNonTurfProductLink");
      HiddenField control5 = (HiddenField) e.Item.FindControl("hdnNonTurfStockStatus");
      HtmlGenericControl control6 = (HtmlGenericControl) e.Item.FindControl("divvmproduct");
      if (control5.Value == "False")
      {
        control4.InnerHtml = "Read More";
        control6.Attributes.Add("class", "vmproduct_box css3 notAvailble");
      }
      control4.HRef = "~/Admin/AdminTurfDescriptionPage.aspx?" + QueryStrings.TurfID + "=" + control2.Value + "$NonTurf_" + Encryption.EncryptQueryString(this.ddlTurfZone.SelectedValue) + "_" + Encryption.EncryptQueryString(control3.Value);
    }

    protected void rptTurfClassification_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item || e.Item.ItemIndex != 0)
        return;
      ((WebControl) e.Item.FindControl("lnkTurfName")).Attributes.Add("class", "active");
    }

    protected void rptNonTurfClassification_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (this.rptTurfClassification.Items.Count != 0 || e.Item.ItemType != ListItemType.Item || e.Item.ItemIndex != 0)
        return;
      ((WebControl) e.Item.FindControl("lnkNonTurfName")).Attributes.Add("class", "active");
    }

    protected void ddlTurfZone_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.hdnTurfType.Value == ((Enums.TurfProductType) 1).ToString())
      {
        this.BindFinalTurfProducts(Convert.ToInt64(this.hdnTurfClassificationID.Value), Convert.ToInt64(this.ddlTurfZone.SelectedValue));
      }
      else
      {
        if (!(this.hdnTurfType.Value == ((Enums.TurfProductType) 2).ToString()))
          return;
        this.BindFinalNonTurfProducts(Convert.ToInt64(this.hdnTurfClassificationID.Value), Convert.ToInt64(this.ddlTurfZone.SelectedValue));
      }
    }
  }
}
