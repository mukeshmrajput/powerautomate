﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewCommercialPartnerUser
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using Entity.Response.CommercialPartner;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewCommercialPartnerUser : Page
  {
    protected HtmlGenericControl H1Title;
    protected UserManagementSubMenus UserManagementSubMenus1;
    protected RadGrid grdCommercialPartnerApproval;
    protected HtmlTable tableLegend;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liCommercialPartnerUsers");
      if (this.Session["CommercialPartnerApproval"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.UpdateSuccess, (object) PageName.strCommercialPartnerApproval), (Enums.NotificationType) 1), true);
        this.Session["CommercialPartnerApproval"] = (object) null;
      }
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["CommercialPartnerAddUpdate"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["CommercialPartnerAddUpdate"]), (Enums.NotificationType) 1), true);
        this.Session["CommercialPartnerAddUpdate"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<CommercialPartnerResponseBE> partnerResponseBeList = new List<CommercialPartnerResponseBE>();
      List<CommercialPartnerResponseBE> commercialPartnerUsers = CommercialPartnerMgmt.GetAllCommercialPartnerUsers();
      this.grdCommercialPartnerApproval.VirtualItemCount = commercialPartnerUsers.Count<CommercialPartnerResponseBE>();
      ((BaseDataBoundControl) this.grdCommercialPartnerApproval).DataSource = (object) commercialPartnerUsers;
      ((Control) this.grdCommercialPartnerApproval).DataBind();
      if (commercialPartnerUsers.Count<CommercialPartnerResponseBE>() == 0)
        this.grdCommercialPartnerApproval.AllowFilteringByColumn = false;
      ViewCommercialPartnerUser.SetPaggingText(this.grdCommercialPartnerApproval, "Paging");
    }

    protected void grdCommercialPartnerApproval_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdCommercialPartnerApproval.MasterTableView.Items).Count == 0)
      {
        this.grdCommercialPartnerApproval.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdCommercialPartnerApproval.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdCommercialPartnerApproval.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdCommercialPartnerApproval.PagerStyle.AlwaysVisible = true;
      }
      this.grdCommercialPartnerApproval.Rebind();
      ViewCommercialPartnerUser.SetPaggingText(this.grdCommercialPartnerApproval, "Paging");
    }

    protected void grdCommercialPartnerApproval_SortCommand(
      object sender,
      GridSortCommandEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdCommercialPartnerApproval_PageSizeChanged(
      object sender,
      GridPageSizeChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdCommercialPartnerApproval_PageIndexChanged(
      object sender,
      GridPageChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewCommercialPartnerUser.aspx");

    protected void grdCommercialPartnerApproval_ItemCommand(object sender, GridCommandEventArgs e)
    {
      this.BindGrid();
      this.grdCommercialPartnerApproval.Rebind();
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
