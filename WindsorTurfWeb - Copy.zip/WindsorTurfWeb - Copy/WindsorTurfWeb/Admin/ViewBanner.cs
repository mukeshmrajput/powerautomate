﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewBanner
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.BannerManagement;
using Entity.Request.BannerManagement;
using Entity.Response.BannerManagement;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ViewBanner : Page
  {
    public long UserId;
    private BannerRequest objRequest = new BannerRequest();
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HtmlGenericControl H1Title;
    protected HtmlGenericControl DivAdd;
    protected RadGrid grdBanner;
    protected HtmlTable tableLegend;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("LiBannerManagement");
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.IsPostBack)
        return;
      this.BindGrid();
      if (this.Session["AddUpdateBanner"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["AddUpdateBanner"]), (Enums.NotificationType) 1), true);
        this.Session["AddUpdateBanner"] = (object) null;
      }
      if (this.Session["BannerCount"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["BannerCount"]), (Enums.NotificationType) 3), true);
        this.Session["BannerCount"] = (object) null;
      }
    }

    private void BindGrid()
    {
      List<BannerResponse> bannerResponseList = new List<BannerResponse>();
      List<BannerResponse> allBanners = BannerMgmt.GetAllBanners();
      this.grdBanner.VirtualItemCount = allBanners.Count<BannerResponse>();
      ((BaseDataBoundControl) this.grdBanner).DataSource = (object) allBanners;
      ((Control) this.grdBanner).DataBind();
      if (allBanners.Count<BannerResponse>() == 0)
        this.grdBanner.AllowFilteringByColumn = false;
      if (allBanners.Count == 5)
        this.DivAdd.Visible = false;
      else
        this.DivAdd.Visible = true;
      ViewBanner.SetPaggingText(this.grdBanner, "Paging");
    }

    protected void grdBanner_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdBanner.MasterTableView.Items).Count == 0)
      {
        this.grdBanner.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdBanner.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdBanner.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdBanner.PagerStyle.AlwaysVisible = true;
      }
      this.grdBanner.Rebind();
      ViewBanner.SetPaggingText(this.grdBanner, "Paging");
    }

    protected void grdBanner_SortCommand(object sender, GridSortCommandEventArgs e) => this.BindGrid();

    protected void grdBanner_PageSizeChanged(object sender, GridPageSizeChangedEventArgs e) => this.BindGrid();

    protected void grdBanner_PageIndexChanged(object sender, GridPageChangedEventArgs e) => this.BindGrid();

    protected void grdBanner_ItemCommand(object sender, GridCommandEventArgs e)
    {
      if (((CommandEventArgs) e).CommandName == "Delete")
      {
        BannerMgmt.DeleteBanner(Convert.ToInt64(((CommandEventArgs) e).CommandArgument.ToString()), Convert.ToInt64(Convert.ToInt64(this.UserId)), HttpContext.Current.Request.UserHostAddress);
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) "Banner"), (Enums.NotificationType) 1), true);
      }
      this.BindGrid();
      this.grdBanner.Rebind();
    }

    public static string SetDeleteConfirmation() => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) "Banner") + "')";

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewBanner.aspx");

    protected void grdBanner_ItemDataBound(object sender, GridItemEventArgs e)
    {
      if (e.Item.ItemType != 7 && e.Item.ItemType != 1)
        return;
      HtmlAnchor control = (HtmlAnchor) ((Control) e.Item).FindControl("a_view");
      string str = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "BannerImage"));
      if (!string.IsNullOrEmpty(str))
      {
        if (control != null)
        {
          control.HRef = ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["BannerOriginalImagePath"] + str;
          control.InnerHtml = "<img src=\"../Content/Panels/images/image_icon.png\" alt=\"View Image\" title=\"View Image\" style=\"border: none;\" />";
          control.Attributes.Add("class", "highslide");
          control.Attributes.Add("onclick", "return hs.expand(this);");
          control.Style.Add("margin", "5px auto 0 auto");
        }
      }
      else if (control != null)
      {
        control.HRef = "#";
        control.InnerHtml = "-";
        control.Style.Add("margin", "0px 0px 0 14px");
      }
    }

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }
  }
}
