﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.PageManagementEdit
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PageManagement;
using Entity.BaseEntity;
using Entity.Common.PageManagement;
using Entity.Response.PageManagement;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class PageManagementEdit : Page
  {
    public string HeaderOriginalImagePath = ConfigurationManager.AppSettings[nameof (HeaderOriginalImagePath)];
    public string HeaderThumbImagePath = ConfigurationManager.AppSettings[nameof (HeaderThumbImagePath)];
    public string HomePageOriginalImagePath = ConfigurationManager.AppSettings[nameof (HomePageOriginalImagePath)];
    public string HomePageThumbImagePath = ConfigurationManager.AppSettings[nameof (HomePageThumbImagePath)];
    private long PageManagementID = 0;
    public long UserId;
    public string strValidationPageMgmt = "PageMgmtValidation";
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected Literal ltrPageName;
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl divMessage;
    protected Literal ltrMessage;
    protected HtmlGenericControl divFooter;
    protected CheckBox chkIsFooter;
    protected HtmlGenericControl divShowonHomePage;
    protected CheckBox chkShowOnHomePage;
    protected HtmlGenericControl divHomePageImage;
    protected TextBox txtHomePageImage;
    protected FileUpload fldHomePage;
    protected HtmlAnchor lnkHomePageImage;
    protected HtmlAnchor lnkHomePageThumb;
    protected Image ImgHomePageThumb;
    protected Button btnHomePageImageDelete;
    protected RequiredFieldValidator rfvHomePageImage;
    protected HiddenField hdnDivHomePageImage;
    protected HiddenField hdnDivHomePageImageDoc;
    protected HiddenField hdnDivHomePageCancel;
    protected HiddenField hdnHomePageNameImage;
    protected HiddenField hdnHomePageUploadType;
    protected HtmlGenericControl divHomePageDescription;
    protected TextBox txtHomePageDescription;
    protected RequiredFieldValidator rfvHomePageDescription;
    protected RegularExpressionValidator regHomePageDescription;
    protected HtmlGenericControl divParentPage;
    protected DropDownList drpParentPage;
    protected RequiredFieldValidator rfvParenetPage;
    protected TextBox txtPageName;
    protected RequiredFieldValidator rfvPageName;
    protected RegularExpressionValidator regPageName;
    protected TextBox txtLinkURL;
    protected RequiredFieldValidator rfvLinkURL;
    protected RegularExpressionValidator regLinkURL;
    protected HtmlGenericControl divHeaderImage;
    protected TextBox txtimgHeader;
    protected FileUpload fldHeader;
    protected HtmlAnchor lnkHeaderImage;
    protected HtmlAnchor lnkHeaderThumb;
    protected Image ImgThumb;
    protected Button btnHeaderImageDelete;
    protected RequiredFieldValidator rfvHeaderImage;
    protected HiddenField hdnDivHeaderImage;
    protected HiddenField hdnHeaderImageDoc;
    protected HiddenField hdnHeaderImageCancel;
    protected HiddenField hdnHeaderImageName;
    protected HiddenField hdnUploadType;
    protected HiddenField hdnDocName;
    protected HtmlGenericControl divDescription;
    protected RadEditor redBody;
    protected HtmlGenericControl divMetaTags;
    protected TextBox txtPageTitle;
    protected RequiredFieldValidator rfvTitle;
    protected RegularExpressionValidator regTitle;
    protected TextBox txtMetaDescription;
    protected RequiredFieldValidator rfvMetaDescription;
    protected RegularExpressionValidator regMetaDescription;
    protected TextBox txtMetaKeywords;
    protected RequiredFieldValidator rfvMetaKeywords;
    protected RegularExpressionValidator regMetaKeywords;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected Button btnCancel;
    protected HiddenField hdnLinkURL;
    protected HiddenField hdnShowonMenu;
    protected HiddenField hdnDisplayOrder;
    protected HiddenField hdnID;
    protected HiddenField hdnIsStatic;
    protected HiddenField hdnChkHomePageVal;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      if (this.IsPostBack)
        return;
      this.chkIsFooter.Focus();
      this.SetValidations();
      this.FillParentDrp();
      if (!string.IsNullOrEmpty(this.Request.QueryString["PageManagementID"]) && this.Request.QueryString["PageManagementID"].ToString() != "1")
      {
        this.hdnID.Value = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["PageManagementID"])).ToString();
        PageManagementBE pageById = PageManagementMgmt.GetPageByID(Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["PageManagementID"])));
        if (pageById != null)
        {
          if (pageById.IsEditable)
          {
            this.SetValues(pageById);
            this.btnSubmit.Text = "Update";
            this.btnSubmit.ToolTip = "Update";
          }
          else
            this.Response.Redirect("~/Admin/ViewPageManagement.aspx");
        }
      }
      if (this.txtLinkURL.Enabled)
      {
        this.txtPageName.Attributes.Add("onkeyup", "SetLinkURL('1');");
        this.txtLinkURL.Attributes.Add("onkeyup", "SetLinkURL('2');");
      }
    }

    private void FillParentDrp()
    {
      List<ParentPageBE> parentPageBeList = new List<ParentPageBE>();
      List<ParentPageBE> parentPageData = PageManagementMgmt.GetParentPageData();
      if (parentPageData.Count > 0)
      {
        this.drpParentPage.DataSource = (object) parentPageData;
        this.drpParentPage.DataTextField = "PageName";
        this.drpParentPage.DataValueField = "PageManagementID";
        this.drpParentPage.DataBind();
      }
      this.drpParentPage.Items.Insert(0, new ListItem("-Select-", "0"));
    }

    private void SetValues(PageManagementBE objPage)
    {
      this.chkIsFooter.Checked = objPage.ShowOnFooter;
      this.chkShowOnHomePage.Checked = objPage.ShowOnHomePage;
      if (this.chkShowOnHomePage.Checked)
      {
        this.divHomePageImage.Style.Add("display", "block");
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, true, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.divHomePageDescription.Style.Add("display", "block");
        Validations.SetRequiredFieldValidator(this.rfvHomePageDescription, true, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
        Validations.SetRegularExpressionValidator(this.regHomePageDescription, Regex.Description, true, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
        this.txtHomePageDescription.Text = objPage.ShortDescription;
        this.divParentPage.Visible = false;
        this.rfvHomePageImage.Enabled = true;
      }
      else
      {
        this.divHomePageImage.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, false, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.divHomePageDescription.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageDescription, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
        Validations.SetRegularExpressionValidator(this.regHomePageDescription, Regex.Description, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
      }
      if (this.chkIsFooter.Checked)
      {
        this.divHomePageImage.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, false, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.chkShowOnHomePage.Enabled = false;
        this.divHomePageDescription.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageDescription, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
        Validations.SetRegularExpressionValidator(this.regHomePageDescription, Regex.Description, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
        this.divFooter.Style.Add("display", "block");
        this.divParentPage.Style.Add("display", "none");
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, false, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
      else
      {
        this.divFooter.Style.Add("display", "none");
        this.divParentPage.Style.Add("display", "block");
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, true, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
      bool flag;
      if (objPage.ShowOnMenu && objPage.ParentID == 1L)
      {
        HiddenField hdnShowonMenu = this.hdnShowonMenu;
        flag = objPage.ShowOnMenu;
        string str = flag.ToString();
        hdnShowonMenu.Value = str;
        this.divParentPage.Style.Add("display", "none");
      }
      else if (!this.chkIsFooter.Checked && objPage.ParentID > 1L)
      {
        this.divParentPage.Style.Add("display", "block");
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, true, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
      if (objPage.IsStatic && !objPage.ShowOnMenu)
      {
        HiddenField hdnShowonMenu = this.hdnShowonMenu;
        flag = objPage.ShowOnMenu;
        string str1 = flag.ToString();
        hdnShowonMenu.Value = str1;
        HiddenField hdnIsStatic = this.hdnIsStatic;
        flag = objPage.IsStatic;
        string str2 = flag.ToString();
        hdnIsStatic.Value = str2;
      }
      if (objPage.IsStatic && !objPage.ShowDescription)
      {
        this.divHomePageImage.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, false, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.divHomePageDescription.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageDescription, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
        Validations.SetRegularExpressionValidator(this.regHomePageDescription, Regex.Description, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
        this.chkShowOnHomePage.Enabled = false;
        this.chkIsActive.Enabled = false;
        this.divShowonHomePage.Visible = false;
      }
      if (objPage.IsStatic)
      {
        this.divParentPage.Style.Add("display", "none");
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, false, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
        this.chkIsFooter.Enabled = false;
        this.txtLinkURL.Enabled = false;
      }
      if (this.chkShowOnHomePage.Checked)
      {
        this.divParentPage.Style.Add("display", "none");
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, false, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
      if (objPage.LinkUrl == "home" || objPage.ShowOnMenu && objPage.ParentID == 1L)
      {
        this.divHomePageImage.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, false, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.chkShowOnHomePage.Enabled = false;
        this.divShowonHomePage.Visible = false;
        this.divHomePageDescription.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageDescription, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
        Validations.SetRegularExpressionValidator(this.regHomePageDescription, Regex.Description, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
      }
      if (objPage.ShowOnMenu && objPage.ChildCount == 0L && objPage.ParentID > 1L)
      {
        this.chkShowOnHomePage.Enabled = true;
        this.divShowonHomePage.Visible = true;
      }
      if (objPage.ShowOnMenu && objPage.ChildCount > 0L && objPage.ParentID > 1L)
      {
        this.divHomePageImage.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, false, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.chkShowOnHomePage.Enabled = false;
        this.divShowonHomePage.Visible = false;
        this.divHomePageDescription.Style.Add("display", "none");
        Validations.SetRequiredFieldValidator(this.rfvHomePageDescription, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
        Validations.SetRegularExpressionValidator(this.regHomePageDescription, Regex.Description, false, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
      }
      this.drpParentPage.SelectedValue = objPage.ParentID.ToString();
      this.txtPageName.Text = objPage.NameOnMenu;
      this.txtLinkURL.Enabled = objPage.IsEditableLinkURL;
      this.hdnLinkURL.Value = objPage.LinkUrl;
      this.txtLinkURL.Text = objPage.LinkUrl;
      this.hdnDisplayOrder.Value = objPage.DisplayOrder.ToString();
      this.redBody.Content = objPage.Description;
      this.txtPageTitle.Text = objPage.PageTitle;
      this.txtMetaDescription.Text = objPage.MetaDescription;
      this.txtMetaKeywords.Text = objPage.MetaKeyword;
      this.chkIsActive.Checked = objPage.IsActive;
      if (!string.IsNullOrEmpty(objPage.HeaderImage) && objPage.HeaderImage != "none")
      {
        this.hdnHeaderImageDoc.Value = "block";
        this.hdnDivHeaderImage.Value = "none";
        this.hdnHeaderImageCancel.Value = "block";
        this.hdnHeaderImageName.Value = objPage.HeaderImage;
        this.lnkHeaderImage.HRef = ConfigurationManager.AppSettings["LivePath"] + this.HeaderOriginalImagePath + objPage.HeaderImage;
        this.lnkHeaderImage.Target = "_blank";
        this.ImgThumb.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.HeaderOriginalImagePath + objPage.HeaderImage;
        this.lnkHeaderThumb.HRef = ConfigurationManager.AppSettings["LivePath"] + this.HeaderThumbImagePath + objPage.HeaderImage;
        this.lnkHeaderThumb.Visible = true;
        this.rfvHeaderImage.Enabled = false;
      }
      else
      {
        this.hdnHeaderImageDoc.Value = "none";
        this.hdnDivHeaderImage.Value = "block";
        this.hdnHeaderImageCancel.Value = "none";
        this.hdnHeaderImageName.Value = "";
        this.rfvHeaderImage.Enabled = true;
      }
      if (this.chkShowOnHomePage.Checked)
      {
        if (!string.IsNullOrEmpty(objPage.HomePageImage) && objPage.HomePageImage != "none")
        {
          this.hdnDivHomePageImageDoc.Value = "block";
          this.hdnDivHomePageImage.Value = "none";
          this.hdnDivHomePageCancel.Value = "block";
          this.hdnHomePageNameImage.Value = objPage.HomePageImage;
          this.txtHomePageImage.Text = objPage.HomePageImage;
          this.lnkHomePageImage.HRef = ConfigurationManager.AppSettings["LivePath"] + this.HomePageOriginalImagePath + objPage.HomePageImage;
          this.lnkHomePageImage.Target = "_blank";
          this.ImgHomePageThumb.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.HomePageOriginalImagePath + objPage.HomePageImage;
          this.lnkHomePageThumb.HRef = ConfigurationManager.AppSettings["LivePath"] + this.HomePageThumbImagePath + objPage.HomePageImage;
          this.lnkHomePageThumb.Visible = true;
          this.rfvHomePageImage.Enabled = true;
          this.rfvHomePageDescription.Enabled = true;
          this.regHomePageDescription.Enabled = true;
        }
        else
        {
          this.hdnDivHomePageImageDoc.Value = "none";
          this.hdnDivHomePageImage.Value = "block";
          this.hdnDivHomePageCancel.Value = "none";
          this.hdnHomePageNameImage.Value = "";
          this.rfvHomePageImage.Enabled = false;
          this.rfvHomePageDescription.Enabled = false;
          this.regHomePageDescription.Enabled = false;
        }
      }
      if (objPage.ShowDescription)
        this.divDescription.Visible = true;
      else
        this.divDescription.Visible = false;
      if (objPage.ShowHeaderImage)
        this.divHeaderImage.Visible = true;
      else
        this.divHeaderImage.Visible = false;
      if (objPage.ShowMetaTags)
        this.divMetaTags.Visible = true;
      else
        this.divMetaTags.Visible = false;
    }

    private void SetValidations()
    {
      Validations.SetRequiredFieldValidator(this.rfvTitle, true, (object) this.txtPageTitle, this.strValidationPageMgmt);
      Validations.SetRequiredFieldValidator(this.rfvLinkURL, true, (object) this.txtLinkURL, this.strValidationPageMgmt);
      Validations.SetRegularExpressionValidator(this.regPageName, Regex.Title, true, (object) this.txtPageTitle, this.strValidationPageMgmt);
      Validations.SetRegularExpressionValidator(this.regLinkURL, Regex.Title, true, (object) this.txtLinkURL, this.strValidationPageMgmt);
      Validations.SetRequiredFieldValidator(this.rfvPageName, true, (object) this.txtPageName, this.strValidationPageMgmt);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, true, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      Validations.SetRegularExpressionValidator(this.regTitle, Regex.Title, true, (object) this.txtPageTitle, this.strValidationPageMgmt);
      Validations.SetRequiredFieldValidator(this.rfvHomePageDescription, true, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
      Validations.SetRegularExpressionValidator(this.regHomePageDescription, Regex.MetaKeyword, true, (object) this.txtHomePageDescription, this.strValidationPageMgmt);
      Validations.SetRequiredFieldValidator(this.rfvMetaDescription, true, (object) this.txtMetaDescription, this.strValidationPageMgmt);
      Validations.SetRegularExpressionValidator(this.regMetaDescription, Regex.MetaKeyword, true, (object) this.txtMetaDescription, this.strValidationPageMgmt);
      Validations.SetRequiredFieldValidator(this.rfvMetaKeywords, true, (object) this.txtMetaKeywords, this.strValidationPageMgmt);
      Validations.SetRegularExpressionValidator(this.regMetaKeywords, Regex.MetaKeyword, true, (object) this.txtMetaKeywords, this.strValidationPageMgmt);
      Validations.SetRequiredFieldValidator(this.rfvHeaderImage, true, (object) this.txtimgHeader, this.strValidationPageMgmt);
      Validations.SetRequiredFieldValidator(this.rfvHomePageImage, false, (object) this.txtHomePageImage, this.strValidationPageMgmt);
      this.fldHeader.Attributes.Add("OnChange", "return UploadFileSelect('" + this.fldHeader.ClientID + "','" + this.txtimgHeader.ClientID + "', this, 'Page Management');");
      this.fldHomePage.Attributes.Add("OnChange", "return UploadFileHomePageSelect('" + this.fldHomePage.ClientID + "','" + this.txtHomePageImage.ClientID + "', this, 'Page Management');");
      this.btnSubmit.ValidationGroup = this.strValidationPageMgmt;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      Entity.Response.Response response = new Entity.Response.Response();
      PageManagementBE objPage = new PageManagementBE();
      this.FillEntityData(objPage);
      switch ((string.IsNullOrEmpty(this.Request.QueryString["PageManagementID"]) ? (BaseResponseEntity<Entity.Response.Response>) PageManagementMgmt.AddPageManagementDetails(objPage) : (BaseResponseEntity<Entity.Response.Response>) PageManagementMgmt.UpdatePageDetails(objPage)).ResponseType - -1)
      {
        case 0:
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists, (object) "Page Name"), (Enums.NotificationType) -1), true);
          break;
        case 1:
          this.divMessage.Visible = true;
          this.ltrMessage.Text = string.Format(Messages.RecordUpdateFail, (object) "Page");
          this.divMessage.Style.Add("color", UtilityFunctions.SetMessageColor(0));
          break;
        case 2:
          this.Session["PageManagementAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) "Page");
          this.Session["fldHeader"] = (object) null;
          this.Session["fldHomePage"] = (object) null;
          this.Response.Redirect("~/Admin/ViewPageManagement.aspx");
          break;
        case 3:
          this.Session["PageManagementAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) "Page");
          this.Session["fldHeader"] = (object) null;
          this.Session["fldHomePage"] = (object) null;
          this.Response.Redirect("~/Admin/ViewPageManagement.aspx");
          break;
      }
    }

    public void FillEntityData(PageManagementBE objPage)
    {
      objPage.ShowOnFooter = this.chkIsFooter.Checked;
      if (!string.IsNullOrEmpty(this.hdnChkHomePageVal.Value))
        this.chkShowOnHomePage.Checked = Convert.ToBoolean(this.hdnChkHomePageVal.Value);
      if (this.chkIsFooter.Checked)
        objPage.ParentID = 1L;
      else if (this.chkShowOnHomePage.Checked)
      {
        objPage.ParentID = 1L;
        objPage.ShortDescription = this.txtHomePageDescription.Text;
      }
      else
        objPage.ParentID = !Convert.ToBoolean(this.hdnShowonMenu.Value) ? Convert.ToInt64(this.drpParentPage.SelectedValue.ToString()) : 1L;
      if (objPage.ParentID == 0L)
        objPage.ParentID = 1L;
      objPage.NameOnMenu = this.txtPageName.Text.Trim();
      int num = objPage.ParentID <= 0L ? 0 : (!this.chkIsFooter.Checked ? 1 : 0);
      objPage.ShowOnMenu = num != 0;
      if (Convert.ToBoolean(this.hdnIsStatic.Value) && !Convert.ToBoolean(this.hdnShowonMenu.Value))
        objPage.ShowOnMenu = false;
      objPage.ShowOnHomePage = this.chkShowOnHomePage.Checked;
      if (this.chkShowOnHomePage.Checked)
        objPage.ShowOnMenu = false;
      objPage.Description = this.redBody.Content;
      objPage.MetaKeyword = this.txtMetaKeywords.Text.Trim();
      objPage.MetaDescription = this.txtMetaDescription.Text.Trim();
      objPage.PageTitle = this.txtPageTitle.Text.Trim();
      objPage.LinkUrl = this.txtLinkURL.Text.Trim();
      objPage.IsActive = this.chkIsActive.Checked;
      if (string.IsNullOrEmpty(this.Request.QueryString["PageManagementID"]))
      {
        objPage.PageManagementID = 0L;
        objPage.IsEditableLinkURL = true;
        objPage.IsEditable = true;
        objPage.IsSubPage = true;
        objPage.ShowDescription = true;
        objPage.ShowHeaderImage = true;
        objPage.ShowMetaTags = true;
        objPage.CreatedBy = Convert.ToInt64(this.UserId);
        objPage.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      }
      else
      {
        objPage.PageManagementID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["PageManagementID"]));
        objPage.IsEditableLinkURL = this.txtLinkURL.Enabled;
        objPage.IsEditable = true;
        objPage.IsSubPage = true;
        objPage.ShowDescription = this.divDescription.Visible;
        objPage.ShowHeaderImage = this.divHeaderImage.Visible;
        objPage.ShowMetaTags = this.divMetaTags.Visible;
        objPage.ModifiedBy = Convert.ToInt64(this.UserId);
        objPage.UpdatedByIP = HttpContext.Current.Request.UserHostAddress;
      }
      string FileName1 = string.Empty;
      FileUpload fileUpload1 = new FileUpload();
      FileUpload fldHeader = this.fldHeader;
      if (!string.IsNullOrEmpty(fldHeader.FileName))
      {
        if (fldHeader.FileName.Length > 0)
        {
          string[] strArray = fldHeader.FileName.Split('\\');
          FileName1 = UtilityFunctions.ChangeFileName(strArray[strArray.Length - 1].ToString());
          string extension = Path.GetExtension(fldHeader.FileName);
          if (extension == ".jpeg" || extension == ".JPEG" || extension == ".png" || extension == ".PNG" || extension == ".jpg" || extension == ".JPG" || extension == ".bmp" || extension == ".BMP" || extension == ".gif" || extension == ".GIF")
          {
            fldHeader.SaveAs(this.Server.MapPath("~/") + this.HeaderOriginalImagePath + FileName1);
            Resizer.FixedSize(FileName1, fldHeader, this.HeaderThumbImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["HeaderThumbImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["HeaderThumbImageHeight"]));
          }
          else
            fldHeader.SaveAs(this.Server.MapPath("~/") + this.HeaderOriginalImagePath + FileName1);
          objPage.HeaderImage = FileName1;
          if (!string.IsNullOrEmpty(this.hdnHeaderImageName.Value))
          {
            FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.HeaderOriginalImagePath + this.hdnHeaderImageName.Value);
            if (fileInfo.Exists)
              fileInfo.Delete();
          }
        }
      }
      else
        objPage.HeaderImage = this.hdnHeaderImageName.Value;
      string empty = string.Empty;
      FileUpload fileUpload2 = new FileUpload();
      FileUpload fldHomePage = this.fldHomePage;
      if (!string.IsNullOrEmpty(fldHomePage.FileName))
      {
        if (fldHomePage.FileName.Length <= 0)
          return;
        UtilityFunctions.CreateDirectory(this.Server.MapPath("~/") + this.HomePageOriginalImagePath);
        UtilityFunctions.CreateDirectory(this.Server.MapPath("~/") + this.HomePageThumbImagePath);
        string[] strArray = fldHomePage.FileName.Split('\\');
        string FileName2 = UtilityFunctions.ChangeFileName(strArray[strArray.Length - 1].ToString());
        string extension = Path.GetExtension(fldHomePage.FileName);
        if (extension == ".jpeg" || extension == ".JPEG" || extension == ".png" || extension == ".PNG" || extension == ".jpg" || extension == ".JPG" || extension == ".bmp" || extension == ".BMP" || extension == ".gif" || extension == ".GIF")
        {
          fldHomePage.SaveAs(this.Server.MapPath("~/") + this.HomePageOriginalImagePath + FileName2);
          Resizer.FixedSize(FileName2, fldHomePage, this.HomePageThumbImagePath, Convert.ToInt32(ConfigurationManager.AppSettings["HomePageThumbImageWidth"]), Convert.ToInt32(ConfigurationManager.AppSettings["HomePageThumbImageHeight"]));
        }
        else
          fldHomePage.SaveAs(this.Server.MapPath("~/") + this.HomePageOriginalImagePath + FileName1);
        objPage.HomePageImage = FileName2;
        if (!string.IsNullOrEmpty(this.hdnHomePageNameImage.Value))
        {
          FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.HomePageOriginalImagePath + this.hdnHomePageNameImage.Value);
          if (fileInfo.Exists)
            fileInfo.Delete();
        }
      }
      else
        objPage.HomePageImage = this.hdnHomePageNameImage.Value;
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewPageManagement.aspx");

    protected void btnHeaderImageDelete_Click(object sender, EventArgs e)
    {
      PageManagementMgmt.DeleteHeaderImageById(Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["PageManagementID"])));
      FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.HeaderOriginalImagePath + this.hdnHeaderImageName.Value);
      if (fileInfo.Exists)
        fileInfo.Delete();
      this.hdnHeaderImageDoc.Value = "none";
      this.hdnDivHeaderImage.Value = "block";
      this.hdnHeaderImageCancel.Value = "none";
      this.hdnHeaderImageName.Value = "none";
      this.fldHeader.Dispose();
      this.rfvHeaderImage.Enabled = true;
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) Messages.HeaderImage), (Enums.NotificationType) 1), true);
    }

    private bool ImageValidationMessage()
    {
      string lower = this.fldHeader.FileName.Substring(this.fldHeader.FileName.LastIndexOf(".") + 1).ToLower();
      if (Regex.UploadImage.Contains(lower) && !string.IsNullOrEmpty(lower))
      {
        if (this.fldHeader.FileContent.Length > 2097152L)
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.Imagemsg, (object) "Header Image"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      else
      {
        if (string.IsNullOrEmpty(lower) && string.IsNullOrEmpty(this.hdnHeaderImageName.Value))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.Imagemsg, (object) "Header Image"), (Enums.NotificationType) 2, false), true);
          return false;
        }
        if (!string.IsNullOrEmpty(lower))
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.Imagemsg, (object) "Header Image"), (Enums.NotificationType) 2, false), true);
          return false;
        }
      }
      return true;
    }

    protected void chkIsFooter_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkIsFooter.Checked)
      {
        this.divHomePageImage.Visible = false;
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, false, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.chkShowOnHomePage.Enabled = false;
        this.chkShowOnHomePage.Checked = false;
        this.divShowonHomePage.Visible = false;
      }
      else
      {
        this.divHomePageImage.Visible = true;
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, true, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.chkShowOnHomePage.Enabled = true;
        this.divShowonHomePage.Visible = true;
        this.chkShowOnHomePage.Checked = false;
      }
      if (this.chkShowOnHomePage.Checked)
      {
        this.divHomePageImage.Visible = true;
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, true, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.divParentPage.Visible = false;
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, false, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
      else
      {
        this.divHomePageImage.Visible = false;
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, false, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.divParentPage.Visible = true;
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, true, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
      if (this.chkIsFooter.Checked)
      {
        this.divParentPage.Visible = false;
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, false, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
      else
      {
        this.divParentPage.Visible = true;
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, true, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
    }

    protected void chkShowOnHomePage_CheckedChanged(object sender, EventArgs e)
    {
      if (this.chkShowOnHomePage.Checked)
      {
        this.divHomePageImage.Visible = true;
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, true, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.divParentPage.Visible = false;
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, false, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
      else
      {
        this.divHomePageImage.Visible = false;
        Validations.SetRequiredFieldValidator(this.rfvHomePageImage, false, (object) this.txtHomePageImage, this.strValidationPageMgmt);
        this.divParentPage.Visible = true;
        Validations.SetRequiredFieldValidatorDropdown(this.rfvParenetPage, true, (object) this.drpParentPage, "0", this.strValidationPageMgmt);
      }
    }

    protected void btnHomePageImageDelete_Click(object sender, EventArgs e)
    {
      PageManagementMgmt.DeleteHomePageImageById(Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["PageManagementID"])));
      FileInfo fileInfo = new FileInfo(this.Server.MapPath("~/") + this.HomePageOriginalImagePath + this.hdnHomePageNameImage.Value);
      if (fileInfo.Exists)
        fileInfo.Delete();
      this.hdnDivHomePageImageDoc.Value = "none";
      this.hdnDivHomePageImage.Value = "block";
      this.hdnDivHomePageCancel.Value = "none";
      this.hdnHomePageNameImage.Value = "none";
      this.fldHomePage.Dispose();
      this.rfvHomePageImage.Enabled = true;
      System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.DeleteSuccessSingleItem, (object) Messages.HomePageImage), (Enums.NotificationType) 1), true);
    }
  }
}
