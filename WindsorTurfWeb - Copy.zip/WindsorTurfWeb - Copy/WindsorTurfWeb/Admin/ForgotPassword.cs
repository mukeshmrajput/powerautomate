﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ForgotPassword
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.UserManagement;
using Entity.Response.UserManagement;
using Helper;
using Resources;
using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class ForgotPassword : Page
  {
    public string strForgetPasswordValidation = "ForgetPasswordValidation";
    protected HtmlHead Head1;
    protected HtmlForm form1;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl dvDefaultMsg;
    protected Literal ltrDefaultMsg;
    protected HtmlGenericControl divResponseStatus;
    protected Literal ltrResponseStatus;
    protected HtmlGenericControl dvEmailInputs;
    protected Literal ltrEmailTitle;
    protected TextBox txtUserName;
    protected RequiredFieldValidator reqUserName;
    protected RegularExpressionValidator regUserName;
    protected HtmlGenericControl dvButtons;
    protected Button btnSend;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Title = UtilityFunctions.AdminPageTitle("Login");
      this.Page.Form.DefaultButton = this.btnSend.UniqueID;
      this.Page.Form.DefaultFocus = this.txtUserName.UniqueID;
      if (this.Request.QueryString["Username"] != null)
        this.txtUserName.Text = this.Request.QueryString["Username"].ToString();
      else
        this.txtUserName.Focus();
      if (!this.IsPostBack)
      {
        this.ValidationIntialization();
        this.ltrResponseStatus.Text = "&nbsp;";
      }
      this.ltrDefaultMsg.Text = Messages.DefaultText;
      this.h1Title.InnerText = "Forgot Password?";
      this.ltrEmailTitle.Text = HTMLControlText.Email;
    }

    private void ValidationIntialization()
    {
      Validations.SetRequiredFieldValidator(this.reqUserName, true, (object) this.txtUserName, this.strForgetPasswordValidation);
      Validations.SetRegularExpressionValidator(this.regUserName, Regex.Email, true, (object) this.txtUserName, this.strForgetPasswordValidation);
      this.btnSend.ValidationGroup = this.strForgetPasswordValidation;
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      UserResponseBE credentialsByEmail = UserMgmt.GetCredentialsByEmail(this.txtUserName.Text.Trim(), (long) Convert.ToInt32((object) (Enums.UserType) 1));
      if (credentialsByEmail.Email != null)
      {
        Mail.ForgotPassword(credentialsByEmail.Email, credentialsByEmail.UserName, credentialsByEmail.Password, credentialsByEmail.UserID);
        this.dvEmailInputs.Visible = this.dvButtons.Visible = this.dvDefaultMsg.Visible = false;
        this.ltrResponseStatus.Text = "<div class=\"successcolor fld pdt8per\">" + string.Format(Messages.EmailSentSuccess, (object) ("<div class=\"fntbold\">" + this.txtUserName.Text.Trim() + "</div>")) + "</div>";
        this.divResponseStatus.Visible = true;
      }
      else
      {
        this.ltrResponseStatus.Text = "<div class=\"failurecolor fld\">" + string.Format(Messages.NoEmailFound, (object) ("<div class=\"fntbold\">" + this.txtUserName.Text.Trim() + "</div>")) + "</div>";
        this.divResponseStatus.Visible = true;
      }
    }
  }
}
