﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateQuantityPricing
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.NonTurfProductPricing.QuantityPricing;
using Entity.Common.ProductPricing.NonTurfProductPricing.QuantityPricing;
using Entity.Response.ProductPricing.NonTurfProductPricing.QuantityPricing;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateQuantityPricing : Page
  {
    public static long fQuantityPriceID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected DropDownList ddlNonTurfProduct;
    protected RequiredFieldValidator rfvNonTurfProduct;
    protected DropDownList ddlQuantityZone;
    protected RequiredFieldValidator rfvQuantityZone;
    protected DropDownList ddlQuantityRange;
    protected RequiredFieldValidator rfvQuantityRange;
    protected TextBox txtRetailPrice;
    protected RequiredFieldValidator rfvRetailPrice;
    protected RegularExpressionValidator regRetailPrice;
    protected TextBox txtTradePrice;
    protected RequiredFieldValidator rfvTradePrice;
    protected RegularExpressionValidator regTradePrice;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnQuantityPriceID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewQuantityPrice");
      if (this.Request.QueryString[QueryStrings.QuantityPriceID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strAddQuantityPrice;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        AddUpdateQuantityPricing.fQuantityPriceID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.QuantityPriceID].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddQuantityPrice;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateQuantityPricing.fQuantityPriceID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.BindDropdown();
        this.ValidationExpression();
        if (AddUpdateQuantityPricing.fQuantityPriceID > 0L)
          this.GetQuantityPricingDetails(QuantityPriceMgmt.GetQuantityRangeDetailByID(Convert.ToInt64(AddUpdateQuantityPricing.fQuantityPriceID)));
      }
      this.ddlNonTurfProduct.Focus();
    }

    protected void GetQuantityPricingDetails(QuantityPriceResponseBE objQuantityPriceResponse)
    {
      this.ddlNonTurfProduct.SelectedValue = Convert.ToString(objQuantityPriceResponse.NonTurfProductID);
      this.ddlQuantityRange.SelectedValue = Convert.ToString(objQuantityPriceResponse.QuantityRangeID);
      this.ddlQuantityZone.SelectedValue = Convert.ToString(objQuantityPriceResponse.QuantityZoneID);
      this.txtRetailPrice.Text = Convert.ToString(objQuantityPriceResponse.RetailPrice);
      this.txtTradePrice.Text = Convert.ToString(objQuantityPriceResponse.TradePrice);
      this.chkIsActive.Checked = Convert.ToBoolean(objQuantityPriceResponse.IsActive);
    }

    protected void BindDropdown()
    {
      BindDropDown.BindNonTurfProduct((ListControl) this.ddlNonTurfProduct);
      BindDropDown.BindQuantityZone((ListControl) this.ddlQuantityZone);
      BindDropDown.BindQuantityRange((ListControl) this.ddlQuantityRange);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      QuantityPriceBE quantityPriceBe = new QuantityPriceBE();
      quantityPriceBe.QuantityPriceID = AddUpdateQuantityPricing.fQuantityPriceID <= 0L ? 0L : AddUpdateQuantityPricing.fQuantityPriceID;
      quantityPriceBe.NonTurfProductID = Convert.ToInt64(this.ddlNonTurfProduct.SelectedValue);
      quantityPriceBe.QuantityZoneID = Convert.ToInt64(this.ddlQuantityZone.SelectedValue);
      quantityPriceBe.QuantityRangeID = Convert.ToInt64(this.ddlQuantityRange.SelectedValue);
      quantityPriceBe.RetailPrice = Convert.ToDecimal(this.txtRetailPrice.Text.Trim());
      quantityPriceBe.TradePrice = Convert.ToDecimal(this.txtTradePrice.Text.Trim());
      quantityPriceBe.IsActive = this.chkIsActive.Checked;
      quantityPriceBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      quantityPriceBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      if (QuantityPriceMgmt.AddUpdateQuantityPrice(quantityPriceBe) > 0L)
      {
        if (quantityPriceBe.QuantityPriceID > 0L)
          this.Session["QuantityPriceAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddQuantityPrice);
        else if (quantityPriceBe.QuantityPriceID == 0L)
          this.Session["QuantityPriceAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddQuantityPrice);
        this.Response.Redirect("~/Admin/ViewQuantityPricing.aspx");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.NonTurfExists.ToString()), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorDropdown(this.rfvQuantityZone, true, (object) this.ddlQuantityZone, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvQuantityRange, true, (object) this.ddlQuantityRange, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvNonTurfProduct, true, (object) this.ddlNonTurfProduct, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvRetailPrice, true, (object) this.txtRetailPrice, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regRetailPrice, Regex.NumbersWithDotOnly, true, (object) this.txtRetailPrice, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTradePrice, true, (object) this.txtTradePrice, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTradePrice, Regex.NumbersWithDotOnly, true, (object) this.txtTradePrice, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
