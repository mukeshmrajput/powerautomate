﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewUpdateOrderProcessingPurchaseDetailsPopUp
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Common;
using BLL.PaymentOptions.PaymentType;
using BLL.PurchaseOrderDetail;
using Entity.Common.PurchaseOrderDetail;
using Entity.Common.Response;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class ViewUpdateOrderProcessingPurchaseDetailsPopUp : Page
  {
    private long RetailPurchaseOrderID;
    private long PurchaseOrderId;
    private string TransactionId;
    public static int productQty = 0;
    public string strValidationUserGrp = "ValGrpCommercial";
    public string CardImagePath = ConfigurationManager.AppSettings[nameof (CardImagePath)];
    public string CompletedOrderedPickUpInvoicePath = ConfigurationManager.AppSettings[nameof (CompletedOrderedPickUpInvoicePath)];
    public string CompletedOrderedDeliveryInvoicePath = ConfigurationManager.AppSettings[nameof (CompletedOrderedDeliveryInvoicePath)];
    protected HtmlHead Head1;
    protected HtmlForm form1;
    protected System.Web.UI.ScriptManager scrpt1;
    protected HtmlGenericControl divBtnPrintOrder;
    protected LinkButton btnPrintOrder;
    protected HiddenField hdnStaticMapLat;
    protected HiddenField hdnStaticMapLng;
    protected HiddenField hdnAddress;
    protected HiddenField hdnIsDashFlag;
    protected HtmlGenericControl divGetAllDetails;
    protected HtmlGenericControl h1Title;
    protected Literal ltrOrderNo;
    protected Literal ltrOriginatorID;
    protected Literal ltrName;
    protected Literal ltrEmail;
    protected Literal ltrPaymentTypeName;
    protected Literal ltrGrandTotal;
    protected Literal ltrPaidDate;
    protected HtmlGenericControl divExpectedDeliveryDate;
    protected Literal ltrDeliveryDate;
    protected HtmlGenericControl divExpectedDeliveryDateTextbox;
    protected RadDatePicker radDeliveryDate;
    protected HtmlGenericControl divPickUpDate;
    protected Literal ltrPickupDate;
    protected HtmlGenericControl divPickUpDateTextbox;
    protected RadDatePicker radPickupDate;
    protected HtmlGenericControl divPickUpAt;
    protected Literal ltrPickUpAt;
    protected HtmlGenericControl divDeliveryInstructions;
    protected Literal ltrDeliveryInstructions;
    protected Literal ltrSubmittedDate;
    protected Literal ltrOrderBy;
    protected Literal ltrUserTypeName;
    protected Literal ltrHearAboutUs;
    protected Literal ltrDeliveryRegionName;
    protected Literal ltrIsOrderUnderCompany;
    protected Literal ltrNote;
    protected HtmlGenericControl DivPaymentMethod;
    protected RadioButtonList rdbPaymentMethod;
    protected HtmlGenericControl Divcoddeposite;
    protected RadioButtonList rdbcoddeposite;
    protected HtmlGenericControl DivOrderDelivery;
    protected RadioButtonList rdbOrderDelivery;
    protected HtmlGenericControl DivOrderPickup;
    protected RadioButtonList rdbOrderPickup;
    protected HtmlGenericControl DivFinalStatus;
    protected Literal lblFinalStatus;
    protected HtmlGenericControl divCreditcarddetail;
    protected RadioButtonList rdlCardType;
    protected DropDownList ddlCardType;
    protected TextBox txtCardOwnerName;
    protected RequiredFieldValidator rfvCardOwnerName;
    protected RegularExpressionValidator regCardOwnerName;
    protected TextBox txtCardNo;
    protected RequiredFieldValidator rfvCardNo;
    protected CustomValidator ccNumCustVal;
    protected TextBox txtCVV;
    protected RequiredFieldValidator rfvCVV;
    protected DropDownList ddlExpireMonth;
    protected RequiredFieldValidator rfvExpireMonth;
    protected DropDownList ddlExpireYear;
    protected RequiredFieldValidator rfvExpireYear;
    protected Label txtAmoutInAud;
    protected HtmlGenericControl divBilling;
    protected Literal ltrBillingBusinessName;
    protected Literal ltrBillingABN;
    protected Literal ltrBillingAddressLine1;
    protected Literal ltrBillingAddressLine2;
    protected Literal ltrBillingSuburb;
    protected Literal lblBillingContactNumber;
    protected Literal ltrBillingStateName;
    protected Literal ltrBillingPostCode;
    protected HtmlGenericControl divShipping;
    protected Literal ltrShippingBusinessName;
    protected Literal ltrShippingABN;
    protected Literal ltrShippingAddressLine1;
    protected Literal ltrShippingAddressLine2;
    protected Literal ltrShippingSuburb;
    protected Literal lblShippingContactNumber;
    protected Literal ltrShippingStateName;
    protected Literal ltrShippingPostCode;
    protected HtmlGenericControl divAddress;
    protected Literal ltrBusinessName;
    protected Literal ltrABN;
    protected Literal ltrAddressLine1;
    protected Literal ltrAddressLine2;
    protected Literal ltrSuburb;
    protected Literal ltrContactNumber;
    protected Literal ltrStateName;
    protected Literal ltrPostCode;
    protected HtmlGenericControl divMapDeliveryAddress;
    protected HtmlGenericControl divDeliveryGoogleMap;
    protected HtmlGenericControl divGoogleMapImage;
    protected HtmlImage imgMap;
    protected HtmlGenericControl DivCreditCard;
    protected Literal ltrCardHolderName;
    protected Literal ltrCreditCardNo;
    protected Literal ltrExpiryDate;
    protected HtmlGenericControl Divrpt;
    protected Repeater rptProductDetail;
    protected HtmlGenericControl DivbtnPaymentUpdate;
    protected Button btnContinue;
    protected HtmlGenericControl DivbtnUpdate;
    protected Button btnUpdate;
    protected HiddenField hdnPickUpDetailID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      this.Page.Header.DataBind();
      if (this.Request.QueryString[QueryStrings.RetailPurchaseOrderID] != null)
        this.RetailPurchaseOrderID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.RetailPurchaseOrderID].ToString()));
      if (this.Request.QueryString[QueryStrings.IsDash] != null)
      {
        this.hdnIsDashFlag.Value = Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.IsDash].ToString());
        this.divBtnPrintOrder.Visible = true;
      }
      if (this.IsPostBack)
        return;
      if (this.RetailPurchaseOrderID > 0L)
        this.FillAllData(PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(this.RetailPurchaseOrderID));
      this.ValidationExpression();
      this.BindDropDown();
    }

    protected void FillAllData(PurchaseOrderDetailBE obj)
    {
      if (obj == null)
        return;
      this.ltrDeliveryInstructions.Text = !string.IsNullOrEmpty(obj.DeliveryInstructions) ? obj.DeliveryInstructions : "N/A";
      this.ltrDeliveryRegionName.Text = !string.IsNullOrEmpty(obj.DeliveryRegionName) ? obj.DeliveryRegionName : "N/A";
      if (obj.PickUpAtID != 0)
      {
        this.divPickUpAt.Visible = true;
        this.ltrPickUpAt.Text = obj.PickUpAtID == 1 ? "Morning" : "Afternoon";
      }
      this.txtAmoutInAud.Text = obj.GrandTotal.ToString();
      this.ltrName.Text = obj.Name;
      this.ltrOrderNo.Text = obj.OrderNostr;
      this.ltrEmail.Text = obj.EmailAddress;
      this.ltrNote.Text = !string.IsNullOrEmpty(obj.Note) ? obj.Note : "N/A";
      this.ltrOrderBy.Text = !string.IsNullOrEmpty(obj.OrderBy) ? obj.OrderBy : obj.Name;
      if (obj.UserTypeID == (long) Convert.ToInt32((object) (Enums.UserType) 6))
        this.ltrOriginatorID.Text = "RC" + Convert.ToString(obj.OrderNo);
      else if (obj.UserTypeID == (long) Convert.ToInt32((object) (Enums.UserType) 4))
        this.ltrOriginatorID.Text = "CP" + Convert.ToString(obj.OrderNo);
      else if (obj.UserTypeID == (long) Convert.ToInt32((object) (Enums.UserType) 5))
        this.ltrOriginatorID.Text = "CC" + Convert.ToString(obj.OrderNo);
      DateTime dateTime;
      if (obj.PaymentStatus == 1)
      {
        Literal ltrPaidDate = this.ltrPaidDate;
        string str;
        if (!(obj.PaidDate != DateTime.MinValue))
        {
          str = "N/A";
        }
        else
        {
          dateTime = Convert.ToDateTime(obj.PaidDate);
          str = dateTime.ToString("dd/MM/yyyy");
        }
        ltrPaidDate.Text = str;
      }
      else
        this.ltrPaidDate.Text = "N/A";
      this.ltrGrandTotal.Text = obj.GrandTotal.ToString();
      Literal ltrDeliveryDate = this.ltrDeliveryDate;
      DateTime? nullable = obj.DeliveryDate;
      dateTime = DateTime.MinValue;
      string str1;
      if ((nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != dateTime ? 1 : 0) : 0) : 1) == 0)
      {
        str1 = "N/A";
      }
      else
      {
        dateTime = Convert.ToDateTime((object) obj.DeliveryDate);
        str1 = dateTime.ToString("dd/MM/yyyy");
      }
      ltrDeliveryDate.Text = str1;
      Literal ltrPickupDate = this.ltrPickupDate;
      nullable = obj.PickupDate;
      dateTime = DateTime.MinValue;
      string str2;
      if ((nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != dateTime ? 1 : 0) : 0) : 1) == 0)
      {
        str2 = "N/A";
      }
      else
      {
        dateTime = Convert.ToDateTime((object) obj.PickupDate);
        str2 = dateTime.ToString("dd/MM/yyyy");
      }
      ltrPickupDate.Text = str2;
      Literal ltrSubmittedDate = this.ltrSubmittedDate;
      dateTime = obj.SubmittedDate;
      string str3 = dateTime.ToString("dd/MM/yyyy");
      ltrSubmittedDate.Text = str3;
      this.ltrUserTypeName.Text = obj.UserTypeName;
      if (obj.objUserCreditCardMaster.CreditCardNo != "")
        this.ltrCreditCardNo.Text = "XXXX-XXXX-XXXX-" + obj.objUserCreditCardMaster.CreditCardNo.ToString().Substring(obj.objUserCreditCardMaster.CreditCardNo.ToString().Length - 4, 4);
      Literal ltrExpiryDate = this.ltrExpiryDate;
      int num = obj.objUserCreditCardMaster.ExpiryMonth;
      string str4 = num.ToString();
      num = obj.objUserCreditCardMaster.ExpiryYear;
      string str5 = num.ToString();
      string str6 = str4 + "/" + str5;
      ltrExpiryDate.Text = str6;
      this.ltrBillingABN.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingCompanyABN) ? obj.objBillingResponse.BillingCompanyABN : "N/A";
      this.ltrBillingBusinessName.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingBusinessName) ? obj.objBillingResponse.BillingBusinessName : "N/A";
      this.ltrBillingAddressLine1.Text = obj.objBillingResponse.BillingAddressLine1;
      this.ltrBillingAddressLine2.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingAddressLine2) ? obj.objBillingResponse.BillingAddressLine2 : "N/A";
      this.ltrBillingSuburb.Text = obj.objBillingResponse.BillingSuburb;
      this.ltrBillingStateName.Text = obj.objBillingResponse.BillingStateName;
      Literal ltrBillingPostCode = this.ltrBillingPostCode;
      num = obj.objBillingResponse.BillingPostcode;
      string str7 = num.ToString();
      ltrBillingPostCode.Text = str7;
      this.lblBillingContactNumber.Text = obj.objBillingResponse.BillingHomePhone;
      this.ltrHearAboutUs.Text = obj.HearAboutUsName;
      this.ltrPaymentTypeName.Text = obj.PaymentTypeName;
      this.ltrCardHolderName.Text = obj.objUserCreditCardMaster.CardHolderName;
      this.ltrShippingABN.Text = !string.IsNullOrEmpty(obj.objBillingResponse.ShippingCompanyABN) ? obj.objBillingResponse.ShippingCompanyABN : "N/A";
      this.ltrShippingBusinessName.Text = !string.IsNullOrEmpty(obj.objBillingResponse.ShippingBusinessName) ? obj.objBillingResponse.ShippingBusinessName : "N/A";
      this.ltrShippingAddressLine1.Text = !string.IsNullOrEmpty(obj.objBillingResponse.ShippingAddressLine1) ? obj.objBillingResponse.ShippingAddressLine1 : "N/A";
      this.ltrShippingAddressLine2.Text = !string.IsNullOrEmpty(obj.objBillingResponse.ShippingAddressLine2) ? obj.objBillingResponse.ShippingAddressLine2 : "N/A";
      this.ltrShippingSuburb.Text = !string.IsNullOrEmpty(obj.objBillingResponse.ShippingSuburb) ? obj.objBillingResponse.ShippingSuburb : "N/A";
      Literal shippingPostCode = this.ltrShippingPostCode;
      num = obj.objBillingResponse.ShippingPostcode;
      string str8;
      if (string.IsNullOrEmpty(num.ToString()))
      {
        str8 = "N/A";
      }
      else
      {
        num = obj.objBillingResponse.ShippingPostcode;
        str8 = num.ToString();
      }
      shippingPostCode.Text = str8;
      this.ltrShippingStateName.Text = obj.objBillingResponse.ShippingStateName;
      this.lblShippingContactNumber.Text = obj.objBillingResponse.ShippingHomePhone;
      HiddenField hdnAddress = this.hdnAddress;
      string[] strArray = new string[8]
      {
        !string.IsNullOrEmpty(obj.objBillingResponse.ShippingAddressLine1) ? obj.objBillingResponse.ShippingAddressLine1 : "",
        ",",
        !string.IsNullOrEmpty(obj.objBillingResponse.ShippingAddressLine2) ? obj.objBillingResponse.ShippingAddressLine2 + "," : "",
        !string.IsNullOrEmpty(obj.objBillingResponse.ShippingSuburb) ? obj.objBillingResponse.ShippingSuburb : "",
        ",",
        obj.objBillingResponse.ShippingStateName,
        ",",
        null
      };
      num = obj.objBillingResponse.ShippingPostcode;
      string str9;
      if (string.IsNullOrEmpty(num.ToString()))
      {
        str9 = "";
      }
      else
      {
        num = obj.objBillingResponse.ShippingPostcode;
        str9 = num.ToString();
      }
      strArray[7] = str9;
      string str10 = string.Concat(strArray);
      hdnAddress.Value = str10;
      this.ltrIsOrderUnderCompany.Text = obj.IsOrderUnderCompany == 1 ? "Yes" : "No";
      if (obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 1))
        this.DivCreditCard.Visible = true;
      else
        this.DivCreditCard.Visible = false;
      if (obj.PickUpDetailID == 1L)
      {
        this.divBilling.Visible = false;
        this.divShipping.Visible = false;
        this.divExpectedDeliveryDate.Visible = false;
        this.divDeliveryInstructions.Visible = false;
        this.ltrAddressLine1.Text = obj.objBillingResponse.BillingAddressLine1;
        this.ltrAddressLine2.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingAddressLine2) ? obj.objBillingResponse.BillingAddressLine2 : "N/A";
        this.ltrSuburb.Text = obj.objBillingResponse.BillingSuburb;
        Literal ltrPostCode = this.ltrPostCode;
        num = obj.objBillingResponse.BillingPostcode;
        string str11 = num.ToString();
        ltrPostCode.Text = str11;
        this.ltrABN.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingCompanyABN) ? obj.objBillingResponse.BillingCompanyABN : "N/A";
        this.ltrStateName.Text = obj.objBillingResponse.BillingStateName;
        this.ltrContactNumber.Text = obj.objBillingResponse.BillingHomePhone;
        this.ltrBusinessName.Text = !string.IsNullOrEmpty(obj.objBillingResponse.BillingBusinessName) ? obj.objBillingResponse.BillingBusinessName : "N/A";
        this.divMapDeliveryAddress.Visible = false;
      }
      else if (obj.PickUpDetailID == 2L)
      {
        this.divPickUpDate.Visible = false;
        this.divAddress.Visible = false;
        this.divMapDeliveryAddress.Visible = true;
      }
      this.hdnPickUpDetailID.Value = obj.PickUpDetailID.ToString();
      if (obj.OrderStatus == Convert.ToInt32((object) (Enums.OrderStatus) 2) && obj.IsAcceptedByAdmin)
      {
        this.Divcoddeposite.Visible = true;
        this.rdbcoddeposite.Enabled = false;
        this.rdbcoddeposite.SelectedValue = "1";
        if (this.hdnPickUpDetailID.Value == "1")
        {
          this.radPickupDate.SelectedDate = obj.PickupDate;
          this.divPickUpDateTextbox.Visible = true;
          this.divPickUpDate.Visible = false;
          this.DivOrderPickup.Visible = true;
        }
        else
        {
          this.radDeliveryDate.SelectedDate = obj.DeliveryDate;
          this.divExpectedDeliveryDateTextbox.Visible = true;
          this.divExpectedDeliveryDate.Visible = false;
          this.DivOrderDelivery.Visible = true;
        }
      }
      else if (obj.OrderStatus == Convert.ToInt32((object) (Enums.OrderStatus) 1) && obj.IsAcceptedByAdmin)
      {
        this.Divcoddeposite.Visible = false;
        this.DivOrderPickup.Visible = false;
        this.DivOrderDelivery.Visible = false;
        this.DivFinalStatus.Visible = true;
        this.lblFinalStatus.Text = "Order Completed";
        this.DivbtnUpdate.Visible = false;
      }
      else if (obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 2) || obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 3))
      {
        if (obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 2) || obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 3))
        {
          if (obj.PickUpDetailID == 1L)
          {
            this.divPickUpDateTextbox.Visible = true;
            this.radPickupDate.SelectedDate = obj.PickupDate;
            this.divPickUpDate.Visible = false;
          }
          else if (obj.PickUpDetailID == 1L)
          {
            this.divExpectedDeliveryDateTextbox.Visible = true;
            this.radDeliveryDate.SelectedDate = obj.DeliveryDate;
            this.divExpectedDeliveryDate.Visible = false;
          }
          this.Divcoddeposite.Visible = true;
        }
      }
      else if ((obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 1) || obj.PaymentTypeName.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 5)) && obj.PaymentStatus == 1)
      {
        if (obj.PickUpDetailID == 1L)
        {
          this.radPickupDate.SelectedDate = obj.PickupDate;
          this.divPickUpDateTextbox.Visible = true;
          this.divPickUpDate.Visible = false;
          this.DivOrderPickup.Visible = true;
        }
        else
        {
          this.radDeliveryDate.SelectedDate = obj.DeliveryDate;
          this.divExpectedDeliveryDateTextbox.Visible = true;
          this.divExpectedDeliveryDate.Visible = false;
          this.DivOrderDelivery.Visible = true;
        }
      }
      else
      {
        this.DivPaymentMethod.Visible = true;
        List<PaymentTypeResponse> paymentOptions = PaymentTypeMgmt.GetPaymentOptions();
        IEnumerable<string> strTypes = ((IEnumerable<string>) (Convert.ToString((object) (Enums.PaymentTypes) 5) + "," + Convert.ToString((object) (Enums.PaymentTypes) 4)).Split(',')).Select<string, string>((System.Func<string, string>) (str => Convert.ToString(str)));
        this.rdbPaymentMethod.DataSource = (object) paymentOptions.Where<PaymentTypeResponse>((System.Func<PaymentTypeResponse, bool>) (m => !strTypes.Contains<string>(m.PaymentTypeName.Replace(" ", "")))).ToList<PaymentTypeResponse>();
        this.rdbPaymentMethod.DataTextField = "PaymentTypeName";
        this.rdbPaymentMethod.DataValueField = "PaymentTypeID";
        this.rdbPaymentMethod.DataBind();
        this.rdbPaymentMethod.SelectedValue = this.rdbPaymentMethod.Items[0].Value;
        if (obj.PickUpDetailID == 1L)
        {
          this.divPickUpDate.Visible = false;
          this.divPickUpDateTextbox.Visible = true;
          this.radPickupDate.SelectedDate = obj.PickupDate;
        }
        else if (obj.PickUpDetailID == 2L)
        {
          this.divExpectedDeliveryDate.Visible = false;
          this.divExpectedDeliveryDateTextbox.Visible = true;
          this.radDeliveryDate.SelectedDate = obj.DeliveryDate;
        }
        if (this.rdbPaymentMethod.SelectedItem.Text.Replace(" ", "") == ((Enums.PaymentTypes) 1).ToString())
        {
          this.DivbtnUpdate.Visible = false;
          this.DivbtnPaymentUpdate.Visible = true;
          this.divCreditcarddetail.Visible = true;
        }
        else
        {
          this.DivbtnPaymentUpdate.Visible = false;
          this.DivbtnUpdate.Visible = true;
          this.divCreditcarddetail.Visible = false;
        }
      }
      List<PurchaseOrderProductDetailBE> orderProductDetailBeList = new List<PurchaseOrderProductDetailBE>();
      this.rptProductDetail.DataSource = (object) PurchaseOrderDetailMgmt.PurchaseOrderDetailByPurchaseOrderID(obj.PurchaseOrderId);
      this.rptProductDetail.DataBind();
    }

    protected void rdbcoddeposite_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.rdbcoddeposite.SelectedValue == "1")
      {
        if (this.hdnPickUpDetailID.Value == "1")
        {
          this.divPickUpDateTextbox.Visible = true;
          this.divPickUpDate.Visible = false;
          this.DivOrderPickup.Visible = true;
        }
        else
        {
          this.divExpectedDeliveryDateTextbox.Visible = true;
          this.divExpectedDeliveryDate.Visible = false;
          this.DivOrderDelivery.Visible = true;
        }
      }
      else if (this.hdnPickUpDetailID.Value == "1")
      {
        this.divPickUpDateTextbox.Visible = true;
        this.divPickUpDate.Visible = false;
        this.DivOrderPickup.Visible = true;
      }
      else
      {
        this.divExpectedDeliveryDateTextbox.Visible = true;
        this.divExpectedDeliveryDate.Visible = false;
        this.DivOrderDelivery.Visible = true;
      }
    }

    protected void btnUpdate_Click(object sender, EventArgs e)
    {
      PurchaseOrderDetailBE retailPurchaseOrderId = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(this.RetailPurchaseOrderID);
      PaymentPurchaseOrderDetailBE purchaseOrderDetailBe1 = new PaymentPurchaseOrderDetailBE();
      PurchaseOrderDetailBE purchaseOrderDetailBe2 = new PurchaseOrderDetailBE();
      purchaseOrderDetailBe2.RetailPurchaseOrderID = this.RetailPurchaseOrderID;
      purchaseOrderDetailBe1.PurchaseOrderId = retailPurchaseOrderId.PurchaseOrderId;
      purchaseOrderDetailBe1.TransactionId = retailPurchaseOrderId.TransactionId;
      if (this.DivPaymentMethod.Visible)
      {
        List<PurchaseOrderProductDetailBE> orderProductDetailBeList = new List<PurchaseOrderProductDetailBE>();
        List<PurchaseOrderProductDetailBE> lstProduct = PurchaseOrderDetailMgmt.PurchaseOrderDetailByPurchaseOrderID(retailPurchaseOrderId.PurchaseOrderId);
        if (this.rdbPaymentMethod.SelectedItem.Text.Replace(" ", "") == ((Enums.PaymentTypes) 3).ToString())
        {
          purchaseOrderDetailBe1.PaymentTypeId = (long) Convert.ToInt32(this.rdbPaymentMethod.SelectedValue);
          purchaseOrderDetailBe1.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 2);
          purchaseOrderDetailBe1.RetailPurchaseOrderID = retailPurchaseOrderId.RetailPurchaseOrderID;
          DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
          purchaseOrderDetailBe2.PaymentDate = new DateTime?(dateTime);
          if (this.divExpectedDeliveryDateTextbox.Visible)
          {
            purchaseOrderDetailBe1.UpdateMode = "Delivery";
            purchaseOrderDetailBe1.UpdatedDate = this.radDeliveryDate.SelectedDate;
            retailPurchaseOrderId.DeliveryDate = this.radDeliveryDate.SelectedDate;
          }
          else if (this.divPickUpDateTextbox.Visible)
          {
            purchaseOrderDetailBe1.UpdateMode = "Pickup";
            purchaseOrderDetailBe1.UpdatedDate = this.radPickupDate.SelectedDate;
            retailPurchaseOrderId.PickupDate = this.radPickupDate.SelectedDate;
          }
          long num1 = (long) PurchaseOrderDetailMgmt.UpdatePaymentDetail(purchaseOrderDetailBe1);
          retailPurchaseOrderId.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 2);
          retailPurchaseOrderId.PaymentTypeId = Convert.ToInt64(this.rdbPaymentMethod.SelectedValue);
          PurchaseOrderDetailMgmt.AddPurchaseOrderTrack(retailPurchaseOrderId);
          string str = UtilityFunctions.BindProductDetailForInvoice((DataTable) null, lstProduct, (List<PurchaseOrderProductDetailBE>) null);
          if (Convert.ToInt32(retailPurchaseOrderId.PickUpDetailID.ToString()) == 1)
          {
            DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
            if (!nullable.HasValue)
            {
              retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
            }
            else
            {
              nullable = retailPurchaseOrderId.PickupDate;
              if (!nullable.HasValue)
                retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
            }
            string PurchaseProductDetail = str;
            long num2 = retailPurchaseOrderId.OrderNo;
            string iOrderNo = num2.ToString();
            nullable = retailPurchaseOrderId.DeliveryDate;
            DateTime minValue1 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue1 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId.PickupDate;
            DateTime minValue2 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue2 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            num2 = retailPurchaseOrderId.PickUpDetailID;
            string PickUpdetail = num2.ToString() == "1" ? "PickUp" : "Delivery";
            num2 = retailPurchaseOrderId.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num2.ToString();
            num2 = retailPurchaseOrderId.PickUpDetailID;
            string hdnPickUpDetailID = num2.ToString();
            Decimal num3 = retailPurchaseOrderId.SubTotal;
            string hdnSubTotal = num3.ToString();
            num3 = retailPurchaseOrderId.GrandTotal;
            string hdnFinalTotal = num3.ToString();
            num3 = retailPurchaseOrderId.PickUpPrice;
            string hdnPickDeliveryPrice = num3.ToString();
            string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
            string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
            num3 = retailPurchaseOrderId.GST;
            string hdnGSTVal = num3.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, "Awaiting Payment", "Direct Deposit", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
          }
          else if (Convert.ToInt32(retailPurchaseOrderId.PickUpDetailID.ToString()) == 2)
          {
            DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
            if (!nullable.HasValue)
            {
              retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
            }
            else
            {
              nullable = retailPurchaseOrderId.PickupDate;
              if (!nullable.HasValue)
                retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
            }
            string PurchaseProductDetail = str;
            long num4 = retailPurchaseOrderId.OrderNo;
            string iOrderNo = num4.ToString();
            nullable = retailPurchaseOrderId.DeliveryDate;
            DateTime minValue3 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue3 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId.PickupDate;
            DateTime minValue4 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue4 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            num4 = retailPurchaseOrderId.PickUpDetailID;
            string PickUpdetail = num4.ToString() == "1" ? "PickUp" : "Delivery";
            num4 = retailPurchaseOrderId.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num4.ToString();
            num4 = retailPurchaseOrderId.PickUpDetailID;
            string hdnPickUpDetailID = num4.ToString();
            Decimal num5 = retailPurchaseOrderId.SubTotal;
            string hdnSubTotal = num5.ToString();
            num5 = retailPurchaseOrderId.GrandTotal;
            string hdnFinalTotal = num5.ToString();
            num5 = retailPurchaseOrderId.DeliveryPrice;
            string hdnPickDeliveryPrice = num5.ToString();
            string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
            string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
            num5 = retailPurchaseOrderId.GST;
            string hdnGSTVal = num5.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, "Awaiting Payment", "Direct Deposit", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
          }
        }
        else if (this.rdbPaymentMethod.SelectedItem.Text.Replace(" ", "") == ((Enums.PaymentTypes) 2).ToString())
        {
          purchaseOrderDetailBe1.PaymentTypeId = Convert.ToInt64(this.rdbPaymentMethod.SelectedValue);
          purchaseOrderDetailBe1.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 2);
          purchaseOrderDetailBe1.RetailPurchaseOrderID = retailPurchaseOrderId.RetailPurchaseOrderID;
          DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
          purchaseOrderDetailBe2.PaymentDate = new DateTime?(dateTime);
          if (this.divExpectedDeliveryDateTextbox.Visible)
          {
            purchaseOrderDetailBe1.UpdateMode = "Delivery";
            purchaseOrderDetailBe1.UpdatedDate = this.radDeliveryDate.SelectedDate;
            retailPurchaseOrderId.DeliveryDate = this.radDeliveryDate.SelectedDate;
          }
          else if (this.divPickUpDateTextbox.Visible)
          {
            purchaseOrderDetailBe1.UpdateMode = "Pickup";
            purchaseOrderDetailBe1.UpdatedDate = this.radPickupDate.SelectedDate;
            retailPurchaseOrderId.PickupDate = this.radPickupDate.SelectedDate;
          }
          long num6 = (long) PurchaseOrderDetailMgmt.UpdatePaymentDetail(purchaseOrderDetailBe1);
          retailPurchaseOrderId.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 2);
          retailPurchaseOrderId.PaymentTypeId = Convert.ToInt64(this.rdbPaymentMethod.SelectedValue);
          PurchaseOrderDetailMgmt.AddPurchaseOrderTrack(retailPurchaseOrderId);
          string str = UtilityFunctions.BindProductDetailForInvoice((DataTable) null, lstProduct, (List<PurchaseOrderProductDetailBE>) null);
          if (Convert.ToInt32(retailPurchaseOrderId.PickUpDetailID.ToString()) == 1)
          {
            DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
            if (!nullable.HasValue)
            {
              retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
            }
            else
            {
              nullable = retailPurchaseOrderId.PickupDate;
              if (!nullable.HasValue)
                retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
            }
            string PurchaseProductDetail = str;
            long num7 = retailPurchaseOrderId.OrderNo;
            string iOrderNo = num7.ToString();
            nullable = retailPurchaseOrderId.DeliveryDate;
            DateTime minValue5 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue5 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId.PickupDate;
            DateTime minValue6 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue6 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            num7 = retailPurchaseOrderId.PickUpDetailID;
            string PickUpdetail = num7.ToString() == "1" ? "PickUp" : "Delivery";
            num7 = retailPurchaseOrderId.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num7.ToString();
            num7 = retailPurchaseOrderId.PickUpDetailID;
            string hdnPickUpDetailID = num7.ToString();
            Decimal num8 = retailPurchaseOrderId.SubTotal;
            string hdnSubTotal = num8.ToString();
            num8 = retailPurchaseOrderId.GrandTotal;
            string hdnFinalTotal = num8.ToString();
            num8 = retailPurchaseOrderId.PickUpPrice;
            string hdnPickDeliveryPrice = num8.ToString();
            string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
            string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
            num8 = retailPurchaseOrderId.GST;
            string hdnGSTVal = num8.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, "Awaiting Payment", "COD", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
          }
          else if (Convert.ToInt32(retailPurchaseOrderId.PickUpDetailID.ToString()) == 2)
          {
            DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
            if (!nullable.HasValue)
            {
              retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
            }
            else
            {
              nullable = retailPurchaseOrderId.PickupDate;
              if (!nullable.HasValue)
                retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
            }
            string PurchaseProductDetail = str;
            long num9 = retailPurchaseOrderId.OrderNo;
            string iOrderNo = num9.ToString();
            nullable = retailPurchaseOrderId.DeliveryDate;
            DateTime minValue7 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue7 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId.PickupDate;
            DateTime minValue8 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue8 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            num9 = retailPurchaseOrderId.PickUpDetailID;
            string PickUpdetail = num9.ToString() == "1" ? "PickUp" : "Delivery";
            num9 = retailPurchaseOrderId.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num9.ToString();
            num9 = retailPurchaseOrderId.PickUpDetailID;
            string hdnPickUpDetailID = num9.ToString();
            Decimal num10 = retailPurchaseOrderId.SubTotal;
            string hdnSubTotal = num10.ToString();
            num10 = retailPurchaseOrderId.GrandTotal;
            string hdnFinalTotal = num10.ToString();
            num10 = retailPurchaseOrderId.DeliveryPrice;
            string hdnPickDeliveryPrice = num10.ToString();
            string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
            string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
            num10 = retailPurchaseOrderId.GST;
            string hdnGSTVal = num10.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, "Awaiting Payment", "COD", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
          }
        }
        this.Session["TransactionSucess"] = (object) string.Format(Messages.TransactionSuccess, (object) retailPurchaseOrderId.OrderNostr);
      }
      else
      {
        if (this.Divcoddeposite.Visible)
        {
          if (this.rdbcoddeposite.SelectedValue == "1")
          {
            if (this.DivOrderPickup.Visible)
            {
              if (this.rdbOrderPickup.SelectedValue == "1")
              {
                purchaseOrderDetailBe2.OrderStatus = Convert.ToInt32((object) (Enums.OrderStatus) 1);
                purchaseOrderDetailBe2.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
                if (!retailPurchaseOrderId.DeliveryDate.HasValue)
                  retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
                else if (!retailPurchaseOrderId.PickupDate.HasValue)
                  retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
                if (this.divExpectedDeliveryDateTextbox.Visible)
                {
                  purchaseOrderDetailBe2.UpdateMode = "Delivery";
                  purchaseOrderDetailBe2.UpdatedDate = this.radDeliveryDate.SelectedDate;
                  retailPurchaseOrderId.DeliveryDate = this.radDeliveryDate.SelectedDate;
                }
                else if (this.divPickUpDateTextbox.Visible)
                {
                  purchaseOrderDetailBe2.UpdateMode = "Pickup";
                  purchaseOrderDetailBe2.UpdatedDate = this.radPickupDate.SelectedDate;
                  retailPurchaseOrderId.PickupDate = this.radPickupDate.SelectedDate;
                }
                string emailAddress = retailPurchaseOrderId.EmailAddress;
                string name = retailPurchaseOrderId.Name;
                long num = retailPurchaseOrderId.OrderNo;
                string OrderID = Convert.ToString("I-" + num.ToString());
                string OrderPrice = retailPurchaseOrderId.GrandTotal.ToString();
                DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
                DateTime minValue9 = DateTime.MinValue;
                string ExpectedDeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue9 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
                nullable = retailPurchaseOrderId.PickupDate;
                DateTime minValue10 = DateTime.MinValue;
                string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue10 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
                string Specialinstructions = !string.IsNullOrEmpty(retailPurchaseOrderId.DeliveryInstructions) ? retailPurchaseOrderId.DeliveryInstructions : "N/A";
                num = retailPurchaseOrderId.PickUpDetailID;
                string PickUpDetail = num.ToString() == "1" ? "PickUp" : "Delivery";
                string PaymentOption = retailPurchaseOrderId.PaymentTypeName.ToString();
                Mail.ConfirmFinalOrderEmail(emailAddress, name, OrderID, OrderPrice, ExpectedDeliveryDate, PickupDate, Specialinstructions, PickUpDetail, PaymentOption);
              }
              else
              {
                purchaseOrderDetailBe2.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
                purchaseOrderDetailBe2.OrderStatus = Convert.ToInt32((object) (Enums.OrderStatus) 2);
                if (this.divExpectedDeliveryDateTextbox.Visible)
                {
                  purchaseOrderDetailBe2.UpdateMode = "Delivery";
                  purchaseOrderDetailBe2.UpdatedDate = this.radDeliveryDate.SelectedDate;
                  retailPurchaseOrderId.DeliveryDate = this.radDeliveryDate.SelectedDate;
                }
                else if (this.divPickUpDateTextbox.Visible)
                {
                  purchaseOrderDetailBe2.UpdateMode = "Pickup";
                  purchaseOrderDetailBe2.UpdatedDate = this.radPickupDate.SelectedDate;
                  retailPurchaseOrderId.PickupDate = this.radPickupDate.SelectedDate;
                }
              }
              purchaseOrderDetailBe2.IsAcceptedByAdmin = true;
              PurchaseOrderDetailMgmt.UpdateOrderStatusForCODDirectDeposit(purchaseOrderDetailBe2);
            }
            else if (this.DivOrderDelivery.Visible)
            {
              if (this.rdbOrderDelivery.SelectedValue == "1")
              {
                purchaseOrderDetailBe2.OrderStatus = Convert.ToInt32((object) (Enums.OrderStatus) 1);
                purchaseOrderDetailBe2.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
                if (!retailPurchaseOrderId.DeliveryDate.HasValue)
                  retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
                else if (!retailPurchaseOrderId.PickupDate.HasValue)
                  retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
                if (this.divExpectedDeliveryDateTextbox.Visible)
                {
                  purchaseOrderDetailBe2.UpdateMode = "Delivery";
                  purchaseOrderDetailBe2.UpdatedDate = this.radDeliveryDate.SelectedDate;
                  retailPurchaseOrderId.DeliveryDate = this.radDeliveryDate.SelectedDate;
                }
                else if (this.divPickUpDateTextbox.Visible)
                {
                  purchaseOrderDetailBe2.UpdateMode = "Pickup";
                  purchaseOrderDetailBe2.UpdatedDate = this.radPickupDate.SelectedDate;
                  retailPurchaseOrderId.PickupDate = this.radPickupDate.SelectedDate;
                }
                string emailAddress = retailPurchaseOrderId.EmailAddress;
                string name = retailPurchaseOrderId.Name;
                long num = retailPurchaseOrderId.OrderNo;
                string OrderID = Convert.ToString("I-" + num.ToString());
                string OrderPrice = retailPurchaseOrderId.GrandTotal.ToString();
                DateTime? nullable = retailPurchaseOrderId.DeliveryDate;
                DateTime minValue11 = DateTime.MinValue;
                string ExpectedDeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue11 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
                nullable = retailPurchaseOrderId.PickupDate;
                DateTime minValue12 = DateTime.MinValue;
                string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue12 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
                string Specialinstructions = !string.IsNullOrEmpty(retailPurchaseOrderId.DeliveryInstructions) ? retailPurchaseOrderId.DeliveryInstructions : "N/A";
                num = retailPurchaseOrderId.PickUpDetailID;
                string PickUpDetail = num.ToString() == "1" ? "PickUp" : "Delivery";
                string PaymentOption = retailPurchaseOrderId.PaymentTypeName.ToString();
                Mail.ConfirmFinalOrderEmail(emailAddress, name, OrderID, OrderPrice, ExpectedDeliveryDate, PickupDate, Specialinstructions, PickUpDetail, PaymentOption);
              }
              else
              {
                purchaseOrderDetailBe2.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
                purchaseOrderDetailBe2.OrderStatus = Convert.ToInt32((object) (Enums.OrderStatus) 2);
                if (this.divExpectedDeliveryDateTextbox.Visible)
                {
                  purchaseOrderDetailBe2.UpdateMode = "Delivery";
                  purchaseOrderDetailBe2.UpdatedDate = this.radDeliveryDate.SelectedDate;
                  retailPurchaseOrderId.DeliveryDate = this.radDeliveryDate.SelectedDate;
                }
                else if (this.divPickUpDateTextbox.Visible)
                {
                  purchaseOrderDetailBe2.UpdateMode = "Pickup";
                  purchaseOrderDetailBe2.UpdatedDate = this.radPickupDate.SelectedDate;
                  retailPurchaseOrderId.PickupDate = this.radPickupDate.SelectedDate;
                }
              }
              purchaseOrderDetailBe2.IsAcceptedByAdmin = true;
              PurchaseOrderDetailMgmt.UpdateOrderStatusForCODDirectDeposit(purchaseOrderDetailBe2);
            }
          }
          else
          {
            purchaseOrderDetailBe2.OrderStatus = Convert.ToInt32((object) (Enums.OrderStatus) 2);
            purchaseOrderDetailBe2.IsAcceptedByAdmin = false;
            PurchaseOrderDetailMgmt.UpdateOrderStatusForCODDirectDeposit(purchaseOrderDetailBe2);
          }
        }
        else
        {
          DateTime? nullable;
          long num;
          if (this.DivOrderDelivery.Visible)
          {
            if (this.rdbOrderDelivery.SelectedValue == "1")
            {
              purchaseOrderDetailBe2.OrderStatus = Convert.ToInt32((object) (Enums.OrderStatus) 1);
              purchaseOrderDetailBe2.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
              purchaseOrderDetailBe2.IsAcceptedByAdmin = true;
              if (this.divExpectedDeliveryDateTextbox.Visible)
              {
                purchaseOrderDetailBe2.UpdateMode = "Delivery";
                purchaseOrderDetailBe2.UpdatedDate = this.radDeliveryDate.SelectedDate;
                retailPurchaseOrderId.DeliveryDate = this.radDeliveryDate.SelectedDate;
              }
              else if (this.divPickUpDateTextbox.Visible)
              {
                purchaseOrderDetailBe2.UpdateMode = "Pickup";
                purchaseOrderDetailBe2.UpdatedDate = this.radPickupDate.SelectedDate;
                retailPurchaseOrderId.PickupDate = this.radPickupDate.SelectedDate;
              }
              PurchaseOrderDetailMgmt.UpdateOrderStatusForCODDirectDeposit(purchaseOrderDetailBe2);
              nullable = retailPurchaseOrderId.DeliveryDate;
              if (!nullable.HasValue)
              {
                retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
              }
              else
              {
                nullable = retailPurchaseOrderId.PickupDate;
                if (!nullable.HasValue)
                  retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
              }
              string emailAddress = retailPurchaseOrderId.EmailAddress;
              string name = retailPurchaseOrderId.Name;
              num = retailPurchaseOrderId.OrderNo;
              string OrderID = Convert.ToString("I-" + num.ToString());
              string OrderPrice = retailPurchaseOrderId.GrandTotal.ToString();
              nullable = retailPurchaseOrderId.DeliveryDate;
              DateTime minValue13 = DateTime.MinValue;
              string ExpectedDeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue13 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
              nullable = retailPurchaseOrderId.PickupDate;
              DateTime minValue14 = DateTime.MinValue;
              string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue14 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
              string Specialinstructions = !string.IsNullOrEmpty(retailPurchaseOrderId.DeliveryInstructions) ? retailPurchaseOrderId.DeliveryInstructions : "N/A";
              num = retailPurchaseOrderId.PickUpDetailID;
              string PickUpDetail = num.ToString() == "1" ? "PickUp" : "Delivery";
              string PaymentOption = retailPurchaseOrderId.PaymentTypeName.ToString();
              Mail.ConfirmFinalOrderEmail(emailAddress, name, OrderID, OrderPrice, ExpectedDeliveryDate, PickupDate, Specialinstructions, PickUpDetail, PaymentOption);
            }
            else
            {
              purchaseOrderDetailBe2.OrderStatus = Convert.ToInt32((object) (Enums.OrderStatus) 2);
              purchaseOrderDetailBe2.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
              purchaseOrderDetailBe2.IsAcceptedByAdmin = true;
              PurchaseOrderDetailMgmt.UpdateOrderStatusForCODDirectDeposit(purchaseOrderDetailBe2);
            }
          }
          if (this.DivOrderPickup.Visible)
          {
            if (this.rdbOrderPickup.SelectedValue == "1")
            {
              purchaseOrderDetailBe2.OrderStatus = Convert.ToInt32((object) (Enums.OrderStatus) 1);
              purchaseOrderDetailBe2.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
              purchaseOrderDetailBe2.IsAcceptedByAdmin = true;
              if (this.divExpectedDeliveryDateTextbox.Visible)
              {
                purchaseOrderDetailBe2.UpdateMode = "Delivery";
                purchaseOrderDetailBe2.UpdatedDate = this.radDeliveryDate.SelectedDate;
                retailPurchaseOrderId.DeliveryDate = this.radDeliveryDate.SelectedDate;
              }
              else if (this.divPickUpDateTextbox.Visible)
              {
                purchaseOrderDetailBe2.UpdateMode = "Pickup";
                purchaseOrderDetailBe2.UpdatedDate = this.radPickupDate.SelectedDate;
                retailPurchaseOrderId.PickupDate = this.radPickupDate.SelectedDate;
              }
              PurchaseOrderDetailMgmt.UpdateOrderStatusForCODDirectDeposit(purchaseOrderDetailBe2);
              nullable = retailPurchaseOrderId.DeliveryDate;
              if (!nullable.HasValue)
              {
                retailPurchaseOrderId.DeliveryDate = new DateTime?(DateTime.MinValue);
              }
              else
              {
                nullable = retailPurchaseOrderId.PickupDate;
                if (!nullable.HasValue)
                  retailPurchaseOrderId.PickupDate = new DateTime?(DateTime.MinValue);
              }
              string emailAddress = retailPurchaseOrderId.EmailAddress;
              string name = retailPurchaseOrderId.Name;
              num = retailPurchaseOrderId.OrderNo;
              string OrderID = Convert.ToString("I-" + num.ToString());
              string OrderPrice = retailPurchaseOrderId.GrandTotal.ToString();
              nullable = retailPurchaseOrderId.DeliveryDate;
              DateTime minValue15 = DateTime.MinValue;
              string ExpectedDeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue15 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
              nullable = retailPurchaseOrderId.PickupDate;
              DateTime minValue16 = DateTime.MinValue;
              string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue16 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId.PickupDate).ToString("dd/MM/yyyy") : "N/A";
              string Specialinstructions = !string.IsNullOrEmpty(retailPurchaseOrderId.DeliveryInstructions) ? retailPurchaseOrderId.DeliveryInstructions : "N/A";
              num = retailPurchaseOrderId.PickUpDetailID;
              string PickUpDetail = num.ToString() == "1" ? "PickUp" : "Delivery";
              string PaymentOption = retailPurchaseOrderId.PaymentTypeName.ToString();
              Mail.ConfirmFinalOrderEmail(emailAddress, name, OrderID, OrderPrice, ExpectedDeliveryDate, PickupDate, Specialinstructions, PickUpDetail, PaymentOption);
            }
            else
            {
              purchaseOrderDetailBe2.OrderStatus = Convert.ToInt32((object) (Enums.OrderStatus) 2);
              purchaseOrderDetailBe2.PaymentStatus = 1;
              purchaseOrderDetailBe2.IsAcceptedByAdmin = true;
              if (this.divExpectedDeliveryDateTextbox.Visible)
              {
                purchaseOrderDetailBe2.UpdateMode = "Delivery";
                purchaseOrderDetailBe2.UpdatedDate = this.radDeliveryDate.SelectedDate;
                retailPurchaseOrderId.DeliveryDate = this.radDeliveryDate.SelectedDate;
              }
              else if (this.divPickUpDateTextbox.Visible)
              {
                purchaseOrderDetailBe2.UpdateMode = "Pickup";
                purchaseOrderDetailBe2.UpdatedDate = this.radPickupDate.SelectedDate;
                retailPurchaseOrderId.PickupDate = this.radPickupDate.SelectedDate;
              }
              PurchaseOrderDetailMgmt.UpdateOrderStatusForCODDirectDeposit(purchaseOrderDetailBe2);
            }
          }
        }
        this.Session["OrderStatus"] = (object) string.Format(Messages.UpdateSuccess, (object) "Order Status");
      }
      if (!string.IsNullOrEmpty(this.hdnIsDashFlag.Value))
        System.Web.UI.ScriptManager.RegisterStartupScript((Page) this, typeof (string), "Saved", "parent.$.fancybox.close();;window.parent.location = 'Welcome.aspx';", true);
      else
        System.Web.UI.ScriptManager.RegisterStartupScript((Page) this, typeof (string), "Saved", "parent.$.fancybox.close();;window.parent.location = 'ViewOrderProcessingPurchaseDetail.aspx';", true);
    }

    protected void rdbPaymentMethod_SelectedIndexChanged(object sender, EventArgs e)
    {
      if (this.rdbPaymentMethod.SelectedItem.Text.Replace(" ", "") == ((Enums.PaymentTypes) 1).ToString())
      {
        this.divCreditcarddetail.Visible = true;
        this.DivbtnUpdate.Visible = false;
        this.DivbtnPaymentUpdate.Visible = true;
      }
      else
      {
        this.divCreditcarddetail.Visible = false;
        this.DivbtnUpdate.Visible = true;
        this.DivbtnPaymentUpdate.Visible = false;
      }
    }

    protected void BindDropDown()
    {
      int num = 0;
      this.BindYear();
      List<CardNameResponse> cardDetail = DropDownMgmt.GetCardDetail();
      foreach (CardNameResponse cardNameResponse in cardDetail)
      {
        this.rdlCardType.Items.Add(new ListItem("<img src='" + ConfigurationManager.AppSettings["LivePath"] + this.CardImagePath + cardNameResponse.CardImage + "' height=\"40\" width=\"70\" alt='" + cardNameResponse.CardName + "' title='" + cardNameResponse.CardName + "'/>", num.ToString()));
        this.rdlCardType.CellPadding = 5;
        this.rdlCardType.CellSpacing = 5;
        ++num;
      }
      this.rdlCardType.SelectedValue = this.rdlCardType.Items[0].Value;
      this.ddlCardType.DataSource = (object) cardDetail;
      this.ddlCardType.DataTextField = "CardName";
      this.ddlCardType.DataValueField = "CardId";
      this.ddlCardType.DataBind();
    }

    protected void BindYear()
    {
      int year = DateTime.UtcNow.Year;
      this.ddlExpireYear.Items.Add(new ListItem("Year", "-1"));
      for (int index = year; index <= 2050; ++index)
        this.ddlExpireYear.Items.Add(new ListItem(index.ToString(), index.ToString()));
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvCardOwnerName, true, (object) this.txtCardOwnerName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regCardOwnerName, Regex.Title, true, (object) this.txtCardOwnerName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvCardNo, true, (object) this.txtCardNo, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvCVV, true, (object) this.txtCVV, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvExpireMonth, true, (object) this.ddlExpireMonth, "-1", this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvExpireYear, true, (object) this.ddlExpireYear, "-1", this.strValidationUserGrp);
      this.btnContinue.ValidationGroup = this.strValidationUserGrp;
    }

    protected void btnContinue_Click(object sender, EventArgs e)
    {
      PurchaseOrderDetailBE retailPurchaseOrderId1 = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(this.RetailPurchaseOrderID);
      PaymentPurchaseOrderDetailBE purchaseOrderDetailBe1 = new PaymentPurchaseOrderDetailBE();
      PurchaseOrderDetailBE purchaseOrderDetailBe2 = new PurchaseOrderDetailBE();
      purchaseOrderDetailBe1.PurchaseOrderId = retailPurchaseOrderId1.PurchaseOrderId;
      purchaseOrderDetailBe1.TransactionId = retailPurchaseOrderId1.TransactionId;
      PurchaseOrderDetailBE purchaseOrderDetailBe3 = new PurchaseOrderDetailBE();
      purchaseOrderDetailBe3.objUserCreditCardMaster.CreditCardType = this.rdlCardType.SelectedValue;
      purchaseOrderDetailBe3.objUserCreditCardMaster.CreditCardNo = this.txtCardNo.Text;
      purchaseOrderDetailBe3.objUserCreditCardMaster.ExpiryMonth = Convert.ToInt32(this.ddlExpireMonth.SelectedValue);
      purchaseOrderDetailBe3.objUserCreditCardMaster.ExpiryYear = Convert.ToInt32(this.ddlExpireYear.SelectedValue);
      purchaseOrderDetailBe3.objUserCreditCardMaster.CardHolderName = this.txtCardOwnerName.Text;
      purchaseOrderDetailBe3.objUserCreditCardMaster.CVVCode = Convert.ToInt32(this.txtCVV.Text);
      this.ddlCardType.SelectedValue = this.rdlCardType.SelectedValue;
      PaymentGatewayResponse paymentGatewayResponse = new PaymentGatewayResponse();
      PaymentGatewayResponse responseFromXmlPostData = UtilityFunctions.GetPaymentResponseFromXMLPostData(Convert.ToString(retailPurchaseOrderId1.GrandTotal.ToString().Replace(".", "").Replace(",", "")), this.txtCardNo.Text, this.ddlExpireMonth.SelectedValue + "/" + this.ddlExpireYear.SelectedValue.ToString().Substring(2, 2), this.txtCVV.Text, this.rdlCardType.SelectedValue, this.ddlCardType.SelectedItem.Text, this.txtCardOwnerName.Text, retailPurchaseOrderId1.OrderNostr);
      if (responseFromXmlPostData != null)
      {
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.MessageID = responseFromXmlPostData.messageID;
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.MessageTimestamp = responseFromXmlPostData.messageTimestamp;
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.RequestType = "Payment";
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.statusCode = Convert.ToInt32(responseFromXmlPostData.statusCode);
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.StatusDescription = responseFromXmlPostData.statusDescription;
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.ResponseCode = Convert.ToInt32(responseFromXmlPostData.responseCode);
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.ResponseText = responseFromXmlPostData.responseText;
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.TxnID = responseFromXmlPostData.txnID;
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.TxnType = Convert.ToInt64(responseFromXmlPostData.txnType);
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.TxnSource = Convert.ToInt64(responseFromXmlPostData.txnSource);
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.Amount = purchaseOrderDetailBe3.objPaymentPurchaseOrder.GrandPrice;
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.Approved = responseFromXmlPostData.approved;
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.CardDescription = responseFromXmlPostData.cardDescription;
        purchaseOrderDetailBe3.objPaymentCreditCardResponse.SettlementDate = responseFromXmlPostData.settlementDate;
        if (responseFromXmlPostData.responseCode == "00" || responseFromXmlPostData.responseCode == "08" || responseFromXmlPostData.responseCode == "11" || responseFromXmlPostData.responseCode == "16" || responseFromXmlPostData.responseCode == "77")
        {
          purchaseOrderDetailBe3.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
          DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
          purchaseOrderDetailBe3.PaymentDate = new DateTime?(dateTime);
        }
        else
          purchaseOrderDetailBe3.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 0);
      }
      else
        purchaseOrderDetailBe3.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 0);
      long purchaseOrderId = retailPurchaseOrderId1.PurchaseOrderId;
      if (purchaseOrderId > 0L)
      {
        purchaseOrderDetailBe3.PurchaseOrderId = purchaseOrderId;
        PurchaseOrderDetailMgmt.AddUpdatePurchaseOrderCreditCardDetail(purchaseOrderDetailBe3);
      }
      if (purchaseOrderDetailBe3.PaymentStatus == 1)
      {
        long num1 = retailPurchaseOrderId1.RetailPurchaseOrderID;
        PurchaseOrderDetailBE retailPurchaseOrderId2 = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(Convert.ToInt64(num1.ToString()));
        List<PurchaseOrderProductDetailBE> orderProductDetailBeList = new List<PurchaseOrderProductDetailBE>();
        List<PurchaseOrderProductDetailBE> lstProduct = PurchaseOrderDetailMgmt.PurchaseOrderDetailByPurchaseOrderID(retailPurchaseOrderId1.PurchaseOrderId);
        purchaseOrderDetailBe1.PaymentTypeId = Convert.ToInt64(this.rdbPaymentMethod.SelectedValue);
        purchaseOrderDetailBe1.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
        purchaseOrderDetailBe1.RetailPurchaseOrderID = retailPurchaseOrderId2.RetailPurchaseOrderID;
        DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
        purchaseOrderDetailBe2.PaymentDate = new DateTime?(dateTime);
        if (this.divExpectedDeliveryDateTextbox.Visible)
        {
          purchaseOrderDetailBe1.UpdateMode = "Delivery";
          purchaseOrderDetailBe1.UpdatedDate = this.radDeliveryDate.SelectedDate;
          retailPurchaseOrderId1.DeliveryDate = this.radDeliveryDate.SelectedDate;
        }
        else if (this.divPickUpDateTextbox.Visible)
        {
          purchaseOrderDetailBe1.UpdateMode = "Pickup";
          purchaseOrderDetailBe1.UpdatedDate = this.radPickupDate.SelectedDate;
          retailPurchaseOrderId1.PickupDate = this.radPickupDate.SelectedDate;
        }
        long num2 = (long) PurchaseOrderDetailMgmt.UpdatePaymentDetail(purchaseOrderDetailBe1);
        retailPurchaseOrderId1.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
        retailPurchaseOrderId1.PaymentTypeId = Convert.ToInt64(this.rdbPaymentMethod.SelectedValue);
        PurchaseOrderDetailMgmt.AddPurchaseOrderTrack(retailPurchaseOrderId1);
        string str = UtilityFunctions.BindProductDetailForInvoice((DataTable) null, lstProduct, (List<PurchaseOrderProductDetailBE>) null);
        num1 = retailPurchaseOrderId1.PickUpDetailID;
        if (Convert.ToInt32(num1.ToString()) == 1)
        {
          DateTime? nullable = retailPurchaseOrderId1.DeliveryDate;
          if (!nullable.HasValue)
          {
            retailPurchaseOrderId1.DeliveryDate = new DateTime?(DateTime.MinValue);
          }
          else
          {
            nullable = retailPurchaseOrderId1.PickupDate;
            if (!nullable.HasValue)
              retailPurchaseOrderId1.PickupDate = new DateTime?(DateTime.MinValue);
          }
          string PurchaseProductDetail = str;
          num1 = retailPurchaseOrderId1.OrderNo;
          string iOrderNo = num1.ToString();
          nullable = retailPurchaseOrderId1.DeliveryDate;
          DateTime minValue1 = DateTime.MinValue;
          string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue1 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId1.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
          nullable = retailPurchaseOrderId1.PickupDate;
          DateTime minValue2 = DateTime.MinValue;
          string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue2 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId1.PickupDate).ToString("dd/MM/yyyy") : "N/A";
          string PaymentStatus = purchaseOrderDetailBe3.PaymentStatus.ToString() == "1" ? "Paid" : "Failed";
          num1 = retailPurchaseOrderId1.PickUpDetailID;
          string PickUpdetail = num1.ToString() == "1" ? "PickUp" : "Delivery";
          num1 = retailPurchaseOrderId1.RetailPurchaseOrderID;
          string hdnRetailPurchaseOrderID = num1.ToString();
          num1 = retailPurchaseOrderId1.PickUpDetailID;
          string hdnPickUpDetailID = num1.ToString();
          Decimal num3 = retailPurchaseOrderId1.SubTotal;
          string hdnSubTotal = num3.ToString();
          num3 = retailPurchaseOrderId1.GrandTotal;
          string hdnFinalTotal = num3.ToString();
          num3 = retailPurchaseOrderId1.PickUpPrice;
          string hdnPickDeliveryPrice = num3.ToString();
          string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
          string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
          num3 = retailPurchaseOrderId1.GST;
          string hdnGSTVal = num3.ToString();
          UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, PaymentStatus, "Credit Card", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
        }
        else
        {
          num1 = retailPurchaseOrderId1.PickUpDetailID;
          if (Convert.ToInt32(num1.ToString()) == 2)
          {
            DateTime? nullable = retailPurchaseOrderId1.DeliveryDate;
            if (!nullable.HasValue)
            {
              retailPurchaseOrderId1.DeliveryDate = new DateTime?(DateTime.MinValue);
            }
            else
            {
              nullable = retailPurchaseOrderId1.PickupDate;
              if (!nullable.HasValue)
                retailPurchaseOrderId1.PickupDate = new DateTime?(DateTime.MinValue);
            }
            string PurchaseProductDetail = str;
            num1 = retailPurchaseOrderId1.OrderNo;
            string iOrderNo = num1.ToString();
            nullable = retailPurchaseOrderId1.DeliveryDate;
            DateTime minValue3 = DateTime.MinValue;
            string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue3 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId1.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
            nullable = retailPurchaseOrderId1.PickupDate;
            DateTime minValue4 = DateTime.MinValue;
            string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue4 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) retailPurchaseOrderId1.PickupDate).ToString("dd/MM/yyyy") : "N/A";
            string PaymentStatus = purchaseOrderDetailBe3.PaymentStatus.ToString() == "1" ? "Paid" : "Failed";
            num1 = retailPurchaseOrderId1.PickUpDetailID;
            string PickUpdetail = num1.ToString() == "1" ? "PickUp" : "Delivery";
            num1 = retailPurchaseOrderId1.RetailPurchaseOrderID;
            string hdnRetailPurchaseOrderID = num1.ToString();
            num1 = retailPurchaseOrderId1.PickUpDetailID;
            string hdnPickUpDetailID = num1.ToString();
            Decimal num4 = retailPurchaseOrderId1.SubTotal;
            string hdnSubTotal = num4.ToString();
            num4 = retailPurchaseOrderId1.GrandTotal;
            string hdnFinalTotal = num4.ToString();
            num4 = retailPurchaseOrderId1.DeliveryPrice;
            string hdnPickDeliveryPrice = num4.ToString();
            string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
            string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
            num4 = retailPurchaseOrderId1.GST;
            string hdnGSTVal = num4.ToString();
            UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, PaymentStatus, "Credit Card", PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
          }
        }
        this.Session["TransactionSucess"] = (object) string.Format(Messages.TransactionSuccess, (object) retailPurchaseOrderId1.OrderNostr);
        System.Web.UI.ScriptManager.RegisterStartupScript((Page) this, typeof (string), "Saved", "parent.$.fancybox.close();window.parent.location = 'ViewOrderProcessingPurchaseDetail.aspx';", true);
      }
      else
      {
        if (purchaseOrderDetailBe3.PaymentStatus != 0)
          return;
        this.Session["TransactionFail"] = (object) string.Format(Messages.TransactionFailed);
        System.Web.UI.ScriptManager.RegisterStartupScript((Page) this, typeof (string), "Saved", "parent.$.fancybox.close();window.parent.location = 'ViewOrderProcessingPurchaseDetail.aspx';", true);
      }
    }

    protected void btnPrintOrder_Click(object sender, EventArgs e)
    {
      this.imgMap.Src = "https://maps.googleapis.com/maps/api/staticmap" + "?center=" + this.hdnStaticMapLat.Value + ", " + this.hdnStaticMapLng.Value + "&size=800x170&scale=1" + "&zoom=13" + "&maptype=ROADMAP" + "&markers=color:red|(" + this.hdnStaticMapLat.Value + ", " + this.hdnStaticMapLng.Value + ")&sensor=false\";";
      StringBuilder sb1 = new StringBuilder();
      this.btnPrintOrder.Visible = false;
      this.DivbtnUpdate.Visible = false;
      this.divDeliveryGoogleMap.Visible = false;
      this.divGoogleMapImage.Style.Add("display", "block");
      this.form1.RenderControl(new HtmlTextWriter((TextWriter) new StringWriter(sb1)));
      string sb2 = sb1.ToString().Replace("<div class=\"input_name_StaffBold\">", " <div class=\"input_name_StaffBold\" style=\"font-size: 16px !important;\">").Replace("<div class=\"input_value_Staff\">", "  <div class=\"input_value_Staff\" style=\"font-size: 16px !important;\">").Replace("<legend>", "  <legend style=\"font-size: 18px !important;\">").Replace("<div class=\"creat_user\">", "<div class=\"creat_user\" style=\"border:none; box-shadow:none;\">").Replace("<div class=\"user_information\">", "<div class=\"user_information\" style=\"border:none; box-shadow:none;\">").ToString();
      string strFileName = "OrderDetail";
      string FileName = "OrderDetail" + DateTime.Now.Ticks.ToString();
      UtilityFunctions.GeneratePDFUsingHtml(this.Server.MapPath("~"), FileName, strFileName, sb2);
    }
  }
}
