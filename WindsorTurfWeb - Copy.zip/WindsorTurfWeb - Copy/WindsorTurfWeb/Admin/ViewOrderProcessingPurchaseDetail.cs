﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewOrderProcessingPurchaseDetail
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PurchaseOrderDetail;
using Entity.Common.PurchaseOrderDetail;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class ViewOrderProcessingPurchaseDetail : Page
  {
    public string strValidationGrp = "SearchValidation";
    public DataTable _dtAdminCART = (DataTable) null;
    protected HtmlGenericControl H1Title;
    protected DropDownList ddlUserType;
    protected TextBox txtSearch;
    protected CheckBox chkOrderDate;
    protected CheckBox chkPaidDate;
    protected RadioButton rdbDeliveryDate;
    protected RadioButton rdbPickUpDate;
    protected RadDatePicker txtFromDate;
    protected RadDatePicker txtToDate;
    protected CompareValidator cmpDate;
    protected Button btnSearch;
    protected Button btnViewAll;
    protected Button btnClearFilter;
    protected RadGrid grdOrderProcessingPurchaseDetail;
    protected HtmlTable tableLegend;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (!this.IsPostBack)
      {
        this.BindDropdown();
        this.BindGrid();
        if (this.Session["dtAdminCART"] != null)
        {
          this._dtAdminCART = (DataTable) this.Session["dtAdminCART"];
          this._dtAdminCART.Rows.Clear();
          HttpContext.Current.Session["dtAdminCART"] = (object) this._dtAdminCART;
        }
      }
      if (this.Session["TransactionSucess"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["TransactionSucess"]), (Enums.NotificationType) 1), true);
        this.Session["TransactionSucess"] = (object) null;
      }
      if (this.Session["TransactionFail"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["TransactionFail"]), (Enums.NotificationType) 2), true);
        this.Session["TransactionFail"] = (object) null;
      }
      if (this.Session["OrderStatus"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(this.Session["OrderStatus"]), (Enums.NotificationType) 1), true);
        this.Session["OrderStatus"] = (object) null;
      }
      if (this.Request.QueryString[QueryStrings.Status] == null)
        return;
      string str = Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.Status].ToString());
      if (str == "adminsuccesscredit")
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(string.Format(Messages.TransactionSuccess, this.Session["AdminPurchaseOrderNo"])), (Enums.NotificationType) 1), true);
      if (str == "adminfailedrecredit")
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(Convert.ToString(string.Format(Messages.TransactionFailed)), (Enums.NotificationType) 2), true);
    }

    protected void FilterCriteria()
    {
      string str1 = this.txtFromDate.SelectedDate.ToString();
      string str2 = this.txtToDate.SelectedDate.ToString();
      if ((this.chkOrderDate.Checked || this.chkPaidDate.Checked || this.rdbDeliveryDate.Checked || this.rdbPickUpDate.Checked) && (!string.IsNullOrEmpty(str1) || !string.IsNullOrEmpty(str2)) || (!this.chkOrderDate.Checked || !this.chkPaidDate.Checked || !this.rdbDeliveryDate.Checked || !this.rdbPickUpDate.Checked) && (!string.IsNullOrEmpty(str1) || !string.IsNullOrEmpty(str2)))
      {
        long int64 = Convert.ToInt64(this.ddlUserType.SelectedValue);
        string str3 = "";
        string str4 = "";
        string str5 = "";
        string str6 = "";
        DateTime? selectedDate = this.txtFromDate.SelectedDate;
        int num;
        if (selectedDate.ToString() == "")
        {
          selectedDate = this.txtToDate.SelectedDate;
          num = selectedDate.ToString() == "" ? 1 : 0;
        }
        else
          num = 0;
        string str7;
        string str8;
        if (num != 0)
        {
          str7 = (string) null;
          str8 = (string) null;
        }
        else
        {
          selectedDate = this.txtFromDate.SelectedDate;
          if (!string.IsNullOrEmpty(selectedDate.ToString()))
          {
            selectedDate = this.txtFromDate.SelectedDate;
            str7 = string.Format("{0:yyyy/MM/dd}", (object) Convert.ToDateTime(selectedDate.ToString()));
          }
          else
            str7 = (string) null;
          selectedDate = this.txtToDate.SelectedDate;
          if (!string.IsNullOrEmpty(selectedDate.ToString()))
          {
            selectedDate = this.txtToDate.SelectedDate;
            str8 = string.Format("{0:yyyy/MM/dd}", (object) Convert.ToDateTime(selectedDate.ToString()));
          }
          else
            str8 = string.Format("{0:yyyy/MM/dd}", (object) Convert.ToDateTime(DateTime.Now.Date.ToString()));
        }
        if (this.chkOrderDate.Checked)
          str3 = " AND (1 = CASE WHEN '" + str7 + "' ='''' AND '" + str8 + "' ='''' THEN 1  WHEN '" + str7 + "' ='''' AND CONVERT(DATE,(PPOD.CreatedDate))<= CONVERT(DATE,'" + str8 + "') THEN 1  WHEN '" + str8 + "' = '''' AND CONVERT(DATE,(PPOD.CreatedDate)) >= CONVERT(DATE,'" + str7 + "') THEN 1  WHEN CONVERT(DATE,(PPOD.CreatedDate)) >= CONVERT(DATE,'" + str7 + "') AND CONVERT(DATE,(PPOD.CreatedDate)) <= CONVERT(DATE,'" + str8 + "') THEN 1 ELSE 0 END)";
        if (this.chkPaidDate.Checked)
          str4 = " AND (1 = CASE WHEN '" + str7 + "' ='''' AND '" + str8 + "' ='''' THEN 1  WHEN '" + str7 + "' ='''' AND CONVERT(DATE,(PPOD.PaymentDate))<= CONVERT(DATE,'" + str8 + "') THEN 1  WHEN '" + str8 + "' = '''' AND CONVERT(DATE,(PPOD.PaymentDate)) >= CONVERT(DATE,'" + str7 + "') THEN 1  WHEN CONVERT(DATE,(PPOD.PaymentDate)) >= CONVERT(DATE,'" + str7 + "') AND CONVERT(DATE,(PPOD.PaymentDate)) <= CONVERT(DATE,'" + str8 + "') THEN 1 ELSE 0 END)";
        if (this.rdbDeliveryDate.Checked)
          str5 = " AND (1 = CASE WHEN '" + str7 + "' ='''' AND '" + str8 + "' ='''' THEN 1  WHEN '" + str7 + "' ='''' AND CONVERT(DATE,(ODB.DeliveryDate))<= CONVERT(DATE,'" + str8 + "') THEN 1  WHEN '" + str8 + "' = '''' AND CONVERT(DATE,(ODB.DeliveryDate)) >= CONVERT(DATE,'" + str7 + "') THEN 1  WHEN CONVERT(DATE,(ODB.DeliveryDate)) >= CONVERT(DATE,'" + str7 + "') AND CONVERT(DATE,(ODB.DeliveryDate)) <= CONVERT(DATE,'" + str8 + "') THEN 1 ELSE 0 END)";
        if (this.rdbPickUpDate.Checked)
          str6 = " AND (1 = CASE WHEN '" + str7 + "' ='''' AND '" + str8 + "' ='''' THEN 1  WHEN '" + str7 + "' ='''' AND CONVERT(DATE,(ODB.PickupDate))<= CONVERT(DATE,'" + str8 + "') THEN 1  WHEN '" + str8 + "' = '''' AND CONVERT(DATE,(ODB.PickupDate)) >= CONVERT(DATE,'" + str7 + "') THEN 1  WHEN CONVERT(DATE,(ODB.PickupDate)) >= CONVERT(DATE,'" + str7 + "') AND CONVERT(DATE,(ODB.PickupDate)) <= CONVERT(DATE,'" + str8 + "') THEN 1 ELSE 0 END)";
        if (!this.chkOrderDate.Checked && !this.chkPaidDate.Checked && !this.rdbDeliveryDate.Checked && !this.rdbPickUpDate.Checked)
          str3 = " AND (1 = CASE WHEN '" + str7 + "' ='''' AND '" + str8 + "' ='''' THEN 1  WHEN '" + str7 + "' ='''' AND CONVERT(DATE,(PPOD.CreatedDate))<= CONVERT(DATE,'" + str8 + "') THEN 1  WHEN '" + str8 + "' = '''' AND CONVERT(DATE,(PPOD.CreatedDate)) >= CONVERT(DATE,'" + str7 + "') THEN 1  WHEN CONVERT(DATE,(PPOD.CreatedDate)) >= CONVERT(DATE,'" + str7 + "') AND CONVERT(DATE,(PPOD.CreatedDate)) <= CONVERT(DATE,'" + str8 + "') THEN 1 ELSE 0 END)";
        string str9 = str3 + str4 + str5 + str6;
        string str10 = !(this.ddlUserType.SelectedValue.ToString() != "-1") ? str9.ToString() : str9 + " AND RPD.UserTypeID =" + int64.ToString();
        if (this.txtSearch.Text.Trim() != "")
          str10 = str10 + " AND ODB.BillingBusinessName LIKE '%" + this.txtSearch.Text.Trim() + "%' OR ODB.BillingFirstName LIKE '%" + this.txtSearch.Text.Trim() + "%' OR ODB.BillingLastName LIKE '%" + this.txtSearch.Text.Trim() + "%' OR ODB.BillingFirstName+' '+ODB.BillingLastName  LIKE '%" + this.txtSearch.Text.Trim() + "%'";
        str10.Substring(str10.Length - Math.Min(4, str10.Length));
        if (str10.Substring(0, 4) == " AND")
          str10 = str10.Remove(0, 4);
        List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
        List<PurchaseOrderDetailBE> purchaseDetailForSearch = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailForSearch(str10);
        this.grdOrderProcessingPurchaseDetail.VirtualItemCount = purchaseDetailForSearch.Count<PurchaseOrderDetailBE>();
        ((BaseDataBoundControl) this.grdOrderProcessingPurchaseDetail).DataSource = (object) purchaseDetailForSearch;
        ((Control) this.grdOrderProcessingPurchaseDetail).DataBind();
      }
      else if (!this.chkOrderDate.Checked && !this.chkPaidDate.Checked && !this.rdbDeliveryDate.Checked && !this.rdbPickUpDate.Checked && string.IsNullOrEmpty(str1) && string.IsNullOrEmpty(str2))
      {
        long int64 = Convert.ToInt64(this.ddlUserType.SelectedValue);
        string str11 = "";
        string str12 = !(this.ddlUserType.SelectedValue.ToString() != "-1") ? str11.ToString() : str11 + " AND RPD.UserTypeID =" + int64.ToString();
        if (this.txtSearch.Text.Trim() != "")
          str12 = str12 + " AND ODB.BillingBusinessName LIKE '%" + this.txtSearch.Text.Trim() + "%' OR ODB.BillingFirstName LIKE '%" + this.txtSearch.Text.Trim() + "%' OR ODB.BillingLastName LIKE '%" + this.txtSearch.Text.Trim() + "%' OR ODB.BillingFirstName+' '+ODB.BillingLastName  LIKE '%" + this.txtSearch.Text.Trim() + "%'";
        if (str12 == "")
        {
          List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
          List<PurchaseOrderDetailBE> processingPurchaseDetail = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetail();
          this.grdOrderProcessingPurchaseDetail.VirtualItemCount = processingPurchaseDetail.Count<PurchaseOrderDetailBE>();
          ((BaseDataBoundControl) this.grdOrderProcessingPurchaseDetail).DataSource = (object) processingPurchaseDetail;
          ((Control) this.grdOrderProcessingPurchaseDetail).DataBind();
          if (processingPurchaseDetail.Count<PurchaseOrderDetailBE>() == 0)
            this.grdOrderProcessingPurchaseDetail.AllowFilteringByColumn = false;
          ViewOrderProcessingPurchaseDetail.SetPaggingText(this.grdOrderProcessingPurchaseDetail, "Paging");
        }
        else
        {
          str12.Substring(str12.Length - Math.Min(4, str12.Length));
          if (str12.Substring(0, 4) == " AND")
            str12 = str12.Remove(0, 4);
          List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
          List<PurchaseOrderDetailBE> purchaseDetailForSearch = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailForSearch(str12);
          this.grdOrderProcessingPurchaseDetail.VirtualItemCount = purchaseDetailForSearch.Count<PurchaseOrderDetailBE>();
          ((BaseDataBoundControl) this.grdOrderProcessingPurchaseDetail).DataSource = (object) purchaseDetailForSearch;
          ((Control) this.grdOrderProcessingPurchaseDetail).DataBind();
        }
      }
      else
      {
        long int64 = Convert.ToInt64(this.ddlUserType.SelectedValue);
        string str13 = "";
        string str14 = !(this.ddlUserType.SelectedValue.ToString() != "-1") ? str13.ToString() : str13 + " AND RPD.UserTypeID =" + int64.ToString();
        if (this.txtSearch.Text.Trim() != "")
        {
          str14 = str14 + " AND ODB.BillingBusinessName LIKE '%" + this.txtSearch.Text.Trim() + "%' OR ODB.BillingFirstName LIKE '%" + this.txtSearch.Text.Trim() + "%' OR ODB.BillingLastName LIKE '%" + this.txtSearch.Text.Trim() + "%' OR ODB.BillingFirstName+' '+ODB.BillingLastName  LIKE '%" + this.txtSearch.Text.Trim() + "%'";
          str14.Substring(str14.Length - Math.Min(4, str14.Length));
          if (str14.Substring(0, 4) == " AND")
            str14 = str14.Remove(0, 4);
        }
        if (str14 == "")
        {
          List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
          List<PurchaseOrderDetailBE> processingPurchaseDetail = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetail();
          this.grdOrderProcessingPurchaseDetail.VirtualItemCount = processingPurchaseDetail.Count<PurchaseOrderDetailBE>();
          ((BaseDataBoundControl) this.grdOrderProcessingPurchaseDetail).DataSource = (object) processingPurchaseDetail;
          ((Control) this.grdOrderProcessingPurchaseDetail).DataBind();
          if (processingPurchaseDetail.Count<PurchaseOrderDetailBE>() == 0)
            this.grdOrderProcessingPurchaseDetail.AllowFilteringByColumn = false;
          ViewOrderProcessingPurchaseDetail.SetPaggingText(this.grdOrderProcessingPurchaseDetail, "Paging");
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format("Please select From Date/To Date search criteria"), (Enums.NotificationType) 2, false), true);
        }
        else
        {
          if (str14.Substring(0, 4) == " AND")
            str14 = str14.Remove(0, 4);
          List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
          List<PurchaseOrderDetailBE> purchaseDetailForSearch = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailForSearch(str14);
          this.grdOrderProcessingPurchaseDetail.VirtualItemCount = purchaseDetailForSearch.Count<PurchaseOrderDetailBE>();
          ((BaseDataBoundControl) this.grdOrderProcessingPurchaseDetail).DataSource = (object) purchaseDetailForSearch;
          ((Control) this.grdOrderProcessingPurchaseDetail).DataBind();
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format("Please select From Date/To Date search criteria"), (Enums.NotificationType) 2, false), true);
        }
      }
    }

    private void BindGrid() => this.FilterCriteria();

    protected void grdOrderProcessingPurchaseDetail_PreRender(object sender, EventArgs e)
    {
      if (((GridItemCollection) this.grdOrderProcessingPurchaseDetail.MasterTableView.Items).Count == 0)
      {
        this.grdOrderProcessingPurchaseDetail.ShowFooter = false;
        this.tableLegend.Visible = false;
        this.grdOrderProcessingPurchaseDetail.PagerStyle.AlwaysVisible = false;
      }
      else
      {
        this.grdOrderProcessingPurchaseDetail.ShowFooter = true;
        this.tableLegend.Visible = true;
        this.grdOrderProcessingPurchaseDetail.PagerStyle.AlwaysVisible = true;
      }
      this.grdOrderProcessingPurchaseDetail.Rebind();
      ViewOrderProcessingPurchaseDetail.SetPaggingText(this.grdOrderProcessingPurchaseDetail, "Paging");
    }

    protected void grdOrderProcessingPurchaseDetail_SortCommand(
      object sender,
      GridSortCommandEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdOrderProcessingPurchaseDetail_PageSizeChanged(
      object sender,
      GridPageSizeChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdOrderProcessingPurchaseDetail_PageIndexChanged(
      object sender,
      GridPageChangedEventArgs e)
    {
      this.BindGrid();
    }

    protected void grdOrderProcessingPurchaseDetail_ItemCommand(
      object sender,
      GridCommandEventArgs e)
    {
      this.BindGrid();
      this.grdOrderProcessingPurchaseDetail.Rebind();
    }

    protected void grdOrderProcessingPurchaseDetail_ItemDataBound(
      object sender,
      GridItemEventArgs e)
    {
    }

    protected void btnShowAll_Click(object sender, ImageClickEventArgs e) => this.Response.Redirect("~/Admin/ViewOrderProcessingPurchaseDetail.aspx");

    public static void SetPaggingText(RadGrid _RadGrid, string _moduleName = "")
    {
      _moduleName = string.IsNullOrEmpty(_moduleName) ? "Records" : _moduleName;
      if (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 0)
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "{4} <strong>{5}</strong> item" + (((GridItemCollection) _RadGrid.MasterTableView.Items).Count > 1 ? "s" : "") + " in <strong>{1}</strong> page" + (_RadGrid.PageCount > 0 ? "(s)" : "");
      else
        _RadGrid.MasterTableView.PagerStyle.PagerTextFormat = "";
    }

    protected void BindDropdown() => BindDropDown.GetUserForDropDown((ListControl) this.ddlUserType);

    protected void ddlUserType_SelectedIndexChanged(object sender, EventArgs e)
    {
    }

    protected void btnSearch_Click(object sender, EventArgs e) => this.FilterCriteria();

    protected void btnViewAll_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewOrderProcessingPurchaseDetail.aspx");

    protected void btnClearFilter_Click(object sender, EventArgs e)
    {
      this.chkOrderDate.Checked = false;
      this.chkPaidDate.Checked = false;
      this.rdbDeliveryDate.Checked = false;
      this.rdbPickUpDate.Checked = false;
      this.txtToDate.Clear();
      this.txtFromDate.Clear();
      this.txtSearch.Text = "";
      this.ddlUserType.SelectedValue = "-1";
      this.BindGrid();
    }
  }
}
