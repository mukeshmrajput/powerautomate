﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateUser
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.UserManagement;
using Entity.Common.UserManagement;
using Entity.Response.UserManagement;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateUser : Page
  {
    public static string fPassword;
    public static string fEmail;
    public static long fUserID = 0;
    public string strValidationUserGrp = "UserValidation";
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected TextBox txtFirstName;
    protected RequiredFieldValidator rfvFirstName;
    protected RegularExpressionValidator regFirstName;
    protected TextBox txtLastName;
    protected RequiredFieldValidator rfvLastName;
    protected RegularExpressionValidator regLastName;
    protected TextBox txtEmail;
    protected RequiredFieldValidator rfvEmail;
    protected RegularExpressionValidator regEmail;
    protected TextBox txtPassword;
    protected RequiredFieldValidator rfvPassword;
    protected RegularExpressionValidator regPassword;
    protected TextBox txtConfirmPassword;
    protected RequiredFieldValidator rfvConfirmPassword;
    protected RegularExpressionValidator regConfirmPassword;
    protected CompareValidator cmpvConfirmPassword;
    protected RadioButtonList rdlUserType;
    protected CheckBox chkSelectAllModules;
    protected DataList dtlstmodule;
    protected CustomValidator cvModule;
    protected CheckBox chkStatus;
    protected Button btnSub;
    protected Button btnCancel;
    protected HiddenField hdnUserId;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.DefaultButton = this.btnSub.UniqueID;
      this.txtFirstName.Focus();
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.Request.QueryString[QueryStrings.LoginMasterID] != null)
      {
        this.h1Title.InnerText = "Edit Admin User";
        this.btnSub.Text = "Update";
        this.btnSub.ToolTip = "Update";
        AddUpdateUser.fUserID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.LoginMasterID].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add Admin User";
        this.btnSub.Text = "Save";
        this.btnSub.ToolTip = "Save";
        AddUpdateUser.fUserID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        if (AddUpdateUser.fUserID > 0L)
        {
          UserBE userInfoById = UserMgmt.GetUserInfoById(Convert.ToInt64(AddUpdateUser.fUserID));
          this.BindModule();
          this.GetUserInformation(userInfoById);
        }
        else
          this.BindModule();
      }
      this.txtFirstName.Focus();
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvFirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regFirstName, Regex.FirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvLastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regLastName, Regex.LastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvEmail, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regEmail, Regex.Email, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvPassword, true, (object) this.txtPassword, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regPassword, Regex.Password, true, (object) this.txtPassword, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidator(this.rfvConfirmPassword, true, (object) this.txtConfirmPassword, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidator(this.regConfirmPassword, Regex.Password, true, (object) this.txtConfirmPassword, this.strValidationUserGrp);
      Validations.SetCompareFieldValidator(this.cmpvConfirmPassword, true, (object) this.txtConfirmPassword, (object) this.txtPassword, this.strValidationUserGrp);
      if (AddUpdateUser.fUserID > 0L)
        this.cmpvConfirmPassword.ErrorMessage = string.Format(Messages.NewPasswordAndConfirmPasswordNotMatch);
      else
        this.cmpvConfirmPassword.ErrorMessage = string.Format(Messages.PasswordAndConfirmPasswordNotMatch);
      this.btnSub.ValidationGroup = this.strValidationUserGrp;
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewUser.aspx");

    protected void AddUserInfo()
    {
      if (!this.Page.IsValid)
        return;
      if (UserMgmt.CheckEmailExists(this.txtEmail.Text.Trim(), Convert.ToInt64(this.hdnUserId.Value)))
      {
        UserBE userBe = new UserBE();
        userBe.LoginMasterID = AddUpdateUser.fUserID <= 0L ? 0L : AddUpdateUser.fUserID;
        userBe.FirstName = this.txtFirstName.Text.Trim();
        userBe.LastName = this.txtLastName.Text.Trim();
        userBe.Email = this.txtEmail.Text.Trim();
        userBe.Password = Encryption.EncryptQueryString(this.txtPassword.Text.Trim());
        userBe.UserType = (long) Convert.ToInt32(this.rdlUserType.SelectedValue);
        userBe.IsActive = !this.chkStatus.Checked ? Convert.ToBoolean((object) (Enums.IsActive) 0) : Convert.ToBoolean((object) (Enums.IsActive) 1);
        userBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
        userBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
        long num = UserMgmt.AddUpdateUserInformation(userBe);
        if (num > 0L)
        {
          UserMgmt.DeleteUserAccess(num);
          DataTable dtUserModuleAccess = new DataTable();
          if (this.dtlstmodule.Items.Count > 0)
          {
            dtUserModuleAccess = this.AddColumns(dtUserModuleAccess);
            for (int index = 0; index < this.dtlstmodule.Items.Count; ++index)
            {
              bool flag = ((CheckBox) this.dtlstmodule.Items[index].FindControl("chkModule")).Checked;
              DataRow row = dtUserModuleAccess.NewRow();
              row["LoginMasterID"] = (object) num;
              row["ModuleID"] = (object) Convert.ToInt64((this.dtlstmodule.Items[index].FindControl("hdnId") as HiddenField).Value);
              row["IsChecked"] = (object) Convert.ToBoolean(flag);
              dtUserModuleAccess.Rows.Add(row);
            }
          }
          string empty = string.Empty;
          string processStatus = AddUpdateUser.fUserID <= 0L ? "0" : "1";
          userBe.dtUserModuleAccess = dtUserModuleAccess;
          UserMgmt.AddUserAccess(userBe);
          Mail.NewUserCreatedUpdated(this.txtEmail.Text.Trim(), this.txtFirstName.Text + " " + this.txtLastName.Text, this.txtPassword.Text, this.rdlUserType.SelectedItem.Text, processStatus);
        }
        if (userBe.LoginMasterID > 0L)
          this.Session["UserAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) "Admin User");
        else if (userBe.LoginMasterID == 0L)
          this.Session["UserAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) "Admin User");
        this.Response.Redirect("~/Admin/ViewUser.aspx");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExistsEmail.ToString(), (object) HTMLControlText.Email), (Enums.NotificationType) 2, false), true);
    }

    protected void BindModule()
    {
      List<ModuleResponseBE> moduleResponseBeList = new List<ModuleResponseBE>();
      this.dtlstmodule.DataSource = (object) UserMgmt.GetModuleInfo();
      this.dtlstmodule.DataBind();
    }

    protected void GetUserInformation(UserBE objUser)
    {
      List<UserBE> userBeList = new List<UserBE>();
      List<UserBE> userModuleInfoById = UserMgmt.GetUserModuleInfoById(objUser.LoginMasterID);
      this.txtFirstName.Text = objUser.FirstName;
      this.txtLastName.Text = objUser.LastName;
      this.txtPassword.Attributes.Add("value", Encryption.DecryptQueryString(objUser.Password));
      this.txtConfirmPassword.Attributes.Add("value", Encryption.DecryptQueryString(objUser.Password));
      AddUpdateUser.fPassword = objUser.Password;
      this.txtEmail.Text = objUser.Email;
      AddUpdateUser.fEmail = objUser.Email;
      this.rdlUserType.SelectedValue = objUser.UserTypeID.ToString();
      this.chkStatus.Checked = objUser.IsActive;
      this.hdnUserId.Value = objUser.LoginMasterID.ToString();
      objUser.LoginMasterID = Convert.ToInt64(this.hdnUserId.Value);
      this.chkStatus.Checked = Convert.ToBoolean(objUser.IsActive);
      for (int index = 0; index < userModuleInfoById.Count; ++index)
      {
        foreach (DataListItem dataListItem in this.dtlstmodule.Items)
        {
          HiddenField control1 = (HiddenField) dataListItem.FindControl("hdnId");
          CheckBox control2 = (CheckBox) dataListItem.FindControl("chkModule");
          if (userModuleInfoById[index].objModuleDetail.ModuleID.ToString() == control1.Value)
            control2.Checked = userModuleInfoById[index].objModuleDetail.IsChecked;
        }
      }
    }

    protected void btnSub_Click(object sender, EventArgs e) => this.AddUserInfo();

    private DataTable AddColumns(DataTable dtUserModuleAccess)
    {
      dtUserModuleAccess.Columns.Add(new DataColumn("LoginMasterID", typeof (long)));
      dtUserModuleAccess.Columns.Add(new DataColumn("ModuleID", typeof (long)));
      dtUserModuleAccess.Columns.Add(new DataColumn("IsChecked", typeof (bool)));
      return dtUserModuleAccess;
    }
  }
}
