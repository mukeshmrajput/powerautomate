﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateTestimonials
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Testimonials;
using Helper;
using Resources;
using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateTestimonials : Page
  {
    public long fTestimonialsMgmntID = 0;
    public long UserId;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HighslideControlAdmin HighslideControlAdmin1;
    protected HtmlGenericControl h1Title;
    protected HtmlGenericControl divTab;
    protected TextBox txtTitle;
    protected RequiredFieldValidator rfvTitle;
    protected RegularExpressionValidator regTitle;
    protected TextBox txtTestimonialsDesc;
    protected RequiredFieldValidator rfvDescription;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liTestimonialsManagement");
      this.txtTitle.Focus();
      this.ValidationExpression();
      this.UserId = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      this.fTestimonialsMgmntID = 0L;
      if (this.Request.QueryString["TestimonialsID"] != null)
        this.fTestimonialsMgmntID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["TestimonialsID"].ToString()));
      if (!this.IsPostBack)
      {
        if (this.Request.QueryString["TestimonialsID"] != null)
        {
          this.h1Title.InnerText = "Edit Testimonials";
          this.btnSubmit.Text = "Update";
          this.btnSubmit.ToolTip = "Update";
          this.fTestimonialsMgmntID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["TestimonialsID"].ToString()));
          if (this.Session["UpdateMsg"] != null)
            this.Session["UpdateMsg"] = (object) null;
          this.FillData(this.fTestimonialsMgmntID);
        }
        else
        {
          this.h1Title.InnerText = "Add Testimonials";
          this.btnSubmit.Text = "Save";
          this.btnSubmit.ToolTip = "Save";
        }
      }
      this.txtTestimonialsDesc.Attributes["maxlength"] = "375";
      this.txtTitle.Focus();
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvTitle, true, (object) this.txtTitle, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTitle, Regex.NewsTitle, true, (object) this.txtTitle, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvDescription, true, (object) this.txtTestimonialsDesc, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }

    protected void FillData(long TestimonialsID)
    {
      Entity.Common.Testimonials.Testimonials testimonials = new Entity.Common.Testimonials.Testimonials();
      Entity.Common.Testimonials.Testimonials testimonialsDetailsById = TestimonialsMgmt.GetTestimonialsDetailsByID(TestimonialsID);
      if (testimonialsDetailsById == null)
        return;
      this.txtTitle.Text = testimonialsDetailsById.Title;
      this.txtTestimonialsDesc.Text = testimonialsDetailsById.Description;
      this.chkIsActive.Checked = testimonialsDetailsById.IsActive;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (TestimonialsMgmt.AddUpdateTestimonials(new Entity.Common.Testimonials.Testimonials()
      {
        CreatedBy = Convert.ToInt64(this.UserId),
        TestimonialsID = this.fTestimonialsMgmntID <= 0L ? 0L : this.fTestimonialsMgmntID,
        Title = this.txtTitle.Text.Trim(),
        Description = this.txtTestimonialsDesc.Text.Trim(),
        IsActive = this.chkIsActive.Checked
      }) == -1L)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Testimonials"), (Enums.NotificationType) 2, false), true);
      }
      else
      {
        if (this.fTestimonialsMgmntID > 0L)
          this.Session[nameof (AddUpdateTestimonials)] = (object) string.Format(Messages.UpdateSuccess, (object) "Testimonials");
        else
          this.Session[nameof (AddUpdateTestimonials)] = (object) string.Format(Messages.AddSuccess, (object) "Testimonials");
        this.Response.Redirect("~/Admin/ViewTestimonials.aspx");
      }
    }
  }
}
