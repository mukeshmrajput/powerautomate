﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateHearAboutUs
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.HearAboutUs;
using Entity.Common.HearAboutUs;
using Entity.Response.HearAboutUs;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateHearAboutUs : Page
  {
    public static long fHearAboutUsID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtHearAboutUsName;
    protected RequiredFieldValidator rfvHearAboutUsName;
    protected RegularExpressionValidator regHearAboutUsName;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnHearAboutUsID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liHearAboutUs");
      if (this.Request.QueryString["HearAboutUsID"] != null)
      {
        this.h1Title.InnerText = "Edit Hear About Us";
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        AddUpdateHearAboutUs.fHearAboutUsID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["HearAboutUsID"].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add Hear About Us";
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
        AddUpdateHearAboutUs.fHearAboutUsID = 0L;
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        if (AddUpdateHearAboutUs.fHearAboutUsID > 0L)
          this.GetHearAboutUsDetails(HearAboutUsMgmt.GetHearAboutUsDetailByID(Convert.ToInt64(AddUpdateHearAboutUs.fHearAboutUsID)));
      }
      this.txtHearAboutUsName.Focus();
    }

    protected void GetHearAboutUsDetails(HearAboutUsResponseBE objHearAboutUsBE)
    {
      this.txtHearAboutUsName.Text = objHearAboutUsBE.Name;
      this.chkIsActive.Checked = objHearAboutUsBE.IsActive;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      HearAboutUsBE hearAboutUsBe = new HearAboutUsBE();
      hearAboutUsBe.HearAboutUsID = AddUpdateHearAboutUs.fHearAboutUsID <= 0L ? 0L : AddUpdateHearAboutUs.fHearAboutUsID;
      hearAboutUsBe.Name = this.txtHearAboutUsName.Text.Trim();
      hearAboutUsBe.IsActive = this.chkIsActive.Checked;
      hearAboutUsBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      hearAboutUsBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      if (HearAboutUsMgmt.AddUpdateHearAboutUs(hearAboutUsBe) > 0L)
      {
        if (hearAboutUsBe.HearAboutUsID > 0L)
          this.Session["HearAboutUsAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) "Hear About Us");
        else if (hearAboutUsBe.HearAboutUsID == 0L)
          this.Session["HearAboutUsAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) "Hear About Us");
        this.Response.Redirect("~/Admin/ViewHearAboutUs.aspx");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "Hear About Us"), (Enums.NotificationType) 2, false), true);
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvHearAboutUsName, true, (object) this.txtHearAboutUsName, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
