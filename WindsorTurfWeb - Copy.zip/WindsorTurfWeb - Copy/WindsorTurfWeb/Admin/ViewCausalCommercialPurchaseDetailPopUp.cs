﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.ViewCausalCommercialPurchaseDetailPopUp
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CausalCommercialPurchaseDetail;
using Entity.Common.CausalCommercialPurchaseDetail;
using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class ViewCausalCommercialPurchaseDetailPopUp : Page
  {
    private long RetailPurchaseOrderID = 0;
    protected HtmlForm form1;
    protected HtmlGenericControl h1Title;
    protected Literal lblBillingFirstName;
    protected Literal lblBillingLastName;
    protected Literal lblEmailAddress;
    protected Literal lblBillingBusinessName;
    protected Literal lblBillingCompanyABN;
    protected Literal lblBillingAddressLine1;
    protected Literal lblBillingAddressLine2;
    protected Literal lblBillingHomePhone;
    protected Literal lblBillingSuburb;
    protected Literal lblBillingState;
    protected Literal lblPostCode;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      if (this.Request.QueryString[QueryStrings.RetailPurchaseOrderID] != null)
        this.RetailPurchaseOrderID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.RetailPurchaseOrderID].ToString()));
      if (this.IsPostBack || this.RetailPurchaseOrderID <= 0L)
        return;
      this.FillAllData(CausalCommercialPurchaseDetailMgmt.GetAllCausalCommercialUserPurchaseDetailByID(this.RetailPurchaseOrderID));
    }

    protected void FillAllData(CausalCommercialPurchaseDetailBE obj)
    {
      if (obj == null)
        return;
      this.lblBillingFirstName.Text = obj.BillingFirstName;
      this.lblBillingLastName.Text = obj.BillingLastName;
      this.lblEmailAddress.Text = obj.EmailAddress;
      this.lblBillingBusinessName.Text = !string.IsNullOrEmpty(obj.BillingBusinessName) ? obj.BillingBusinessName : "N/A";
      this.lblBillingCompanyABN.Text = !string.IsNullOrEmpty(obj.BillingCompanyABN) ? obj.BillingCompanyABN : "N/A";
      this.lblBillingAddressLine1.Text = obj.BillingAddressLine1;
      this.lblBillingAddressLine2.Text = !string.IsNullOrEmpty(obj.BillingAddressLine2) ? obj.BillingAddressLine2 : "N/A";
      this.lblBillingHomePhone.Text = obj.BillingHomePhone;
      this.lblBillingSuburb.Text = obj.BillingSuburb;
      this.lblPostCode.Text = obj.BillingPostcode.ToString();
      this.lblBillingState.Text = obj.StateName;
    }
  }
}
