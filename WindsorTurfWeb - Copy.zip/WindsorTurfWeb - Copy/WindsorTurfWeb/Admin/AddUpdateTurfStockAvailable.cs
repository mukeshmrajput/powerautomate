﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdateTurfStockAvailable
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.TurfProductManagement.TurfStockAvailable;
using Entity.Common.StockManagement.TurfProductManagement.TurfStockAvailable;
using Entity.Response.StockManagement.TurfProductManagement.TurfStockAvailable;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdateTurfStockAvailable : Page
  {
    public static long fTurfStockAvailableID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtTurfStockName;
    protected RequiredFieldValidator rfvTurfStockName;
    protected RegularExpressionValidator regTurfStockName;
    protected DropDownList ddlTurfProduct;
    protected RequiredFieldValidator rfvTurfProduct;
    protected TextBox txtTurfStockDesc;
    protected RequiredFieldValidator rfvTurfStockDesc;
    protected CheckBox chkIsActive;
    protected Button btnSubmit;
    protected HiddenField hdnQuantityPriceID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liViewTurfStockAvailable");
      if (this.Request.QueryString[QueryStrings.TurfStockAvailableID] != null)
      {
        this.h1Title.InnerText = "Edit " + PageName.strAddTurfStockAvailable;
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
        AddUpdateTurfStockAvailable.fTurfStockAvailableID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString[QueryStrings.TurfStockAvailableID].ToString()));
      }
      else
      {
        this.h1Title.InnerText = "Add " + PageName.strAddTurfStockAvailable;
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        this.BindDropdown();
        if (AddUpdateTurfStockAvailable.fTurfStockAvailableID > 0L)
          this.GetTurfStockDetails(TurfStockAvailableMgmt.GetTurfStockAvailableDetailByID(Convert.ToInt64(AddUpdateTurfStockAvailable.fTurfStockAvailableID)));
      }
      this.txtTurfStockName.Focus();
    }

    protected void GetTurfStockDetails(
      TurfStockAvailableResponseBE objTurfStockAvailableResponseBE)
    {
      this.txtTurfStockName.Text = Convert.ToString(objTurfStockAvailableResponseBE.Name);
      this.txtTurfStockDesc.Text = Convert.ToString(objTurfStockAvailableResponseBE.Description);
      this.ddlTurfProduct.SelectedValue = Convert.ToString(objTurfStockAvailableResponseBE.TurfProductID);
      this.chkIsActive.Checked = Convert.ToBoolean(objTurfStockAvailableResponseBE.IsActive);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      TurfStockAvailableBE stockAvailableBe = new TurfStockAvailableBE();
      stockAvailableBe.TurfStockAvailableID = AddUpdateTurfStockAvailable.fTurfStockAvailableID <= 0L ? 0L : AddUpdateTurfStockAvailable.fTurfStockAvailableID;
      stockAvailableBe.Name = this.txtTurfStockName.Text.Trim();
      stockAvailableBe.Description = this.txtTurfStockDesc.Text.Trim();
      stockAvailableBe.TurfProductID = Convert.ToInt64(this.ddlTurfProduct.SelectedValue);
      stockAvailableBe.IsActive = this.chkIsActive.Checked;
      stockAvailableBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      stockAvailableBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      long num = TurfStockAvailableMgmt.AddUpdateTurfStockAvailable(stockAvailableBe);
      if (num > 0L)
      {
        if (stockAvailableBe.TurfStockAvailableID > 0L)
          this.Session["TurfStockAvailableAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) PageName.strAddTurfStockAvailable);
        else if (stockAvailableBe.TurfStockAvailableID == 0L)
          this.Session["TurfStockAvailableAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) PageName.strAddTurfStockAvailable);
        this.Response.Redirect("~/Admin/ViewTurfStockAvailable.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) PageName.strAddTurfStockAvailable), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/ViewTurfStockAvailable.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvTurfStockName, true, (object) this.txtTurfStockName, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regTurfStockName, Regex.Title, true, (object) this.txtTurfStockName, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvTurfStockDesc, true, (object) this.txtTurfStockDesc, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvTurfProduct, true, (object) this.ddlTurfProduct, "-1", this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }

    protected void BindDropdown() => BindDropDown.BindTurfProduct((ListControl) this.ddlTurfProduct);
  }
}
