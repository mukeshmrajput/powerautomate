﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddNewsletter
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Newsletter;
using Helper;
using Resources;
using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Admin
{
  public class AddNewsletter : Page
  {
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl divTab;
    protected HtmlGenericControl divMessage;
    protected Literal ltrMessage;
    protected TextBox txtEmailAddress;
    protected RequiredFieldValidator rfvEmailAddress;
    protected RegularExpressionValidator regEmailAddress;
    protected Button btnSubmit;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liNewsletterList");
      this.ValidationExpression();
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvEmailAddress, true, (object) this.txtEmailAddress, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regEmailAddress, Regex.Email, true, (object) this.txtEmailAddress, this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (NewsletterMgmt.CheckEmailExists(this.txtEmailAddress.Text.Trim(), 0L))
      {
        NewsletterMgmt.AddNewsLetter(this.FillAddData());
        this.divMessage.Visible = true;
        this.txtEmailAddress.Text = "";
        this.Session[nameof (AddNewsletter)] = (object) "AddSuccessfully";
        this.Response.Redirect("~/Admin/Newsletterlist.aspx");
      }
      else
      {
        this.divMessage.Visible = true;
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExistsEmail, (object) "Email Address"), (Enums.NotificationType) 3), true);
        this.txtEmailAddress.Text = "";
      }
    }

    private Entity.Common.Newsletter.Newsletter FillAddData() => new Entity.Common.Newsletter.Newsletter()
    {
      Email = this.txtEmailAddress.Text.Trim()
    };
  }
}
