﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AdminTurfDescription
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Response.PageManagement;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Admin.UserControl;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AdminTurfDescription : Page
  {
    private DataTable dt = new DataTable();
    private DataTable dtAdminCART;
    private DataTable dtQUOTE;
    private DataRow drProduct;
    public string HeaderImagePath = ConfigurationManager.AppSettings["ImagePath"];
    public string strFinalPageTitle;
    protected HtmlGenericControl divTab;
    protected WebUserControl1 AdminPurchaseProcess1;
    protected HtmlImage imgProductImage;
    protected Label lblTurfName;
    protected Label lblPriceName;
    protected Label lblMainPrice;
    protected HtmlGenericControl divStockUnavailable;
    protected Literal ltrDescription;
    protected HtmlGenericControl divAddToCart;
    protected Label lblAreaSize;
    protected TextBox txtAreaSize;
    protected RequiredFieldValidator rfvAreaSize;
    protected RegularExpressionValidator regAreaSize;
    protected CompareValidator cvAreaSize;
    protected Label lblTotalPrice;
    protected ImageButton BtnAddtoCart;
    protected HtmlGenericControl divUses;
    protected Literal ltruses;
    protected HtmlGenericControl divMaintenance;
    protected Literal ltrMaintenance;
    protected HtmlGenericControl divCharacteristics;
    protected Literal ltrCharacteristics;
    protected HiddenField hdnTurfProductID;
    protected HiddenField hdnTurfZoneID;
    protected HiddenField hdnTurfType;
    protected HiddenField hdnPageTitle;
    protected HiddenField hdnPlaceOrderUserType;
    protected HiddenField hdnCommercialRegistration;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      this.txtAreaSize.Focus();
      if (this.Session["dtAdminCART"] != null)
      {
        DataTable dataTable = (DataTable) this.Session["dtAdminCART"];
      }
      if (this.IsPostBack)
        return;
      if (this.Session["PlaceOrderType"] != null && !string.IsNullOrEmpty(this.Session["PlaceOrderType"].ToString()))
        this.hdnPlaceOrderUserType.Value = Convert.ToString(this.Session["PlaceOrderType"]);
      if (this.Session["CommercialRegistration"] != null && !string.IsNullOrEmpty(this.Session["CommercialRegistration"].ToString()))
        this.hdnCommercialRegistration.Value = Convert.ToString(this.Session["CommercialRegistration"]);
      this.BtnAddtoCart.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.HeaderImagePath + "add-to-cart.png";
      this.BtnAddtoCart.Focus();
      if (this.Request.QueryString[QueryStrings.TurfID] != null)
      {
        string[] strArray1 = this.Request.QueryString[QueryStrings.TurfID].ToString().ToString().Split('$');
        string empty1 = string.Empty;
        string empty2 = string.Empty;
        string empty3 = string.Empty;
        if (!string.IsNullOrEmpty(strArray1[1].ToString()))
        {
          string[] strArray2 = strArray1[1].ToString().Split('_');
          empty2 = strArray2[0].ToString();
          this.hdnTurfType.Value = empty2;
          empty3 = strArray2[1].ToString();
          empty1 = strArray2[2].ToString();
        }
        if (!string.IsNullOrEmpty(empty1))
        {
          this.Session["TurfId"] = (object) Encryption.DecryptQueryString(empty1);
          this.hdnTurfProductID.Value = this.Session["TurfId"].ToString();
          if (!string.IsNullOrEmpty(this.hdnTurfProductID.Value))
          {
            this.Session["TurfZoneID"] = (object) Encryption.DecryptQueryString(empty3);
            this.hdnTurfZoneID.Value = this.Session["TurfZoneID"].ToString();
            if (empty2 == ((Enums.TurfProductType) 1).ToString())
              this.BindTurfProductDetailsByIDForFront(TurfProductMgmt.GetTurfProductDetailsByIDForAdmin(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID()));
            else if (empty2 == ((Enums.TurfProductType) 2).ToString())
              this.BindNonTurfProductDetailsByIDForFront(NonTurfProductMgmt.GetNonTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID()));
          }
        }
        else
          this.Response.Redirect("/default.aspx");
      }
      else
        this.Response.Redirect("/default.aspx");
    }

    protected void BindTurfProductDetailsByIDForFront(TurfProductResponseBE objTurf)
    {
      if (objTurf != null)
      {
        PageManagementResponseBE objDesc = new PageManagementResponseBE();
        objDesc.PageName = objTurf.PageName;
        objDesc.MetaDescription = objTurf.MetaDescription;
        objDesc.MetaKeyword = objTurf.MetaKeyword;
        objDesc.PageTitle = objTurf.PageTitle;
        this.strFinalPageTitle = objTurf.PageTitle;
        this.hdnPageTitle.Value = objTurf.PageTitle;
        PageBase.SetSEO(objDesc);
        if (!string.IsNullOrEmpty(objTurf.MainImage))
          this.imgProductImage.Src = ConfigurationManager.AppSettings["Livepath"].ToString() + ConfigurationManager.AppSettings["TurfContentPageImagePath"].ToString() + objTurf.MainImage.ToString();
        this.lblTurfName.Text = objTurf.TurfName;
        this.lblPriceName.Text = "Price Per Metre : $";
        this.lblAreaSize.Text = "Area size(m<sub>2</sub>) :";
        this.lblMainPrice.Text = string.Format("{0:0.00}", (object) double.Parse(objTurf.FinalPrice.ToString()));
        this.lblTotalPrice.Text = string.Format("{0:0.00}", (object) double.Parse(objTurf.FinalPrice.ToString()));
        this.ltrDescription.Text = objTurf.Description;
        if (!string.IsNullOrEmpty(objTurf.Uses))
          this.ltruses.Text = objTurf.Uses;
        else
          this.divUses.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Maintenance))
          this.ltrMaintenance.Text = objTurf.Maintenance;
        else
          this.divMaintenance.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Characteristics))
          this.ltrCharacteristics.Text = objTurf.Characteristics;
        else
          this.divCharacteristics.Visible = false;
        if (!objTurf.TurfStockStatus)
        {
          this.divAddToCart.Visible = false;
          this.divStockUnavailable.Visible = true;
        }
        else
        {
          this.divAddToCart.Visible = true;
          this.divStockUnavailable.Visible = false;
        }
      }
      else
        this.Response.Redirect("/default.aspx");
    }

    protected void BindNonTurfProductDetailsByIDForFront(NonTurfProductResponseBE objTurf)
    {
      if (objTurf != null)
      {
        PageManagementResponseBE objDesc = new PageManagementResponseBE();
        objDesc.PageName = objTurf.PageName;
        objDesc.MetaDescription = objTurf.MetaDescription;
        objDesc.MetaKeyword = objTurf.MetaKeyword;
        objDesc.PageTitle = objTurf.PageTitle;
        this.strFinalPageTitle = objTurf.PageTitle;
        this.hdnPageTitle.Value = objTurf.PageTitle;
        PageBase.SetSEO(objDesc);
        this.imgProductImage.Src = ConfigurationManager.AppSettings["Livepath"].ToString() + ConfigurationManager.AppSettings["TurfContentPageImagePath"].ToString() + objTurf.MainImage.ToString();
        this.lblTurfName.Text = objTurf.NonTurfName;
        this.lblPriceName.Text = "Price Per Item : $";
        this.lblAreaSize.Text = "Quantity";
        Label lblMainPrice = this.lblMainPrice;
        Decimal finalPrice = objTurf.FinalPrice;
        string str1 = string.Format("{0:0.00}", (object) double.Parse(finalPrice.ToString()));
        lblMainPrice.Text = str1;
        Label lblTotalPrice = this.lblTotalPrice;
        finalPrice = objTurf.FinalPrice;
        string str2 = string.Format("{0:0.00}", (object) double.Parse(finalPrice.ToString()));
        lblTotalPrice.Text = str2;
        this.ltrDescription.Text = objTurf.Description;
        if (!string.IsNullOrEmpty(objTurf.Uses))
          this.ltruses.Text = objTurf.Uses;
        else
          this.divUses.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Maintenance))
          this.ltrMaintenance.Text = objTurf.Maintenance;
        else
          this.divMaintenance.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Characteristics))
          this.ltrCharacteristics.Text = objTurf.Characteristics;
        else
          this.divCharacteristics.Visible = false;
        if (!objTurf.NonTurfStockStatus)
        {
          this.divAddToCart.Visible = false;
          this.divStockUnavailable.Visible = true;
        }
        else
        {
          this.divAddToCart.Visible = true;
          this.divStockUnavailable.Visible = false;
        }
      }
      else
        this.Response.Redirect("/default.aspx");
    }

    private DataTable AddColumns(DataTable dtAdminCART)
    {
      dtAdminCART.Columns.Add(new DataColumn("TurfProductID", typeof (long)));
      dtAdminCART.Columns.Add(new DataColumn("OrderNo", typeof (string)));
      dtAdminCART.Columns.Add(new DataColumn("TurfClassificationID", typeof (long)));
      dtAdminCART.Columns.Add(new DataColumn("TurfName", typeof (string)));
      dtAdminCART.Columns.Add(new DataColumn("TurfType", typeof (string)));
      dtAdminCART.Columns.Add(new DataColumn("Price", typeof (double)));
      dtAdminCART.Columns.Add(new DataColumn("Quantity", typeof (double)));
      dtAdminCART.Columns.Add(new DataColumn("Type", typeof (int)));
      dtAdminCART.Columns.Add(new DataColumn("MainImage", typeof (string)));
      dtAdminCART.Columns.Add(new DataColumn("ProductType", typeof (int)));
      dtAdminCART.Columns.Add(new DataColumn("TurfZoneID", typeof (long)));
      return dtAdminCART;
    }

    protected void AddItem()
    {
      Convert.ToInt32(this.hdnTurfProductID.Value.ToString());
      if (this.hdnTurfType.Value == ((Enums.TurfProductType) 1).ToString())
      {
        TurfProductResponseBE detailsByIdForAdmin = TurfProductMgmt.GetTurfProductDetailsByIDForAdmin(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
        if (this.Session["dtAdminCART"] == null)
        {
          this.dtAdminCART = new DataTable();
          this.dtAdminCART = this.AddColumns(this.dtAdminCART);
          this.drProduct = this.dtAdminCART.NewRow();
          this.Session["identity"] = (object) "1";
          this.drProduct["TurfProductID"] = (object) detailsByIdForAdmin.TurfProductID;
          this.drProduct["OrderNo"] = (object) (detailsByIdForAdmin.TurfProductID.ToString() + "|" + detailsByIdForAdmin.TurfName);
          this.drProduct["TurfClassificationID"] = (object) detailsByIdForAdmin.TurfClassificationID;
          this.drProduct["TurfName"] = (object) detailsByIdForAdmin.TurfName;
          this.drProduct["Price"] = (object) detailsByIdForAdmin.FinalPrice;
          this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
          this.drProduct["MainImage"] = (object) detailsByIdForAdmin.MainImage;
          this.drProduct["Type"] = (object) 0;
          this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 1;
          this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
          this.drProduct["TurfType"] = (object) "Turf Selection";
          this.dtAdminCART.Rows.Add(this.drProduct);
          this.Session["dtAdminCART"] = (object) this.dtAdminCART;
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForAdmin.TurfName.ToString()), (Enums.NotificationType) 1), true);
          this.SetCartValue(this.dtAdminCART);
          this.Response.Redirect("~/Admin/AdminCheckoutPage.aspx");
        }
        else
        {
          this.dtAdminCART = new DataTable();
          this.dtAdminCART = (DataTable) this.Session["dtAdminCART"];
          bool flag = false;
          for (int index = 0; index < this.dtAdminCART.Rows.Count; ++index)
          {
            if (this.dtAdminCART.Rows[index]["OrderNo"].ToString() == detailsByIdForAdmin.TurfProductID.ToString() + "|" + detailsByIdForAdmin.TurfName)
            {
              flag = true;
              this.SetCartValue(this.dtAdminCART);
            }
          }
          if (!flag)
          {
            this.drProduct = this.dtAdminCART.NewRow();
            this.drProduct["TurfProductID"] = (object) Convert.ToString(this.dtAdminCART.Rows.Count + 1);
            this.Session["identity"] = (object) (Convert.ToInt32(this.Session["identity"].ToString()) + 1).ToString();
            this.drProduct["TurfProductID"] = (object) detailsByIdForAdmin.TurfProductID;
            this.drProduct["OrderNo"] = (object) (detailsByIdForAdmin.TurfProductID.ToString() + "|" + detailsByIdForAdmin.TurfName);
            this.drProduct["TurfClassificationID"] = (object) detailsByIdForAdmin.TurfClassificationID;
            this.drProduct["TurfName"] = (object) detailsByIdForAdmin.TurfName;
            this.drProduct["Price"] = (object) detailsByIdForAdmin.FinalPrice;
            this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
            this.drProduct["MainImage"] = (object) detailsByIdForAdmin.MainImage;
            this.drProduct["Type"] = (object) 0;
            this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 1;
            this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
            this.drProduct["TurfType"] = (object) "Turf Selection";
            this.dtAdminCART.Rows.Add(this.drProduct);
            this.Session["dtAdminCART"] = (object) this.dtAdminCART;
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForAdmin.TurfName.ToString()), (Enums.NotificationType) 1), true);
            this.SetCartValue(this.dtAdminCART);
            this.Response.Redirect("~/Admin/AdminCheckoutPage.aspx");
          }
          else
          {
            this.strFinalPageTitle = this.hdnPageTitle.Value;
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadySelectedTurf), (Enums.NotificationType) 2), true);
          }
        }
      }
      else
      {
        if (!(this.hdnTurfType.Value == ((Enums.TurfProductType) 2).ToString()))
          return;
        NonTurfProductResponseBE detailsByIdForFront = NonTurfProductMgmt.GetNonTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
        if (this.Session["dtAdminCART"] == null)
        {
          this.dtAdminCART = new DataTable();
          this.dtAdminCART = this.AddColumns(this.dtAdminCART);
          this.drProduct = this.dtAdminCART.NewRow();
          this.Session["identity"] = (object) "1";
          this.drProduct["TurfProductID"] = (object) detailsByIdForFront.NonTurfProductID;
          this.drProduct["OrderNo"] = (object) (detailsByIdForFront.NonTurfProductID.ToString() + "|" + detailsByIdForFront.NonTurfName);
          this.drProduct["TurfClassificationID"] = (object) detailsByIdForFront.NonTurfClassificationID;
          this.drProduct["TurfName"] = (object) detailsByIdForFront.NonTurfName;
          this.drProduct["Price"] = (object) detailsByIdForFront.FinalPrice;
          this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
          this.drProduct["MainImage"] = (object) detailsByIdForFront.MainImage;
          this.drProduct["Type"] = (object) 0;
          this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 2;
          this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
          this.drProduct["TurfType"] = (object) "Turf Care";
          this.dtAdminCART.Rows.Add(this.drProduct);
          this.Session["dtAdminCART"] = (object) this.dtAdminCART;
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForFront.NonTurfName.ToString()), (Enums.NotificationType) 1), true);
          this.SetCartValue(this.dtAdminCART);
          this.Response.Redirect("~/Admin/AdminCheckoutPage.aspx");
        }
        else
        {
          this.dtAdminCART = new DataTable();
          this.dtAdminCART = (DataTable) this.Session["dtAdminCART"];
          bool flag = false;
          for (int index = 0; index < this.dtAdminCART.Rows.Count; ++index)
          {
            if (this.dtAdminCART.Rows[index]["OrderNo"].ToString() == detailsByIdForFront.NonTurfProductID.ToString() + "|" + detailsByIdForFront.NonTurfName)
            {
              flag = true;
              this.SetCartValue(this.dtAdminCART);
            }
          }
          if (!flag)
          {
            this.drProduct = this.dtAdminCART.NewRow();
            this.drProduct["TurfProductID"] = (object) Convert.ToString(this.dtAdminCART.Rows.Count + 1);
            this.Session["identity"] = (object) (Convert.ToInt32(this.Session["identity"].ToString()) + 1).ToString();
            this.drProduct["TurfProductID"] = (object) detailsByIdForFront.NonTurfProductID;
            this.drProduct["OrderNo"] = (object) (detailsByIdForFront.NonTurfProductID.ToString() + "|" + detailsByIdForFront.NonTurfName);
            this.drProduct["TurfClassificationID"] = (object) detailsByIdForFront.NonTurfClassificationID;
            this.drProduct["TurfName"] = (object) detailsByIdForFront.NonTurfName;
            this.drProduct["Price"] = (object) detailsByIdForFront.FinalPrice;
            this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
            this.drProduct["MainImage"] = (object) detailsByIdForFront.MainImage;
            this.drProduct["Type"] = (object) 0;
            this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 2;
            this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
            this.drProduct["TurfType"] = (object) "Turf Care";
            this.dtAdminCART.Rows.Add(this.drProduct);
            this.Session["dtAdminCART"] = (object) this.dtAdminCART;
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForFront.NonTurfName.ToString()), (Enums.NotificationType) 1), true);
            this.SetCartValue(this.dtAdminCART);
            this.Response.Redirect("~/Admin/AdminCheckoutPage.aspx");
          }
          else
          {
            this.strFinalPageTitle = this.hdnPageTitle.Value;
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadySelectedTurf), (Enums.NotificationType) 2), true);
          }
        }
      }
    }

    protected void BtnAddtoCart_Click(object sender, ImageClickEventArgs e)
    {
      if (Convert.ToDouble(this.txtAreaSize.Text) <= 0.0)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AreaSizeValidation), (Enums.NotificationType) 2), true);
      }
      else
      {
        this.dt.Clear();
        if (this.hdnTurfType.Value == ((Enums.TurfProductType) 1).ToString())
        {
          TurfProductResponseBE productResponseBe = new TurfProductResponseBE();
          if (TurfProductMgmt.GetTurfRangeForPurchase(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), Convert.ToDecimal(this.txtAreaSize.Text), (long) UtilityFunctions.GetFrontUserID()) != null)
          {
            this.AddItem();
          }
          else
          {
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.InvalidRangePurchase), (Enums.NotificationType) 2), true);
            this.txtAreaSize.Focus();
          }
        }
        else
        {
          if (!(this.hdnTurfType.Value == ((Enums.TurfProductType) 2).ToString()))
            return;
          NonTurfProductResponseBE productResponseBe = new NonTurfProductResponseBE();
          if (NonTurfProductMgmt.GetNonQuantityRangeForPurchase(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), Convert.ToDecimal(this.txtAreaSize.Text), (long) UtilityFunctions.GetFrontUserID()) != null)
          {
            this.AddItem();
          }
          else
          {
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.InvalidRangePurchase), (Enums.NotificationType) 2), true);
            this.txtAreaSize.Focus();
          }
        }
      }
    }

    protected void SetCartValue(DataTable dtAdminCART)
    {
      Label control = (Label) this.AdminPurchaseProcess1.FindControl("ltradmin_cart");
      control.Text = "Cart (" + dtAdminCART.Rows.Count.ToString() + ")";
      control.ToolTip = "Cart (" + dtAdminCART.Rows.Count.ToString() + ")";
    }
  }
}
