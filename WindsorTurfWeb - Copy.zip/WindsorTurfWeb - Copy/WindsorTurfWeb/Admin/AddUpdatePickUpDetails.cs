﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Admin.AddUpdatePickUpDetails
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PickUpEditor;
using Entity.Common.PickUpEditor;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Admin
{
  public class AddUpdatePickUpDetails : Page
  {
    public static long fPickUpDetailID = 0;
    public string strValidationTurfGrp = "TurfGrpValidation";
    protected HtmlGenericControl h1Title;
    protected TextBox txtPickUpAddress;
    protected RequiredFieldValidator rfvPickUpAddress;
    protected RegularExpressionValidator regPickUpAddress;
    protected DropDownList ddlCustomerAppliesTo;
    protected RequiredFieldValidator rfvCustomerAppliesTo;
    protected DropDownList ddlTurfAreaSize;
    protected RequiredFieldValidator rfvTurfAreaSize;
    protected TextBox txtPickupServiceFee;
    protected RequiredFieldValidator rfvPickupServiceFee;
    protected RegularExpressionValidator regPickupServiceFee;
    protected Button btnSubmit;
    protected HiddenField hdnPickUpDetailID;

    protected void Page_Load(object sender, EventArgs e)
    {
      UtilityFunctions.CheckAccessOfLoginUser();
      UtilityFunctions.CheckUserModuleAccessOnPage("liPickUpEditor");
      if (!string.IsNullOrEmpty(this.Request.QueryString["PickUpDetailID"]))
      {
        AddUpdatePickUpDetails.fPickUpDetailID = Convert.ToInt64(Encryption.DecryptQueryString(this.Request.QueryString["PickUpDetailID"].ToString()));
        this.h1Title.InnerText = "Edit PickUp Detail";
        this.btnSubmit.Text = "Update";
        this.btnSubmit.ToolTip = "Update";
      }
      else
      {
        AddUpdatePickUpDetails.fPickUpDetailID = 0L;
        this.h1Title.InnerText = "Add PickUp Detail";
        this.btnSubmit.Text = "Save";
        this.btnSubmit.ToolTip = "Save";
      }
      if (!this.IsPostBack)
      {
        this.ValidationExpression();
        this.BindDropDown();
        if (AddUpdatePickUpDetails.fPickUpDetailID > 0L)
          this.GetPickUpDetails(PickUpDetailMgmt.GetPickUpDetailByPickUpDetailID(Convert.ToInt64(AddUpdatePickUpDetails.fPickUpDetailID)));
      }
      this.txtPickUpAddress.Focus();
    }

    protected void GetPickUpDetails(PickUpDetailsBE objPickUpDetailsBE)
    {
      this.txtPickUpAddress.Text = objPickUpDetailsBE.PickUpAddress;
      this.ddlTurfAreaSize.SelectedValue = Convert.ToString(objPickUpDetailsBE.TurfRangeID);
      this.ddlCustomerAppliesTo.SelectedValue = Convert.ToString(objPickUpDetailsBE.CustomerAppliesTo);
      this.txtPickupServiceFee.Text = Convert.ToString(objPickUpDetailsBE.objTurfPricePickUp.Price);
    }

    protected void BindDropDown()
    {
      WindsorTurfWeb.Common.BindDropDown.BindDropDownByTag((ListControl) this.ddlCustomerAppliesTo, (Enums.DropdownListTag) 1, "CustomerAppliesTo");
      WindsorTurfWeb.Common.BindDropDown.BindTurfRange((ListControl) this.ddlTurfAreaSize);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      PickUpDetailsBE pickUpDetailsBe = new PickUpDetailsBE();
      pickUpDetailsBe.PickUpDetailID = AddUpdatePickUpDetails.fPickUpDetailID <= 0L ? 0L : AddUpdatePickUpDetails.fPickUpDetailID;
      pickUpDetailsBe.PickUpAddress = this.txtPickUpAddress.Text.Trim();
      pickUpDetailsBe.TurfRangeID = Convert.ToInt64(this.ddlTurfAreaSize.SelectedValue);
      pickUpDetailsBe.objTurfPricePickUp.Price = Convert.ToDecimal(this.txtPickupServiceFee.Text.Trim());
      pickUpDetailsBe.CustomerAppliesTo = Convert.ToInt32(this.ddlCustomerAppliesTo.SelectedValue);
      pickUpDetailsBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      pickUpDetailsBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      long num = PickUpDetailMgmt.AddUpdatePickupDetails(pickUpDetailsBe);
      if (num > 0L)
      {
        if (pickUpDetailsBe.PickUpDetailID > 0L)
          this.Session["PickUpDetailAddUpdate"] = (object) string.Format(Messages.UpdateSuccess, (object) "PickUp Detail");
        else if (pickUpDetailsBe.PickUpDetailID == 0L)
          this.Session["PickUpDetailAddUpdate"] = (object) string.Format(Messages.AddSuccess, (object) "PickUp Detail");
        this.Response.Redirect("~/Admin/ViewPickUpDetails.aspx");
      }
      else if (num == -1L)
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotification(string.Format(Messages.AlreadyExists.ToString(), (object) "PickUp Detail"), (Enums.NotificationType) 2, false), true);
    }

    protected void btnCancel_Click(object sender, EventArgs e) => this.Response.Redirect("~/Admin/Welcome.aspx");

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidator(this.rfvPickUpAddress, true, (object) this.txtPickUpAddress, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regPickUpAddress, Regex.Address, true, (object) this.txtPickUpAddress, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidator(this.rfvPickupServiceFee, true, (object) this.txtPickupServiceFee, this.strValidationTurfGrp);
      Validations.SetRegularExpressionValidator(this.regPickupServiceFee, Regex.NumericWithDecimal, true, (object) this.txtPickupServiceFee, this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvCustomerAppliesTo, true, (object) this.ddlCustomerAppliesTo, "-1", this.strValidationTurfGrp);
      Validations.SetRequiredFieldValidatorDropdown(this.rfvTurfAreaSize, true, (object) this.ddlTurfAreaSize, "-1", this.strValidationTurfGrp);
      this.btnSubmit.ValidationGroup = this.strValidationTurfGrp;
    }
  }
}
