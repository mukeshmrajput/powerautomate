﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.TurfContentDetailPage
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Response.PageManagement;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using System;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class TurfContentDetailPage : Page
  {
    private DataTable dt = new DataTable();
    private DataTable dtCART;
    private DataTable dtQUOTE;
    private DataRow drProduct;
    public string HeaderImagePath = ConfigurationManager.AppSettings["ImagePath"];
    public string strFinalPageTitle;
    protected HiddenField hdnTurfProductID;
    protected HiddenField hdnTurfZoneID;
    protected HiddenField hdnTurfType;
    protected HiddenField hdnPageTitle;
    protected HtmlImage imgProductImage;
    protected Label lblTurfName;
    protected Label lblPriceName;
    protected Label lblMainPrice;
    protected Literal ltrDescription;
    protected HtmlGenericControl divUses;
    protected Literal ltruses;
    protected HtmlGenericControl divMaintenance;
    protected Literal ltrMaintenance;
    protected HtmlGenericControl divCharacteristics;
    protected Literal ltrCharacteristics;
    protected HiddenField hdnPlaceOrderUserType;
    protected HiddenField hdnCommercialRegistration;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      if (this.IsPostBack)
        return;
      UtilityFunctions.SetDefaultCommonHeader(this.Page, "", "");
      string[] strArray1 = this.Request.Url.ToString().Split(new string[1]
      {
        "Type1="
      }, StringSplitOptions.None);
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      if (!string.IsNullOrEmpty(strArray1[1].ToString()))
      {
        string[] strArray2 = strArray1[1].ToString().Split('_');
        empty2 = strArray2[0].ToString();
        this.hdnTurfType.Value = empty2;
        empty3 = strArray2[1].ToString();
        empty1 = strArray2[2].ToString();
      }
      if (!string.IsNullOrEmpty(empty1))
      {
        this.Session["TurfId"] = (object) Encryption.DecryptQueryString(empty1);
        this.hdnTurfProductID.Value = this.Session["TurfId"].ToString();
        if (!string.IsNullOrEmpty(this.hdnTurfProductID.Value))
        {
          this.Session["TurfZoneID"] = (object) Encryption.DecryptQueryString(empty3);
          this.hdnTurfZoneID.Value = this.Session["TurfZoneID"].ToString();
          if (empty2 == ((Enums.TurfProductType) 1).ToString())
            this.BindTurfProductDetailsByIDForFront(TurfProductMgmt.GetTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID()));
          else if (empty2 == ((Enums.TurfProductType) 2).ToString())
            this.BindNonTurfProductDetailsByIDForFront(NonTurfProductMgmt.GetNonTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID()));
        }
      }
      else
        this.Response.Redirect("/default.aspx");
    }

    protected void BindTurfProductDetailsByIDForFront(TurfProductResponseBE objTurf)
    {
      if (objTurf != null)
      {
        PageManagementResponseBE objDesc = new PageManagementResponseBE();
        objDesc.PageName = objTurf.PageName;
        objDesc.MetaDescription = objTurf.MetaDescription;
        objDesc.MetaKeyword = objTurf.MetaKeyword;
        objDesc.PageTitle = objTurf.PageTitle;
        this.strFinalPageTitle = objTurf.PageTitle;
        this.hdnPageTitle.Value = objTurf.PageTitle;
        Literal control1 = (Literal) this.Master.FindControl("ltrPageName");
        Literal control2 = (Literal) this.Master.FindControl("ltrMainPageName");
        control1.Text = objTurf.TurfName;
        control2.Text = objTurf.TurfName;
        PageBase.SetSEO(objDesc);
        this.imgProductImage.Src = ConfigurationManager.AppSettings["Livepath"].ToString() + ConfigurationManager.AppSettings["TurfContentPageImagePath"].ToString() + objTurf.MainImage.ToString();
        this.lblTurfName.Text = objTurf.TurfName;
        this.lblPriceName.Text = "Price Per Metre : $";
        this.lblMainPrice.Text = string.Format("{0:0.00}", (object) double.Parse(objTurf.FinalPrice.ToString()));
        this.ltrDescription.Text = objTurf.Description;
        if (!string.IsNullOrEmpty(objTurf.Uses))
          this.ltruses.Text = objTurf.Uses;
        else
          this.divUses.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Maintenance))
          this.ltrMaintenance.Text = objTurf.Maintenance;
        else
          this.divMaintenance.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Characteristics))
          this.ltrCharacteristics.Text = objTurf.Characteristics;
        else
          this.divCharacteristics.Visible = false;
      }
      else
        this.Response.Redirect("/default.aspx");
    }

    protected void BindNonTurfProductDetailsByIDForFront(NonTurfProductResponseBE objTurf)
    {
      if (objTurf != null)
      {
        PageManagementResponseBE objDesc = new PageManagementResponseBE();
        objDesc.PageName = objTurf.PageName;
        objDesc.MetaDescription = objTurf.MetaDescription;
        objDesc.MetaKeyword = objTurf.MetaKeyword;
        objDesc.PageTitle = objTurf.PageTitle;
        this.strFinalPageTitle = objTurf.PageTitle;
        this.hdnPageTitle.Value = objTurf.PageTitle;
        Literal control1 = (Literal) this.Master.FindControl("ltrPageName");
        Literal control2 = (Literal) this.Master.FindControl("ltrMainPageName");
        control1.Text = objTurf.NonTurfName;
        control2.Text = objTurf.NonTurfName;
        PageBase.SetSEO(objDesc);
        this.imgProductImage.Src = ConfigurationManager.AppSettings["Livepath"].ToString() + ConfigurationManager.AppSettings["TurfContentPageImagePath"].ToString() + objTurf.MainImage.ToString();
        this.lblTurfName.Text = objTurf.NonTurfName;
        this.lblPriceName.Text = "Price Per Item : $";
        this.lblMainPrice.Text = string.Format("{0:0.00}", (object) double.Parse(objTurf.FinalPrice.ToString()));
        this.ltrDescription.Text = objTurf.Description;
        if (!string.IsNullOrEmpty(objTurf.Uses))
          this.ltruses.Text = objTurf.Uses;
        else
          this.divUses.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Maintenance))
          this.ltrMaintenance.Text = objTurf.Maintenance;
        else
          this.divMaintenance.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Characteristics))
          this.ltrCharacteristics.Text = objTurf.Characteristics;
        else
          this.divCharacteristics.Visible = false;
      }
      else
        this.Response.Redirect("/default.aspx");
    }
  }
}
