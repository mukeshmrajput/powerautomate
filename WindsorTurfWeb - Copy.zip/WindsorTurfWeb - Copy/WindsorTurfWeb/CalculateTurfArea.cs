﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.CalculateTurfArea
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Miscellaneous;
using BLL.PageManagement;
using BLL.QuoteDetail;
using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Common.Miscellaneous;
using Entity.Common.PurchaseOrderDetail;
using Entity.Common.QuoteDetail;
using Entity.Response.PageManagement;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb
{
  public class CalculateTurfArea : Page
  {
    private DataTable _dtQUOTE = new DataTable();
    private DataTable _dtQuoteDetail = new DataTable();
    private DataRow drProduct;
    public string strValidationTurfGrp = "TurfGrpValidation";
    private Decimal strPrice = 0M;
    private double quan;
    private double total;
    private double subtotal;
    private double netQty;
    protected UpdatePanel UpdatePanel1;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected HtmlGenericControl divContinueShopBtn;
    protected Button btnContShopping;
    protected Literal ltrTriangularArea1;
    protected TextBox txtTriArea1Length;
    protected TextBox txtTriArea1Width;
    protected TextBox txtTriArea1Qty;
    protected Literal ltrTriangularArea2;
    protected TextBox txtTriArea2Length;
    protected TextBox txtTriArea2Width;
    protected TextBox txtTriArea2Qty;
    protected Literal ltrTriangularArea3;
    protected TextBox txtTriArea3Length;
    protected TextBox txtTriArea3Width;
    protected TextBox txtTriArea3Qty;
    protected TextBox txtTotalTriangularArea;
    protected Button btnTriangular;
    protected Literal ltrRectangularArea1;
    protected TextBox txtRectArea1Length;
    protected TextBox txtRectArea1Width;
    protected TextBox txtRectArea1Qty;
    protected Literal ltrRectangularArea2;
    protected TextBox txtRectArea2Length;
    protected TextBox txtRectArea2Width;
    protected TextBox txtRectArea2Qty;
    protected Literal ltrRectangularArea3;
    protected TextBox txtRectArea3Length;
    protected TextBox txtRectArea3Width;
    protected TextBox txtRectArea3Qty;
    protected TextBox txtlblTotalRectangularArea;
    protected Button btnCalculateRectangular;
    protected Literal ltrCircularArea1;
    protected TextBox txtCircArea1Diameter;
    protected TextBox txtCircArea1Qty;
    protected Literal ltrCircularArea2;
    protected TextBox txtCircArea2Diameter;
    protected TextBox txtCircArea2Qty;
    protected Literal ltrCircularArea3;
    protected TextBox txtCircArea3Diameter;
    protected TextBox txtCircArea3Qty;
    protected TextBox txtTotalCircularArea;
    protected Button btnTotalCircularArea;
    protected Literal ltrHalfCircularArea1;
    protected TextBox txtHalfCircArea1Diameter;
    protected TextBox txtHalfCircArea1Qty;
    protected Literal ltrHalfCircularArea2;
    protected TextBox txtHalfCircArea2Diameter;
    protected TextBox txtHalfCircArea2Qty;
    protected Literal ltrHalfCircularArea3;
    protected TextBox txtHalfCircArea3Diameter;
    protected TextBox txtHalfCircArea3Qty;
    protected TextBox txtHalfCircularArea;
    protected Button btnHalfCircularArea;
    protected TextBox txtTotalAllArea;
    protected HtmlGenericControl DivrdbLaying;
    protected RadioButtonList rdbLaying;
    protected Button btnContinue;
    protected Literal ltrPostCode;
    protected Literal ltrGSTVal;
    protected HiddenField hdnGSTVal;
    protected HiddenField hdnPostCode;
    protected HiddenField hdnPickupDelivery;
    protected HiddenField hdnPickUpPrice;
    protected HiddenField hdnDeliveryPrice;
    protected HiddenField hdnIsOrderUnderCompany;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      UtilityFunctions.SetDefaultCommonHeader(this.Page, "", "Turf Calculator");
      if (!this.IsPostBack)
      {
        if (this.Session["dtQUOTE"] != null)
        {
          DataTable dataTable = (DataTable) this.Session["dtQUOTE"];
        }
        PageManagementResponseBE managementResponseBe = new PageManagementResponseBE();
        PageManagementResponseBE pageByLinkUrl = PageManagementMgmt.GetPageByLinkURL("calculate-turfarea");
        if (pageByLinkUrl != null && pageByLinkUrl.PageManagementID > 0L)
          UtilityFunctions.SetDefaultCommonHeader(this.Page, pageByLinkUrl.HeaderImage, pageByLinkUrl.NameOnMenu);
        if (this.Session["dtQuoteDetail"] != null)
        {
          this.hdnIsOrderUnderCompany.Value = ((DataTable) this.Session["dtQuoteDetail"]).Rows[0]["OrderUnderCompany"].ToString();
          if (this.hdnIsOrderUnderCompany.Value == "1")
            this.DivrdbLaying.Visible = false;
        }
      }
      PurchaseOrderDetailBE purchaseOrderDetailBe = new PurchaseOrderDetailBE();
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
        purchaseOrderDetailBe.CreatedBy = Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID"));
      else if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
        purchaseOrderDetailBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      else if (this.hdnIsOrderUnderCompany.Value == "1")
      {
        this.DivrdbLaying.Visible = false;
      }
      else
      {
        this.DivrdbLaying.Visible = true;
        purchaseOrderDetailBe.CreatedBy = 0L;
      }
    }

    protected void btnContinue_Click(object sender, EventArgs e)
    {
      DataTable dataTable1 = new DataTable();
      if (this.Session["dtQUOTE"] != null)
        dataTable1 = (DataTable) this.Session["dtQUOTE"];
      if (this.Session["dtQuoteDetail"] != null)
      {
        DataTable dataTable2 = (DataTable) this.Session["dtQuoteDetail"];
        this.hdnPostCode.Value = dataTable2.Rows[0]["PostCode"].ToString();
        this.hdnPickupDelivery.Value = dataTable2.Rows[0]["PickUpDeliveryID"].ToString();
      }
      QuoteDetailBE quoteDetailBe = new QuoteDetailBE();
      this.hdnPostCode.Value = dataTable1.Rows[0]["ProductType"].ToString();
      this.quan = Convert.ToDouble(this.txtTotalAllArea.Text);
      NonTurfProductResponseBE productResponseBe1 = new NonTurfProductResponseBE();
      TurfProductResponseBE productResponseBe2 = new TurfProductResponseBE();
      long int64_1 = Convert.ToInt64(dataTable1.Rows[0]["TurfProductID"].ToString());
      long int64_2 = Convert.ToInt64(dataTable1.Rows[0]["TurfZoneID"].ToString());
      double num1;
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
      {
        if (Convert.ToInt32(dataTable1.Rows[0]["ProductType"].ToString()) == Convert.ToInt32((object) (Enums.TurfProductType) 2))
        {
          num1 = Convert.ToDouble(NonTurfProductMgmt.GetNonQuantityRangeForPurchase(int64_1, int64_2, Convert.ToDecimal(this.quan), Convert.ToInt64((object) (Enums.UserType) 4)).FinalPrice.ToString());
          this.subtotal = num1;
        }
        else
        {
          num1 = Convert.ToDouble(TurfProductMgmt.GetTurfRangeForPurchase(int64_1, int64_2, Convert.ToDecimal(this.quan), Convert.ToInt64((object) (Enums.UserType) 4)).FinalPrice.ToString());
          this.subtotal = num1;
        }
      }
      else if (Convert.ToInt32(dataTable1.Rows[0]["ProductType"].ToString()) == Convert.ToInt32((object) (Enums.TurfProductType) 2))
      {
        num1 = Convert.ToDouble(NonTurfProductMgmt.GetNonQuantityRangeForPurchase(int64_1, int64_2, Convert.ToDecimal(this.quan), 0L).FinalPrice.ToString());
        this.subtotal = num1;
      }
      else
      {
        num1 = Convert.ToDouble(TurfProductMgmt.GetTurfRangeForPurchase(int64_1, int64_2, Convert.ToDecimal(this.quan), 0L).FinalPrice.ToString());
        this.subtotal = num1;
      }
      if (num1 > 0.0)
      {
        this.total = this.subtotal;
        Decimal num2 = Convert.ToDecimal(this.txtTotalAllArea.Text);
        Decimal num3 = Convert.ToDecimal(this.total);
        if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
        {
          Decimal num4 = Convert.ToDecimal(num2) * Convert.ToDecimal(num3);
          quoteDetailBe.ProductQuantity = Convert.ToDecimal(num2);
          quoteDetailBe.ProductPrice = Convert.ToDecimal(num3);
          quoteDetailBe.ProductAreaPerMeter = Convert.ToDecimal(num2);
          quoteDetailBe.ProductTotalPrice = Convert.ToDecimal(num4);
          quoteDetailBe.TotalQuotePrice = Convert.ToDecimal(num4);
          quoteDetailBe.UserTypeID = (long) Convert.ToInt32((object) (Enums.UserType) 4);
          quoteDetailBe.CreatedBy = Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID"));
          quoteDetailBe.CommercialPartnerID = Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID"));
        }
        else if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
        {
          Decimal num5 = Convert.ToDecimal(num2) * Convert.ToDecimal(num3);
          quoteDetailBe.ProductQuantity = Convert.ToDecimal(num2);
          quoteDetailBe.ProductPrice = Convert.ToDecimal(num3);
          quoteDetailBe.ProductAreaPerMeter = Convert.ToDecimal(num2);
          quoteDetailBe.ProductTotalPrice = Convert.ToDecimal(num5);
          quoteDetailBe.TotalQuotePrice = Convert.ToDecimal(num5);
          quoteDetailBe.CreatedBy = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
        }
        else
        {
          quoteDetailBe.UserTypeID = quoteDetailBe.IsOrderUnderCompany != 1 ? (long) Convert.ToInt32((object) (Enums.UserType) 6) : (long) Convert.ToInt32((object) (Enums.UserType) 5);
          quoteDetailBe.CreatedBy = 0L;
          quoteDetailBe.ProductPrice = Convert.ToDecimal(dataTable1.Rows[0]["Price"].ToString());
          if (this.rdbLaying.SelectedValue == "1")
          {
            quoteDetailBe.ProductQuantity = Convert.ToDecimal(num2);
            Decimal num6 = Convert.ToDecimal(num2) * Convert.ToDecimal(num3);
            Decimal num7 = Convert.ToDecimal(num2) - 50M;
            Decimal num8;
            if (num7 <= 0M)
            {
              num8 = Convert.ToDecimal(num3) + Convert.ToDecimal(100);
            }
            else
            {
              Decimal num9 = Convert.ToDecimal(num7) * Convert.ToDecimal(1.6);
              Decimal num10 = Convert.ToDecimal(100) + Convert.ToDecimal(num9);
              num8 = Convert.ToDecimal(num3) + Convert.ToDecimal(num10);
            }
            SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
            this.ltrGSTVal.Text = string.Format("{0:C}", (object) double.Parse((num8 * siteConfiguration.GST / 100M).ToString("#0.00"))).Replace("$", "");
            this.hdnGSTVal.Value = !string.IsNullOrEmpty(this.ltrGSTVal.Text) ? this.ltrGSTVal.Text : "0.00";
            Decimal num11 = Convert.ToDecimal(num8) + Convert.ToDecimal(this.hdnGSTVal.Value);
            quoteDetailBe.ProductAreaPerMeter = Convert.ToDecimal(num2);
            quoteDetailBe.ProductTotalPrice = Convert.ToDecimal(num11);
            quoteDetailBe.TotalQuotePrice = Convert.ToDecimal(num6);
            quoteDetailBe.IsLyning = true;
            quoteDetailBe.LyingBasePrice = 100M;
            quoteDetailBe.LyingGSTPrice = Convert.ToDecimal(this.hdnGSTVal.Value);
            quoteDetailBe.LyingTotalPrice = Convert.ToDecimal(num11);
          }
          else if (this.rdbLaying.SelectedValue == "2")
          {
            quoteDetailBe.ProductQuantity = Convert.ToDecimal(dataTable1.Rows[0]["Quantity"].ToString());
            Decimal num12 = Convert.ToDecimal(UtilityFunctions.GetSubTotal(num2.ToString(), num3.ToString()));
            quoteDetailBe.ProductAreaPerMeter = Convert.ToDecimal(num2);
            quoteDetailBe.ProductTotalPrice = Convert.ToDecimal(num12);
            quoteDetailBe.TotalQuotePrice = Convert.ToDecimal(num12);
            quoteDetailBe.IsLyning = false;
          }
          else
          {
            quoteDetailBe.ProductQuantity = Convert.ToDecimal(num2);
            Decimal num13 = Convert.ToDecimal(UtilityFunctions.GetSubTotal(num2.ToString(), num3.ToString()));
            quoteDetailBe.ProductAreaPerMeter = Convert.ToDecimal(num2);
            quoteDetailBe.ProductTotalPrice = Convert.ToDecimal(num13);
            quoteDetailBe.TotalQuotePrice = Convert.ToDecimal(num13);
            quoteDetailBe.IsLyning = false;
          }
        }
        quoteDetailBe.TurfProductID = Convert.ToInt64(dataTable1.Rows[0]["TurfProductID"].ToString());
        quoteDetailBe.TurfProductName = dataTable1.Rows[0]["TurfName"].ToString();
        quoteDetailBe.TurfZoneID = Convert.ToInt64(dataTable1.Rows[0]["TurfZoneID"].ToString());
        quoteDetailBe.TurfClassificationID = Convert.ToInt64(dataTable1.Rows[0]["TurfClassificationID"].ToString());
        quoteDetailBe.ProductType = Convert.ToString(dataTable1.Rows[0]["ProductType"].ToString());
        quoteDetailBe.MainImage = Convert.ToString(dataTable1.Rows[0]["MainImage"].ToString());
        if (this.Session["dtQuoteDetail"] != null)
        {
          DataTable dataTable3 = (DataTable) this.Session["dtQuoteDetail"];
          quoteDetailBe.EmailAddress = dataTable3.Rows[0]["Email"].ToString();
          quoteDetailBe.BusinessName = dataTable3.Rows[0]["BusinessName"].ToString();
          quoteDetailBe.FirstName = dataTable3.Rows[0]["FirstName"].ToString();
          quoteDetailBe.LastName = dataTable3.Rows[0]["LastName"].ToString();
          quoteDetailBe.Postcode = Convert.ToInt32(dataTable3.Rows[0]["PostCode"].ToString());
          quoteDetailBe.PickUpDetailID = Convert.ToInt64(dataTable3.Rows[0]["PickUpDeliveryID"].ToString());
          quoteDetailBe.IsOrderUnderCompany = Convert.ToInt32(dataTable3.Rows[0]["OrderUnderCompany"].ToString());
          quoteDetailBe.AllAreaTotal = this.txtTotalAllArea.Text;
          quoteDetailBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
          if (quoteDetailBe.PickUpDetailID == 1L)
            quoteDetailBe.PickUpPrice = Convert.ToDecimal(this.strPrice);
          else
            quoteDetailBe.DeliveryPrice = this.strPrice;
        }
        quoteDetailBe.dtQuoteTurfAreaCalculation = new DataTable()
        {
          Columns = {
            {
              "AreaTypeID",
              typeof (long)
            },
            {
              "AreaTotal",
              typeof (Decimal)
            }
          },
          Rows = {
            new object[2]
            {
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 2),
              (object) Convert.ToDecimal(this.txtTotalTriangularArea.Text.Trim())
            },
            new object[2]
            {
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 1),
              (object) Convert.ToDecimal(this.txtlblTotalRectangularArea.Text.Trim())
            },
            new object[2]
            {
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 3),
              (object) Convert.ToDecimal(this.txtTotalCircularArea.Text.Trim())
            },
            new object[2]
            {
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 4),
              (object) Convert.ToDecimal(this.txtHalfCircularArea.Text.Trim())
            }
          }
        };
        quoteDetailBe.dtQuoteTurfAreaWiseDetail = new DataTable()
        {
          Columns = {
            {
              "SubAreaName",
              typeof (string)
            },
            {
              "AreaLength",
              typeof (Decimal)
            },
            {
              "AreaWidth",
              typeof (Decimal)
            },
            {
              "AreaDiameter",
              typeof (Decimal)
            },
            {
              "AreaQuantity",
              typeof (int)
            },
            {
              "AreaTypeID",
              typeof (long)
            }
          },
          Rows = {
            new object[6]
            {
              (object) "Area #1",
              (object) Convert.ToDecimal(this.txtTriArea1Length.Text.Trim()),
              (object) Convert.ToDecimal(this.txtTriArea1Width.Text.Trim()),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToInt32(this.txtTriArea1Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 2)
            },
            new object[6]
            {
              (object) "Area #2",
              (object) Convert.ToDecimal(this.txtTriArea2Length.Text.Trim()),
              (object) Convert.ToDecimal(this.txtTriArea2Width.Text.Trim()),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToInt32(this.txtTriArea2Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 2)
            },
            new object[6]
            {
              (object) "Area #3",
              (object) Convert.ToDecimal(this.txtTriArea3Length.Text.Trim()),
              (object) Convert.ToDecimal(this.txtTriArea3Width.Text.Trim()),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToInt32(this.txtTriArea3Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 2)
            },
            new object[6]
            {
              (object) "Area #1",
              (object) Convert.ToDecimal(this.txtRectArea1Length.Text.Trim()),
              (object) Convert.ToDecimal(this.txtRectArea1Width.Text.Trim()),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToInt32(this.txtRectArea1Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 1)
            },
            new object[6]
            {
              (object) "Area #2",
              (object) Convert.ToDecimal(this.txtRectArea2Length.Text.Trim()),
              (object) Convert.ToDecimal(this.txtRectArea2Width.Text.Trim()),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToInt32(this.txtRectArea2Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 1)
            },
            new object[6]
            {
              (object) "Area #3",
              (object) Convert.ToDecimal(this.txtRectArea3Length.Text.Trim()),
              (object) Convert.ToDecimal(this.txtRectArea3Width.Text.Trim()),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToInt32(this.txtRectArea3Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 1)
            },
            new object[6]
            {
              (object) "Area #1",
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(this.txtCircArea1Diameter.Text.Trim()),
              (object) Convert.ToInt32(this.txtCircArea1Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 3)
            },
            new object[6]
            {
              (object) "Area #2",
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(this.txtCircArea2Diameter.Text.Trim()),
              (object) Convert.ToInt32(this.txtCircArea2Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 3)
            },
            new object[6]
            {
              (object) "Area #3",
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(this.txtCircArea3Diameter.Text.Trim()),
              (object) Convert.ToInt32(this.txtCircArea3Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 3)
            },
            new object[6]
            {
              (object) "Area #1",
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(this.txtHalfCircArea1Diameter.Text.Trim()),
              (object) Convert.ToInt32(this.txtHalfCircArea1Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 4)
            },
            new object[6]
            {
              (object) "Area #2",
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(this.txtHalfCircArea2Diameter.Text.Trim()),
              (object) Convert.ToInt32(this.txtHalfCircArea2Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 4)
            },
            new object[6]
            {
              (object) "Area #3",
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(0.0),
              (object) Convert.ToDecimal(this.txtHalfCircArea3Diameter.Text.Trim()),
              (object) Convert.ToInt32(this.txtHalfCircArea3Qty.Text.Trim()),
              (object) Convert.ToInt64((object) (Enums.AreaTypes) 4)
            }
          }
        };
        long num14 = QuoteDetailMgmt.AddQuoteDetails(quoteDetailBe);
        UtilityFunctions.SetQuoteEmptyMessage(this.Page, this._dtQUOTE);
        UtilityFunctions.SetQuoteDetailEmptyMessage(this.Page, this._dtQuoteDetail);
        this.Session["QuoteDetailID"] = (object) num14;
        this.Session["IsLaying"] = (object) this.rdbLaying.SelectedValue;
        this.Session["IsOrderUnderCompany"] = (object) quoteDetailBe.IsOrderUnderCompany;
        this.Response.Redirect("/quote-detail");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format("Turf Price is not defined for " + this.txtTotalAllArea.Text + " Area size."), (Enums.NotificationType) 3), true);
    }
  }
}
