﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.FrontUserControl.FooterPart
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Miscellaneous;
using BLL.Newsletter;
using BLL.PageManagement;
using Entity.Common.Miscellaneous;
using Entity.Response.PageManagement;
using PerceptiveMCAPI;
using PerceptiveMCAPI.Methods;
using PerceptiveMCAPI.Types;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.FrontUserControl
{
  public class FooterPart : UserControl
  {
    public string strValidationEmail = "EmailValidation";
    protected Repeater rptFooter;
    protected HtmlGenericControl DivMail;
    protected Literal lblMsg;
    protected Literal lblmsgsucess;
    protected TextBox txtEmail;
    protected RequiredFieldValidator rfvEmail;
    protected RegularExpressionValidator regEmail;
    protected Button btnSubmit;
    protected HiddenField hdnUserId;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.IsPostBack)
        return;
      this.ValidationExpression();
      this.BindFooterMenus();
    }

    protected void BindFooterMenus()
    {
      List<PageManagementResponseBE> managementResponseBeList = new List<PageManagementResponseBE>();
      List<PageManagementResponseBE> footerMenus = PageManagementMgmt.GetFooterMenus();
      if (footerMenus == null)
        return;
      this.rptFooter.DataSource = (object) footerMenus;
      this.rptFooter.DataBind();
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      if (NewsletterMgmt.CheckEmailExists(this.txtEmail.Text.Trim(), Convert.ToInt64(this.hdnUserId.Value)))
      {
        listSubscribeOutput listSubscribeOutput = new listSubscribe().Execute(new listSubscribeInput(new listSubscribeParms()
        {
          apikey = ConfigurationManager.AppSettings["MailChimpAPIKey"].ToString(),
          id = ConfigurationManager.AppSettings["MailChimplistId"].ToString(),
          email_address = this.txtEmail.Text.Trim(),
          merge_vars = new Dictionary<string, object>(),
          double_optin = true,
          email_type = (EnumValues.emailType) 1,
          replace_interests = true,
          send_welcome = false,
          update_existing = true
        }));
        if (((Api_BaseOutput) listSubscribeOutput).api_ErrorMessages.Count > 0)
        {
          string empty1 = string.Empty;
          string empty2 = string.Empty;
          SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
          Mail.SendMailNotification(siteConfiguration.FromEmail, siteConfiguration.FromName, "dipti@demowork.com", ((Api_BaseOutput) listSubscribeOutput).api_ErrorMessages[0].error.ToString(), "Error in SUBSCRIBE", "", "", true);
          this.DivMail.Attributes.Add("class", "mailicon_Subscribe msgsubnewslatter");
          this.txtEmail.Focus();
          this.lblMsg.Visible = true;
          this.lblMsg.Text = "Fail to subscribe, please try later.";
          this.txtEmail.Text = "";
          this.lblmsgsucess.Visible = false;
        }
        else
        {
          NewsletterMgmt.AddNewsLetter(this.FillAddData());
          this.DivMail.Attributes.Add("class", "mailicon_Subscribe msgsubnewslatter");
          this.txtEmail.Focus();
          this.lblmsgsucess.Visible = true;
          this.lblmsgsucess.Text = Messages.NewsLetterSucess.ToString();
          this.txtEmail.Text = "";
          this.lblMsg.Visible = false;
        }
      }
      else
      {
        this.DivMail.Attributes.Add("class", "mailicon_Subscribe msgsubnewslatter");
        this.txtEmail.Focus();
        this.lblMsg.Visible = true;
        this.lblMsg.Text = Messages.AlreadySubscribeNewsletter.ToString();
        this.txtEmail.Text = "";
        this.lblmsgsucess.Visible = false;
      }
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorForFront(this.rfvEmail, true, (object) this.txtEmail, this.strValidationEmail);
      Validations.SetRegularExpressionValidatorForFront(this.regEmail, Regex.Email, true, (object) this.txtEmail, this.strValidationEmail);
      this.btnSubmit.ValidationGroup = this.strValidationEmail;
    }

    private Entity.Common.Newsletter.Newsletter FillAddData() => new Entity.Common.Newsletter.Newsletter()
    {
      Email = this.txtEmail.Text.Trim()
    };
  }
}
