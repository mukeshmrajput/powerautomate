﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.FrontUserControl.CommericalLogin
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using Entity.Common.Request;
using Entity.Common.Response;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.FrontUserControl
{
  public class CommericalLogin : UserControl
  {
    private DataTable _dtCart = new DataTable();
    private DataTable _dtQUOTE = new DataTable();
    protected LinkButton lbtnlogout;
    protected Label lb_errorMsg;
    protected TextBox txtUserName;
    protected RequiredFieldValidator req_Username;
    protected RegularExpressionValidator Reg_Username2;
    protected TextBox txtPassword;
    protected RequiredFieldValidator Req_Passqord;
    protected RegularExpressionValidator reg_Password;
    protected Button btnSubmit;

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      string url = "";
      string str = Convert.ToString((object) this.Request.UrlReferrer);
      if (str.IndexOf('=') > 0)
        url = str.Substring(str.IndexOf('=')).TrimStart('=');
      HttpContext current = HttpContext.Current;
      AuthenticateUserRequest authenticateUserRequest = new AuthenticateUserRequest();
      authenticateUserRequest.UserLoginEmail = this.txtUserName.Text.Trim();
      authenticateUserRequest.UserPassword = Encryption.EncryptQueryString(this.txtPassword.Text.Trim());
      authenticateUserRequest.LoginIP = this.Request.UserHostAddress;
      authenticateUserRequest.Browser = current.Request.Browser.Browser + " " + current.Request.Browser.Version;
      List<AuthenticateUserResponse> authenticateUserResponseList1 = new List<AuthenticateUserResponse>();
      List<AuthenticateUserResponse> authenticateUserResponseList2 = CommercialPartnerMgmt.AuthenticateCommercialPartnerUser(authenticateUserRequest);
      if (authenticateUserResponseList2.Count > 0)
      {
        Guid.NewGuid().ToString();
        UtilityFunctions.CreateUserdataCookie(authenticateUserResponseList2[0].LoginMasterID, authenticateUserResponseList2[0].UserName, authenticateUserResponseList2[0].Email, authenticateUserResponseList2[0].UserTypeID.ToString());
        if (authenticateUserResponseList2[0].LoginMasterID == 0L)
        {
          HtmlGenericControl control = (HtmlGenericControl) this.txtUserName.FindControl("lb_errorMsg");
          this.lb_errorMsg.Visible = true;
          this.lb_errorMsg.Text = Validation.InvalidEmailPassword;
          ScriptManager.RegisterClientScriptBlock((Control) this, this.GetType(), "script1", "$(function () { $('#drop').css('display','block'); });", true);
        }
        else if (!string.IsNullOrEmpty(url))
          this.Response.Redirect(url);
        else
          this.Response.Redirect("/order-history");
      }
      else
      {
        Label control = (Label) this.txtUserName.FindControl("lb_errorMsg");
        control.Visible = true;
        control.Text = Validation.InvalidEmailPassword;
        control.Style.Add("color", UtilityFunctions.SetMessageColor(0));
        ScriptManager.RegisterClientScriptBlock((Control) this, this.GetType(), "script1", "$(function () { $('#drop').css('display','block'); });", true);
      }
    }

    protected void ClearCart() => UtilityFunctions.SetCartEmptyMessage(this.Page, this._dtCart);

    protected void ClearQuote() => UtilityFunctions.SetQuoteEmptyMessage(this.Page, this._dtQUOTE);

    protected void lbtnlogout_Click(object sender, EventArgs e)
    {
      this.ClearCart();
      FormsAuthentication.SignOut();
      this.Session.Clear();
      this.Session.Abandon();
      if (this.Request.Cookies[".Frontendcookie"] != null)
        this.Response.Cookies.Add(new HttpCookie(".Frontendcookie")
        {
          Expires = DateTime.Now.AddDays(-1.0)
        });
      this.Response.Redirect("/default.aspx");
    }
  }
}
