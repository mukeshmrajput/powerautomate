﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.FrontUserControl.Paging
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.FrontUserControl
{
  public class Paging : UserControl
  {
    private int StartPage;
    private int EndPage;
    private int PrePageDiff;
    private int PostPageDiff;
    protected HtmlGenericControl divPagingType1;
    protected Literal ltrPaging2;
    protected Repeater rptPages;
    protected HtmlGenericControl divtxtPaging;
    protected TextBox txtGotoPage;
    protected CompareValidator cfvGotoPage;
    protected CompareValidator cfvMaxPage;
    protected RequiredFieldValidator rfvGotoPage;
    protected RegularExpressionValidator revGotoPage;
    protected Button btnGotoPage;
    protected HtmlGenericControl divdrpPaging;
    protected DropDownList ddlCustomPage;
    protected HtmlGenericControl divlblPaging;
    protected Literal ltrRecordPage;
    protected HiddenField hdnTotalPage;
    protected HiddenField hdnTotalRecords;
    protected HiddenField hdnPageSize;
    protected HiddenField hdnCurrentPage;

    private int CurrentPage
    {
      get => string.IsNullOrEmpty(this.hdnCurrentPage.Value) ? 1 : int.Parse(this.hdnCurrentPage.Value);
      set => this.hdnCurrentPage.Value = value.ToString();
    }

    private int _TotalPage
    {
      get => string.IsNullOrEmpty(this.hdnTotalPage.Value) ? 0 : int.Parse(this.hdnTotalPage.Value);
      set => this.hdnTotalPage.Value = value.ToString();
    }

    public int PageSize
    {
      get => string.IsNullOrEmpty(this.hdnPageSize.Value) ? Convert.ToInt32(ConfigurationManager.AppSettings["FrontPageSize"].ToString()) : Convert.ToInt32(this.hdnPageSize.Value);
      set => this.hdnPageSize.Value = value.ToString();
    }

    public int PageId
    {
      get => string.IsNullOrEmpty(this.hdnCurrentPage.Value) ? 0 : int.Parse(this.hdnCurrentPage.Value);
      set => this.hdnCurrentPage.Value = value.ToString();
    }

    public int TotalRecords
    {
      get => string.IsNullOrEmpty(this.hdnTotalRecords.Value) ? 0 : int.Parse(this.hdnTotalRecords.Value);
      set => this.hdnTotalRecords.Value = value.ToString();
    }

    public int PageDisplay { get; set; }

    public int PagingType { get; set; }

    public string NavigateUrl { get; set; }

    public string Width { get; set; }

    public event EventHandler CustomPageSelectedIndexChanged;

    public event EventHandler GoToPageClick;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.divPagingType1.Visible = true;
      this.revGotoPage.ValidationExpression = Regex.NumbersOnly + "*";
      this.CurrentPage = string.IsNullOrEmpty(this.hdnCurrentPage.Value) ? 0 : Convert.ToInt32(this.hdnCurrentPage.Value);
      if (!this.IsPostBack)
      {
        if (!string.IsNullOrEmpty(this.hdnPageSize.Value))
        {
          this.PageSize = Convert.ToInt32(this.hdnPageSize.Value);
          this.ddlCustomPage.SelectedIndex = this.ddlCustomPage.Items.IndexOf(this.ddlCustomPage.Items.FindByValue(this.hdnPageSize.Value));
        }
        else
        {
          this.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["FrontPageSize"].ToString());
          this.ddlCustomPage.SelectedIndex = this.ddlCustomPage.Items.IndexOf(this.ddlCustomPage.Items.FindByValue(ConfigurationManager.AppSettings["FrontPageSize"].ToString()));
        }
      }
      this.InitializePaging();
      this.GeneratePagingType1();
    }

    private void InitializePaging()
    {
      if (this.TotalRecords > 0)
      {
        this.divlblPaging.Visible = true;
        this.divtxtPaging.Visible = true;
        this.divdrpPaging.Visible = true;
        this._TotalPage = this.TotalRecords / this.PageSize + (this.TotalRecords % this.PageSize > 0 ? 1 : 0);
        if (this._TotalPage <= this.PageDisplay)
        {
          this.PrePageDiff = 0;
          this.PostPageDiff = this.PageDisplay;
          this.StartPage = 0;
          this.EndPage = this._TotalPage;
        }
        else
        {
          if (this.PageDisplay % 2 == 0)
          {
            this.PrePageDiff = this.PageDisplay / 2 - 1 < 0 ? 0 : this.PageDisplay / 2 - 1;
            this.PostPageDiff = this.PageDisplay / 2;
          }
          else
            this.PrePageDiff = this.PostPageDiff = this.PageDisplay / 2;
          this.StartPage = this.CurrentPage - this.PrePageDiff - 1;
          this.EndPage = this.CurrentPage + this.PostPageDiff - 1;
        }
        if (this.StartPage < 0)
        {
          this.EndPage = this.PageDisplay;
          this.StartPage = 0;
        }
        if (this.EndPage >= this._TotalPage)
          this.EndPage = this._TotalPage;
        HiddenField hdnTotalPage = this.hdnTotalPage;
        int num = this._TotalPage;
        string str1 = num.ToString();
        hdnTotalPage.Value = str1;
        HiddenField hdnTotalRecords = this.hdnTotalRecords;
        num = this.TotalRecords;
        string str2 = num.ToString();
        hdnTotalRecords.Value = str2;
        HiddenField hdnPageSize = this.hdnPageSize;
        num = this.PageSize;
        string str3 = num.ToString();
        hdnPageSize.Value = str3;
        CompareValidator cfvMaxPage = this.cfvMaxPage;
        num = this._TotalPage;
        string str4 = num.ToString();
        cfvMaxPage.ValueToCompare = str4;
      }
      if (this.TotalRecords > 5)
        return;
      this.divlblPaging.Visible = false;
      this.divtxtPaging.Visible = false;
      this.divdrpPaging.Visible = false;
    }

    private void GeneratePagingType1()
    {
      this.BindPaging();
      if (Convert.ToInt32((this.CurrentPage + 1) * this.PageSize) >= this.TotalRecords)
      {
        Literal ltrPaging2 = this.ltrPaging2;
        string[] strArray = new string[7];
        strArray[0] = "Search Results ";
        int num = (this.CurrentPage + 1) * this.PageSize - this.PageSize + 1;
        strArray[1] = num.ToString();
        strArray[2] = "-";
        num = this.TotalRecords;
        strArray[3] = num.ToString();
        strArray[4] = " of ";
        num = this.TotalRecords;
        strArray[5] = num.ToString();
        strArray[6] = " for";
        string str = string.Concat(strArray);
        ltrPaging2.Text = str;
      }
      else
      {
        Literal ltrPaging2 = this.ltrPaging2;
        string[] strArray = new string[7];
        strArray[0] = "Search Results ";
        int num = (this.CurrentPage + 1) * this.PageSize - this.PageSize + 1;
        strArray[1] = num.ToString();
        strArray[2] = "-";
        num = (this.CurrentPage + 1) * this.PageSize;
        strArray[3] = num.ToString();
        strArray[4] = " of ";
        num = this.TotalRecords;
        strArray[5] = num.ToString();
        strArray[6] = " for";
        string str = string.Concat(strArray);
        ltrPaging2.Text = str;
      }
      if (this.Request.Url.ToString().ToLower().Contains("commoncontentsearch") && this.Parent.FindControl("ltrTotalRecordsText") is Literal control1)
        control1.Text = this.ltrPaging2.Text;
      if (this.Request.Url.ToString().ToLower().Contains("newscontentsearch") && this.Parent.FindControl("ltrTotalRecordsText") is Literal control2)
        control2.Text = this.ltrPaging2.Text;
      if (!this.Request.Url.ToString().ToLower().Contains("turfcontentsearch") || !(this.Parent.FindControl("ltrTotalRecordsText") is Literal control3))
        return;
      control3.Text = this.ltrPaging2.Text;
    }

    private void BindPaging()
    {
      List<int> source = new List<int>();
      if (this.StartPage >= 0 && this.StartPage < this.EndPage)
      {
        for (int index = this.StartPage + 1; index <= this.EndPage; ++index)
          source.Add(index);
      }
      this.rptPages.Visible = false;
      if (source.Count<int>() <= 1)
        return;
      this.rptPages.Visible = true;
      this.rptPages.DataSource = (object) source;
      this.rptPages.DataBind();
    }

    private void GeneratePagingType3()
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("<div class=\"arialnew12 pageinglistpad clearfloat\" style=\"width:470px;float:left;\">Results:<span>");
      stringBuilder.Append(this.CurrentPage == 1 ? "<a href=\"javascript:void(0);\">First </a>" : "<a href=\"" + string.Format(this.NavigateUrl, (object) 1) + "\">First </a>");
      stringBuilder.Append(this.CurrentPage == 1 ? "<a href=\"javascript:void(0);\">Previous</a>" : "<a href=\"" + string.Format(this.NavigateUrl, (object) (this.CurrentPage - 1)) + "\">Previous</a>");
      if (this.StartPage > 0 && this.StartPage <= this.EndPage)
      {
        for (int startPage = this.StartPage; startPage <= this.EndPage; ++startPage)
        {
          if (startPage == this.CurrentPage)
            stringBuilder.AppendFormat("<a href=\"javascript:void(0);\" class=\"active\">{0}</a>", (object) startPage);
          else
            stringBuilder.AppendFormat("<a href=\"" + this.NavigateUrl + "\">{0}</a>", (object) startPage);
        }
      }
      stringBuilder.Append(this.CurrentPage == this._TotalPage ? "<a href=\"javascript:void(0);\">Next </a>" : "<a href=\"" + string.Format(this.NavigateUrl, (object) (this.CurrentPage + 1)) + "\">Next </a>");
      stringBuilder.Append(this.CurrentPage == this._TotalPage ? "<a href=\"javascript:void(0);\">Last</a>" : "<a href=\"" + string.Format(this.NavigateUrl, (object) this._TotalPage) + "\">Last</a>");
      stringBuilder.Append("</span></div><div class=\"arialnew12 pageinglistpad\" style=\"width:200px;text-align:right;clear:none;float:left;\">Pages: " + this._TotalPage.ToString() + "</div>");
    }

    public virtual void ResetPaging() => this.GeneratePagingType1();

    protected void btnGotoPage_Click(object sender, EventArgs e)
    {
      if (string.IsNullOrEmpty(this.txtGotoPage.Text))
        return;
      if (Convert.ToInt32(this.txtGotoPage.Text) <= Convert.ToInt32(this.hdnTotalPage.Value))
      {
        this.PageId = string.IsNullOrEmpty(this.txtGotoPage.Text) ? 0 : Convert.ToInt32(this.txtGotoPage.Text) - 1;
        if (this.GoToPageClick != null)
          this.GoToPageClick((object) this, EventArgs.Empty);
      }
      this.txtGotoPage.Text = string.Empty;
    }

    protected void ddlCustomPage_SelectedIndexChanged(object sender, EventArgs e)
    {
      this.PageSize = Convert.ToInt32(this.ddlCustomPage.SelectedValue);
      this.PageId = 0;
      this.InitializePaging();
      this.GeneratePagingType1();
      if (this.CustomPageSelectedIndexChanged != null)
        this.CustomPageSelectedIndexChanged((object) this, EventArgs.Empty);
      this.txtGotoPage.Text = string.Empty;
    }

    protected void rptPages_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
      if (e.CommandName.ToString().ToLower() == "nextpage" || e.CommandName.ToString().ToLower() == "lastpage" || e.CommandName.ToString().ToLower() == "firstpage" || e.CommandName.ToString().ToLower() == "changepage" || e.CommandName.ToString().ToLower() == "previouspage")
      {
        this.PageId = Convert.ToInt32(e.CommandArgument.ToString());
        if (this.GoToPageClick != null)
          this.GoToPageClick((object) this, EventArgs.Empty);
      }
      this.PageSize = Convert.ToInt32(this.ddlCustomPage.SelectedValue);
      this.InitializePaging();
      this.GeneratePagingType1();
      this.txtGotoPage.Text = string.Empty;
    }

    protected void rptPages_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType == ListItemType.Header)
      {
        LinkButton control1 = (LinkButton) e.Item.FindControl("lnkFirstPage");
        LinkButton control2 = (LinkButton) e.Item.FindControl("lnkPreviousPage");
        control1.CommandArgument = "0";
        if (this.CurrentPage > 0)
        {
          control2.CommandArgument = (this.CurrentPage - 1).ToString();
        }
        else
        {
          control2.Enabled = false;
          control1.Enabled = false;
          control2.Visible = false;
          control1.Visible = false;
        }
      }
      else if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
      {
        LinkButton control = (LinkButton) e.Item.FindControl("lnkPageNo");
        if (Convert.ToInt32(control.CommandArgument) != this.CurrentPage)
          return;
        control.CssClass = "active";
        control.Enabled = false;
      }
      else
      {
        if (e.Item.ItemType != ListItemType.Footer)
          return;
        LinkButton control3 = (LinkButton) e.Item.FindControl("lnkNextPage");
        LinkButton control4 = (LinkButton) e.Item.FindControl("lnkLastPage");
        control4.CommandArgument = (this._TotalPage - 1).ToString();
        if (this.CurrentPage == this._TotalPage - 1)
        {
          control4.Enabled = false;
          control3.Enabled = false;
          control4.Visible = false;
          control3.Visible = false;
        }
        else
          control3.CommandArgument = (this.CurrentPage + 1).ToString();
      }
    }

    protected void rptPagesType2_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType == ListItemType.Header)
      {
        LinkButton control1 = (LinkButton) e.Item.FindControl("lnkFirstPageType2");
        LinkButton control2 = (LinkButton) e.Item.FindControl("lnkPreviousPageType2");
        control1.CommandArgument = "0";
        if (this.CurrentPage > 0)
        {
          control2.CommandArgument = (this.CurrentPage - 1).ToString();
        }
        else
        {
          control2.Enabled = false;
          control1.Enabled = false;
        }
      }
      else if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
      {
        LinkButton control = (LinkButton) e.Item.FindControl("lnkPageNoType2");
        if (Convert.ToInt32(control.CommandArgument) != this.CurrentPage)
          return;
        control.CssClass = "active";
        control.Enabled = false;
      }
      else
      {
        if (e.Item.ItemType != ListItemType.Footer)
          return;
        ImageButton control3 = (ImageButton) e.Item.FindControl("lnkNextPageType2");
        ImageButton control4 = (ImageButton) e.Item.FindControl("lnkLastPageType2");
        control4.CommandArgument = (this._TotalPage - 1).ToString();
        if (this.CurrentPage == this._TotalPage - 1)
        {
          control4.Enabled = false;
          control3.Enabled = false;
        }
        else
          control3.CommandArgument = (this.CurrentPage + 1).ToString();
      }
    }

    public void ReloadPaging()
    {
      this.divPagingType1.Visible = true;
      this.revGotoPage.ValidationExpression = Regex.NumbersOnly + "*";
      this.txtGotoPage.Text = string.Empty;
      this.CurrentPage = string.IsNullOrEmpty(this.hdnCurrentPage.Value) || !(this.hdnCurrentPage.Value != "-1") ? 0 : Convert.ToInt32(this.hdnCurrentPage.Value);
      if (!string.IsNullOrEmpty(this.hdnPageSize.Value))
      {
        this.PageSize = Convert.ToInt32(this.hdnPageSize.Value);
        this.ddlCustomPage.SelectedIndex = this.ddlCustomPage.Items.IndexOf(this.ddlCustomPage.Items.FindByValue(this.hdnPageSize.Value));
      }
      else
      {
        this.PageSize = Convert.ToInt32(ConfigurationManager.AppSettings["FrontPageSize"].ToString());
        this.ddlCustomPage.SelectedIndex = this.ddlCustomPage.Items.IndexOf(this.ddlCustomPage.Items.FindByValue(ConfigurationManager.AppSettings["FrontPageSize"].ToString()));
      }
      this.InitializePaging();
      this.GeneratePagingType1();
    }
  }
}
