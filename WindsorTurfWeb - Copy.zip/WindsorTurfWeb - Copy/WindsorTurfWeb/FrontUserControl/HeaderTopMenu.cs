﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.FrontUserControl.HeaderTopMenu
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PageManagement;
using Entity.Response.PageManagement;
using Helper;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.FrontUserControl
{
  public class HeaderTopMenu : UserControl
  {
    public static List<PageManagementResponseBE> LstTopPage = new List<PageManagementResponseBE>();
    protected HtmlGenericControl divWelcome;
    protected Literal ltrWelcomeText;
    protected CommericalLogin CommericalLogin1;
    protected HtmlAnchor aCheckoutPage;
    protected Label ltr_cart;
    protected HtmlAnchor aCommercialRegistration;
    protected HtmlGenericControl spnCommercialRegistration;
    protected Repeater rptTopMenus;
    protected TextBox txtSearchText;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.IsPostBack)
        return;
      this.aCheckoutPage.HRef = "/checkout";
      int num1;
      if (this.Session["dtCART"] == null)
      {
        this.ltr_cart.Text = "Cart (0)";
        this.ltr_cart.ToolTip = "Cart (0)";
      }
      else
      {
        Label ltrCart1 = this.ltr_cart;
        num1 = ((DataTable) this.Session["dtCART"]).Rows.Count;
        string str1 = "Cart (" + num1.ToString() + ")";
        ltrCart1.Text = str1;
        Label ltrCart2 = this.ltr_cart;
        num1 = ((DataTable) this.Session["dtCART"]).Rows.Count;
        string str2 = "Cart (" + num1.ToString() + ")";
        ltrCart2.ToolTip = str2;
      }
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
      {
        this.divWelcome.Visible = true;
        this.ltrWelcomeText.Text = UtilityFunctions.ReadUserdataCookie("LoginFrontUserName");
        this.aCommercialRegistration.HRef = "/order-history";
        this.spnCommercialRegistration.InnerText = "My Account";
        this.aCommercialRegistration.Title = "My Account";
      }
      else
      {
        int num2;
        if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))))
        {
          string str3 = PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3));
          num1 = Convert.ToInt32((object) (Enums.UserType) 4);
          string str4 = num1.ToString();
          num2 = str3 != str4 ? 1 : 0;
        }
        else
          num2 = 0;
        if (num2 != 0)
        {
          this.divWelcome.Visible = true;
          this.ltrWelcomeText.Text = PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 2));
          this.aCommercialRegistration.HRef = "/Admin/Welcome.aspx";
          this.spnCommercialRegistration.InnerText = "My Account";
          this.aCommercialRegistration.Title = "My Account";
        }
        else
        {
          this.aCommercialRegistration.HRef = "/commercial-registration";
          this.spnCommercialRegistration.InnerText = PageName.strCommercialPartner;
          this.aCommercialRegistration.Title = PageName.strCommercialPartner;
          this.ltrWelcomeText.Text = string.Empty;
        }
      }
      this.LoadMenu();
    }

    protected void LoadMenu()
    {
      HeaderTopMenu.LstTopPage.Clear();
      HeaderTopMenu.LstTopPage = PageManagementMgmt.GetHomePageTopMenusForFrontEnd();
      if (HeaderTopMenu.LstTopPage.Count <= 0)
        return;
      this.rptTopMenus.DataSource = (object) HeaderTopMenu.LstTopPage.Where<PageManagementResponseBE>((System.Func<PageManagementResponseBE, bool>) (x => x.PageLevel == 0)).ToList<PageManagementResponseBE>();
      this.rptTopMenus.DataBind();
    }

    protected void rptTopMenus_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      HtmlAnchor control1 = (HtmlAnchor) e.Item.FindControl("aLink");
      HiddenField control2 = (HiddenField) e.Item.FindControl("hdnLinkURL");
      Repeater control3 = (Repeater) e.Item.FindControl("rptLevelOne");
      long PageManagementID = Convert.ToInt64(DataBinder.Eval(e.Item.DataItem, "PageManagementID"));
      control1.HRef = ConfigurationManager.AppSettings["LivePath"] + control2.Value;
      HtmlGenericControl control4 = (HtmlGenericControl) e.Item.FindControl("li_menus");
      if (this.Request.RawUrl.ToString().ToLower().Contains(control2.Value.ToLower()))
        control4.Attributes.Add("class", "active");
      if (control3 != null)
      {
        control3.DataSource = (object) HeaderTopMenu.LstTopPage.Where<PageManagementResponseBE>((System.Func<PageManagementResponseBE, bool>) (x => x.ParentID == PageManagementID && x.PageLevel == 1)).ToList<PageManagementResponseBE>();
        control3.DataBind();
      }
      if (control4 != null && HeaderTopMenu.LstTopPage.Where<PageManagementResponseBE>((System.Func<PageManagementResponseBE, bool>) (x => x.ParentID == PageManagementID && x.PageLevel == 1)).ToList<PageManagementResponseBE>().Count == 0)
        control4.Attributes.Add("class", "nochild");
      foreach (RepeaterItem repeaterItem in control3.Items)
      {
        HiddenField control5 = (HiddenField) repeaterItem.FindControl("hdnLinkURL");
        Repeater control6 = (Repeater) repeaterItem.FindControl("rptLevelTwo");
        if (this.Request.RawUrl.ToString().ToLower().Contains(control5.Value.ToLower()))
          control4.Attributes.Add("class", "active");
        foreach (Control control7 in control6.Items)
        {
          HiddenField control8 = (HiddenField) control7.FindControl("hdnLinkURL");
          if (this.Request.RawUrl.ToString().ToLower().Contains(control8.Value.ToLower()))
            control4.Attributes.Add("class", "active");
        }
      }
    }

    protected void rptLevelOne_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      HtmlAnchor control1 = (HtmlAnchor) e.Item.FindControl("aLink");
      HiddenField control2 = (HiddenField) e.Item.FindControl("hdnLinkURL");
      Repeater control3 = (Repeater) e.Item.FindControl("rptLevelTwo");
      long PageManagementID = Convert.ToInt64(DataBinder.Eval(e.Item.DataItem, "PageManagementID"));
      control1.HRef = ConfigurationManager.AppSettings["LivePath"] + control2.Value;
      HtmlGenericControl control4 = (HtmlGenericControl) e.Item.FindControl("li_SubMenu");
      if (control3 != null && control3.Items.Count > 0)
      {
        control3.DataSource = (object) HeaderTopMenu.LstTopPage.Where<PageManagementResponseBE>((System.Func<PageManagementResponseBE, bool>) (x => x.ParentID == PageManagementID && x.PageLevel == 2)).ToList<PageManagementResponseBE>();
        control3.DataBind();
      }
      if (control4 != null && HeaderTopMenu.LstTopPage.Where<PageManagementResponseBE>((System.Func<PageManagementResponseBE, bool>) (x => x.ParentID == PageManagementID && x.PageLevel == 2)).ToList<PageManagementResponseBE>().Count == 0)
        control4.Attributes.Add("class", "nochild");
    }

    protected void rptLevelTwo_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      ((HtmlAnchor) e.Item.FindControl("aLink")).HRef = ConfigurationManager.AppSettings["LivePath"] + ((HiddenField) e.Item.FindControl("hdnLinkURL")).Value;
    }
  }
}
