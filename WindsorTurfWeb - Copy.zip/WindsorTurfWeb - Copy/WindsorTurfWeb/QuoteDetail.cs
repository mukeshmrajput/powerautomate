﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.QuoteDetail
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PageManagement;
using BLL.QuoteDetail;
using Entity.Common.QuoteDetail;
using Entity.Response.PageManagement;
using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb
{
  public class QuoteDetail : Page
  {
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected Repeater rptQuoteDetail;
    protected HtmlGenericControl DivNoRecord;
    protected Label lblMsgNoRecord;
    protected HtmlGenericControl divAdd;
    protected Button btnContinue;
    protected HiddenField hdnQuoteDetailID;
    protected HiddenField hdnIsLaying;
    protected HiddenField hdnIsOrderUnderCompany;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      if (this.Session["QuoteDetailID"] != null && !string.IsNullOrEmpty(this.Session["QuoteDetailID"].ToString()))
        this.hdnQuoteDetailID.Value = Convert.ToString(this.Session["QuoteDetailID"]);
      if (this.Session["IsLaying"] != null && !string.IsNullOrEmpty(this.Session["IsLaying"].ToString()))
        this.hdnIsLaying.Value = Convert.ToString(this.Session["IsLaying"]);
      if (this.Session["IsOrderUnderCompany"] != null && !string.IsNullOrEmpty(this.Session["IsOrderUnderCompany"].ToString()))
        this.hdnIsOrderUnderCompany.Value = Convert.ToString(this.Session["IsOrderUnderCompany"]);
      PageManagementResponseBE managementResponseBe = new PageManagementResponseBE();
      PageManagementResponseBE pageByLinkUrl = PageManagementMgmt.GetPageByLinkURL("quote-detail");
      if (pageByLinkUrl != null && pageByLinkUrl.PageManagementID > 0L)
        UtilityFunctions.SetDefaultCommonHeader(this.Page, pageByLinkUrl.HeaderImage, pageByLinkUrl.NameOnMenu);
      if (this.IsPostBack || string.IsNullOrEmpty(this.hdnQuoteDetailID.Value))
        return;
      this.BindGrid();
      if (this.hdnIsLaying.Value == "1")
      {
        this.btnContinue.Visible = false;
        this.spnMsg.Visible = true;
        this.lblMsg.Text = "Please call Windsor Turf on (02) 4577 2550 to discuss finalising your order.";
      }
      else if (this.hdnIsOrderUnderCompany.Value == "1")
      {
        this.btnContinue.Visible = true;
      }
      else
      {
        if (this.Session["IsLaying"] != null)
          this.Session["IsLaying"] = (object) null;
        if (this.Session["IsOrderUnderCompany"] != null)
          this.Session["IsOrderUnderCompany"] = (object) null;
        this.btnContinue.Visible = true;
      }
    }

    protected void btnContinue_Click(object sender, EventArgs e)
    {
      if (this.Session["IsLaying"] != null)
        this.Session["IsLaying"] = (object) null;
      if (this.Session["IsOrderUnderCompany"] != null)
        this.Session["IsOrderUnderCompany"] = (object) null;
      this.Response.Redirect("/retail-purchase-detail");
    }

    protected void rptQuoteDetail_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      QuoteDetailBE detailByQuoteDetailId = QuoteDetailMgmt.GetQuoteDetailByQuoteDetailID(Convert.ToInt64(this.hdnQuoteDetailID.Value));
      if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
      {
        HtmlTableCell control1 = e.Item.FindControl("tdPickUpPrice") as HtmlTableCell;
        HtmlTableCell control2 = e.Item.FindControl("tdDeliveryPrice") as HtmlTableCell;
        HtmlTableCell control3 = e.Item.FindControl("tdLyingTotalPrice") as HtmlTableCell;
        Label control4 = (Label) e.Item.FindControl("lblTotalQuotePrice");
        Label control5 = (Label) e.Item.FindControl("lblDeliveryPrice");
        Label control6 = (Label) e.Item.FindControl("lblPickUpPrice");
        if (detailByQuoteDetailId.PickUpDetailID == 1L)
        {
          control4.Text = Convert.ToString(Convert.ToDecimal(control4.Text) + Convert.ToDecimal(control6.Text));
          control1.Visible = false;
          control2.Visible = false;
        }
        else
        {
          control4.Text = Convert.ToString(Convert.ToDecimal(control4.Text) + Convert.ToDecimal(control5.Text));
          control1.Visible = false;
          control2.Visible = false;
        }
        if (detailByQuoteDetailId.IsLyning)
          control3.Visible = false;
        else
          control3.Visible = false;
      }
      if (e.Item.ItemType != ListItemType.Header)
        return;
      HtmlTableCell control7 = (HtmlTableCell) e.Item.FindControl("thPickup");
      HtmlTableCell control8 = (HtmlTableCell) e.Item.FindControl("thDelivery");
      HtmlTableCell control9 = (HtmlTableCell) e.Item.FindControl("thLayingPrice");
      if (detailByQuoteDetailId.PickUpDetailID == 1L)
      {
        control7.Visible = false;
        control8.Visible = false;
      }
      else
      {
        control7.Visible = false;
        control8.Visible = false;
      }
      if (detailByQuoteDetailId.IsLyning)
        control9.Visible = false;
      else
        control9.Visible = false;
    }

    private void BindGrid()
    {
      List<QuoteDetailBE> detailByQuoteDetailId = QuoteDetailMgmt.GetAllQuoteDetailByQuoteDetailID(Convert.ToInt64(this.hdnQuoteDetailID.Value));
      if (detailByQuoteDetailId.Count <= 0)
        return;
      this.rptQuoteDetail.DataSource = (object) detailByQuoteDetailId;
      this.rptQuoteDetail.DataBind();
    }
  }
}
