﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Handler.CancelPayment
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace WindsorTurfWeb.Handler
{
  public class CancelPayment : Page
  {
    protected HtmlForm form1;

    protected void Page_Load(object sender, EventArgs e) => this.Response.Redirect("/thank-you/CancelPayment");
  }
}
