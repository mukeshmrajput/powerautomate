﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Handler.GeneralFunctions
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.NonTurfProductPricing.DeliveryRegion;
using BLL.ProductPricing.TurfProductPricing.ServiceRegions;
using Entity.Common.CommonList;
using Entity.Response.ProductPricing.TurfProductPricing.ServiceRegions;
using System;
using System.Web;
using System.Web.Script.Serialization;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb.Handler
{
  public class GeneralFunctions : IHttpHandler
  {
    public void ProcessRequest(HttpContext context)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      if (!string.IsNullOrEmpty(context.Request.QueryString["PostCodeVal"]))
      {
        string str1 = context.Request.QueryString["PostCodeVal"].ToString();
        if (string.IsNullOrEmpty(str1))
          return;
        string str2 = UtilityFunctions.CheckPostCodeUsingAPI(str1.ToString());
        HandlerResponse handlerResponse = new HandlerResponse();
        if (!str2.Contains("{\"localities\":\"\"}"))
        {
          handlerResponse.Success = true;
          handlerResponse.Value = "1";
        }
        else
        {
          handlerResponse.Success = true;
          handlerResponse.Value = "-1";
        }
        string s = new JavaScriptSerializer().Serialize((object) handlerResponse);
        context.Response.ContentType = "application/json";
        context.Response.Write(s);
        context.Response.End();
      }
      else if (!string.IsNullOrEmpty(context.Request.QueryString["PostCodeValue"]))
      {
        string str = context.Request.QueryString["PostCodeValue"].ToString();
        if (string.IsNullOrEmpty(str))
          return;
        int num = DeliveryRegionMgmt.CheckPostalCodeRangeByDeliveryRegionAndQuantityZone(Convert.ToInt32(str));
        HandlerResponse handlerResponse = new HandlerResponse();
        if (num > 0)
        {
          handlerResponse.Success = true;
          handlerResponse.Value = "1";
        }
        else
        {
          handlerResponse.Success = true;
          handlerResponse.Value = "-1";
        }
        string s = new JavaScriptSerializer().Serialize((object) handlerResponse);
        context.Response.ContentType = "application/json";
        context.Response.Write(s);
        context.Response.End();
      }
      else
      {
        if (string.IsNullOrEmpty(context.Request.QueryString["PostCodeValueServiceRegion"]))
          return;
        string str3 = context.Request.QueryString["PostCodeValueServiceRegion"].ToString();
        if (!string.IsNullOrEmpty(str3))
        {
          string str4 = UtilityFunctions.CheckPostCodeUsingAPI(str3.ToString());
          HandlerResponse handlerResponse = new HandlerResponse();
          if (!str4.Contains("{\"localities\":\"\"}"))
          {
            long serviceRegionId = ServiceRegionMgmt.CheckPostalCodeRangeInServiceRegion(Convert.ToInt32(context.Request.QueryString["PostCodeValueServiceRegion"].ToString())).ServiceRegionID;
            if (serviceRegionId > 0L)
            {
              ServiceRegionResponseBE detailForTurfZoneById = ServiceRegionMgmt.GetServiceRegionRangeDetailForTurfZoneByID(serviceRegionId);
              if (detailForTurfZoneById.TurfZoneName == "Metropolitan")
              {
                handlerResponse.Success = true;
                handlerResponse.Value = "1";
              }
              else if (detailForTurfZoneById.TurfZoneName == "Regional")
              {
                handlerResponse.Success = true;
                handlerResponse.Value = "2";
              }
            }
            else
            {
              handlerResponse.Success = true;
              handlerResponse.Value = "0";
            }
          }
          else
          {
            handlerResponse.Success = true;
            handlerResponse.Value = "0";
          }
          string s = new JavaScriptSerializer().Serialize((object) handlerResponse);
          context.Response.ContentType = "application/json";
          context.Response.Write(s);
          context.Response.End();
        }
      }
    }

    public bool IsReusable => false;
  }
}
