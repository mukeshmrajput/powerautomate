﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Handler.RangeCheck
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.ProductPricing.NonTurfProductPricing.DeliveryRegion;
using BLL.ProductPricing.NonTurfProductPricing.QuantityRanges;
using BLL.ProductPricing.TurfProductPricing.ServiceRegions;
using BLL.ProductPricing.TurfProductPricing.TurfRanges;
using Entity.Common.CommonList;
using System.Web;
using System.Web.Script.Serialization;

namespace WindsorTurfWeb.Handler
{
  public class RangeCheck : IHttpHandler
  {
    private bool result;

    public void ProcessRequest(HttpContext context)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      string empty4 = string.Empty;
      if (!string.IsNullOrEmpty(context.Request.QueryString["TurfRangeValue"]))
        this.result = TurfRangeMgmt.CheckTurfRangeValue(context.Request.QueryString["TurfRangeValue"].ToString());
      if (!string.IsNullOrEmpty(context.Request.QueryString["QuantityRangeValue"]))
        this.result = QuantityRangeMgmt.CheckQuantityRangeValue(context.Request.QueryString["QuantityRangeValue"].ToString());
      if (!string.IsNullOrEmpty(context.Request.QueryString["ServiceRegionRangeValue"]))
        this.result = ServiceRegionMgmt.CheckServiceRegionRangeValue(context.Request.QueryString["ServiceRegionRangeValue"].ToString());
      if (!string.IsNullOrEmpty(context.Request.QueryString["DeliveryRegionRange"]))
        this.result = DeliveryRegionMgmt.CheckDeliveryRegionRangeValue(context.Request.QueryString["DeliveryRegionRange"].ToString());
      HandlerResponse handlerResponse = new HandlerResponse();
      if (this.result)
      {
        handlerResponse.Success = true;
        handlerResponse.Value = "1";
      }
      else
      {
        handlerResponse.Success = true;
        handlerResponse.Value = "-1";
      }
      string s = new JavaScriptSerializer().Serialize((object) handlerResponse);
      context.Response.ContentType = "application/json";
      context.Response.Write(s);
      context.Response.End();
    }

    public bool IsReusable => false;
  }
}
