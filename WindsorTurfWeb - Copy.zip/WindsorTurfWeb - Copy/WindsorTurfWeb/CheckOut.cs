﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.CheckOut
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PageManagement;
using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Response.PageManagement;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;

namespace WindsorTurfWeb
{
  public class CheckOut : Page
  {
    public static int productQty = 0;
    private DataTable _dtCart = new DataTable();
    private double quan;
    private double total;
    private double subtotal;
    private double netQty;
    private string str = "";
    private string _productid;
    public int s = 0;
    protected HighslideControlFront HighslideControlFront1;
    protected UpdatePanel up1;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected HtmlGenericControl divContinueShopBtn;
    protected Button btnContShopping;
    protected HiddenField hdnOriginalQuantityEdit;
    protected HtmlGenericControl divShoppingCartDetail;
    protected Literal ltr_countPrd;
    protected Button btnEmptyBag;
    protected Repeater rpt_cart;
    protected Button btnContinueShopping;
    protected Button btnCheckOut;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      if (this.Session["dtCART"] != null)
        UtilityFunctions.CheckForInactiveUserForLogout(this.Page, (DataTable) this.Session["dtCART"]);
      if (this.Session["QuoteDetailID"] != null)
        this.Session["QuoteDetailID"] = (object) null;
      if (this.IsPostBack)
        return;
      PageManagementResponseBE managementResponseBe = new PageManagementResponseBE();
      PageManagementResponseBE pageByLinkUrl = PageManagementMgmt.GetPageByLinkURL("checkout");
      if (pageByLinkUrl != null && pageByLinkUrl.PageManagementID > 0L)
        UtilityFunctions.SetDefaultCommonHeader(this.Page, pageByLinkUrl.HeaderImage, pageByLinkUrl.NameOnMenu);
      this.BindRepeter();
      this.btnContinueShopping.Text = PageName.strBtnShopName;
      this.btnContinueShopping.ToolTip = PageName.strBtnShopName;
      this.btnContShopping.Text = PageName.strBtnShopName;
      this.btnContShopping.ToolTip = PageName.strBtnShopName;
    }

    public string GetId()
    {
      if (this.Session["dtCART"] == null)
        return this.str;
      ++this.s;
      this.str = Convert.ToString(this.s);
      return this.str;
    }

    public void BindRepeter()
    {
      if (this.Session["dtCART"] != null)
      {
        this._dtCart = (DataTable) this.Session["dtCART"];
        if (this._dtCart.Rows.Count > 0)
        {
          this.divShoppingCartDetail.Visible = true;
          this.spnMsg.Visible = false;
          this.divContinueShopBtn.Visible = false;
          this._dtCart = UtilityFunctions.ReverseRowsInDataTable(this._dtCart);
          this.rpt_cart.DataSource = (object) this._dtCart;
          this.rpt_cart.DataBind();
          Literal ltrCountPrd = this.ltr_countPrd;
          int count = ((DataTable) this.Session["dtCART"]).Rows.Count;
          string str1 = count.ToString();
          ltrCountPrd.Text = str1;
          this.ltr_countPrd.Text = "Total No. of Product(s) : " + this.ltr_countPrd.Text;
          Label control = (Label) this.Master.FindControl("HeaderTopMenu1").FindControl("ltr_cart");
          Label label1 = control;
          count = ((DataTable) this.Session["dtCART"]).Rows.Count;
          string str2 = "Cart (" + count.ToString() + ")";
          label1.Text = str2;
          Label label2 = control;
          count = ((DataTable) this.Session["dtCART"]).Rows.Count;
          string str3 = "Cart (" + count.ToString() + ")";
          label2.ToolTip = str3;
        }
        else if (this._dtCart.Rows.Count == 0)
        {
          this.rpt_cart.DataSource = (object) this._dtCart;
          this.rpt_cart.DataBind();
          this.rpt_cart.Visible = false;
          this.ltr_countPrd.Text = "0";
          this.DisplayCartEmptyMessage();
          UtilityFunctions.SetCartEmptyMessage(this.Page, this._dtCart);
        }
        ((Label) this.rpt_cart.Controls[this.rpt_cart.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtCart, (DataTable) this.Session["dtCART"]);
      }
      else
      {
        this.DisplayCartEmptyMessage();
        UtilityFunctions.SetCartEmptyMessage(this.Page, this._dtCart);
      }
    }

    protected void rpt_cart_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
      RepeaterItem repeaterItem = e.Item;
      if (e.CommandName == "delete")
      {
        this._dtCart = (DataTable) this.Session["dtCART"];
        this._productid = e.CommandArgument.ToString();
        DataView dataView = new DataView(this._dtCart);
        dataView.RowFilter = "OrderNo ='" + this._productid + "' ";
        string str = string.Empty;
        if (dataView.Count > 0)
        {
          str = dataView[0]["TurfName"].ToString().Trim();
          dataView[0].Delete();
          this._dtCart.AcceptChanges();
        }
        this.BindRepeter();
        if (this.rpt_cart.Items.Count > 0)
        {
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.ProductRemovedFromCart, (object) str), (Enums.NotificationType) 1), true);
          this.divContinueShopBtn.Visible = false;
          this.divShoppingCartDetail.Visible = true;
        }
        ((Label) this.rpt_cart.Controls[this.rpt_cart.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtCart, (DataTable) this.Session["dtCART"]);
      }
      if (e.CommandName == "edit")
      {
        ((TextBox) repeaterItem.FindControl("txt_quan")).Text = ((Label) repeaterItem.FindControl("lbl_quan")).Text.ToString();
        this.netQty = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString());
        this.hdnOriginalQuantityEdit.Value = this.netQty.ToString();
        repeaterItem.FindControl("lbl_quan").Visible = false;
        repeaterItem.FindControl("txt_quan").Visible = true;
        repeaterItem.FindControl("ibtnCalculateArea").Visible = true;
        repeaterItem.FindControl("btn_Update").Visible = true;
        repeaterItem.FindControl("btn_edit").Visible = false;
        repeaterItem.FindControl("btn_cancel").Visible = true;
        this._dtCart = (DataTable) this.Session["dtCART"];
        ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:block");
        if (this._dtCart != null)
        {
          for (int index = 0; index < this._dtCart.Rows.Count; ++index)
          {
            if (((HiddenField) repeaterItem.FindControl("hdn_OrdNo")).Value.ToString() == this._dtCart.Rows[index]["OrderNo"].ToString())
            {
              if (this._dtCart.Rows[index]["Type"].ToString() == "0")
              {
                ((WebControl) repeaterItem.FindControl("reg_qty")).Enabled = false;
                ((WebControl) repeaterItem.FindControl("rgval_qty")).Enabled = true;
              }
              else
              {
                ((WebControl) repeaterItem.FindControl("reg_qty")).Enabled = true;
                ((WebControl) repeaterItem.FindControl("rgval_qty")).Enabled = false;
              }
            }
          }
        }
      }
      if (e.CommandName == "cancel")
      {
        repeaterItem.FindControl("lbl_quan").Visible = true;
        repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
        repeaterItem.FindControl("txt_quan").Visible = false;
        repeaterItem.FindControl("btn_Update").Visible = false;
        repeaterItem.FindControl("btn_edit").Visible = true;
        repeaterItem.FindControl("btn_cancel").Visible = false;
        this.Response.Redirect("/checkout");
      }
      if (e.CommandName == "calculate")
      {
        TextBox control1 = (TextBox) e.Item.FindControl("txt_quan");
        Label control2 = (Label) e.Item.FindControl("lbl_unitprice");
        Label control3 = (Label) e.Item.FindControl("lbl_subtotal");
        LinkButton control4 = (LinkButton) repeaterItem.FindControl("ibtnCalculateArea");
        ((HtmlAnchor) repeaterItem.FindControl("aCalculateArea")).HRef = "GetAreaValue.aspx?txtTO=" + control1.Text + "&lblprice=" + control2.Text + "&lblsub=" + control3.Text;
      }
      if (!(e.CommandName == "update"))
        return;
      ((HtmlControl) repeaterItem.FindControl("divCalculateArea")).Attributes.Add("style", "display:none");
      this._dtCart = (DataTable) this.Session["dtCART"];
      if (this.spnMsg.Visible)
      {
        this.spnMsg.Visible = false;
        this.lblMsg.Text = string.Empty;
      }
      if (this._dtCart == null)
      {
        this.DisplayCartEmptyMessage();
        UtilityFunctions.SetCartEmptyMessage(this.Page, this._dtCart);
      }
      if (this._dtCart != null)
      {
        for (int index = 0; index < this._dtCart.Rows.Count; ++index)
        {
          if (((HiddenField) repeaterItem.FindControl("hdn_OrdNo")).Value.ToString() == this._dtCart.Rows[index]["OrderNo"].ToString())
          {
            if (((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString() == "" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "0" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "0.00" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "00" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "01" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "02" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "03" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "04" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "05" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "06" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "07" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "08" || ((TextBox) repeaterItem.FindControl("txt_quan")).Text == "09")
              return;
            this.quan = Convert.ToDouble(((TextBox) repeaterItem.FindControl("txt_quan")).Text.ToString());
            this.subtotal = Convert.ToDouble(((Label) repeaterItem.FindControl("lbl_unitprice")).Text.ToString());
            NonTurfProductResponseBE productResponseBe1 = new NonTurfProductResponseBE();
            TurfProductResponseBE productResponseBe2 = new TurfProductResponseBE();
            long int64_1 = Convert.ToInt64(this._dtCart.Rows[index]["TurfProductID"].ToString());
            long int64_2 = Convert.ToInt64(this._dtCart.Rows[index]["TurfZoneID"].ToString());
            double num;
            if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
            {
              if (Convert.ToInt32(this._dtCart.Rows[index]["ProductType"].ToString()) == Convert.ToInt32((object) (Enums.TurfProductType) 2))
              {
                num = Convert.ToDouble(NonTurfProductMgmt.GetNonQuantityRangeForPurchase(int64_1, int64_2, Convert.ToDecimal(this.quan), Convert.ToInt64((object) (Enums.UserType) 4)).FinalPrice.ToString());
                this.subtotal = num;
              }
              else
              {
                num = Convert.ToDouble(TurfProductMgmt.GetTurfRangeForPurchase(int64_1, int64_2, Convert.ToDecimal(this.quan), Convert.ToInt64((object) (Enums.UserType) 4)).FinalPrice.ToString());
                this.subtotal = num;
              }
            }
            else if (Convert.ToInt32(this._dtCart.Rows[index]["ProductType"].ToString()) == Convert.ToInt32((object) (Enums.TurfProductType) 2))
            {
              num = Convert.ToDouble(NonTurfProductMgmt.GetNonQuantityRangeForPurchase(int64_1, int64_2, Convert.ToDecimal(this.quan), 0L).FinalPrice.ToString());
              this.subtotal = num;
            }
            else
            {
              num = Convert.ToDouble(TurfProductMgmt.GetTurfRangeForPurchase(int64_1, int64_2, Convert.ToDecimal(this.quan), 0L).FinalPrice.ToString());
              this.subtotal = num;
            }
            if (num > 0.0)
            {
              this.total = this.quan * this.subtotal;
              ((Label) repeaterItem.FindControl("lbl_subtotal")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.total);
              repeaterItem.FindControl("lbl_quan").Visible = true;
              ((Label) repeaterItem.FindControl("lbl_quan")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.quan);
              ((Label) repeaterItem.FindControl("lbl_unitprice")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) num);
              repeaterItem.FindControl("txt_quan").Visible = false;
              repeaterItem.FindControl("btn_Update").Visible = false;
              repeaterItem.FindControl("btn_edit").Visible = true;
              repeaterItem.FindControl("btn_cancel").Visible = false;
              repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
              this._dtCart.Rows[index].BeginEdit();
              this._dtCart.Rows[index]["Quantity"] = (object) ((Label) repeaterItem.FindControl("lbl_quan")).Text;
              this._dtCart.Rows[index]["Price"] = (object) ((Label) repeaterItem.FindControl("lbl_unitprice")).Text;
              this._dtCart.AcceptChanges();
              foreach (string str in (IEnumerable<string>) this._dtCart.AsEnumerable().Select<DataRow, string>((System.Func<DataRow, string>) (dt => dt.Field<string>("TurfName"))))
              {
                System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.UpdateSuccess, (object) str), (Enums.NotificationType) 1), true);
                this.divContinueShopBtn.Visible = false;
                this.divShoppingCartDetail.Visible = true;
              }
            }
            else
            {
              repeaterItem.FindControl("lbl_quan").Visible = true;
              repeaterItem.FindControl("ibtnCalculateArea").Visible = false;
              repeaterItem.FindControl("txt_quan").Visible = false;
              repeaterItem.FindControl("btn_Update").Visible = false;
              repeaterItem.FindControl("btn_edit").Visible = true;
              repeaterItem.FindControl("btn_cancel").Visible = false;
              ((Label) repeaterItem.FindControl("lbl_quan")).Text = string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) this.hdnOriginalQuantityEdit.Value);
              System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format("Turf Price is not defined for this Area size."), (Enums.NotificationType) 3), true);
            }
          }
        }
      }
      ((Label) this.rpt_cart.Controls[this.rpt_cart.Controls.Count - 1].FindControl("lbl_Grandtotal")).Text = UtilityFunctions.GetGrandTotal(this._dtCart, (DataTable) this.Session["dtCART"]);
    }

    protected void rpt_cart_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item)
        return;
      LinkButton control1 = (LinkButton) e.Item.FindControl("ibtnCalculateArea");
      TextBox control2 = (TextBox) e.Item.FindControl("txt_quan");
    }

    protected void btnEmptyBag_Click(object sender, EventArgs e)
    {
      if (this.Session["dtCART"] == null)
        return;
      UtilityFunctions.SetCartEmptyMessage(this.Page, this._dtCart);
      this.Response.Redirect("/checkout");
    }

    protected void btnContinueShopping_Click(object sender, EventArgs e) => this.Response.Redirect("/shop");

    protected void btnCheckOut_Click(object sender, EventArgs e)
    {
      TextBox control = this.rpt_cart.Controls[this.rpt_cart.Controls.Count - 1].Controls[0].FindControl("txtNoteForPurchase") as TextBox;
      if (!string.IsNullOrEmpty(control.Text))
        this.Session["Note"] = (object) control.Text;
      if (this.Session["dtCART"] != null)
      {
        if (((DataTable) this.Session["dtCART"]).Rows.Count <= 0)
          return;
        this.Response.Redirect("/retail-purchase-detail");
      }
      else
      {
        this.DisplayCartEmptyMessage();
        UtilityFunctions.SetCartEmptyMessage(this.Page, this._dtCart);
      }
    }

    protected void btnContShopping_Click(object sender, EventArgs e) => this.Response.Redirect("/shop");

    protected void DisplayCartEmptyMessage()
    {
      this.spnMsg.Visible = true;
      this.lblMsg.Text = string.Format(Messages.ShoppingCartEmpty);
      this.divContinueShopBtn.Visible = true;
      this.divShoppingCartDetail.Visible = false;
      this.spnMsg.Style.Add("color", UtilityFunctions.SetMessageColor(0));
    }
  }
}
