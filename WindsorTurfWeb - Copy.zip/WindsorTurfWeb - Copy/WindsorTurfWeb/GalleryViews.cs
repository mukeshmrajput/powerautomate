﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.GalleryViews
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PageManagement;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Response.PageManagement;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Resources;
using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb
{
  public class GalleryViews : Page
  {
    public string strDescription = string.Empty;
    public long LoginUserID;
    protected HtmlGenericControl divMainShopData;
    protected TextBox txtPostcode;
    protected HtmlGenericControl spnMsgPostCode;
    protected Label lblMessagePostCode;
    protected HtmlGenericControl divNoProducts;
    protected Label lblNoProductFound;
    protected HtmlGenericControl divProductDetails;
    protected HtmlGenericControl divTurfProducts;
    protected DataList dlTurfProducts;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      PageManagementResponseBE managementResponseBe = new PageManagementResponseBE();
      PageManagementResponseBE pageByLinkUrl = PageManagementMgmt.GetPageByLinkURL("Gallery");
      if (pageByLinkUrl == null || pageByLinkUrl.PageManagementID <= 0L)
        return;
      UtilityFunctions.SetDefaultCommonHeader(this.Page, pageByLinkUrl.HeaderImage, pageByLinkUrl.NameOnMenu);
    }

    protected void BindFinalTurfProducts(long TurfClassificationID, long TurfZoneID)
    {
      List<TurfProductResponseBE> productsForShopPage = TurfProductMgmt.GetAllTurfProductsForShopPage(TurfClassificationID, TurfZoneID, UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
      if (productsForShopPage.Count > 0)
      {
        this.dlTurfProducts.DataSource = (object) productsForShopPage;
        this.dlTurfProducts.DataBind();
        this.divTurfProducts.Visible = true;
        this.divProductDetails.Visible = true;
        this.divNoProducts.Style.Add("display", "none");
        this.lblNoProductFound.Text = string.Empty;
      }
      else
      {
        this.dlTurfProducts.DataSource = (object) null;
        this.dlTurfProducts.DataBind();
        this.divProductDetails.Visible = false;
        this.divNoProducts.Style.Add("display", "block");
        this.lblNoProductFound.Text = string.Format(Messages.NoRecordFound, (object) "Turf Product");
        this.divNoProducts.Style.Add("color", UtilityFunctions.SetMessageColor(0));
      }
    }
  }
}
