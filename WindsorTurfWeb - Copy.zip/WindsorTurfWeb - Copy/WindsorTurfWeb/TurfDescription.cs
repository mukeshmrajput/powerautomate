﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.TurfDescription
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Response.PageManagement;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class TurfDescription : Page
  {
    private DataTable dt = new DataTable();
    private DataTable dtCART;
    private DataTable dtQUOTE;
    private DataRow drProduct;
    public bool IsStockAvailable = false;
    public string HeaderImagePath = ConfigurationManager.AppSettings["ImagePath"];
    public string strFinalPageTitle;
    protected Literal ltrMetatags;
    protected HiddenField hdnTurfProductID;
    protected HiddenField hdnTurfZoneID;
    protected HiddenField hdnTurfType;
    protected HiddenField hdnPageTitle;
    protected HtmlGenericControl spnMsg;
    protected Label lb_error;
    protected HtmlImage imgProductImage;
    protected Label lblTurfName;
    protected Label lblPriceName;
    protected Label lblMainPrice;
    protected HtmlGenericControl divStockUnavailable;
    protected Literal ltrDescription;
    protected HtmlGenericControl divAddToCart;
    protected Label lblAreaSize;
    protected TextBox txtAreaSize;
    protected RequiredFieldValidator rfvAreaSize;
    protected RegularExpressionValidator regAreaSize;
    protected CompareValidator cvAreaSize;
    protected Label lblTotalPrice;
    protected ImageButton BtnAddtoCart;
    protected ImageButton BtnAddtoQuote;
    protected HtmlGenericControl divUses;
    protected Literal ltruses;
    protected HtmlGenericControl divMaintenance;
    protected Literal ltrMaintenance;
    protected HtmlGenericControl divCharacteristics;
    protected Literal ltrCharacteristics;
    protected HiddenField hdnCommercialRegistration;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      this.txtAreaSize.Focus();
      if (this.Session["dtCART"] != null)
        UtilityFunctions.CheckForInactiveUserForLogout(this.Page, (DataTable) this.Session["dtCART"]);
      if (this.Session["QuoteDetailID"] != null)
        this.Session["QuoteDetailID"] = (object) null;
      if (this.IsPostBack)
        return;
      UtilityFunctions.SetDefaultCommonHeader(this.Page, "", "");
      if (this.Session["CommercialRegistration"] != null && !string.IsNullOrEmpty(this.Session["CommercialRegistration"].ToString()))
        this.hdnCommercialRegistration.Value = Convert.ToString(this.Session["CommercialRegistration"]);
      if (this.hdnCommercialRegistration.Value == ((Enums.PersonType) 1).ToString())
        this.BtnAddtoQuote.Visible = false;
      this.BtnAddtoCart.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.HeaderImagePath + "add-to-cart.png";
      this.BtnAddtoQuote.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.HeaderImagePath + "add-quote.png";
      string[] strArray1 = this.Request.Url.ToString().Split(new string[1]
      {
        "Type1="
      }, StringSplitOptions.None);
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      if (!string.IsNullOrEmpty(strArray1[1].ToString()))
      {
        string[] strArray2 = strArray1[1].ToString().Split('_');
        empty2 = strArray2[0].ToString();
        this.hdnTurfType.Value = empty2;
        empty3 = strArray2[1].ToString();
        empty1 = strArray2[2].ToString();
      }
      if (!string.IsNullOrEmpty(empty1))
      {
        this.Session["TurfId"] = (object) Encryption.DecryptQueryString(empty1);
        this.hdnTurfProductID.Value = this.Session["TurfId"].ToString();
        if (!string.IsNullOrEmpty(this.hdnTurfProductID.Value))
        {
          this.Session["TurfZoneID"] = (object) Encryption.DecryptQueryString(empty3);
          this.hdnTurfZoneID.Value = this.Session["TurfZoneID"].ToString();
          if (empty2 == ((Enums.TurfProductType) 1).ToString())
          {
            TurfProductResponseBE detailsByIdForFront = TurfProductMgmt.GetTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
            this.IsStockAvailable = detailsByIdForFront.TurfStockStatus;
            this.BindTurfProductDetailsByIDForFront(detailsByIdForFront);
          }
          else if (empty2 == ((Enums.TurfProductType) 2).ToString())
          {
            NonTurfProductResponseBE detailsByIdForFront = NonTurfProductMgmt.GetNonTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
            this.IsStockAvailable = detailsByIdForFront.NonTurfStockStatus;
            this.BindNonTurfProductDetailsByIDForFront(detailsByIdForFront);
          }
        }
      }
      else
        this.Response.Redirect("/default.aspx");
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
      {
        this.BtnAddtoQuote.Visible = true;
        this.BtnAddtoCart.Visible = true;
        this.divAddToCart.Visible = true;
      }
      else if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))))
      {
        this.BtnAddtoQuote.Visible = false;
        this.BtnAddtoCart.Visible = false;
        this.divAddToCart.Visible = false;
      }
      else
      {
        this.BtnAddtoQuote.Visible = true;
        this.BtnAddtoCart.Visible = true;
        this.divAddToCart.Visible = true;
      }
      if (!this.IsStockAvailable)
      {
        this.BtnAddtoCart.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.HeaderImagePath + "addToCartGray.png";
        this.BtnAddtoQuote.ImageUrl = ConfigurationManager.AppSettings["LivePath"] + this.HeaderImagePath + "addQuoteGray.png";
        this.BtnAddtoCart.Enabled = false;
        this.BtnAddtoQuote.Enabled = false;
        this.BtnAddtoCart.ToolTip = "Currently Unavailable";
      }
      else
      {
        this.BtnAddtoCart.Enabled = true;
        this.BtnAddtoQuote.Enabled = true;
        this.BtnAddtoCart.ToolTip = "ADD TO CART";
      }
    }

    protected void BindTurfProductDetailsByIDForFront(TurfProductResponseBE objTurf)
    {
      if (objTurf != null)
      {
        PageManagementResponseBE objDesc = new PageManagementResponseBE();
        objDesc.PageName = objTurf.PageName;
        objDesc.MetaDescription = objTurf.MetaDescription;
        objDesc.MetaKeyword = objTurf.MetaKeyword;
        objDesc.PageTitle = objTurf.PageTitle;
        this.strFinalPageTitle = objTurf.PageTitle;
        this.hdnPageTitle.Value = objTurf.PageTitle;
        Literal control1 = (Literal) this.Master.FindControl("ltrPageName");
        Literal control2 = (Literal) this.Master.FindControl("ltrMainPageName");
        control1.Text = objTurf.TurfName;
        control2.Text = objTurf.TurfName;
        this.ltrMetatags.Text = PageBase.SetSEO(objDesc);
        if (!string.IsNullOrEmpty(objTurf.MainImage))
          this.imgProductImage.Src = ConfigurationManager.AppSettings["Livepath"].ToString() + ConfigurationManager.AppSettings["TurfContentPageImagePath"].ToString() + objTurf.MainImage.ToString();
        this.lblTurfName.Text = objTurf.TurfName;
        this.lblPriceName.Text = "Price Per Metre : $";
        this.lblAreaSize.Text = "Area size(m<sub>2</sub>) :";
        this.lblMainPrice.Text = string.Format("{0:0.00}", (object) double.Parse(objTurf.FinalPrice.ToString()));
        this.lblTotalPrice.Text = string.Format("{0:0.00}", (object) double.Parse(objTurf.FinalPrice.ToString()));
        this.ltrDescription.Text = objTurf.Description;
        if (!string.IsNullOrEmpty(objTurf.Uses))
          this.ltruses.Text = objTurf.Uses;
        else
          this.divUses.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Maintenance))
          this.ltrMaintenance.Text = objTurf.Maintenance;
        else
          this.divMaintenance.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Characteristics))
          this.ltrCharacteristics.Text = objTurf.Characteristics;
        else
          this.divCharacteristics.Visible = false;
        if (!objTurf.TurfStockStatus)
        {
          this.divAddToCart.Visible = false;
          this.divStockUnavailable.Visible = true;
        }
        else
        {
          this.divAddToCart.Visible = true;
          this.divStockUnavailable.Visible = false;
        }
      }
      else
        this.Response.Redirect("/default.aspx");
    }

    protected void BindNonTurfProductDetailsByIDForFront(NonTurfProductResponseBE objTurf)
    {
      if (objTurf != null)
      {
        PageManagementResponseBE objDesc = new PageManagementResponseBE();
        objDesc.PageName = objTurf.PageName;
        objDesc.MetaDescription = objTurf.MetaDescription;
        objDesc.MetaKeyword = objTurf.MetaKeyword;
        objDesc.PageTitle = objTurf.PageTitle;
        this.strFinalPageTitle = objTurf.PageTitle;
        this.hdnPageTitle.Value = objTurf.PageTitle;
        Literal control1 = (Literal) this.Master.FindControl("ltrPageName");
        Literal control2 = (Literal) this.Master.FindControl("ltrMainPageName");
        control1.Text = objTurf.NonTurfName;
        control2.Text = objTurf.NonTurfName;
        this.ltrMetatags.Text = PageBase.SetSEO(objDesc);
        this.imgProductImage.Src = ConfigurationManager.AppSettings["Livepath"].ToString() + ConfigurationManager.AppSettings["TurfContentPageImagePath"].ToString() + objTurf.MainImage.ToString();
        this.lblTurfName.Text = objTurf.NonTurfName;
        this.lblPriceName.Text = "Price Per Item : $";
        this.lblAreaSize.Text = "Quantity";
        Label lblMainPrice = this.lblMainPrice;
        Decimal finalPrice = objTurf.FinalPrice;
        string str1 = string.Format("{0:0.00}", (object) double.Parse(finalPrice.ToString()));
        lblMainPrice.Text = str1;
        Label lblTotalPrice = this.lblTotalPrice;
        finalPrice = objTurf.FinalPrice;
        string str2 = string.Format("{0:0.00}", (object) double.Parse(finalPrice.ToString()));
        lblTotalPrice.Text = str2;
        this.ltrDescription.Text = objTurf.Description;
        if (!string.IsNullOrEmpty(objTurf.Uses))
          this.ltruses.Text = objTurf.Uses;
        else
          this.divUses.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Maintenance))
          this.ltrMaintenance.Text = objTurf.Maintenance;
        else
          this.divMaintenance.Visible = false;
        if (!string.IsNullOrEmpty(objTurf.Characteristics))
          this.ltrCharacteristics.Text = objTurf.Characteristics;
        else
          this.divCharacteristics.Visible = false;
        if (!objTurf.NonTurfStockStatus)
        {
          this.divAddToCart.Visible = false;
          this.divStockUnavailable.Visible = true;
        }
        else
        {
          this.divAddToCart.Visible = true;
          this.divStockUnavailable.Visible = false;
        }
      }
      else
        this.Response.Redirect("/default.aspx");
    }

    private DataTable AddColumns(DataTable dtCART)
    {
      dtCART.Columns.Add(new DataColumn("TurfProductID", typeof (long)));
      dtCART.Columns.Add(new DataColumn("OrderNo", typeof (string)));
      dtCART.Columns.Add(new DataColumn("TurfClassificationID", typeof (long)));
      dtCART.Columns.Add(new DataColumn("TurfName", typeof (string)));
      dtCART.Columns.Add(new DataColumn("TurfType", typeof (string)));
      dtCART.Columns.Add(new DataColumn("Price", typeof (double)));
      dtCART.Columns.Add(new DataColumn("Quantity", typeof (double)));
      dtCART.Columns.Add(new DataColumn("Type", typeof (int)));
      dtCART.Columns.Add(new DataColumn("MainImage", typeof (string)));
      dtCART.Columns.Add(new DataColumn("ProductType", typeof (int)));
      dtCART.Columns.Add(new DataColumn("TurfZoneID", typeof (long)));
      return dtCART;
    }

    protected void AddItem()
    {
      Convert.ToInt32(this.hdnTurfProductID.Value.ToString());
      if (this.hdnTurfType.Value == ((Enums.TurfProductType) 1).ToString())
      {
        TurfProductResponseBE detailsByIdForFront = TurfProductMgmt.GetTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
        if (this.Session["dtCART"] == null)
        {
          this.dtCART = new DataTable();
          this.dtCART = this.AddColumns(this.dtCART);
          this.drProduct = this.dtCART.NewRow();
          this.Session["identity"] = (object) "1";
          this.drProduct["TurfProductID"] = (object) detailsByIdForFront.TurfProductID;
          this.drProduct["OrderNo"] = (object) (detailsByIdForFront.TurfProductID.ToString() + "|" + detailsByIdForFront.TurfName);
          this.drProduct["TurfClassificationID"] = (object) detailsByIdForFront.TurfClassificationID;
          this.drProduct["TurfName"] = (object) detailsByIdForFront.TurfName;
          this.drProduct["Price"] = (object) detailsByIdForFront.FinalPrice;
          this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
          this.drProduct["MainImage"] = (object) detailsByIdForFront.MainImage;
          this.drProduct["Type"] = (object) 0;
          this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 1;
          this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
          this.drProduct["TurfType"] = (object) "Turf Selection";
          this.dtCART.Rows.Add(this.drProduct);
          this.Session["dtCART"] = (object) this.dtCART;
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForFront.TurfName.ToString()), (Enums.NotificationType) 1), true);
          this.SetCartValue(this.dtCART);
          this.Response.Redirect("/checkout");
        }
        else
        {
          this.dtCART = new DataTable();
          this.dtCART = (DataTable) this.Session["dtCART"];
          bool flag = false;
          for (int index = 0; index < this.dtCART.Rows.Count; ++index)
          {
            if (this.dtCART.Rows[index]["OrderNo"].ToString() == detailsByIdForFront.TurfProductID.ToString() + "|" + detailsByIdForFront.TurfName)
            {
              flag = true;
              this.SetCartValue(this.dtCART);
            }
          }
          if (!flag)
          {
            this.drProduct = this.dtCART.NewRow();
            this.drProduct["TurfProductID"] = (object) Convert.ToString(this.dtCART.Rows.Count + 1);
            this.Session["identity"] = (object) (Convert.ToInt32(this.Session["identity"].ToString()) + 1).ToString();
            this.drProduct["TurfProductID"] = (object) detailsByIdForFront.TurfProductID;
            this.drProduct["OrderNo"] = (object) (detailsByIdForFront.TurfProductID.ToString() + "|" + detailsByIdForFront.TurfName);
            this.drProduct["TurfClassificationID"] = (object) detailsByIdForFront.TurfClassificationID;
            this.drProduct["TurfName"] = (object) detailsByIdForFront.TurfName;
            this.drProduct["Price"] = (object) detailsByIdForFront.FinalPrice;
            this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
            this.drProduct["MainImage"] = (object) detailsByIdForFront.MainImage;
            this.drProduct["Type"] = (object) 0;
            this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 1;
            this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
            this.drProduct["TurfType"] = (object) "Turf Selection";
            this.dtCART.Rows.Add(this.drProduct);
            this.Session["dtCART"] = (object) this.dtCART;
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForFront.TurfName.ToString()), (Enums.NotificationType) 1), true);
            this.SetCartValue(this.dtCART);
            this.Response.Redirect("/checkout");
          }
          else
          {
            this.strFinalPageTitle = this.hdnPageTitle.Value;
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.AlreadySelectedTurf), (Enums.NotificationType) 3), true);
          }
        }
      }
      else
      {
        if (!(this.hdnTurfType.Value == ((Enums.TurfProductType) 2).ToString()))
          return;
        NonTurfProductResponseBE detailsByIdForFront = NonTurfProductMgmt.GetNonTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
        if (this.Session["dtCART"] == null)
        {
          this.dtCART = new DataTable();
          this.dtCART = this.AddColumns(this.dtCART);
          this.drProduct = this.dtCART.NewRow();
          this.Session["identity"] = (object) "1";
          this.drProduct["TurfProductID"] = (object) detailsByIdForFront.NonTurfProductID;
          this.drProduct["OrderNo"] = (object) (detailsByIdForFront.NonTurfProductID.ToString() + "|" + detailsByIdForFront.NonTurfName);
          this.drProduct["TurfClassificationID"] = (object) detailsByIdForFront.NonTurfClassificationID;
          this.drProduct["TurfName"] = (object) detailsByIdForFront.NonTurfName;
          this.drProduct["Price"] = (object) detailsByIdForFront.FinalPrice;
          this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
          this.drProduct["MainImage"] = (object) detailsByIdForFront.MainImage;
          this.drProduct["Type"] = (object) 0;
          this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 2;
          this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
          this.drProduct["TurfType"] = (object) "Turf Care";
          this.dtCART.Rows.Add(this.drProduct);
          this.Session["dtCART"] = (object) this.dtCART;
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForFront.NonTurfName.ToString()), (Enums.NotificationType) 1), true);
          this.SetCartValue(this.dtCART);
          this.Response.Redirect("/checkout");
        }
        else
        {
          this.dtCART = new DataTable();
          this.dtCART = (DataTable) this.Session["dtCART"];
          bool flag = false;
          for (int index = 0; index < this.dtCART.Rows.Count; ++index)
          {
            if (this.dtCART.Rows[index]["OrderNo"].ToString() == detailsByIdForFront.NonTurfProductID.ToString() + "|" + detailsByIdForFront.NonTurfName)
            {
              flag = true;
              this.SetCartValue(this.dtCART);
            }
          }
          if (!flag)
          {
            this.drProduct = this.dtCART.NewRow();
            this.drProduct["TurfProductID"] = (object) Convert.ToString(this.dtCART.Rows.Count + 1);
            this.Session["identity"] = (object) (Convert.ToInt32(this.Session["identity"].ToString()) + 1).ToString();
            this.drProduct["TurfProductID"] = (object) detailsByIdForFront.NonTurfProductID;
            this.drProduct["OrderNo"] = (object) (detailsByIdForFront.NonTurfProductID.ToString() + "|" + detailsByIdForFront.NonTurfName);
            this.drProduct["TurfClassificationID"] = (object) detailsByIdForFront.NonTurfClassificationID;
            this.drProduct["TurfName"] = (object) detailsByIdForFront.NonTurfName;
            this.drProduct["Price"] = (object) detailsByIdForFront.FinalPrice;
            this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
            this.drProduct["MainImage"] = (object) detailsByIdForFront.MainImage;
            this.drProduct["Type"] = (object) 0;
            this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 2;
            this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
            this.drProduct["TurfType"] = (object) "Turf Care";
            this.dtCART.Rows.Add(this.drProduct);
            this.Session["dtCART"] = (object) this.dtCART;
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForFront.NonTurfName.ToString()), (Enums.NotificationType) 1), true);
            this.SetCartValue(this.dtCART);
            this.Response.Redirect("/checkout");
          }
          else
          {
            this.strFinalPageTitle = this.hdnPageTitle.Value;
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.AlreadySelectedTurf), (Enums.NotificationType) 3), true);
          }
        }
      }
    }

    protected void BtnAddtoCart_Click(object sender, ImageClickEventArgs e)
    {
      if (Convert.ToDouble(this.txtAreaSize.Text) <= 0.0)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.AreaSizeValidation), (Enums.NotificationType) 3), true);
      }
      else
      {
        this.dt.Clear();
        if (this.hdnTurfType.Value == ((Enums.TurfProductType) 1).ToString())
        {
          TurfProductResponseBE productResponseBe = new TurfProductResponseBE();
          if (TurfProductMgmt.GetTurfRangeForPurchase(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), Convert.ToDecimal(this.txtAreaSize.Text), (long) UtilityFunctions.GetFrontUserID()) != null)
          {
            this.AddItem();
          }
          else
          {
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.InvalidRangePurchase), (Enums.NotificationType) 3), true);
            this.txtAreaSize.Focus();
          }
        }
        else
        {
          if (!(this.hdnTurfType.Value == ((Enums.TurfProductType) 2).ToString()))
            return;
          NonTurfProductResponseBE productResponseBe = new NonTurfProductResponseBE();
          if (NonTurfProductMgmt.GetNonQuantityRangeForPurchase(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), Convert.ToDecimal(this.txtAreaSize.Text), (long) UtilityFunctions.GetFrontUserID()) != null)
          {
            this.AddItem();
          }
          else
          {
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.InvalidRangePurchase), (Enums.NotificationType) 3), true);
            this.txtAreaSize.Focus();
          }
        }
      }
    }

    protected void SetCartValue(DataTable dtCart)
    {
      Label control = (Label) this.Master.FindControl("HeaderTopMenu1").FindControl("ltr_cart");
      control.Text = "Cart (" + dtCart.Rows.Count.ToString() + ")";
      control.ToolTip = "Cart (" + dtCart.Rows.Count.ToString() + ")";
    }

    private DataTable AddColumnsQuote(DataTable dtQUOTE)
    {
      dtQUOTE.Columns.Add(new DataColumn("TurfProductID", typeof (long)));
      dtQUOTE.Columns.Add(new DataColumn("OrderNo", typeof (string)));
      dtQUOTE.Columns.Add(new DataColumn("TurfClassificationID", typeof (long)));
      dtQUOTE.Columns.Add(new DataColumn("TurfName", typeof (string)));
      dtQUOTE.Columns.Add(new DataColumn("Price", typeof (double)));
      dtQUOTE.Columns.Add(new DataColumn("Quantity", typeof (double)));
      dtQUOTE.Columns.Add(new DataColumn("Type", typeof (int)));
      dtQUOTE.Columns.Add(new DataColumn("MainImage", typeof (string)));
      dtQUOTE.Columns.Add(new DataColumn("ProductType", typeof (int)));
      dtQUOTE.Columns.Add(new DataColumn("TurfZoneID", typeof (long)));
      dtQUOTE.Columns.Add(new DataColumn("TurfType", typeof (string)));
      return dtQUOTE;
    }

    protected void AddItemQuote()
    {
      Convert.ToInt32(this.hdnTurfProductID.Value.ToString());
      if (this.hdnTurfType.Value == ((Enums.TurfProductType) 1).ToString())
      {
        TurfProductResponseBE detailsByIdForFront = TurfProductMgmt.GetTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
        if (this.Session["dtQUOTE"] != null)
          return;
        this.dtQUOTE = new DataTable();
        this.dtQUOTE = this.AddColumnsQuote(this.dtQUOTE);
        this.drProduct = this.dtQUOTE.NewRow();
        this.Session["identity"] = (object) "1";
        this.drProduct["TurfProductID"] = (object) detailsByIdForFront.TurfProductID;
        this.drProduct["OrderNo"] = (object) (detailsByIdForFront.TurfProductID.ToString() + "|" + detailsByIdForFront.TurfName);
        this.drProduct["TurfClassificationID"] = (object) detailsByIdForFront.TurfClassificationID;
        this.drProduct["TurfName"] = (object) detailsByIdForFront.TurfName;
        this.drProduct["Price"] = (object) detailsByIdForFront.FinalPrice;
        this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
        this.drProduct["MainImage"] = (object) detailsByIdForFront.MainImage;
        this.drProduct["Type"] = (object) 0;
        this.drProduct["TurfType"] = (object) "Turf Selection";
        this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 1;
        this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
        this.dtQUOTE.Rows.Add(this.drProduct);
        this.Session["dtQUOTE"] = (object) this.dtQUOTE;
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForFront.TurfName.ToString()), (Enums.NotificationType) 1), true);
        this.Response.Redirect("/get-quote");
      }
      else
      {
        if (!(this.hdnTurfType.Value == ((Enums.TurfProductType) 2).ToString()))
          return;
        NonTurfProductResponseBE detailsByIdForFront = NonTurfProductMgmt.GetNonTurfProductDetailsByIDForFront(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
        if (this.Session["dtQUOTE"] == null)
        {
          this.dtQUOTE = new DataTable();
          this.dtQUOTE = this.AddColumnsQuote(this.dtQUOTE);
          this.drProduct = this.dtQUOTE.NewRow();
          this.Session["identity"] = (object) "1";
          this.drProduct["TurfProductID"] = (object) detailsByIdForFront.NonTurfProductID;
          this.drProduct["OrderNo"] = (object) (detailsByIdForFront.NonTurfProductID.ToString() + "|" + detailsByIdForFront.NonTurfName);
          this.drProduct["TurfClassificationID"] = (object) detailsByIdForFront.NonTurfClassificationID;
          this.drProduct["TurfName"] = (object) detailsByIdForFront.NonTurfName;
          this.drProduct["Price"] = (object) detailsByIdForFront.FinalPrice;
          this.drProduct["Quantity"] = (object) this.txtAreaSize.Text.ToString();
          this.drProduct["MainImage"] = (object) detailsByIdForFront.MainImage;
          this.drProduct["TurfType"] = (object) "Turf Care";
          this.drProduct["ProductType"] = (object) (Enums.TurfProductType) 2;
          this.drProduct["TurfZoneID"] = (object) Convert.ToInt64(this.hdnTurfZoneID.Value);
          this.dtQUOTE.Rows.Add(this.drProduct);
          this.Session["dtQUOTE"] = (object) this.dtQUOTE;
          System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.TurfAddedSuccess, (object) detailsByIdForFront.NonTurfName.ToString()), (Enums.NotificationType) 1), true);
          this.Response.Redirect("/get-quote");
        }
      }
    }

    protected void BtnAddtoQuote_Click(object sender, ImageClickEventArgs e)
    {
      if (Convert.ToDouble(this.txtAreaSize.Text) <= 0.0)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.AreaSizeValidation), (Enums.NotificationType) 3), true);
      }
      else
      {
        this.dt.Clear();
        if (this.hdnTurfType.Value == ((Enums.TurfProductType) 1).ToString())
        {
          TurfProductResponseBE productResponseBe = new TurfProductResponseBE();
          if (TurfProductMgmt.GetTurfRangeForPurchase(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), Convert.ToDecimal(this.txtAreaSize.Text), (long) UtilityFunctions.GetFrontUserID()) != null)
          {
            if (this.Session["dtQUOTE"] != null)
              this.Session["dtQUOTE"] = (object) null;
            this.AddItemQuote();
          }
          else
          {
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.InvalidRangePurchase), (Enums.NotificationType) 3), true);
            this.txtAreaSize.Focus();
          }
        }
        else
        {
          if (!(this.hdnTurfType.Value == ((Enums.TurfProductType) 2).ToString()))
            return;
          NonTurfProductResponseBE productResponseBe = new NonTurfProductResponseBE();
          if (NonTurfProductMgmt.GetNonQuantityRangeForPurchase(Convert.ToInt64(this.hdnTurfProductID.Value), Convert.ToInt64(this.hdnTurfZoneID.Value), Convert.ToDecimal(this.txtAreaSize.Text), (long) UtilityFunctions.GetFrontUserID()) != null)
          {
            if (this.Session["dtQUOTE"] != null)
              this.Session["dtQUOTE"] = (object) null;
            this.AddItemQuote();
          }
          else
          {
            System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.InvalidRangePurchase), (Enums.NotificationType) 3), true);
            this.txtAreaSize.Focus();
          }
        }
      }
    }
  }
}
