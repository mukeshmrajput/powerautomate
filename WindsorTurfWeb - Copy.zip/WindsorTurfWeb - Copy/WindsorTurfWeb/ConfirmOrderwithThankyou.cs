﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.ConfirmOrderwithThankyou
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using PayPalAPIHelper;
using System;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace WindsorTurfWeb
{
  public class ConfirmOrderwithThankyou : Page
  {
    private string payPalToken;
    private bool isTest;
    private string payerID;
    protected HtmlGenericControl thnkdiv;
    protected Literal lblProductName;
    protected HtmlGenericControl Errordiv;
    protected HiddenField hdnPayerID;
    protected HiddenField hdnProductId;
    protected HiddenField hdnamount;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (string.IsNullOrEmpty(Convert.ToString(this.Session["PayPalToken"])))
        this.Response.Redirect("/default.aspx");
      this.payPalToken = this.Session["PayPalToken"] as string;
      this.isTest = (bool) this.Session["IsText"];
      string amount;
      PayPalExpressHelper.GetExpressCheckoutDetails(this.isTest, this.payPalToken, out amount, out string _, out string _, out string _, out string _, out string _, out string _);
      this.payerID = this.Request["PayerID"];
      if (PayPalExpressHelper.DoExpressCheckoutPayment(this.isTest, this.payPalToken, this.payerID, amount, (PayPalCurrency) Enum.Parse(typeof (PayPalCurrency), ConfigurationManager.AppSettings["UseCurrencyCode"].ToString())))
      {
        this.Response.Redirect("/thank-you/successcredit");
        this.Session["PayPalToken"] = (object) null;
      }
      else
      {
        this.Response.Redirect("/thank-you/failedrecredit");
        this.Session["PayPalToken"] = (object) null;
      }
    }
  }
}
