﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.CommonSearchPage
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommonSearch;
using Entity.Common.CommonSearch;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class CommonSearchPage : Page
  {
    public int TotalRecords;
    public int PageIndex = 0;
    protected Literal ltrMetaTags;
    protected TextBox txtSearchText;
    protected Literal ltrTotalRecordsText;
    protected Literal ltrSearchText;
    protected DataList dlSearchRecords;
    protected Paging CustomPaging;
    protected HtmlGenericControl divAdd;
    protected HiddenField hdnSearchMenu;
    protected HiddenField hdnPageNumber;
    protected HiddenField hdnPagecount;
    protected HiddenField hdnPaging;
    protected HiddenField hdfSortField;
    protected HiddenField hdfSort;
    protected HiddenField hdnSearchVal;
    protected HiddenField hdnPageSize;
    protected HiddenField hdnCurrentPage;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      if (!this.IsPostBack)
      {
        UtilityFunctions.SetDefaultCommonHeader(this.Page, "", PageName.strCommonSearch);
        this.hdnSearchMenu.Value = "sitecontent";
        this.GetSearchCriteria();
      }
      this.ltrMetaTags.Text = "<title>" + (!string.IsNullOrEmpty(this.hdnSearchVal.Value) ? this.hdnSearchVal.Value + " | " + ConfigurationManager.AppSettings["PageTitle"] : ConfigurationManager.AppSettings["PageTitle"]) + "</title>";
    }

    protected void GetSearchCriteria()
    {
      this.hdnPageSize.Value = this.CustomPaging.PageSize.ToString();
      this.hdnPageNumber.Value = this.CustomPaging.PageId.ToString();
      this.GetSearchRecords(this.txtSearchText.Text);
    }

    protected void GetSearchRecords(string SearchText)
    {
      if (this.Request.Url.ToString() != null)
      {
        string[] strArray = this.Request.Url.ToString().Replace("-", " ").ToString().Split('=');
        this.hdnSearchVal.Value = strArray[2].ToString();
        this.txtSearchText.Text = strArray[2].ToString();
        this.ltrSearchText.Text = "\"" + this.txtSearchText.Text.ToUpper() + "\"";
      }
      List<CommonSearchBE> commonSearchBeList = new List<CommonSearchBE>();
      List<CommonSearchBE> commonSearchRecords = CommonSearchMgmt.GetCommonSearchRecords(this.txtSearchText.Text, this.hdnSearchMenu.Value, Convert.ToInt32(this.hdnPageSize.Value), Convert.ToInt32(this.hdnPageNumber.Value), ref this.TotalRecords);
      this.dlSearchRecords.DataSource = (object) commonSearchRecords;
      this.dlSearchRecords.DataBind();
      if (commonSearchRecords.Count == 0 && this.PageIndex > 0)
      {
        --this.CustomPaging.PageId;
        this.dlSearchRecords.DataSource = (object) commonSearchRecords;
        this.dlSearchRecords.DataBind();
      }
      else
      {
        if (commonSearchRecords.Count > 0)
        {
          this.CustomPaging.TotalRecords = this.TotalRecords;
          this.CustomPaging.Visible = true;
          this.CustomPaging.ReloadPaging();
        }
        else
          this.CustomPaging.Visible = false;
        this.dlSearchRecords.DataSource = (object) commonSearchRecords;
        this.dlSearchRecords.DataBind();
      }
    }

    protected void CustomPaging_CustomPageSelectedIndexChanged(object sender, EventArgs e) => this.GetSearchCriteria();

    protected void btnGotoPage_Click(object sender, EventArgs e) => this.GetSearchCriteria();

    protected void dlSearchRecords_ItemDataBound(object sender, DataListItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      HtmlAnchor control1 = (HtmlAnchor) e.Item.FindControl("aLinkURL");
      HiddenField control2 = (HiddenField) e.Item.FindControl("hdnLinkURL");
      HtmlAnchor control3 = (HtmlAnchor) e.Item.FindControl("aSelectedPressTitle");
      if (control2.Value.ToLower().Contains("getselectedpressdetail.aspx"))
      {
        string str = ConfigurationManager.AppSettings["LivePath"] + "/GetSelectedPressDetail.aspx/" + Encryption.EncryptQueryString(control2.Value.Split('/')[1].ToString());
        control1.HRef = str.ToString();
        control3.HRef = str.ToString();
      }
      else
      {
        control1.HRef = ConfigurationManager.AppSettings["LivePath"] + control2.Value;
        control3.HRef = ConfigurationManager.AppSettings["LivePath"] + control2.Value;
      }
    }
  }
}
