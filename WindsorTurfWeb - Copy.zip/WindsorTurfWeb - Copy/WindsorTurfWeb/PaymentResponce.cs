﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.PaymentResponce
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BAL.Payment;
using BLL.Error;
using System;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace WindsorTurfWeb
{
  public class PaymentResponce : Page
  {
    protected Dictionary<string, string> m_responseValues = new Dictionary<string, string>();
    protected HtmlForm form1;

    protected Dictionary<string, string> responseValues
    {
      get => this.m_responseValues;
      set => this.m_responseValues = value;
    }

    protected void Page_Load(object sender, EventArgs e)
    {
      StringBuilder stringBuilder = new StringBuilder();
      try
      {
        stringBuilder.AppendLine("Raw Posted Data: " + this.Request.Form?.ToString());
        PaymentMgmt.AddPaymentResponce(stringBuilder.ToString());
      }
      catch (Exception ex)
      {
        HttpContext current = HttpContext.Current;
        ErrorMgmt.AddError(new Entity.Common.Error.Error()
        {
          Url = current.Request.Url.ToString(),
          RawUrl = current.Request.Url.ToString(),
          IpAddress = this.Request.UserHostAddress,
          ExceptionSource = ex.Source,
          ExceptionMessage = ex.Message,
          ExceptionStackTrace = ex.StackTrace,
          UserName = current.User.Identity.IsAuthenticated ? current.User.Identity.Name : "Anonymous",
          Browser = current.Request.Browser.Browser + " " + current.Request.Browser.Version,
          Screen = string.Empty,
          SessionID = current.Session.SessionID,
          Cookie = current.Request.Browser.Cookies
        });
      }
    }
  }
}
