﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.CommercialRegistration
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using BLL.PageManagement;
using Entity.Common.CommercialPartner;
using Entity.Response.PageManagement;
using Helper;
using Resources;
using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb
{
  public class CommercialRegistration : Page
  {
    public static string EncryptedPwd = "";
    public static string appenddate = "";
    public static string appenddatetime = "";
    public string strValidationUserGrp = "ValGrpCommercial";
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected TextBox txtBusinessName;
    protected RequiredFieldValidator rfvBusinessName;
    protected RegularExpressionValidator regBusinessName;
    protected TextBox txtCompanyABN;
    protected RequiredFieldValidator rfvCompanyABN;
    protected CustomValidator cvalCompanyABN;
    protected TextBox txtFirstName;
    protected RequiredFieldValidator rfvFirstName;
    protected RegularExpressionValidator regFirstName;
    protected TextBox txtLastName;
    protected RequiredFieldValidator rfvLastName;
    protected RegularExpressionValidator regLastName;
    protected TextBox txtEmail;
    protected RequiredFieldValidator rfvEmail;
    protected RegularExpressionValidator regEmail;
    protected TextBox txtTelephone;
    protected RequiredFieldValidator rfvTelephone;
    protected TextBox txtFax;
    protected TextBox txtMobileNumber;
    protected TextBox txtAddressLine1;
    protected RequiredFieldValidator rfvAddressLine1;
    protected RegularExpressionValidator regAddressLine1;
    protected TextBox txtAddressLine2;
    protected RegularExpressionValidator regAddressLine2;
    protected TextBox txtSuburb;
    protected RequiredFieldValidator rfvSuburb;
    protected RegularExpressionValidator regSuburb;
    protected DropDownList ddlState;
    protected RequiredFieldValidator rfvState;
    protected TextBox txtPostcode;
    protected RequiredFieldValidator rfvPostcode;
    protected RegularExpressionValidator regPostcode;
    protected Button btnSubmit;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      this.SetFocus((Control) this.txtBusinessName);
      PageManagementResponseBE managementResponseBe = new PageManagementResponseBE();
      PageManagementResponseBE pageByLinkUrl = PageManagementMgmt.GetPageByLinkURL("commercial-registration");
      if (pageByLinkUrl != null && pageByLinkUrl.PageManagementID > 0L)
        UtilityFunctions.SetDefaultCommonHeader(this.Page, pageByLinkUrl.HeaderImage, pageByLinkUrl.NameOnMenu);
      if (this.IsPostBack)
        return;
      this.ValidationExpression();
      BindDropDown.BindAllStates((ListControl) this.ddlState);
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
      CommercialPartnerBE objBE = new CommercialPartnerBE();
      objBE.CommercialPartnerID = 0L;
      objBE.FirstName = this.txtFirstName.Text;
      objBE.LastName = this.txtLastName.Text;
      objBE.Email = this.txtEmail.Text;
      objBE.Fax = this.txtFax.Text;
      objBE.Telephone = this.txtTelephone.Text;
      objBE.Mobile = this.txtMobileNumber.Text;
      objBE.Address1 = this.txtAddressLine1.Text;
      objBE.Address2 = this.txtAddressLine2.Text;
      objBE.Suburb = this.txtSuburb.Text;
      objBE.StateMasterID = Convert.ToInt64(this.ddlState.SelectedValue);
      objBE.PostCode = this.txtPostcode.Text;
      objBE.CompanyABN = this.txtCompanyABN.Text;
      objBE.BusinessName = this.txtBusinessName.Text;
      objBE.CreatedBy = string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) ? 0L : Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      objBE.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      objBE.UserTypeID = Convert.ToInt64((object) (Enums.PersonType) 4);
      objBE.UserStatusID = Convert.ToInt64((object) (Enums.UserStatus) 4);
      if (CommercialPartnerMgmt.AddUpdateCommercialPartner(objBE) > 0L)
      {
        Mail.CommercialPartnerRegistration(objBE, this.ddlState.SelectedItem.Text);
        Mail.CommercialPartnerRegistrationAdmin(objBE, this.ddlState.SelectedItem.Text);
        if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))))
          this.Response.Redirect("~/Admin/ViewCommercialPartnerApproval.aspx");
        else
          this.Response.Redirect("/thank-you/successregistration");
      }
      else
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.AlreadyExists.ToString(), (object) "Email"), (Enums.NotificationType) 3), true);
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorForFront(this.rfvBusinessName, true, (object) this.txtBusinessName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regBusinessName, Regex.Subject, true, (object) this.txtBusinessName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvCompanyABN, true, (object) this.txtCompanyABN, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvFirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regFirstName, Regex.FirstName, true, (object) this.txtFirstName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvLastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regLastName, Regex.LastName, true, (object) this.txtLastName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvEmail, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regEmail, Regex.Email, true, (object) this.txtEmail, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvTelephone, true, (object) this.txtTelephone, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvPostcode, true, (object) this.txtPostcode, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regPostcode, Regex.ZipCode, true, (object) this.txtPostcode, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvAddressLine1, true, (object) this.txtAddressLine1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regAddressLine1, Regex.Address, true, (object) this.txtAddressLine1, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regAddressLine2, Regex.Address, true, (object) this.txtAddressLine2, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdownForFront(this.rfvState, true, (object) this.ddlState, "-1", this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvSuburb, true, (object) this.txtSuburb, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regSuburb, Regex.Address, true, (object) this.txtSuburb, this.strValidationUserGrp);
      this.btnSubmit.ValidationGroup = this.strValidationUserGrp;
    }
  }
}
