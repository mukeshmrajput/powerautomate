﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.ConfirmPayment
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Common;
using BLL.Miscellaneous;
using BLL.PageManagement;
using BLL.PaymentOptions.PaymentType;
using BLL.ProductPricing.NonTurfProductPricing.DeliveryPrices;
using BLL.ProductPricing.NonTurfProductPricing.QuantityZone;
using BLL.ProductPricing.TurfProductPricing.ServiceFees;
using BLL.ProductPricing.TurfProductPricing.TurfZone;
using BLL.PurchaseOrderDetail;
using BLL.QuoteDetail;
using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Common.Miscellaneous;
using Entity.Common.ProductPricing.TurfProductPricing.ServiceFees;
using Entity.Common.ProductPricing.TurfProductPricing.TurfZone;
using Entity.Common.PurchaseOrderDetail;
using Entity.Common.QuoteDetail;
using Entity.Common.Response;
using Entity.Response.PageManagement;
using Entity.Response.ProductPricing.NonTurfProductPricing.DeliveryPrice;
using Entity.Response.ProductPricing.NonTurfProductPricing.QuantityZone;
using Entity.Response.StockManagement.NonTurfProductManagement.NonTurfProducts;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using PayPalAPIHelper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using Telerik.Web.UI;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;

namespace WindsorTurfWeb
{
  public class ConfirmPayment : Page
  {
    public static int productQty = 0;
    private DataTable _dtCart = new DataTable();
    private double quan;
    private double total;
    private double subtotal;
    private double netQty;
    private string str = "";
    private string _productid;
    public int s = 0;
    public string strValidationUserGrp = "ValGrpCommercial";
    public string HeaderImagePath = ConfigurationManager.AppSettings[nameof (HeaderImagePath)];
    public string CardImagePath = ConfigurationManager.AppSettings[nameof (CardImagePath)];
    public string CommonInternalBannerName = ConfigurationManager.AppSettings[nameof (CommonInternalBannerName)];
    public string CompletedOrderedPickUpInvoicePath = ConfigurationManager.AppSettings[nameof (CompletedOrderedPickUpInvoicePath)];
    public string CompletedOrderedDeliveryInvoicePath = ConfigurationManager.AppSettings[nameof (CompletedOrderedDeliveryInvoicePath)];
    protected HighslideControlFront HighslideControlFront1;
    protected UpdatePanel upld1;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected HtmlGenericControl divContinueShopBtn;
    protected Button btnContShopping;
    protected HtmlGenericControl divConfirmPayment;
    protected FieldInformation FieldInformation1;
    protected Repeater rpt_cart;
    protected HiddenField hdnSubTotal;
    protected HiddenField hdnGSTVal;
    protected HiddenField hdnPickDeliveryPrice;
    protected HiddenField hdnFinalTotal;
    protected HiddenField hdnPaymentTypeID;
    protected HiddenField hdnPaymentTypeName;
    protected HiddenField hdnTurfProductCount;
    protected HiddenField hdnPickUpDetailID;
    protected HiddenField hdnRetailPurchaseOrderID;
    protected HiddenField hdnTurfProductID;
    protected HiddenField hdnTurfProductName;
    protected HtmlGenericControl divDeliveryDate;
    protected RadDatePicker radDeliveryDate;
    protected HtmlGenericControl divPickupDate;
    protected RadDatePicker radPickupDate;
    protected HtmlGenericControl divCreditcarddetails;
    protected RadioButtonList rdlCardType;
    protected DropDownList ddlCardType;
    protected TextBox txtCardOwnerName;
    protected RequiredFieldValidator rfvCardOwnerName;
    protected RegularExpressionValidator regCardOwnerName;
    protected TextBox txtCardNo;
    protected RequiredFieldValidator rfvCardNo;
    protected CustomValidator ccNumCustVal;
    protected TextBox txtCVV;
    protected RequiredFieldValidator rfvCVV;
    protected DropDownList ddlExpireMonth;
    protected RequiredFieldValidator rfvExpireMonth;
    protected DropDownList ddlExpireYear;
    protected RequiredFieldValidator rfvExpireYear;
    protected Label txtAmoutInAud;
    protected DropDownList ddlPaypalType;
    protected Button btnContinue;
    protected HiddenField hdnQuoteDetailID;
    protected HiddenField hdnTotalAreaQty;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      if (this.Session["dtCART"] != null)
        UtilityFunctions.CheckForInactiveUserForLogout(this.Page, (DataTable) this.Session["dtCART"]);
      if (this.Session["QuoteDetailID"] != null && !string.IsNullOrEmpty(this.Session["QuoteDetailID"].ToString()))
        this.hdnQuoteDetailID.Value = Convert.ToString(this.Session["QuoteDetailID"]);
      if (this.IsPostBack)
        return;
      PageManagementResponseBE managementResponseBe = new PageManagementResponseBE();
      PageManagementResponseBE pageByLinkUrl = PageManagementMgmt.GetPageByLinkURL("confirm-payment");
      if (pageByLinkUrl != null && pageByLinkUrl.PageManagementID > 0L)
        UtilityFunctions.SetDefaultCommonHeader(this.Page, pageByLinkUrl.HeaderImage, pageByLinkUrl.NameOnMenu);
      this.ValidationExpression();
      this.BindRepeter();
      this.BindDropDown();
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      RadDatePicker radDeliveryDate1 = this.radDeliveryDate;
      DateTime now = DateTime.Now;
      DateTime? nullable1 = new DateTime?(now.AddDays((double) siteConfiguration.DeliveryDays));
      radDeliveryDate1.SelectedDate = nullable1;
      RadDatePicker radDeliveryDate2 = this.radDeliveryDate;
      now = DateTime.Now;
      DateTime dateTime1 = now.AddDays((double) siteConfiguration.DeliveryDays);
      radDeliveryDate2.MinDate = dateTime1;
      DateTime dateTime2 = this.radDeliveryDate.SelectedDate.Value;
      if (dateTime2.DayOfWeek.ToString().ToLower() == "sunday")
      {
        RadDatePicker radDeliveryDate3 = this.radDeliveryDate;
        now = DateTime.Now;
        DateTime? nullable2 = new DateTime?(now.AddDays((double) (siteConfiguration.DeliveryDays + 1)));
        radDeliveryDate3.SelectedDate = nullable2;
      }
      RadDatePicker radPickupDate1 = this.radPickupDate;
      now = DateTime.Now;
      DateTime? nullable3 = new DateTime?(now.AddDays((double) siteConfiguration.DeliveryDays));
      radPickupDate1.SelectedDate = nullable3;
      RadDatePicker radPickupDate2 = this.radPickupDate;
      now = DateTime.Now;
      DateTime dateTime3 = now.AddDays((double) siteConfiguration.DeliveryDays);
      radPickupDate2.MinDate = dateTime3;
      DateTime dateTime4 = this.radDeliveryDate.SelectedDate.Value;
      if (dateTime2.DayOfWeek.ToString().ToLower() == "sunday")
      {
        RadDatePicker radPickupDate3 = this.radPickupDate;
        now = DateTime.Now;
        DateTime? nullable4 = new DateTime?(now.AddDays((double) (siteConfiguration.DeliveryDays + 1)));
        radPickupDate3.SelectedDate = nullable4;
      }
      this.btnContShopping.Text = PageName.strBtnShopName;
      this.btnContShopping.ToolTip = PageName.strBtnShopName;
      List<PaymentTypeResponse> paymentOptions = PaymentTypeMgmt.GetPaymentOptions();
      if (paymentOptions != null)
      {
        foreach (PaymentTypeResponse paymentTypeResponse in paymentOptions)
        {
          if (this.Session["SelectedPaymentType"] != null && Convert.ToInt64(this.Session["SelectedPaymentType"]) == paymentTypeResponse.PaymentTypeID)
          {
            this.hdnPaymentTypeID.Value = Convert.ToString(paymentTypeResponse.PaymentTypeID);
            this.hdnPaymentTypeName.Value = paymentTypeResponse.PaymentTypeName;
            break;
          }
        }
      }
      if (this.Session["SelectedPickUpDetails"] != null && !string.IsNullOrEmpty(this.Session["SelectedPickUpDetails"].ToString()))
        this.hdnPickUpDetailID.Value = this.Session["SelectedPickUpDetails"].ToString();
      if (this.hdnPickUpDetailID.Value == "1")
      {
        this.divPickupDate.Visible = true;
        this.divDeliveryDate.Visible = false;
      }
      else
      {
        this.divDeliveryDate.Visible = true;
        this.divPickupDate.Visible = false;
      }
      if (this.Session["strRetailPurchaseOrderID"] != null && !string.IsNullOrEmpty(this.Session["strRetailPurchaseOrderID"].ToString()))
        this.hdnRetailPurchaseOrderID.Value = Convert.ToString(this.Session["strRetailPurchaseOrderID"]);
      if (this.hdnPaymentTypeName.Value.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 1))
      {
        this.divCreditcarddetails.Visible = true;
        this.FieldInformation1.Visible = true;
      }
      else
      {
        this.divCreditcarddetails.Visible = false;
        this.FieldInformation1.Visible = false;
      }
      this.ddlPaypalType.DataSource = (object) Enum.GetValues(typeof (PayPalEnvironment)).Cast<PayPalEnvironment>().ToList<PayPalEnvironment>();
      this.ddlPaypalType.DataBind();
    }

    protected void BindDropDown()
    {
      int num = 0;
      WindsorTurfWeb.Common.BindDropDown.BindYear((ListControl) this.ddlExpireYear);
      List<CardNameResponse> cardDetail = DropDownMgmt.GetCardDetail();
      foreach (CardNameResponse cardNameResponse in cardDetail)
      {
        this.rdlCardType.Items.Add(new ListItem("<img src='" + ConfigurationManager.AppSettings["LivePath"] + this.CardImagePath + cardNameResponse.CardImage + "' alt='" + cardNameResponse.CardName + "' title='" + cardNameResponse.CardName + "'/>", cardNameResponse.CardId.ToString()));
        this.rdlCardType.CellPadding = 5;
        this.rdlCardType.CellSpacing = 5;
        ++num;
      }
      this.rdlCardType.SelectedValue = this.rdlCardType.Items[0].Value;
      this.ddlCardType.DataSource = (object) cardDetail;
      this.ddlCardType.DataTextField = "CardName";
      this.ddlCardType.DataValueField = "CardId";
      this.ddlCardType.DataBind();
    }

    private void ValidationExpression()
    {
      Validations.SetRequiredFieldValidatorForFront(this.rfvCardOwnerName, true, (object) this.txtCardOwnerName, this.strValidationUserGrp);
      Validations.SetRegularExpressionValidatorForFront(this.regCardOwnerName, Regex.FirstName, true, (object) this.txtCardOwnerName, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvCardNo, true, (object) this.txtCardNo, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorForFront(this.rfvCVV, true, (object) this.txtCVV, this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdownForFront(this.rfvExpireMonth, true, (object) this.ddlExpireMonth, "-1", this.strValidationUserGrp);
      Validations.SetRequiredFieldValidatorDropdownForFront(this.rfvExpireYear, true, (object) this.ddlExpireYear, "-1", this.strValidationUserGrp);
      if (this.divCreditcarddetails.Visible)
        this.ccNumCustVal.ValidationGroup = this.strValidationUserGrp;
      this.btnContinue.ValidationGroup = this.strValidationUserGrp;
    }

    public void BindRepeter()
    {
      if (!string.IsNullOrEmpty(this.hdnQuoteDetailID.Value.ToString()))
      {
        QuoteDetailBE detailByQuoteDetailId1 = QuoteDetailMgmt.GetQuoteDetailByQuoteDetailID(Convert.ToInt64(this.hdnQuoteDetailID.Value));
        List<QuoteDetailBE> detailByQuoteDetailId2 = QuoteDetailMgmt.GetAllQuoteDetailByQuoteDetailID(Convert.ToInt64(this.hdnQuoteDetailID.Value));
        if (detailByQuoteDetailId2.Count > 0)
        {
          int num = 0;
          if (Convert.ToInt32(detailByQuoteDetailId1.ProductType) == Convert.ToInt32((object) (Enums.TurfProductType) 1))
            ++num;
          this.hdnTurfProductCount.Value = num <= 0 ? "0" : Convert.ToString(num);
          this.rpt_cart.DataSource = (object) detailByQuoteDetailId2;
          this.rpt_cart.DataBind();
        }
        else
        {
          this.rpt_cart.DataSource = (object) detailByQuoteDetailId2;
          this.rpt_cart.DataBind();
          this.rpt_cart.Visible = false;
        }
      }
      else if (this.Session["dtCART"] != null)
      {
        this._dtCart = (DataTable) this.Session["dtCART"];
        if (this._dtCart.Rows.Count > 0)
        {
          this._dtCart = UtilityFunctions.ReverseRowsInDataTable(this._dtCart);
          int num1 = 0;
          Decimal num2 = 0M;
          for (int index = 0; index <= this._dtCart.Rows.Count - 1; ++index)
          {
            num2 += (Decimal) Convert.ToInt32(this._dtCart.Rows[index]["Quantity"].ToString());
            if (Convert.ToInt32(this._dtCart.Rows[index]["ProductType"].ToString()) == Convert.ToInt32((object) (Enums.TurfProductType) 1))
              ++num1;
          }
          this.hdnTotalAreaQty.Value = Convert.ToString(num2);
          this.hdnTurfProductCount.Value = num1 <= 0 ? "0" : Convert.ToString(num1);
          this.rpt_cart.DataSource = (object) this._dtCart;
          this.rpt_cart.DataBind();
          Label control = (Label) this.Master.FindControl("HeaderTopMenu1").FindControl("ltr_cart");
          Label label1 = control;
          int count = ((DataTable) this.Session["dtCART"]).Rows.Count;
          string str1 = "Cart (" + count.ToString() + ")";
          label1.Text = str1;
          Label label2 = control;
          count = ((DataTable) this.Session["dtCART"]).Rows.Count;
          string str2 = "Cart (" + count.ToString() + ")";
          label2.ToolTip = str2;
        }
        else
        {
          if (this._dtCart.Rows.Count != 0)
            return;
          this.rpt_cart.DataSource = (object) this._dtCart;
          this.rpt_cart.DataBind();
          this.rpt_cart.Visible = false;
        }
      }
      else
      {
        this.spnMsg.Visible = true;
        this.divContinueShopBtn.Visible = true;
        this.divConfirmPayment.Visible = false;
        this.lblMsg.Text = string.Format(Messages.ShoppingCartEmpty);
        this.spnMsg.Style.Add("color", UtilityFunctions.SetMessageColor(0));
        this.SetCartEmptyMessage();
      }
    }

    protected void SetCartEmptyMessage()
    {
      Label control = (Label) this.Master.FindControl("HeaderTopMenu1").FindControl("ltr_cart");
      control.Text = "Cart (0)";
      control.ToolTip = "Cart (0)";
    }

    protected void btnContinue_Click(object sender, EventArgs e)
    {
      PurchaseOrderDetailBE purchaseOrderDetailBe = new PurchaseOrderDetailBE();
      if (this.Session["Note"] != null)
        purchaseOrderDetailBe.Note = this.Session["Note"].ToString();
      purchaseOrderDetailBe.RetailPurchaseOrderID = Convert.ToInt64(this.hdnRetailPurchaseOrderID.Value);
      purchaseOrderDetailBe.NoOfProducts = this.rpt_cart.Items.Count;
      purchaseOrderDetailBe.SubTotal = Convert.ToDecimal(this.hdnSubTotal.Value);
      purchaseOrderDetailBe.PaymentTypeId = Convert.ToInt64(this.hdnPaymentTypeID.Value);
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
      {
        purchaseOrderDetailBe.CreatedBy = Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID"));
      }
      else
      {
        int num = string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) ? 0 : (PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString() ? 1 : 0);
        purchaseOrderDetailBe.CreatedBy = num == 0 ? 0L : Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
      }
      purchaseOrderDetailBe.CreatedByIP = HttpContext.Current.Request.UserHostAddress;
      purchaseOrderDetailBe.IsActive = true;
      string str1 = string.Empty;
      if (Convert.ToInt32(this.hdnPickUpDetailID.Value) == 1)
      {
        str1 = "PickUp";
        purchaseOrderDetailBe.PickUpPrice = Convert.ToDecimal(this.hdnPickDeliveryPrice.Value);
      }
      else if (Convert.ToInt32(this.hdnPickUpDetailID.Value) == 2)
      {
        str1 = "Delivery";
        purchaseOrderDetailBe.DeliveryPrice = Convert.ToDecimal(this.hdnPickDeliveryPrice.Value);
      }
      long orderManagementId = PurchaseOrderDetailMgmt.GetMaxPurchaseOrderManagementID();
      purchaseOrderDetailBe.objPaymentPurchaseOrder.OrderNo = orderManagementId;
      purchaseOrderDetailBe.objPaymentPurchaseOrder.OrderNostr = "I-" + orderManagementId.ToString();
      purchaseOrderDetailBe.objPaymentPurchaseOrder.GrandPrice = Convert.ToDecimal(this.hdnFinalTotal.Value);
      purchaseOrderDetailBe.objPaymentPurchaseOrder.GST = Convert.ToDecimal(this.hdnGSTVal.Value);
      DataTable dataTable1 = (DataTable) this.Session["dtCART"];
      DataTable dataTable2 = new DataTable();
      if (dataTable1 != null)
      {
        if (dataTable1.Rows.Count > 0)
        {
          dataTable2 = this.AddColumns(dataTable2);
          for (int index = 0; index <= dataTable1.Rows.Count - 1; ++index)
          {
            DataRow row = dataTable2.NewRow();
            row["TurfProductID"] = (object) dataTable1.Rows[index]["TurfProductID"].ToString();
            row["TurfProductName"] = (object) (this.rpt_cart.Items[index].FindControl("lblTurfName") as Label).Text;
            if (Convert.ToInt32(dataTable1.Rows[index]["ProductType"].ToString()) == Convert.ToInt32((object) (Enums.TurfProductType) 1))
            {
              TurfProductResponseBE detailsByIdForFront = TurfProductMgmt.GetTurfProductDetailsByIDForFront(Convert.ToInt64(dataTable1.Rows[index]["TurfProductID"].ToString()), Convert.ToInt64(dataTable1.Rows[index]["TurfZoneID"].ToString()), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
              row["TurfClassificationName"] = !string.IsNullOrEmpty(detailsByIdForFront.TurfClassificationName) ? (object) detailsByIdForFront.TurfClassificationName.ToString() : (object) string.Empty;
              TurfZoneBE turfZoneDetailById = TurfZoneMgmt.GetTurfZoneDetailByID(Convert.ToInt64(dataTable1.Rows[index]["TurfZoneID"].ToString()));
              row["TurfZoneName"] = !string.IsNullOrEmpty(turfZoneDetailById.Name) ? (object) turfZoneDetailById.Name.ToString() : (object) string.Empty;
            }
            else if (Convert.ToInt32(dataTable1.Rows[index]["ProductType"].ToString()) == Convert.ToInt32((object) (Enums.TurfProductType) 2))
            {
              NonTurfProductResponseBE detailsByIdForFront = NonTurfProductMgmt.GetNonTurfProductDetailsByIDForFront(Convert.ToInt64(dataTable1.Rows[index]["TurfProductID"].ToString()), Convert.ToInt64(dataTable1.Rows[index]["TurfZoneID"].ToString()), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
              row["TurfClassificationName"] = !string.IsNullOrEmpty(detailsByIdForFront.TurfClassificationName) ? (object) detailsByIdForFront.TurfClassificationName.ToString() : (object) string.Empty;
              QuantityZoneResponseBE quantityZoneDetailById = QuantityZoneMgmt.GetQuantityZoneDetailByID(Convert.ToInt64(dataTable1.Rows[index]["TurfZoneID"].ToString()));
              row["TurfZoneName"] = !string.IsNullOrEmpty(quantityZoneDetailById.Name) ? (object) quantityZoneDetailById.Name.ToString() : (object) string.Empty;
            }
            row["ProductPrice"] = !string.IsNullOrEmpty((this.rpt_cart.Items[index].FindControl("lbl_unitprice") as Label).Text) ? (object) (this.rpt_cart.Items[index].FindControl("lbl_unitprice") as Label).Text : (object) "0.00";
            row["ProductQuantity"] = (object) (!string.IsNullOrEmpty((this.rpt_cart.Items[index].FindControl("lbl_quan") as Label).Text) ? Convert.ToDouble((this.rpt_cart.Items[index].FindControl("lbl_quan") as Label).Text) : 0.0);
            row["ProductTotalPrice"] = !string.IsNullOrEmpty((this.rpt_cart.Items[index].FindControl("lblSubtotal") as Label).Text) ? (object) (this.rpt_cart.Items[index].FindControl("lblSubtotal") as Label).Text : (object) "0.00";
            row["ProductType"] = (object) dataTable1.Rows[index]["ProductType"].ToString();
            dataTable2.Rows.Add(row);
          }
        }
        else if (!string.IsNullOrEmpty(this.hdnQuoteDetailID.Value.ToString()))
        {
          QuoteDetailBE detailByQuoteDetailId = QuoteDetailMgmt.GetQuoteDetailByQuoteDetailID(Convert.ToInt64(this.hdnQuoteDetailID.Value));
          if (detailByQuoteDetailId != null)
          {
            dataTable2 = this.AddColumns(dataTable2);
            DataRow row = dataTable2.NewRow();
            row["TurfProductID"] = (object) Convert.ToInt64(detailByQuoteDetailId.TurfProductID);
            row["TurfProductName"] = (object) detailByQuoteDetailId.TurfName;
            if (Convert.ToInt32(detailByQuoteDetailId.ProductType) == Convert.ToInt32((object) (Enums.TurfProductType) 1))
            {
              TurfProductResponseBE detailsByIdForFront = TurfProductMgmt.GetTurfProductDetailsByIDForFront(Convert.ToInt64(detailByQuoteDetailId.TurfProductID), Convert.ToInt64(detailByQuoteDetailId.TurfZoneID), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
              row["TurfClassificationName"] = !string.IsNullOrEmpty(detailsByIdForFront.TurfClassificationName) ? (object) detailsByIdForFront.TurfClassificationName.ToString() : (object) string.Empty;
              TurfZoneBE turfZoneDetailById = TurfZoneMgmt.GetTurfZoneDetailByID(Convert.ToInt64(detailByQuoteDetailId.TurfZoneID));
              row["TurfZoneName"] = !string.IsNullOrEmpty(turfZoneDetailById.Name) ? (object) turfZoneDetailById.Name.ToString() : (object) string.Empty;
            }
            else if (Convert.ToInt32(detailByQuoteDetailId.ProductType) == Convert.ToInt32((object) (Enums.TurfProductType) 2))
            {
              NonTurfProductResponseBE detailsByIdForFront = NonTurfProductMgmt.GetNonTurfProductDetailsByIDForFront(Convert.ToInt64(detailByQuoteDetailId.TurfProductID), Convert.ToInt64(detailByQuoteDetailId.TurfZoneID), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
              row["TurfClassificationName"] = !string.IsNullOrEmpty(detailsByIdForFront.TurfClassificationName) ? (object) detailsByIdForFront.TurfClassificationName.ToString() : (object) string.Empty;
              QuantityZoneResponseBE quantityZoneDetailById = QuantityZoneMgmt.GetQuantityZoneDetailByID(Convert.ToInt64(detailByQuoteDetailId.TurfZoneID));
              row["TurfZoneName"] = !string.IsNullOrEmpty(quantityZoneDetailById.Name) ? (object) quantityZoneDetailById.Name.ToString() : (object) string.Empty;
            }
            row["ProductPrice"] = (object) detailByQuoteDetailId.Price;
            row["ProductQuantity"] = (object) Convert.ToDouble(detailByQuoteDetailId.Quantity);
            row["ProductTotalPrice"] = (object) detailByQuoteDetailId.GrandTotal;
            row["ProductType"] = (object) detailByQuoteDetailId.ProductType;
            dataTable2.Rows.Add(row);
            purchaseOrderDetailBe.QuoteDetailID = detailByQuoteDetailId.UserTypeID != Convert.ToInt64((object) (Enums.UserType) 6) ? Convert.ToInt64(this.hdnQuoteDetailID.Value) : 0L;
          }
        }
      }
      else if (!string.IsNullOrEmpty(this.hdnQuoteDetailID.Value.ToString()))
      {
        QuoteDetailBE detailByQuoteDetailId = QuoteDetailMgmt.GetQuoteDetailByQuoteDetailID(Convert.ToInt64(this.hdnQuoteDetailID.Value));
        if (detailByQuoteDetailId != null)
        {
          dataTable2 = this.AddColumns(dataTable2);
          DataRow row = dataTable2.NewRow();
          row["TurfProductID"] = (object) Convert.ToInt64(detailByQuoteDetailId.TurfProductID);
          row["TurfProductName"] = (object) detailByQuoteDetailId.TurfName;
          if (Convert.ToInt32(detailByQuoteDetailId.ProductType) == Convert.ToInt32((object) (Enums.TurfProductType) 1))
          {
            TurfProductResponseBE detailsByIdForFront = TurfProductMgmt.GetTurfProductDetailsByIDForFront(Convert.ToInt64(detailByQuoteDetailId.TurfProductID), Convert.ToInt64(detailByQuoteDetailId.TurfZoneID), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
            row["TurfClassificationName"] = !string.IsNullOrEmpty(detailsByIdForFront.TurfClassificationName) ? (object) detailsByIdForFront.TurfClassificationName.ToString() : (object) string.Empty;
            TurfZoneBE turfZoneDetailById = TurfZoneMgmt.GetTurfZoneDetailByID(Convert.ToInt64(detailByQuoteDetailId.TurfZoneID));
            row["TurfZoneName"] = !string.IsNullOrEmpty(turfZoneDetailById.Name) ? (object) turfZoneDetailById.Name.ToString() : (object) string.Empty;
          }
          else if (Convert.ToInt32(detailByQuoteDetailId.ProductType) == Convert.ToInt32((object) (Enums.TurfProductType) 2))
          {
            NonTurfProductResponseBE detailsByIdForFront = NonTurfProductMgmt.GetNonTurfProductDetailsByIDForFront(Convert.ToInt64(detailByQuoteDetailId.TurfProductID), Convert.ToInt64(detailByQuoteDetailId.TurfZoneID), UtilityFunctions.GetFrontUserID(), UtilityFunctions.GetFrontCommercialPartnerUserID());
            row["TurfClassificationName"] = !string.IsNullOrEmpty(detailsByIdForFront.TurfClassificationName) ? (object) detailsByIdForFront.TurfClassificationName.ToString() : (object) string.Empty;
            QuantityZoneResponseBE quantityZoneDetailById = QuantityZoneMgmt.GetQuantityZoneDetailByID(Convert.ToInt64(detailByQuoteDetailId.TurfZoneID));
            row["TurfZoneName"] = !string.IsNullOrEmpty(quantityZoneDetailById.Name) ? (object) quantityZoneDetailById.Name.ToString() : (object) string.Empty;
          }
          row["ProductPrice"] = (object) detailByQuoteDetailId.Price;
          row["ProductQuantity"] = (object) Convert.ToDouble(detailByQuoteDetailId.Quantity);
          row["ProductTotalPrice"] = (object) detailByQuoteDetailId.GrandTotal;
          row["ProductType"] = (object) detailByQuoteDetailId.ProductType;
          dataTable2.Rows.Add(row);
          purchaseOrderDetailBe.QuoteDetailID = detailByQuoteDetailId.UserTypeID != Convert.ToInt64((object) (Enums.UserType) 6) ? Convert.ToInt64(this.hdnQuoteDetailID.Value) : 0L;
        }
      }
      purchaseOrderDetailBe.dtPurchaseOrderProductDetail = dataTable2;
      if (this.divDeliveryDate.Visible)
      {
        DateTime dateTime = Convert.ToDateTime((object) this.radDeliveryDate.SelectedDate, (IFormatProvider) new CultureInfo("en-GB"));
        purchaseOrderDetailBe.DeliveryDate = new DateTime?(dateTime);
      }
      else if (this.divPickupDate.Visible)
      {
        DateTime dateTime = Convert.ToDateTime((object) this.radPickupDate.SelectedDate, (IFormatProvider) new CultureInfo("en-GB"));
        purchaseOrderDetailBe.PickupDate = new DateTime?(dateTime);
      }
      purchaseOrderDetailBe.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 2);
      long num1 = PurchaseOrderDetailMgmt.AddUpdatePurchaseOrderDetail(purchaseOrderDetailBe);
      purchaseOrderDetailBe.PurchaseOrderId = num1;
      if (this.hdnPaymentTypeName.Value.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 1))
      {
        purchaseOrderDetailBe.objUserCreditCardMaster.CreditCardType = this.rdlCardType.SelectedValue;
        purchaseOrderDetailBe.objUserCreditCardMaster.CreditCardNo = this.txtCardNo.Text;
        purchaseOrderDetailBe.objUserCreditCardMaster.ExpiryMonth = Convert.ToInt32(this.ddlExpireMonth.SelectedValue);
        purchaseOrderDetailBe.objUserCreditCardMaster.ExpiryYear = Convert.ToInt32(this.ddlExpireYear.SelectedValue);
        purchaseOrderDetailBe.objUserCreditCardMaster.CardHolderName = this.txtCardOwnerName.Text;
        purchaseOrderDetailBe.objUserCreditCardMaster.CVVCode = Convert.ToInt32(this.txtCVV.Text);
        this.ddlCardType.SelectedValue = this.rdlCardType.SelectedValue;
        PaymentGatewayResponse paymentGatewayResponse = new PaymentGatewayResponse();
        PaymentGatewayResponse responseFromXmlPostData = UtilityFunctions.GetPaymentResponseFromXMLPostData(Convert.ToString(purchaseOrderDetailBe.objPaymentPurchaseOrder.GrandPrice.ToString().Replace(".", "").Replace(",", "")), this.txtCardNo.Text, this.ddlExpireMonth.SelectedValue + "/" + this.ddlExpireYear.SelectedValue.ToString().Substring(2, 2), this.txtCVV.Text, this.rdlCardType.SelectedValue, this.ddlCardType.SelectedItem.Text, this.txtCardOwnerName.Text, purchaseOrderDetailBe.objPaymentPurchaseOrder.OrderNostr);
        if (responseFromXmlPostData != null)
        {
          purchaseOrderDetailBe.objPaymentCreditCardResponse.MessageID = responseFromXmlPostData.messageID;
          purchaseOrderDetailBe.objPaymentCreditCardResponse.MessageTimestamp = responseFromXmlPostData.messageTimestamp;
          purchaseOrderDetailBe.objPaymentCreditCardResponse.RequestType = "Payment";
          purchaseOrderDetailBe.objPaymentCreditCardResponse.statusCode = Convert.ToInt32(responseFromXmlPostData.statusCode);
          purchaseOrderDetailBe.objPaymentCreditCardResponse.StatusDescription = responseFromXmlPostData.statusDescription;
          purchaseOrderDetailBe.objPaymentCreditCardResponse.ResponseCode = Convert.ToInt32(responseFromXmlPostData.responseCode);
          purchaseOrderDetailBe.objPaymentCreditCardResponse.ResponseText = responseFromXmlPostData.responseText;
          purchaseOrderDetailBe.objPaymentCreditCardResponse.TxnID = responseFromXmlPostData.txnID;
          purchaseOrderDetailBe.objPaymentCreditCardResponse.TxnType = Convert.ToInt64(responseFromXmlPostData.txnType);
          purchaseOrderDetailBe.objPaymentCreditCardResponse.TxnSource = Convert.ToInt64(responseFromXmlPostData.txnSource);
          purchaseOrderDetailBe.objPaymentCreditCardResponse.Amount = purchaseOrderDetailBe.objPaymentPurchaseOrder.GrandPrice;
          purchaseOrderDetailBe.objPaymentCreditCardResponse.Approved = responseFromXmlPostData.approved;
          purchaseOrderDetailBe.objPaymentCreditCardResponse.CardDescription = responseFromXmlPostData.cardDescription;
          purchaseOrderDetailBe.objPaymentCreditCardResponse.SettlementDate = responseFromXmlPostData.settlementDate;
          try
          {
            UtilityFunctions.writetext("======================== Credit Card Response start ====================================" + DateTime.Now.ToString());
            UtilityFunctions.writetext("OrderNo :" + Convert.ToString(purchaseOrderDetailBe.objPaymentPurchaseOrder.OrderNo));
            UtilityFunctions.writetext("OrderNostr :" + Convert.ToString(purchaseOrderDetailBe.objPaymentPurchaseOrder.OrderNostr));
            UtilityFunctions.writetext("MessageID :" + Convert.ToString(responseFromXmlPostData.messageID));
            UtilityFunctions.writetext("MessageTimestamp :" + Convert.ToString(responseFromXmlPostData.messageTimestamp));
            UtilityFunctions.writetext("StatusCode :" + Convert.ToString(responseFromXmlPostData.statusCode));
            UtilityFunctions.writetext("statusDescription :" + Convert.ToString(responseFromXmlPostData.statusDescription));
            UtilityFunctions.writetext("ResponseCode :" + Convert.ToString(responseFromXmlPostData.responseCode));
            UtilityFunctions.writetext("ResponseText : " + Convert.ToString(responseFromXmlPostData.responseText));
            UtilityFunctions.writetext("TxnID :" + Convert.ToString(responseFromXmlPostData.txnID));
            UtilityFunctions.writetext("TxnType :" + Convert.ToString(responseFromXmlPostData.txnType));
            UtilityFunctions.writetext("TxnSource :" + Convert.ToString(responseFromXmlPostData.txnSource));
            UtilityFunctions.writetext("GrandPrice :" + Convert.ToString(purchaseOrderDetailBe.objPaymentPurchaseOrder.GrandPrice));
            UtilityFunctions.writetext("Approved :" + Convert.ToString(responseFromXmlPostData.approved));
            UtilityFunctions.writetext("CardDescription :" + Convert.ToString(responseFromXmlPostData.cardDescription));
            UtilityFunctions.writetext("SettlementDate : " + Convert.ToString(responseFromXmlPostData.settlementDate));
            UtilityFunctions.writetext("======================== Credit Card Response end ====================================" + DateTime.Now.ToString());
          }
          catch (Exception ex)
          {
          }
          if (responseFromXmlPostData.responseCode == "00" || responseFromXmlPostData.responseCode == "08" || responseFromXmlPostData.responseCode == "11" || responseFromXmlPostData.responseCode == "16" || responseFromXmlPostData.responseCode == "77")
          {
            purchaseOrderDetailBe.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 1);
            DateTime dateTime = Convert.ToDateTime((object) DateTime.Now, (IFormatProvider) new CultureInfo("en-GB"));
            purchaseOrderDetailBe.PaymentDate = new DateTime?(dateTime);
          }
          else
            purchaseOrderDetailBe.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 0);
        }
        else
          purchaseOrderDetailBe.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 0);
        long num2 = PurchaseOrderDetailMgmt.AddUpdatePurchaseOrderDetail(purchaseOrderDetailBe);
        if (num2 > 0L)
        {
          purchaseOrderDetailBe.PurchaseOrderId = num2;
          PurchaseOrderDetailMgmt.AddUpdatePurchaseOrderCreditCardDetail(purchaseOrderDetailBe);
        }
        if (purchaseOrderDetailBe.PaymentStatus == 1)
        {
          string str2 = UtilityFunctions.BindProductDetailForInvoice(dataTable2, (List<PurchaseOrderProductDetailBE>) null, (List<PurchaseOrderProductDetailBE>) null);
          DateTime? nullable = purchaseOrderDetailBe.DeliveryDate;
          if (!nullable.HasValue)
          {
            purchaseOrderDetailBe.DeliveryDate = new DateTime?(DateTime.MinValue);
          }
          else
          {
            nullable = purchaseOrderDetailBe.PickupDate;
            if (!nullable.HasValue)
              purchaseOrderDetailBe.PickupDate = new DateTime?(DateTime.MinValue);
          }
          string PurchaseProductDetail = str2;
          string iOrderNo = orderManagementId.ToString();
          nullable = purchaseOrderDetailBe.DeliveryDate;
          DateTime minValue1 = DateTime.MinValue;
          string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue1 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) purchaseOrderDetailBe.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
          nullable = purchaseOrderDetailBe.PickupDate;
          DateTime minValue2 = DateTime.MinValue;
          string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue2 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) purchaseOrderDetailBe.PickupDate).ToString("dd/MM/yyyy") : "N/A";
          string PaymentStatus = purchaseOrderDetailBe.PaymentStatus.ToString() == "1" ? "Paid" : "Failed";
          string PaymentOption = this.hdnPaymentTypeName.Value;
          string PickUpdetail = str1;
          string hdnRetailPurchaseOrderID = this.hdnRetailPurchaseOrderID.Value;
          string hdnPickUpDetailID = this.hdnPickUpDetailID.Value;
          string hdnSubTotal = this.hdnSubTotal.Value;
          string hdnFinalTotal = this.hdnFinalTotal.Value;
          string hdnPickDeliveryPrice = this.hdnPickDeliveryPrice.Value;
          string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
          string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
          string hdnGSTVal = this.hdnGSTVal.Value;
          UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, PaymentStatus, PaymentOption, PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
          this.Response.Redirect("/thank-you/successcredit");
        }
        else
        {
          if (purchaseOrderDetailBe.PaymentStatus != 0)
            return;
          PurchaseOrderDetailBE retailPurchaseOrderId = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(Convert.ToInt64(this.hdnRetailPurchaseOrderID.Value));
          if (!purchaseOrderDetailBe.DeliveryDate.HasValue)
            purchaseOrderDetailBe.DeliveryDate = new DateTime?(DateTime.MinValue);
          else if (!purchaseOrderDetailBe.PickupDate.HasValue)
            purchaseOrderDetailBe.PickupDate = new DateTime?(DateTime.MinValue);
          string emailAddress = retailPurchaseOrderId.EmailAddress;
          string name = retailPurchaseOrderId.Name;
          string OrderID = Convert.ToString("I-" + orderManagementId.ToString());
          string OrderPrice = this.hdnFinalTotal.Value;
          DateTime? nullable = purchaseOrderDetailBe.DeliveryDate;
          DateTime minValue3 = DateTime.MinValue;
          string ExpectedDeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue3 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) purchaseOrderDetailBe.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
          nullable = purchaseOrderDetailBe.PickupDate;
          DateTime minValue4 = DateTime.MinValue;
          string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue4 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) purchaseOrderDetailBe.PickupDate).ToString("dd/MM/yyyy") : "N/A";
          string Specialinstructions = retailPurchaseOrderId.DeliveryInstructions.ToString() == "" ? retailPurchaseOrderId.DeliveryInstructions.ToString() : "N/A";
          string PickUpDetail = str1;
          Mail.OrderEmailForFailedPayment(emailAddress, name, OrderID, OrderPrice, ExpectedDeliveryDate, PickupDate, Specialinstructions, PickUpDetail);
          this.Response.Redirect("/thank-you/failedrecredit");
        }
      }
      else if (this.hdnPaymentTypeName.Value.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 5))
      {
        try
        {
          UtilityFunctions.writetext("======================== Paypal Response start ====================================" + DateTime.Now.ToString());
          UtilityFunctions.writetext(Convert.ToString(purchaseOrderDetailBe.objPaymentPurchaseOrder.OrderNostr));
          UtilityFunctions.writetext(Convert.ToString(purchaseOrderDetailBe.objPaymentPurchaseOrder.OrderNo));
        }
        catch (Exception ex)
        {
        }
        int index = 0;
        Label control1 = this.rpt_cart.Items[index].FindControl("lblSubtotal") as Label;
        Label control2 = this.rpt_cart.Items[index].FindControl("lblTurfName") as Label;
        Label control3 = this.rpt_cart.Items[index].FindControl("lbl_quan") as Label;
        bool boolean = Convert.ToBoolean(ConfigurationManager.AppSettings["UseSandbox"]);
        PayPalCurrency currency = (PayPalCurrency) Enum.Parse(typeof (PayPalCurrency), ConfigurationManager.AppSettings["UseCurrencyCode"].ToString());
        Decimal itemPrice = Decimal.Parse(control1.Text);
        Decimal FinalTotal = Decimal.Parse(this.hdnFinalTotal.Value);
        double Quantity = double.Parse(control3.Text);
        string paypalToken;
        string paypalExpressPayment = PayPalExpressHelper.CreatePaypalExpressPayment(boolean, itemPrice, FinalTotal, currency, control2.Text, Quantity, ConfigurationManager.AppSettings["PaypalReturnUrl"], ConfigurationManager.AppSettings["PaypalCancelUrl"], out paypalToken);
        this.Session["PayPalToken"] = (object) paypalToken;
        this.Session["IsText"] = (object) boolean;
        purchaseOrderDetailBe.SubTotal = itemPrice;
        this.Session["PurchaseOrderId"] = (object) PurchaseOrderDetailMgmt.AddUpdatePurchaseOrderDetail(purchaseOrderDetailBe);
        this.Session["PaypalRetailPurchaseOrderID"] = (object) this.hdnRetailPurchaseOrderID.Value;
        this.Session["SubTotalforPDF"] = (object) this.hdnSubTotal.Value;
        this.Response.Redirect(paypalExpressPayment);
      }
      else
      {
        if (!(this.hdnPaymentTypeName.Value.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 3)) && !(this.hdnPaymentTypeName.Value.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 2)) && !(this.hdnPaymentTypeName.Value.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 4)))
          return;
        try
        {
          UtilityFunctions.writetext("======================== Direct Deposit Response start ====================================" + DateTime.Now.ToString());
          UtilityFunctions.writetext(Convert.ToString(purchaseOrderDetailBe.objPaymentPurchaseOrder.OrderNostr));
          UtilityFunctions.writetext(Convert.ToString(purchaseOrderDetailBe.objPaymentPurchaseOrder.OrderNo));
        }
        catch (Exception ex)
        {
        }
        purchaseOrderDetailBe.PaymentStatus = Convert.ToInt32((object) (Enums.PaymentStatus) 2);
        PurchaseOrderDetailMgmt.AddUpdatePurchaseOrderDetail(purchaseOrderDetailBe);
        string str3 = UtilityFunctions.BindProductDetailForInvoice(dataTable2, (List<PurchaseOrderProductDetailBE>) null, (List<PurchaseOrderProductDetailBE>) null);
        if (!purchaseOrderDetailBe.DeliveryDate.HasValue)
          purchaseOrderDetailBe.DeliveryDate = new DateTime?(DateTime.MinValue);
        else if (!purchaseOrderDetailBe.PickupDate.HasValue)
          purchaseOrderDetailBe.PickupDate = new DateTime?(DateTime.MinValue);
        System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, typeof (string), "javascript", "hidediv();", true);
        string PurchaseProductDetail = str3;
        string iOrderNo = orderManagementId.ToString();
        DateTime? nullable = purchaseOrderDetailBe.DeliveryDate;
        DateTime minValue5 = DateTime.MinValue;
        string DeliveryDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue5 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) purchaseOrderDetailBe.DeliveryDate).ToString("dd/MM/yyyy") : "N/A";
        nullable = purchaseOrderDetailBe.PickupDate;
        DateTime minValue6 = DateTime.MinValue;
        string PickupDate = (nullable.HasValue ? (nullable.HasValue ? (nullable.GetValueOrDefault() != minValue6 ? 1 : 0) : 0) : 1) != 0 ? Convert.ToDateTime((object) purchaseOrderDetailBe.PickupDate).ToString("dd/MM/yyyy") : "N/A";
        string PaymentOption = this.hdnPaymentTypeName.Value;
        string PickUpdetail = str1;
        string hdnRetailPurchaseOrderID = this.hdnRetailPurchaseOrderID.Value;
        string hdnPickUpDetailID = this.hdnPickUpDetailID.Value;
        string hdnSubTotal = this.hdnSubTotal.Value;
        string hdnFinalTotal = this.hdnFinalTotal.Value;
        string hdnPickDeliveryPrice = this.hdnPickDeliveryPrice.Value;
        string pickUpInvoicePath = this.CompletedOrderedPickUpInvoicePath;
        string deliveryInvoicePath = this.CompletedOrderedDeliveryInvoicePath;
        string hdnGSTVal = this.hdnGSTVal.Value;
        UtilityFunctions.GeneratePDFInvoice(PurchaseProductDetail, iOrderNo, DeliveryDate, PickupDate, "Awaiting Payment", PaymentOption, PickUpdetail, hdnRetailPurchaseOrderID, hdnPickUpDetailID, hdnSubTotal, hdnFinalTotal, hdnPickDeliveryPrice, pickUpInvoicePath, deliveryInvoicePath, hdnGSTVal);
        if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
        {
          if (this.Session["QuoteDetailID"] != null)
            this.Session["QuoteDetailID"] = (object) null;
          this.SetCartEmptyMessage();
          this.Response.Redirect("~/Admin/ViewOrderProcessingPurchaseDetail.aspx");
        }
        else
        {
          if (this.Session["QuoteDetailID"] != null)
            this.Session["QuoteDetailID"] = (object) null;
          if (this.hdnPaymentTypeName.Value.Replace(" ", "") == Convert.ToString((object) (Enums.PaymentTypes) 4))
            this.Response.Redirect("/thank-you/accountpayment");
          else
            this.Response.Redirect("/thank-you/successcredit");
        }
      }
    }

    protected void rpt_cart_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Footer)
        return;
      string empty = string.Empty;
      HtmlTableRow control1 = (HtmlTableRow) e.Item.FindControl("trDeliveryPrice");
      Label control2 = (Label) e.Item.FindControl("lblDeliveryPrice");
      Label control3 = (Label) e.Item.FindControl("lblFees");
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      Decimal num1 = 0M;
      string str = string.IsNullOrEmpty(this.hdnQuoteDetailID.Value.ToString()) ? this.hdnTotalAreaQty.Value : QuoteDetailMgmt.GetQuoteDetailByQuoteDetailID(Convert.ToInt64(this.hdnQuoteDetailID.Value)).AllAreaTotal;
      if (this.Session["SelectedPickUpDetails"] != null)
      {
        if (Convert.ToInt32(this.Session["SelectedPickUpDetails"]) == 1)
        {
          num1 = Convert.ToDecimal("0.00");
          control1.Visible = false;
        }
        else if (Convert.ToInt32(this.Session["SelectedPickUpDetails"]) == 2)
        {
          control1.Visible = true;
          if (Convert.ToInt32(this.hdnTurfProductCount.Value) > 0)
          {
            List<TurfZoneResponse> turfZoneResponseList = new List<TurfZoneResponse>();
            List<TurfZoneResponse> list = TurfZoneMgmt.GetTurfZone().Where<TurfZoneResponse>((System.Func<TurfZoneResponse, bool>) (m => m.IsSelectedShopPage)).ToList<TurfZoneResponse>();
            control3.Text = "Delivery Fees ($)";
            if (Convert.ToString(this.Session["ValidPostcode"]) != "")
            {
              ServiceFeesBE purchaseProductForFront = ServiceFeesMgmt.GetServiceFeesPurchaseProductForFront(list[0].TurfZoneID, Convert.ToInt64(this.Session["ValidPostcode"].ToString()), Convert.ToDecimal(str));
              if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
              {
                Decimal num2 = Convert.ToDecimal(string.Format("{0:C}", (object) double.Parse((Convert.ToDecimal(purchaseProductForFront.TradeServiceFees) / (1M + siteConfiguration.GST / 100M)).ToString("#0.00"))).Replace("$", ""));
                control2.Text = Convert.ToString(num2);
              }
              else
              {
                Decimal num3 = Convert.ToDecimal(string.Format("{0:C}", (object) double.Parse((Convert.ToDecimal(purchaseProductForFront.RetailServiceFees) / (1M + siteConfiguration.GST / 100M)).ToString("#0.00"))).Replace("$", ""));
                control2.Text = Convert.ToString(num3);
              }
            }
          }
          else
          {
            control3.Text = "Delivery Fees ($)";
            List<QuantityZoneResponse> quantityZoneResponseList = new List<QuantityZoneResponse>();
            List<QuantityZoneResponse> list = QuantityZoneMgmt.GetQuantityZone().Where<QuantityZoneResponse>((System.Func<QuantityZoneResponse, bool>) (m => m.IsSelectedShopPage)).ToList<QuantityZoneResponse>();
            if (list.Count > 0 && Convert.ToString(this.Session["ValidPostcode"]) != "")
            {
              DeliveryPriceResponseBE purchaseProductForFront = DeliveryPriceMgmt.GetDeliveryPricePurchaseProductForFront(list[0].QuantityZoneID, Convert.ToInt64(this.Session["ValidPostcode"].ToString()), Convert.ToDecimal(str));
              if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
              {
                Decimal num4 = Convert.ToDecimal(string.Format("{0:C}", (object) double.Parse((Convert.ToDecimal(purchaseProductForFront.TradeDeliveryFees) / (1M + siteConfiguration.GST / 100M)).ToString("#0.00"))).Replace("$", ""));
                control2.Text = Convert.ToString(num4);
              }
              else
              {
                Decimal num5 = Convert.ToDecimal(string.Format("{0:C}", (object) double.Parse((Convert.ToDecimal(purchaseProductForFront.RetailDeliveryFees) / (1M + siteConfiguration.GST / 100M)).ToString("#0.00"))).Replace("$", ""));
                control2.Text = Convert.ToString(num5);
              }
            }
          }
          control2.Text = string.Format("{0:C}", (object) double.Parse(control2.Text)).ToString().Replace("$", "");
          num1 = Convert.ToDecimal(control2.Text);
        }
      }
      this.hdnPickDeliveryPrice.Value = Convert.ToString(num1);
      if (!string.IsNullOrEmpty(this.hdnQuoteDetailID.Value.ToString()))
      {
        Label control4 = (Label) e.Item.FindControl("lbl_Grandtotal");
        control4.Style.Add("display", "none");
        control4.Text = (this.rpt_cart.Items[0].FindControl("lblSubtotal") as Label).Text;
        Label control5 = (Label) this.rpt_cart.Controls[this.rpt_cart.Controls.Count - 1].FindControl("lblGrandtotal");
        control5.Style.Add("display", "block");
        control5.Text = (this.rpt_cart.Items[0].FindControl("lblSubtotal") as Label).Text;
        this.hdnSubTotal.Value = !string.IsNullOrEmpty(control5.Text) ? control5.Text : "0.00";
        this.hdnSubTotal.Value = string.Format("{0:C}", (object) double.Parse((Convert.ToDecimal(this.hdnSubTotal.Value) / (1M + siteConfiguration.GST / 100M)).ToString("#0.00"))).Replace("$", "");
        control5.Text = this.hdnSubTotal.Value;
      }
      else
      {
        Label control6 = (Label) e.Item.FindControl("lbl_Grandtotal");
        control6.Style.Add("display", "block");
        control6.Text = string.Format("{0:C}", (object) double.Parse(UtilityFunctions.GetGrandTotal(this._dtCart, (DataTable) this.Session["dtCART"]))).ToString().Replace("$", "");
        this.hdnSubTotal.Value = !string.IsNullOrEmpty(control6.Text) ? control6.Text : "0.00";
        this.hdnSubTotal.Value = string.Format("{0:C}", (object) double.Parse((Convert.ToDecimal(this.hdnSubTotal.Value) / (1M + siteConfiguration.GST / 100M)).ToString("#0.00"))).Replace("$", "");
        control6.Text = this.hdnSubTotal.Value;
      }
      Label control7 = (Label) e.Item.FindControl("lblGSTVal");
      Label control8 = (Label) e.Item.FindControl("lblFinalTotal");
      Decimal num6 = Convert.ToDecimal(this.hdnSubTotal.Value) + num1;
      control7.Text = string.Format("{0:C}", (object) double.Parse((num6 * siteConfiguration.GST / 100M).ToString("#0.00"))).Replace("$", "");
      this.hdnGSTVal.Value = !string.IsNullOrEmpty(control7.Text) ? control7.Text : "0.00";
      Decimal num7 = num6 + Convert.ToDecimal(this.hdnGSTVal.Value);
      control8.Text = string.Format("{0:C}", (object) double.Parse(Convert.ToString(num7))).ToString().Replace("$", "");
      this.hdnFinalTotal.Value = control8.Text;
      this.txtAmoutInAud.Text = string.Format("{0:C}", (object) double.Parse(this.hdnFinalTotal.Value)).ToString().Replace("$", "");
    }

    private DataTable AddColumns(DataTable dtCART)
    {
      dtCART.Columns.Add(new DataColumn("TurfProductID", typeof (long)));
      dtCART.Columns.Add(new DataColumn("TurfProductName", typeof (string)));
      dtCART.Columns.Add(new DataColumn("TurfZoneName", typeof (string)));
      dtCART.Columns.Add(new DataColumn("TurfClassificationName", typeof (string)));
      dtCART.Columns.Add(new DataColumn("ProductPrice", typeof (double)));
      dtCART.Columns.Add(new DataColumn("ProductQuantity", typeof (double)));
      dtCART.Columns.Add(new DataColumn("ProductTotalPrice", typeof (double)));
      dtCART.Columns.Add(new DataColumn("ProductType", typeof (int)));
      return dtCART;
    }

    protected void btnContShopping_Click(object sender, EventArgs e) => this.Response.Redirect("/shop");
  }
}
