﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.ContentPage
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.GalleryManagement;
using BLL.NewsManagement;
using BLL.PageManagement;
using BLL.Testimonials;
using Entity.Common.NewsManagement;
using Entity.Response.GalleryManagement;
using Entity.Response.PageManagement;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;

namespace WindsorTurfWeb
{
  public class ContentPage : Page
  {
    protected Literal ltrMetaTags;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected HtmlGenericControl divContent;
    protected Literal ltrMain;
    protected HtmlGenericControl divResidential;
    protected HtmlGenericControl div1;
    protected DataList DLGallery;
    protected HtmlGenericControl divSelectedPress;
    protected DataList dlSearchRecords;
    protected Paging CustomPaging;
    protected HtmlGenericControl divAdd;
    protected HtmlGenericControl divTestimonials;
    protected DataList dlTestimonials;
    protected Paging Paging1;
    protected HtmlGenericControl div3;
    protected HiddenField hdnPageNumber;
    protected HiddenField hdnPagecount;
    protected HiddenField hdnPaging;
    protected HiddenField hdfSortField;
    protected HiddenField hdfSort;
    protected HiddenField hdnPageSize;
    protected HiddenField hdnCurrentPage;

    protected void Page_Load(object sender, EventArgs e)
    {
      GetConttentPageDataBE conttentPageDataBe = new GetConttentPageDataBE();
      if (this.Request.QueryString.Count > 0)
      {
        if (this.Request.QueryString["LinkURL".ToString()] != null)
        {
          string str = this.Request.QueryString["LinkURL".ToString()].ToString();
          GetConttentPageDataBE crumbByUrlKeyWord = PageManagementMgmt.GetBreadCrumbByURLKeyWord(str);
          if (crumbByUrlKeyWord != null && crumbByUrlKeyWord.PageManagementID > 0L)
          {
            UtilityFunctions.SetBreadCum(this.Page, crumbByUrlKeyWord);
            this.ltrMain.Text = crumbByUrlKeyWord.Description;
            this.ltrMetaTags.Text = PageBase.SetSEO(crumbByUrlKeyWord);
            if (str.ToLower().ToString() == "selected-press")
            {
              this.divSelectedPress.Visible = true;
              this.divContent.Visible = false;
              this.divResidential.Visible = false;
              this.div1.Visible = false;
              this.divTestimonials.Visible = false;
              this.GetSearchCriteria();
            }
            else if (str.ToLower().ToString() == "gallery")
            {
              this.divSelectedPress.Visible = false;
              this.divContent.Visible = false;
              this.divResidential.Visible = false;
              this.div1.Visible = true;
              this.divTestimonials.Visible = false;
              this.GetSearchRecordsForGallary();
            }
            else if (str.ToLower().ToString() == "testimonials")
            {
              this.divSelectedPress.Visible = false;
              this.divContent.Visible = false;
              this.divResidential.Visible = false;
              this.div1.Visible = false;
              this.divTestimonials.Visible = true;
              this.GetSearchCriteriaForTestimonials();
            }
            else
            {
              this.divSelectedPress.Visible = false;
              this.divContent.Visible = true;
              this.divResidential.Visible = false;
              this.div1.Visible = false;
            }
          }
          else
            this.Response.Redirect("/page-not-found");
        }
        else
          this.Response.Redirect("/page-not-found");
      }
      else
        this.Response.Redirect("/page-not-found");
    }

    protected void GetSearchCriteria()
    {
      this.hdnPageSize.Value = this.CustomPaging.PageSize.ToString();
      this.hdnPageNumber.Value = this.CustomPaging.PageId.ToString();
      this.GetSearchRecords();
    }

    protected void GetSearchCriteriaForGallary()
    {
      this.hdnPageSize.Value = this.CustomPaging.PageSize.ToString();
      this.hdnPageNumber.Value = this.CustomPaging.PageId.ToString();
      this.GetSearchRecords();
    }

    protected void GetSearchRecords()
    {
      List<NewsBE> newsForFrontEnd = NewsMgmt.GetNewsForFrontEnd("", Convert.ToInt32(this.hdnPageNumber.Value), Convert.ToInt32(this.hdnPageSize.Value));
      if (newsForFrontEnd.Count == 0)
      {
        --this.CustomPaging.PageId;
        this.divSelectedPress.Visible = false;
        this.CustomPaging.Visible = false;
        this.spnMsg.Visible = true;
        this.lblMsg.Text = "No news found";
        this.spnMsg.Style.Add("color", UtilityFunctions.SetMessageColor(0));
      }
      else if (newsForFrontEnd.Count > 0)
      {
        this.CustomPaging.TotalRecords = newsForFrontEnd[0].TotalRow;
        this.CustomPaging.Visible = true;
        this.CustomPaging.ReloadPaging();
        this.dlSearchRecords.DataSource = (object) newsForFrontEnd;
        this.dlSearchRecords.DataBind();
      }
      else
      {
        this.CustomPaging.Visible = false;
        this.divSelectedPress.Visible = true;
        this.spnMsg.Visible = false;
        this.dlSearchRecords.DataSource = (object) null;
        this.dlSearchRecords.DataBind();
      }
    }

    protected void GetSearchRecordsForGallary()
    {
      List<GalleryResponseBE> allGallery = GalleryMgmt.GetAllGallery();
      if (allGallery.Count == 0)
      {
        --this.CustomPaging.PageId;
        this.divSelectedPress.Visible = false;
        this.CustomPaging.Visible = false;
        this.div1.Visible = false;
        this.spnMsg.Visible = true;
        this.lblMsg.Text = "No Gallery found";
        this.spnMsg.Style.Add("color", UtilityFunctions.SetMessageColor(0));
      }
      else if (allGallery.Count > 0)
      {
        this.CustomPaging.TotalRecords = allGallery.Count<GalleryResponseBE>();
        this.CustomPaging.Visible = true;
        this.CustomPaging.ReloadPaging();
        this.div1.Visible = true;
        this.DLGallery.DataSource = (object) allGallery;
        this.DLGallery.DataBind();
      }
      else
      {
        this.CustomPaging.Visible = false;
        this.divSelectedPress.Visible = true;
        this.spnMsg.Visible = false;
        this.div1.Visible = false;
        this.DLGallery.DataSource = (object) null;
        this.DLGallery.DataBind();
      }
    }

    protected void CustomPaging_CustomPageSelectedIndexChanged(object sender, EventArgs e) => this.GetSearchCriteria();

    protected void btnGotoPage_Click(object sender, EventArgs e) => this.GetSearchCriteria();

    protected void GetSearchCriteriaForTestimonials()
    {
      this.hdnPageSize.Value = this.CustomPaging.PageSize.ToString();
      this.hdnPageNumber.Value = this.CustomPaging.PageId.ToString();
      this.GetTestimonials();
    }

    protected void GetTestimonials()
    {
      List<Entity.Common.Testimonials.Testimonials> testimonials = TestimonialsMgmt.GetTestimonials();
      if (testimonials.Count == 0)
      {
        --this.CustomPaging.PageId;
        this.divSelectedPress.Visible = false;
        this.CustomPaging.Visible = false;
        this.spnMsg.Visible = true;
        this.lblMsg.Text = "No Testimonials found";
        this.spnMsg.Style.Add("color", UtilityFunctions.SetMessageColor(0));
      }
      else if (testimonials.Count > 0)
      {
        this.CustomPaging.TotalRecords = testimonials[0].TotalRow;
        this.CustomPaging.Visible = true;
        this.CustomPaging.ReloadPaging();
        this.dlTestimonials.DataSource = (object) testimonials;
        this.dlTestimonials.DataBind();
      }
      else
      {
        this.CustomPaging.Visible = false;
        this.divSelectedPress.Visible = true;
        this.spnMsg.Visible = false;
        this.dlTestimonials.DataSource = (object) null;
        this.dlTestimonials.DataBind();
      }
    }
  }
}
