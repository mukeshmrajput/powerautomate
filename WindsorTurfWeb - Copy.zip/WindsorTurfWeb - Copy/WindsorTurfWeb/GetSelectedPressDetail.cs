﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.GetSelectedPressDetail
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.NewsManagement;
using Entity.Common.NewsManagement;
using System;
using System.Configuration;
using System.IO;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class GetSelectedPressDetail : Page
  {
    public int rowCount = 0;
    public static string NewsOriginalImagePath = ConfigurationManager.AppSettings[nameof (NewsOriginalImagePath)].ToString();
    protected Literal ltrNewsTitle;
    protected HighslideControlFront HighslideControlFront1;
    protected HtmlGenericControl spnMsg;
    protected Label lblMsg;
    protected HtmlGenericControl pimage;
    protected HtmlAnchor imgMainhrf;
    protected HtmlImage imgSelectedPress;
    protected Literal ltrReleasedDate;
    protected Literal ltrMain;
    protected HtmlGenericControl pURL;
    protected HtmlAnchor aURL;
    protected Literal ltrURL;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      if (this.IsPostBack)
        return;
      this.GetSearchCriteria();
    }

    protected void GetSearchCriteria()
    {
      string[] strArray = this.Request.RawUrl.ToString().Split('/');
      string str = string.Empty;
      if (!string.IsNullOrEmpty(strArray[2].ToString()))
        str = Encryption.DecryptQueryString(strArray[2].ToString());
      NewsBE newsDetailByNewsId = NewsMgmt.GetNewsDetailByNewsID((long) Convert.ToInt32(str.ToString()));
      if (newsDetailByNewsId == null)
        return;
      if (newsDetailByNewsId.IsActive)
      {
        UtilityFunctions.SetDefaultCommonHeader(this.Page, "", newsDetailByNewsId.Title);
        this.ltrMain.Text = newsDetailByNewsId.Description.ToString();
        this.aURL.HRef = newsDetailByNewsId.URL_Link.ToString();
        this.ltrURL.Text = newsDetailByNewsId.URL_Link.ToString();
        this.ltrNewsTitle.Text = newsDetailByNewsId.Title + " | " + PageName.strSelectedPress;
        this.ltrReleasedDate.Text = Convert.ToDateTime(newsDetailByNewsId.Date).ToString("dd/MM/yyyy");
        if (!string.IsNullOrEmpty(newsDetailByNewsId.Image))
        {
          if (File.Exists(this.Server.MapPath("~/") + GetSelectedPressDetail.NewsOriginalImagePath + newsDetailByNewsId.Image.ToString()))
          {
            System.Drawing.Image image = System.Drawing.Image.FromFile(this.Server.MapPath("~/") + GetSelectedPressDetail.NewsOriginalImagePath + newsDetailByNewsId.Image.ToString());
            int width = image.Width;
            int height = image.Height;
            this.imgSelectedPress.Src = ConfigurationManager.AppSettings["LivePath"] + GetSelectedPressDetail.NewsOriginalImagePath + newsDetailByNewsId.Image.ToString();
            this.imgMainhrf.HRef = ConfigurationManager.AppSettings["LivePath"] + GetSelectedPressDetail.NewsOriginalImagePath + newsDetailByNewsId.Image.ToString();
          }
          else
            this.imgSelectedPress.Src = "";
        }
        else
          this.pimage.Visible = false;
        if (!string.IsNullOrEmpty(newsDetailByNewsId.URL_Link))
          this.pURL.Visible = true;
        else
          this.pURL.Visible = false;
      }
      else
        this.Response.Redirect(WebConfigurationManager.AppSettings["LivePath"].ToString() + "Selected-Press");
    }
  }
}
