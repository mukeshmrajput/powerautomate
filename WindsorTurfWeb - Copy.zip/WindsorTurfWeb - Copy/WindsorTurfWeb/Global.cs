﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Global
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Error;
using System;
using System.Configuration;
using System.IO;
using System.Text.RegularExpressions;
using System.Web;

namespace WindsorTurfWeb
{
  public class Global : HttpApplication
  {
    private const string DummyCacheItemKey = "WindsorTurfCacheKey";

    protected void Application_Start(object sender, EventArgs e)
    {
    }

    protected void Session_Start(object sender, EventArgs e)
    {
    }

    protected void Application_BeginRequest(object sender, EventArgs e)
    {
      HttpApplication httpApplication = (HttpApplication) sender;
      string rawUrl = httpApplication.Request.RawUrl;
      string str1 = !rawUrl.ToLower().Contains("?") ? (!rawUrl.Contains("Turf_Type") ? httpApplication.Request.RawUrl.ToLower() : httpApplication.Request.RawUrl) : httpApplication.Request.RawUrl;
      string path = str1;
      string physicalPath = this.Context.Request.PhysicalPath;
      if (str1.ToLower().Contains(".css"))
      {
        this.Context.Response.StatusCode = 200;
        this.Context.Response.ContentType = "text/css";
      }
      else if (str1.ToLower().Contains(".axd"))
      {
        this.Context.Response.StatusCode = 200;
        this.Context.Response.ContentType = "text/javascript";
      }
      else if (str1.ToLower().Contains(".txt"))
      {
        this.Context.Response.StatusCode = 200;
        this.Context.Response.ContentType = "plain/text";
      }
      else if (str1.ToLower().Contains(".xml"))
      {
        this.Context.Response.StatusCode = 200;
        this.Context.Response.ContentType = "text/xml";
      }
      else
      {
        switch (Path.GetExtension(str1).ToLower())
        {
          case ".bmp":
            this.Context.Response.ContentType = "image/x-bmp";
            break;
          case ".doc":
            this.Context.Response.ContentType = "document/doc";
            break;
          case ".docx":
            this.Context.Response.ContentType = "document/docx";
            break;
          case ".gif":
            this.Context.Response.ContentType = "image/gif";
            break;
          case ".htc":
            this.Context.Response.ContentType = "text/x-component";
            break;
          case ".ico":
            this.Context.Response.ContentType = "image/ico";
            break;
          case ".jpg":
            this.Context.Response.ContentType = "image/jpeg";
            break;
          case ".pdf":
            this.Context.Response.ContentType = "application/pdf";
            break;
          case ".png":
            this.Context.Response.ContentType = "image/png";
            break;
          case ".swf":
            this.Context.Response.ContentType = "image/swf";
            break;
          case ".tif":
            this.Context.Response.ContentType = "image/tiff";
            break;
          case ".txt":
            this.Context.Response.ContentType = "plain/text";
            break;
        }
        if (str1.LastIndexOf(".css") != -1 || str1.LastIndexOf(".js") != -1 || str1.LastIndexOf(".png") != -1 || str1.LastIndexOf(".jpg") != -1 || str1.LastIndexOf(".jpeg") != -1 || str1.LastIndexOf(".gif") != -1 || str1.LastIndexOf(".ico") != -1 || str1.LastIndexOf("Convergence") != -1)
        {
          str1.ToLower().Replace(ConfigurationManager.AppSettings["LivePath"].ToString().ToLower(), string.Empty);
          FileInfo fileInfo = new FileInfo(physicalPath);
          this.Response.Cache.SetCacheability(HttpCacheability.Private);
          this.Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches);
          DateTime dateTime = DateTime.Now.AddDays(8.0);
          if (str1.ToLower().Contains("windsorturf") && fileInfo.Exists)
            this.Response.AppendHeader("Last-Modified", fileInfo.LastWriteTimeUtc.ToString("R"));
          this.Response.Cache.SetMaxAge(new TimeSpan(dateTime.ToFileTime()));
        }
        string str2 = HttpContext.Current.Request.Url.ToString();
        if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/home_supplies_lawn_sir_walter.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/primecut.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/windsor_turf_home.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/contactus.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "Our-Location");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/aboutus.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "About-Us");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/becomecommercialpartner.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "Commercial");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/installationandlandscaping.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/want-turf.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/selected-press.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "Selected-Press");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/termsandprivacy.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "Privacy-Policy");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/commonsearchpage.aspx/"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/shoppage.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "shop");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/retailpurchasedetail.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "retail-purchase-detail");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/commercial_registration.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "commercial-registration");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/deliveryandrefunds.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "Deliveries-and-Returns");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/delivery.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "Deliveries-and-Returns");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/turf_type_kikuyus-uses-maintenance-and-characteristics.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/turf_type_shademaster-buffalos-uses-maintenance-and-characteristics.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/turf_type_wintergreen-couchs-uses-maintenance-and-characteristics.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/getselectedpressdetail.aspx/EO1cL1m4mpc%3D"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "get-selected-press-detail/");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/turf_type_sir-walter-sydney-is-australias-favourite-lawn.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/turf_type_greenlees-park-couchs-uses-maintenance-and-characteristics.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/turf_type_santa-anna-couchs-uses-maintenance-and-characteristics.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/residential_sir-walter-sydney-is-australias-favourite-lawn.aspx"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "Residential-Sir-Walter-Sydney-is-Australias-favourite-lawn");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/getselectedpressdetail.aspx/OnTzgZTSXDM%3D"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "get-selected-press-detail/");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/getselectedpressdetail.aspx/%2BlZA8GBJlp0%3D"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString() + "get-selected-press-detail/");
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/menucotent.aspx?pid=-1"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        else if (str2.ToString().ToLower().Contains("http://www.windsorturf.com.au/menucotent.aspx?pid=23"))
          this.Response.Redirect(ConfigurationManager.AppSettings["LivePath"].ToString());
        if (str1.Contains("?fbclid"))
          str1 = str1.Substring(0, str1.IndexOf("?fbclid"));
        if (!str1.ToLower().Contains("admin") && !str1.ToLower().Contains("handler") && !str1.ToLower().Contains("content/") && !str1.ToLower().Contains(".ico") && !str1.ToLower().Contains(".html") && !str1.ToLower().Contains(".txt") && !str1.ToLower().Contains(".axd") && !str1.ToLower().Contains("stats") && !str1.ToLower().Contains(".js") && !str1.ToLower().Contains("/images") && !str1.ToLower().Contains(".css") && !str1.ToLower().Contains("/fonts") && !str1.ToLower().Contains(".htc") && !str1.ToLower().Contains("getcaptcha") && !str1.ToLower().Contains("ConfirmOrderwithThankyou.aspx") && !str1.Contains("ViewOrderProcessingPurchaseDetails.aspx") && !str1.Contains("/highslide/graphics/zoomin.cur"))
        {
          string[] strArray1 = new string[10]
          {
            "~/(Default|default\\.aspx)?",
            "~/([A-Za-z0-9_%+.-]*)(\\/)?",
            "~/([A-Za-z0-9_%+.-]*)[/]?/([A-Za-z0-9_%+.-]*)[/]?",
            "~/([A-Za-z0-9_%+.-]*)[/]?/([A-Za-z0-9_%+.-~=]*)[/]?",
            "~/([A-Za-z0-9_%+.-]*)[/]?/([A-Za-z0-9_%+.-~=]*)[/]?",
            "~/([A-Za-z0-9_%+.-]*)[/]?/([A-Za-z0-9_%+.-~=]*)[/]?",
            "~/(orderhistory.aspx|order-history)(\\/)?",
            "~/(changepassword.aspx|change-password)(\\/)?",
            "~/(updateprofile.aspx|updateprofile)(\\/)?",
            "~/(forgotpassword.aspx|forgot-password)(\\/)?"
          };
          string[] strArray2 = new string[11]
          {
            "~/Default.aspx",
            "~/ContentPage.aspx?LinkURL=$1",
            "~/thankyou.aspx?Type=$1&Type1=$2",
            "~/TurfDescription.aspx?Type=$1&Type1=$2",
            "~/CommonSearchPage.aspx?Type=$1&Type1=$2",
            "~/GetSelectedPressDetail.aspx?Type=$1&Type1=$2",
            "~/GetTestimonialsDetails.aspx?Type=$1&Type1=$2",
            "~/CommercialPartner/OrderHistory.aspx",
            "~/CommercialPartner/ChangePassword.aspx",
            "~/CommercialPartner/UpdateProfile.aspx",
            "~/ForgotPassword.aspx"
          };
          bool flag = false;
          for (int index = 0; index < strArray1.Length; ++index)
          {
            Regex regex = new Regex("^" + Global.ResolveUrl(this.Context.Request.ApplicationPath, strArray1[index]) + "$", RegexOptions.IgnoreCase);
            if (regex.IsMatch(str1))
            {
              string Val;
              switch (index)
              {
                case 1:
                  Val = !str1.ToLower().Contains("our-location") ? (!str1.ToLower().Contains("page-not-found") ? (!(str1.ToLower() == "/shop") ? (!str1.ToLower().Contains("commercial-registration") ? (!str1.ToLower().Contains("confirm-payment") ? (!str1.ToLower().Contains("checkout") ? (!str1.ToLower().Contains("get-quote") ? (!str1.ToLower().Contains("calculate-turfarea") ? (!str1.ToLower().Contains("quote-detail") ? (!str1.ToLower().Contains("retail-purchase-detail") ? (!str1.ToLower().Contains("order-history") ? (!str1.ToLower().Contains("quote-history") ? (!str1.ToLower().Contains("change-password") ? (!str1.ToLower().Contains("updateprofile") ? (!str1.ToLower().Contains("forgotpassword.aspx") ? Global.ResolveUrl(this.Context.Request.ApplicationPath, regex.Replace(str1, strArray2[index].ToString())) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/ForgotPassword.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CommercialPartner/UpdateProfile.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CommercialPartner/ChangePassword.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CommercialPartner/ViewQuoteHistory.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CommercialPartner/OrderHistory.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/RetailPurchaseDetail.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/QuoteDetail.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CalculateTurfArea.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/GetQuote.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CheckOut.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/ConfirmPayment.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CommercialRegistration.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/ShopPage.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/PageNotFound.aspx")) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/OurLocation.aspx");
                  break;
                case 2:
                  Val = !str1.ToLower().Contains("thank-you") ? (!str1.Contains("commoncontentsearch") ? (!str1.Contains("newscontentsearch") ? (!str1.Contains("turfcontentsearch") ? Global.ResolveUrl(this.Context.Request.ApplicationPath, regex.Replace(str1, strArray2[index].ToString().Replace("$1", str1).Replace("$2", str1))) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CommonSearchPageTurf.aspx?Type=" + regex.Replace(str1, "$1") + "&Type1=" + regex.Replace(str1, "$2"))) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CommonSearchPageNews.aspx?Type=" + regex.Replace(str1, "$1") + "&Type1=" + regex.Replace(str1, "$2"))) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/CommonSearchPage.aspx?Type=" + regex.Replace(str1, "$1") + "&Type1=" + regex.Replace(str1, "$2"))) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/ThankYou.aspx?Type=" + regex.Replace(str1, "$1") + "&Type1=" + regex.Replace(str1, "$2"));
                  break;
                case 3:
                  Val = !str1.Contains("TurfSearch_") ? (!str1.Contains("Turf_Type_") ? (!str1.ToLower().Contains("get-selected-press-detail") ? (!str1.ToLower().Contains("testimonials-details") ? Global.ResolveUrl(this.Context.Request.ApplicationPath, regex.Replace(str1, strArray2[index].ToString().Replace("$1", str1).Replace("$2", str1))) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/GetTestimonialsDetails.aspx?Type=" + regex.Replace(str1, "$1") + "&Type1=" + regex.Replace(str1, "$2"))) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/GetSelectedPressDetail.aspx?Type=" + regex.Replace(str1, "$1") + "&Type1=" + regex.Replace(str1, "$2"))) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/TurfDescription.aspx?Type=" + regex.Replace(str1, "$1") + "&Type1=" + regex.Replace(str1, "$2"))) : Global.ResolveUrl(this.Context.Request.ApplicationPath, "~/TurfContentDetailPage.aspx?Type=" + regex.Replace(str1, "$1") + "&Type1=" + regex.Replace(str1, "$2"));
                  break;
                default:
                  Val = Global.ResolveUrl(this.Context.Request.ApplicationPath, regex.Replace(str1, strArray2[index]));
                  break;
              }
              path = Global.ReplaceCareteAnd(Val);
              flag = true;
              break;
            }
          }
          if (flag)
            ;
          this.Context.RewritePath(path);
        }
        string str3 = HttpContext.Current.Request.Url.ToString();
        if (str3.ToLower().StartsWith("http://windsorturf.com.au/"))
        {
          this.Response.Status = "301 Moved Permanently";
          this.Response.AddHeader("Location", str3.Replace("http://windsorturf.com.au/", "https://www.windsorturf.com.au/"));
          this.Response.End();
        }
        else if (str3.ToLower().StartsWith("http://www.windsorturf.com.au/"))
        {
          this.Response.Status = "301 Moved Permanently";
          this.Response.AddHeader("Location", str3.Replace("http://www.windsorturf.com.au/", "https://www.windsorturf.com.au/"));
          this.Response.End();
        }
        else
        {
          if (!str3.ToLower().StartsWith("https://windsorturf.com.au/"))
            return;
          this.Response.Status = "301 Moved Permanently";
          this.Response.AddHeader("Location", str3.Replace("https://windsorturf.com.au/", "https://www.windsorturf.com.au/"));
          this.Response.End();
        }
      }
    }

    internal static string ResolveUrl(string appPath, string url)
    {
      if (url.Length == 0 || url[0] != '~')
        return url;
      if (url.Length == 1)
        return appPath;
      return url[1] == '/' || url[1] == '\\' ? (appPath.Length > 1 ? appPath + "/" + url.Substring(2) : "/" + url.Substring(2)) : (appPath.Length > 1 ? appPath + "/" + url.Substring(1) : appPath + url.Substring(1));
    }

    public static string ReplaceCareteAnd(string Val)
    {
      Val = Val.Replace("^", HttpContext.Current.Server.UrlEncode("&"));
      return Val;
    }

    protected void Application_AuthenticateRequest(object sender, EventArgs e)
    {
    }

    protected void Session_End(object sender, EventArgs e)
    {
    }

    protected void Application_End(object sender, EventArgs e)
    {
    }

    public long AddError(Exception ex)
    {
      string str1 = string.Empty;
      Entity.Common.Error.Error error = new Entity.Common.Error.Error();
      if (ex != null)
      {
        error.Url = "";
        string str2 = "<br><b>Url:</b> " + error.Url;
        error.RawUrl = "";
        string str3 = str2 + "<br><b>RawUrl:</b> " + error.RawUrl;
        error.UserName = "Anonymous";
        string str4 = str3 + "<br><b>UserName:</b> " + error.UserName;
        error.IpAddress = "";
        string str5 = str4 + "<br><b>IpAddress:</b> " + error.IpAddress;
        error.Browser = "";
        string str6 = str5 + "<br><b>Browser:</b> " + error.Browser;
        error.Screen = "";
        string str7 = str6 + "<br><b>Screen:</b> " + error.Screen;
        error.SessionID = "";
        string str8 = str7 + "<br><b>SessionID:</b> " + error.SessionID;
        error.Cookie = false;
        string str9 = str8 + "<br><b>Cookie: </b>" + error.Cookie.ToString();
        error.JavaScript = false;
        str1 = str9 + "<br><b>Javascript: </b>" + error.JavaScript.ToString();
      }
      error.ExceptionMessage = ex.Message;
      string str10 = str1 + "<br><b>Exeption Message: </b>" + error.ExceptionMessage;
      error.ExceptionSource = ex.Source;
      string str11 = str10 + "<br><b>Exeption Source: </b>" + error.ExceptionSource;
      error.ExceptionStackTrace = ex.StackTrace + "<br><b>Inner Exception: </b>" + ex.InnerException?.ToString();
      string str12 = str11 + "<br><b>StackTrace: </b>" + error.ExceptionStackTrace;
      error.ErrorDate = DateTime.Now;
      string str13 = str12 + "<br><b>Error Date: </b>" + error.ErrorDate.ToString();
      return ErrorMgmt.AddError(error);
    }

    private void LogError(HttpContext ctx, Exception exception)
    {
      string str1 = string.Empty;
      Entity.Common.Error.Error error = new Entity.Common.Error.Error();
      if (ctx != null)
      {
        error.Url = ctx.Request.Url.ToString();
        string str2 = "<br><b>Url:</b> " + error.Url;
        error.RawUrl = ctx.Request.RawUrl;
        string str3 = str2 + "<br><b>RawUrl:</b> " + error.RawUrl;
        error.UserName = ctx.User.Identity.IsAuthenticated ? ctx.User.Identity.Name : "Anonymous";
        string str4 = str3 + "<br><b>UserName:</b> " + error.UserName;
        error.IpAddress = ctx.Request.UserHostAddress;
        string str5 = str4 + "<br><b>IpAddress:</b> " + error.IpAddress;
        error.Browser = ctx.Request.Browser.Browser;
        string str6 = str5 + "<br><b>Browser:</b> " + error.Browser;
        error.Screen = ctx.Request.Browser.ScreenPixelsWidth.ToString() + "x" + ctx.Request.Browser.ScreenPixelsHeight.ToString() + " @" + ctx.Request.Browser.ScreenBitDepth.ToString() + "bit";
        string str7 = str6 + "<br><b>Screen:</b> " + error.Screen;
        error.SessionID = "";
        string str8 = str7 + "<br><b>SessionID:</b> " + error.SessionID;
        error.Cookie = ctx.Request.Browser.Cookies;
        string str9 = str8 + "<br><b>Cookie: </b>" + error.Cookie.ToString();
        error.JavaScript = ctx.Request.Browser.JavaScript;
        str1 = str9 + "<br><b>Javascript: </b>" + error.JavaScript.ToString();
      }
      error.ExceptionMessage = exception.Message;
      string str10 = str1 + "<br><b>Exeption Message: </b>" + error.ExceptionMessage;
      error.ExceptionSource = exception.Source;
      string str11 = str10 + "<br><b>Exeption Source: </b>" + error.ExceptionSource;
      error.ExceptionStackTrace = exception.StackTrace + "<br><b>Inner Exception: </b>" + exception.InnerException?.ToString();
      string str12 = str11 + "<br><b>StackTrace: </b>" + error.ExceptionStackTrace;
      error.ErrorDate = DateTime.Now;
      string str13 = str12 + "<br><b>Error Date: </b>" + error.ErrorDate.ToString();
      ErrorMgmt.AddError(error);
    }

    protected void Application_Error(object sender, EventArgs e)
    {
      HttpContext current = HttpContext.Current;
      Exception lastError = current.Server.GetLastError();
      HttpException httpException = lastError as HttpException;
      string lower = ((HttpApplication) sender).Request.RawUrl.ToLower();
      if (httpException != null && httpException.GetHttpCode() == 500)
      {
        this.LogError(current, lastError);
        this.Server.ClearError();
      }
      if (lower.ToLower().Contains(".css") || lower.ToLower().Contains(".js") || lower.ToLower().Contains(".png") || lower.ToLower().Contains(".jpeg") || lower.ToLower().Contains(".gif") || lower.ToLower().Contains("admin"))
        return;
      this.Response.StatusCode = 404;
      this.Response.Redirect("/page-not-found");
    }
  }
}
