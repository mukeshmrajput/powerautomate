﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Default
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.BannerManagement;
using BLL.CommercialPartner;
using BLL.PageManagement;
using BLL.ProductPricing.TurfProductPricing.TurfZone;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using BLL.UserManagement;
using Entity.Common.Response;
using Entity.Common.UserManagement;
using Entity.Response.BannerManagement;
using Entity.Response.CommercialPartner;
using Entity.Response.PageManagement;
using Entity.Response.StockManagement.TurfProductManagement.TurfProducts;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class Default : Page
  {
    public string Livepath = ConfigurationManager.AppSettings[nameof (Livepath)].ToString();
    private DataTable _dtQUOTE = new DataTable();
    protected Literal ltrMetaTags;
    protected HeaderTopMenu HeaderTopMenu1;
    protected Repeater rptBanner;
    protected HtmlGenericControl NoImageLi;
    protected Repeater RptHomeImage;
    protected Literal ltrDefaultTurfProduct;
    protected HtmlAnchor aimgSirWalter;
    protected HtmlImage imgDefaultHomePage;
    protected Literal ltrSirWalter;
    protected HtmlAnchor aSirWalter;
    protected Literal ltrAboutUs;

    protected void Page_Load(object sender, EventArgs e)
    {
      PageManagementResponseBE managementResponseBe = new PageManagementResponseBE();
      PageManagementResponseBE pageByLinkUrl = PageManagementMgmt.GetPageByLinkURL("home");
      if (pageByLinkUrl != null && pageByLinkUrl.PageManagementID > 0L)
        this.ltrMetaTags.Text = PageBase.SetSEO(pageByLinkUrl);
      if (this.Session["AlreadySetPassword"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.SetPasswordStr), (Enums.NotificationType) 3), true);
        this.Session["AlreadySetPassword"] = (object) null;
      }
      if (this.Session["AlreadyResetPassowrd"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.SetPasswordStr), (Enums.NotificationType) 3), true);
        this.Session["AlreadyResetPassowrd"] = (object) null;
      }
      if (this.Session["QuoteDetailID"] != null)
        this.Session["QuoteDetailID"] = (object) null;
      if (this.GetCommercialPartnerInactiveStatus() == "Inactive")
      {
        FormsAuthentication.SignOut();
        this.Session.Clear();
        if (this.Request.Cookies[".Frontendcookie"] != null)
          this.Response.Cookies.Add(new HttpCookie(".Frontendcookie")
          {
            Expires = DateTime.Now.AddDays(-1.0)
          });
        this.Session["InactivateCommercialPartner"] = (object) "InactivateCommercialPartner";
        this.Response.Redirect("/default.aspx");
      }
      if (this.Session["InactivateCommercialPartner"] != null)
      {
        System.Web.UI.ScriptManager.RegisterClientScriptBlock((Page) this, this.GetType(), "script", UtilityFunctions.GetNotificationFront(string.Format(Messages.NoAccessInactivateUser), (Enums.NotificationType) 3), true);
        this.Session["InactivateCommercialPartner"] = (object) null;
        this.Session.Abandon();
      }
      if (this.IsPostBack)
        return;
      this.BindContent();
      UtilityFunctions.SetQuoteEmptyMessage(this.Page, this._dtQUOTE);
    }

    protected void BindContent()
    {
      List<PageManagementResponseBE> managementResponseBeList1 = new List<PageManagementResponseBE>();
      List<PageManagementResponseBE> homePageContent = PageManagementMgmt.GetHomePageContent();
      if (homePageContent != null)
      {
        List<PageManagementResponseBE> managementResponseBeList2 = new List<PageManagementResponseBE>();
        this.ltrAboutUs.Text = homePageContent.Where<PageManagementResponseBE>((System.Func<PageManagementResponseBE, bool>) (m => m.LinkURL == "home")).ToList<PageManagementResponseBE>()[0].Description;
        TurfProductResponseBE productOnHomePage1 = TurfProductMgmt.GetDefaultTurfProductOnHomePage();
        this.ltrDefaultTurfProduct.Text = productOnHomePage1.TurfName;
        this.ltrSirWalter.Text = UtilityFunctions.GetShortText(productOnHomePage1.Description, 400);
        TurfProductResponseBE productOnHomePage2 = TurfProductMgmt.GetDefaultTurfProductOnHomePage();
        this.aSirWalter.HRef = this.GetPageName();
        this.aimgSirWalter.HRef = this.GetPageName();
        if (productOnHomePage2 != null)
        {
          this.aimgSirWalter.Title = productOnHomePage2.TurfName;
          if (productOnHomePage2.MainImage != null)
            this.imgDefaultHomePage.Src = ConfigurationManager.AppSettings["Livepath"].ToString() + ConfigurationManager.AppSettings["TurfShopPageImagePath"].ToString() + productOnHomePage2.MainImage.ToString();
        }
      }
      List<PageManagementResponseBE> managementResponseBeList3 = new List<PageManagementResponseBE>();
      List<PageManagementResponseBE> pageContentForHome = PageManagementMgmt.GetHomePageContentForHome();
      if (pageContentForHome.Count > 0)
      {
        this.RptHomeImage.DataSource = (object) pageContentForHome;
        this.RptHomeImage.DataBind();
      }
      List<BannerResponse> bannerResponseList = new List<BannerResponse>();
      List<BannerResponse> frontEndBanners = BannerMgmt.GetFrontEndBanners();
      if (frontEndBanners.Count > 0)
      {
        this.rptBanner.DataSource = (object) frontEndBanners;
        this.rptBanner.DataBind();
        this.NoImageLi.Visible = false;
      }
      else
        this.NoImageLi.Visible = true;
    }

    public string GetPageName()
    {
      string pageName = string.Empty;
      TurfZoneResponse defaultForHomePage = TurfZoneMgmt.GetTurfZoneDefaultForHomePage();
      TurfProductResponseBE productOnHomePage = TurfProductMgmt.GetDefaultTurfProductOnHomePage();
      if (productOnHomePage != null)
        pageName = productOnHomePage.TurfLinkURL.Replace("%%%", "") + "/Turf_" + Encryption.EncryptQueryString(defaultForHomePage.TurfZoneID.ToString()) + "_" + Encryption.EncryptQueryString(productOnHomePage.TurfProductID.ToString());
      return pageName;
    }

    protected string GetCommercialPartnerInactiveStatus()
    {
      string partnerInactiveStatus = string.Empty;
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
      {
        CommercialPartnerResponseBE detailByLoginMasterId = CommercialPartnerMgmt.GetCommercialPartnerDetailByLoginMasterID(Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")));
        if (detailByLoginMasterId != null && !detailByLoginMasterId.IsActive)
          partnerInactiveStatus = "Inactive";
      }
      else if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
      {
        UserBE userInfoById = UserMgmt.GetUserInfoById(Convert.ToInt64(Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)))));
        if (userInfoById != null && !userInfoById.IsActive)
          partnerInactiveStatus = "Inactive";
      }
      return partnerInactiveStatus;
    }

    protected void RptHomeImage_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      HtmlAnchor control1 = (HtmlAnchor) e.Item.FindControl("aimgCommercial");
      Literal control2 = (Literal) e.Item.FindControl("ltrCommercial");
      HtmlAnchor control3 = (HtmlAnchor) e.Item.FindControl("aCommercial");
      string str1 = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "LinkURL"));
      string str2 = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "PageTitle"));
      string TextValue = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "ShortDescription"));
      string str3 = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "HomePageImage"));
      if (control1 != null && control2 != null && control3 != null)
      {
        control2.Text = UtilityFunctions.GetShortText(TextValue, 400);
        control2.Text = control2.Text.Replace("<p>", "").Replace("</p>", "");
        control2.Text = "<p>" + control2.Text + "</p>";
        control1.HRef = str1;
        control1.Title = str2;
        control3.HRef = str1;
        if (!string.IsNullOrEmpty(str3))
          control1.InnerHtml = "<img src=\"" + ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["HomePageOriginalImagePath"] + str3 + "\" width=\"380\" height=\"318\"  />";
        else
          control1.InnerHtml = "<img src=\"/Content/FrontEnd/Images/Homepagebox.jpg\" width=\"380\" height=\"318\" />";
      }
    }

    protected void rptBanner_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      HtmlGenericControl control1 = (HtmlGenericControl) e.Item.FindControl("liImage");
      HtmlImage control2 = (HtmlImage) e.Item.FindControl("ImgLi");
      string str1 = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "BannerTitle"));
      string str2 = Convert.ToString(DataBinder.Eval(e.Item.DataItem, "BannerImage"));
      if (!string.IsNullOrEmpty(str2) && control1 != null && control2 != null)
      {
        control1.Attributes.Add("data - thumb", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["BannerThumbImagePath"] + str2);
        control1.Attributes.Add("data-title", str1);
        control2.Src = ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["BannerOriginalImagePath"] + str2;
        control2.Attributes.Add("alt", str1);
      }
    }
  }
}
