﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.ThankYou
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;

namespace WindsorTurfWeb
{
  public class ThankYou : Page
  {
    private DataTable _dtCart = new DataTable();
    public string strPageTitle = string.Empty;
    public string ImagePath = ConfigurationManager.AppSettings[nameof (ImagePath)];
    protected HtmlImage imgThankYou;
    protected HtmlGenericControl divRegistration;
    protected HtmlGenericControl divPurchase;
    protected Label lblOrderNumber;
    protected HtmlGenericControl div_CreaditSuccess;
    protected HtmlGenericControl div_CreaditFail;
    protected HtmlGenericControl div_CancelPayment;
    protected HtmlGenericControl div_AccountPaymentType;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      UtilityFunctions.SetDefaultCommonHeader(this.Page, "", PageName.strThankYou);
      this.strPageTitle = PageName.strThankYou;
      if (this.IsPostBack)
        return;
      this.imgThankYou.Src = ConfigurationManager.AppSettings["Livepath"] + this.ImagePath + "Windsorturf-thankyou-page_03.png";
      if (this.Session["CartId"] != null)
        this.lblOrderNumber.Text = this.Session["CartId"].ToString();
      if (!this.IsPostBack)
      {
        string[] strArray = this.Request.Url.ToString().Split('=');
        if (!string.IsNullOrEmpty(strArray[2].ToString()))
        {
          switch (strArray[2].ToString())
          {
            case "successregistration":
              this.divRegistration.Visible = true;
              this.strPageTitle = PageName.strThankYou;
              break;
            case "successpurchase":
              this.divPurchase.Visible = true;
              this.strPageTitle = PageName.strThankYou;
              break;
            case "successcredit":
              this.div_CreaditSuccess.Visible = true;
              this.strPageTitle = PageName.strThankYou;
              break;
            case "failedrecredit":
              UtilityFunctions.SetDefaultCommonHeader(this.Page, "", PageName.strFailedTransaction);
              this.div_CreaditFail.Visible = true;
              this.strPageTitle = PageName.strFailedTransaction;
              break;
            case "cancelpayment":
              UtilityFunctions.SetDefaultCommonHeader(this.Page, "", PageName.strCancel);
              this.imgThankYou.Src = ConfigurationManager.AppSettings["Livepath"] + this.ImagePath + "Windsorturf-Cancelled.png";
              this.div_CancelPayment.Visible = true;
              this.strPageTitle = PageName.strCancel;
              break;
            case "accountpayment":
              this.div_AccountPaymentType.Visible = true;
              this.strPageTitle = PageName.strThankYou;
              break;
          }
          if (this.Session["returnUrl"] != null)
            this.Session["returnUrl"] = (object) null;
        }
        this.ClearCart();
      }
    }

    protected void ClearCart() => UtilityFunctions.SetCartEmptyMessage(this.Page, this._dtCart);
  }
}
