﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.ForgotPassword
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.UserManagement;
using Entity.Response.UserManagement;
using Helper;
using Resources;
using System;
using System.Configuration;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class ForgotPassword : Page
  {
    public string strValidationUserGrp = "PasswordValGrp";
    public string HeaderImagePath = ConfigurationManager.AppSettings["ImagePath"];
    public string CommonInternalBannerName = ConfigurationManager.AppSettings[nameof (CommonInternalBannerName)];
    protected HtmlForm areacalculator;
    protected HtmlGenericControl DivHidHeader;
    protected HtmlGenericControl divMaimMessage;
    protected HtmlGenericControl divMessage;
    protected HtmlGenericControl DivltrErrormsg;
    protected Literal ltrmsg;
    protected HtmlGenericControl DivltrSuccessmsg;
    protected Literal ltrsucess;
    protected HiddenField hdnUserID;
    protected HtmlGenericControl DivHid;
    protected TextBox txtusername;
    protected RequiredFieldValidator rfvUsername;
    protected RegularExpressionValidator regUsername;
    protected Button btnSend;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      this.ValidationIntialization();
      if (!string.IsNullOrEmpty(this.Request.QueryString["UserID"]))
        this.hdnUserID.Value = Convert.ToString(Encryption.DecryptQueryString(this.Request.QueryString["UserID"]));
      this.Page.Form.DefaultButton = this.btnSend.UniqueID;
    }

    private void ValidationIntialization()
    {
      this.rfvUsername.ErrorMessage = string.Format(Validation.Required);
      this.regUsername.ErrorMessage = string.Format(Validation.Invalid1);
      this.regUsername.ValidationExpression = Regex.Email;
    }

    protected void btnSend_Click(object sender, EventArgs e)
    {
      if (!this.Page.IsValid)
        return;
      UserResponseBE idByEmailAddress = UserMgmt.GetUserIDByEmailAddress(this.txtusername.Text.Trim(), (long) Convert.ToInt32((object) (Enums.UserType) 4));
      if (idByEmailAddress.LoginMasterID != 0L)
      {
        Mail.ForgotPasswordForCommercialUser(this.txtusername.Text.Trim(), idByEmailAddress.LoginMasterID, idByEmailAddress.Name);
        UserMgmt.UpdateIsForgotPassword(Convert.ToInt64(idByEmailAddress.LoginMasterID));
        this.DivHid.Visible = false;
        this.DivHidHeader.Visible = false;
        this.DivltrErrormsg.Visible = false;
        this.DivltrSuccessmsg.Visible = true;
        this.ltrsucess.Text = string.Format(Messages.ForgotThankyou);
        this.divMessage.Attributes["class"] = "info2";
        this.divMaimMessage.Style.Add("position", "relative");
        this.divMessage.Style.Add("display", "block");
        System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, typeof (string), "javascript", "ChangeHeightofDiv();", true);
      }
      else
      {
        this.divMessage.Style.Add("display", "block");
        this.DivltrErrormsg.Visible = true;
        this.DivltrSuccessmsg.Visible = false;
        this.ltrmsg.Text = string.Format(Messages.EmailNotExit, (object) this.txtusername.Text);
        this.txtusername.Focus();
        System.Web.UI.ScriptManager.RegisterStartupScript(this.Page, typeof (string), "javascript", "ChangeHeightofDivErrorMsg();", true);
      }
    }
  }
}
