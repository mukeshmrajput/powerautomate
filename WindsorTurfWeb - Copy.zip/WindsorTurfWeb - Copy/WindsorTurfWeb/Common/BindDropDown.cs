﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.BindDropDown
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using BLL.Common;
using BLL.HearAboutUs;
using BLL.ProductPricing.NonTurfProductPricing.DeliveryRegion;
using BLL.ProductPricing.NonTurfProductPricing.QuantityRanges;
using BLL.ProductPricing.NonTurfProductPricing.QuantityZone;
using BLL.ProductPricing.TurfProductPricing.ServiceRegions;
using BLL.ProductPricing.TurfProductPricing.TurfRanges;
using BLL.ProductPricing.TurfProductPricing.TurfZone;
using BLL.PurchaseOrderDetail;
using BLL.QuoteDetail;
using BLL.StateMaster;
using BLL.StockManagement.NonTurfProductManagement.NonTurfProducts;
using BLL.StockManagement.TurfProductManagement.TurfProducts;
using Entity.Common;
using Entity.Common.PurchaseOrderDetail;
using Entity.Common.QuoteDetail;
using Entity.Common.Response;
using Entity.Response.ProductPricing.NonTurfProductPricing.DeliveryRegion;
using Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;

namespace WindsorTurfWeb.Common
{
  public class BindDropDown
  {
    public static void BindAllStates(ListControl objControl)
    {
      List<StateResponse> stateResponseList = new List<StateResponse>();
      List<StateResponse> allStates = StateMasterMgmt.GetAllStates();
      if (allStates.Count > 0)
      {
        objControl.DataSource = (object) allStates;
        objControl.DataTextField = "StateName";
        objControl.DataValueField = "StateMasterID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindTurfProduct(ListControl objControl)
    {
      List<TurfProductResponse> turfProductResponseList = new List<TurfProductResponse>();
      List<TurfProductResponse> turfProduct = TurfProductMgmt.GetTurfProduct();
      if (turfProduct.Count > 0)
      {
        objControl.DataSource = (object) turfProduct;
        objControl.DataTextField = "TurfName";
        objControl.DataValueField = "TurfProductID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindNonTurfProduct(ListControl objControl)
    {
      List<NonTurfProductResponse> turfProductResponseList = new List<NonTurfProductResponse>();
      List<NonTurfProductResponse> nonTurfProduct = NonTurfProductMgmt.GetNonTurfProduct();
      if (nonTurfProduct.Count > 0)
      {
        objControl.DataSource = (object) nonTurfProduct;
        objControl.DataTextField = "NonTurfName";
        objControl.DataValueField = "NonTurfProductID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindTurfRange(ListControl objControl)
    {
      List<TurfRangeResponse> turfRangeResponseList = new List<TurfRangeResponse>();
      List<TurfRangeResponse> turfRange = TurfRangeMgmt.GetTurfRange();
      if (turfRange.Count > 0)
      {
        objControl.DataSource = (object) turfRange;
        objControl.DataTextField = "Title";
        objControl.DataValueField = "TurfRangeID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindQuantityRange(ListControl objControl)
    {
      List<QuantityRangeResponse> quantityRangeResponseList = new List<QuantityRangeResponse>();
      List<QuantityRangeResponse> quantityRange = QuantityRangeMgmt.GetQuantityRange();
      if (quantityRange.Count > 0)
      {
        objControl.DataSource = (object) quantityRange;
        objControl.DataTextField = "Title";
        objControl.DataValueField = "QuantityRangeID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindTurfZone(ListControl objControl)
    {
      List<TurfZoneResponse> turfZoneResponseList = new List<TurfZoneResponse>();
      List<TurfZoneResponse> turfZone = TurfZoneMgmt.GetTurfZone();
      if (turfZone.Count > 0)
      {
        objControl.DataSource = (object) turfZone;
        objControl.DataTextField = "Name";
        objControl.DataValueField = "TurfZoneID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindTurfZoneForShopPage(ListControl objControl)
    {
      List<TurfZoneResponse> turfZoneResponseList = new List<TurfZoneResponse>();
      List<TurfZoneResponse> turfZone = TurfZoneMgmt.GetTurfZone();
      if (turfZone.Count > 0)
      {
        objControl.DataSource = (object) turfZone;
        objControl.DataTextField = "Name";
        objControl.DataValueField = "TurfZoneID";
      }
      objControl.DataBind();
      List<TurfZoneResponse> list = turfZone.Where<TurfZoneResponse>((Func<TurfZoneResponse, bool>) (m => m.IsSelectedShopPage)).ToList<TurfZoneResponse>();
      objControl.SelectedValue = list[0].TurfZoneID.ToString();
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindQuantityZone(ListControl objControl)
    {
      List<QuantityZoneResponse> quantityZoneResponseList = new List<QuantityZoneResponse>();
      List<QuantityZoneResponse> quantityZone = QuantityZoneMgmt.GetQuantityZone();
      if (quantityZone.Count > 0)
      {
        objControl.DataSource = (object) quantityZone;
        objControl.DataTextField = "Name";
        objControl.DataValueField = "QuantityZoneID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindQuantityZoneForShopPage(ListControl objControl)
    {
      List<QuantityZoneResponse> quantityZoneResponseList = new List<QuantityZoneResponse>();
      List<QuantityZoneResponse> quantityZone = QuantityZoneMgmt.GetQuantityZone();
      if (quantityZone.Count > 0)
      {
        objControl.DataSource = (object) quantityZone;
        objControl.DataTextField = "Name";
        objControl.DataValueField = "QuantityZoneID";
      }
      objControl.DataBind();
      List<QuantityZoneResponse> list = quantityZone.Where<QuantityZoneResponse>((Func<QuantityZoneResponse, bool>) (m => m.IsSelectedShopPage = true)).ToList<QuantityZoneResponse>();
      objControl.SelectedValue = list[0].QuantityZoneID.ToString();
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindServiceRegion(ListControl objControl)
    {
      List<ServiceRegionResponse> serviceRegionResponseList = new List<ServiceRegionResponse>();
      List<ServiceRegionResponse> serviceRegion = ServiceRegionMgmt.GetServiceRegion();
      if (serviceRegion.Count > 0)
      {
        objControl.DataSource = (object) serviceRegion;
        objControl.DataTextField = "ServiceRegionName";
        objControl.DataValueField = "ServiceRegionID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindDeliveryRegion(ListControl objControl)
    {
      List<DeliveryRegionResponseBE> regionResponseBeList = new List<DeliveryRegionResponseBE>();
      List<DeliveryRegionResponseBE> deliveryRegion = DeliveryRegionMgmt.GetDeliveryRegion();
      if (deliveryRegion.Count > 0)
      {
        objControl.DataSource = (object) deliveryRegion;
        objControl.DataTextField = "DeliveryRegionName";
        objControl.DataValueField = "DeliveryRegionID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindDropDownByTag(
      ListControl objControl,
      Enums.DropdownListTag objDropdownListTag,
      string DefaultValue)
    {
      List<DropDownListBE> dropdownByListTag = DropDownMgmt.GetDropdownByListTag(objDropdownListTag);
      if (dropdownByListTag.Count > 0)
      {
        objControl.DataSource = (object) dropdownByListTag;
        objControl.DataTextField = "DropDownValue";
        objControl.DataValueField = "DropDownID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void GetMonths(ListControl objControl)
    {
      List<WindsorTurfWeb.Common.GetMonths> getMonthsList = new List<WindsorTurfWeb.Common.GetMonths>();
      for (int index = 1; index < 13; ++index)
      {
        string str1 = index.ToString();
        WindsorTurfWeb.Common.GetMonths getMonths = new WindsorTurfWeb.Common.GetMonths();
        getMonths.MonthID = str1.ToString();
        if (index.ToString().Length == 1)
        {
          string str2 = "0" + index.ToString();
          getMonths.MonthNumber = str2;
        }
        else
          getMonths.MonthNumber = str1;
        getMonthsList.Add(getMonths);
      }
      if (getMonthsList.Count > 0)
      {
        objControl.DataSource = (object) getMonthsList;
        objControl.DataTextField = "MonthNumber";
        objControl.DataValueField = "MonthID";
        objControl.DataBind();
        objControl.Items.Insert(0, new ListItem("Select", "-1"));
        UtilityFunctions.DropDownItemToolTip(objControl);
      }
      else
      {
        objControl.DataSource = (object) null;
        objControl.DataBind();
        objControl.Items.Insert(0, new ListItem("-No Months-", "-1"));
        UtilityFunctions.DropDownItemToolTip(objControl);
      }
    }

    public static void GetYears(ListControl objControl)
    {
      List<WindsorTurfWeb.Common.GetYears> getYearsList = new List<WindsorTurfWeb.Common.GetYears>();
      for (int year = DateTime.Now.Year; year <= DateTime.Now.Year + 20; ++year)
        getYearsList.Add(new WindsorTurfWeb.Common.GetYears()
        {
          YearID = year.ToString(),
          YearName = year.ToString()
        });
      if (getYearsList.Count > 0)
      {
        objControl.DataSource = (object) getYearsList;
        objControl.DataTextField = "YearName";
        objControl.DataValueField = "YearID";
        objControl.DataBind();
        objControl.Items.Insert(0, new ListItem("Select", "-1"));
        UtilityFunctions.DropDownItemToolTip(objControl);
      }
      else
      {
        objControl.DataSource = (object) null;
        objControl.DataBind();
        objControl.Items.Insert(0, new ListItem("-No Years-", "-1"));
        UtilityFunctions.DropDownItemToolTip(objControl);
      }
    }

    public static void BindAllCardTypeDetails(ListControl objControl)
    {
    }

    public static void BindUserStatus(ListControl objControl, string strUserStatusID)
    {
      List<UserStatusResponse> userStatusResponseList = new List<UserStatusResponse>();
      List<UserStatusResponse> source = CommercialPartnerMgmt.GetAllUserStatus();
      if (!string.IsNullOrEmpty(strUserStatusID))
      {
        IEnumerable<long> ids = ((IEnumerable<string>) strUserStatusID.Split(',')).Select<string, long>((Func<string, long>) (str => long.Parse(str)));
        source = source.Where<UserStatusResponse>((Func<UserStatusResponse, bool>) (m => !ids.Contains<long>(m.UserStatusID))).ToList<UserStatusResponse>();
      }
      if (source.Count > 0)
      {
        objControl.DataSource = (object) source;
        objControl.DataTextField = "UserStatusName";
        objControl.DataValueField = "UserStatusID";
      }
      objControl.DataBind();
      if (string.IsNullOrEmpty(strUserStatusID))
        objControl.Items.Insert(0, new ListItem("All", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindAllApprovedCommercialPartner(ListControl objControl)
    {
      List<CommercialPartnerResponse> commercialPartnerResponseList = new List<CommercialPartnerResponse>();
      List<CommercialPartnerResponse> commercialPartner = CommercialPartnerMgmt.GetAllApprovedCommercialPartner();
      if (commercialPartner.Count > 0)
      {
        objControl.DataSource = (object) commercialPartner;
        objControl.DataTextField = "UserName";
        objControl.DataValueField = "LoginMasterID";
      }
      objControl.DataBind();
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void GetAllTurfClassificationForDropDown(ListControl objControl)
    {
      List<TurfProductResponse> turfProductResponseList = new List<TurfProductResponse>();
      List<TurfProductResponse> classificationForDropDown = TurfProductMgmt.GetAllTurfClassificationForDropDown();
      if (classificationForDropDown.Count > 0)
      {
        objControl.DataSource = (object) classificationForDropDown;
        objControl.DataTextField = "Name";
        objControl.DataValueField = "TurfClassificationID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void GetAllNonTurfClassificationForDropDown(ListControl objControl)
    {
      List<NonTurfProductResponse> turfProductResponseList = new List<NonTurfProductResponse>();
      List<NonTurfProductResponse> classificationForDropDown = NonTurfProductMgmt.GetAllNonTurfClassificationForDropDown();
      if (classificationForDropDown.Count > 0)
      {
        objControl.DataSource = (object) classificationForDropDown;
        objControl.DataTextField = "Name";
        objControl.DataValueField = "NonTurfClassificationID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindGetCommercialPartner(ListControl objControl)
    {
      List<CommercialPartnerResponse> commercialPartnerResponseList = new List<CommercialPartnerResponse>();
      List<CommercialPartnerResponse> commercialPartner = CommercialPartnerMgmt.GetCommercialPartner();
      if (commercialPartner.Count > 0)
      {
        objControl.DataSource = (object) commercialPartner;
        objControl.DataTextField = "Name";
        objControl.DataValueField = "CommercialPartnerID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindHearAboutUs(ListControl objControl)
    {
      List<HearAboutUsResponse> hearAboutUsResponseList = new List<HearAboutUsResponse>();
      List<HearAboutUsResponse> hearAboutUs = HearAboutUsMgmt.GetHearAboutUs();
      if (hearAboutUs.Count > 0)
      {
        objControl.DataSource = (object) hearAboutUs;
        objControl.DataTextField = "Name";
        objControl.DataValueField = "HearAboutUsID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindCommercialPartnerUsers(ListControl objControl)
    {
      List<CommercialPartnerResponse> commercialPartnerResponseList = new List<CommercialPartnerResponse>();
      List<CommercialPartnerResponse> commercialPartnerUsers = CommercialPartnerMgmt.GetCommercialPartnerUsers();
      if (commercialPartnerUsers.Count > 0)
      {
        objControl.DataSource = (object) commercialPartnerUsers;
        objControl.DataTextField = "CommercialPartnerName";
        objControl.DataValueField = "CommercialPartnerID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("Select", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void GetUserForDropDown(ListControl objControl)
    {
      List<PurchaseOrderDetailBE> purchaseOrderDetailBeList = new List<PurchaseOrderDetailBE>();
      List<PurchaseOrderDetailBE> userForDropDown = PurchaseOrderDetailMgmt.GetUserForDropDown();
      if (userForDropDown.Count > 0)
      {
        objControl.DataSource = (object) userForDropDown;
        objControl.DataTextField = "UserTypeName";
        objControl.DataValueField = "UserTypeID";
      }
      objControl.DataBind();
      objControl.Items.Insert(0, new ListItem("All", "-1"));
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void GetPaymentStatusForDropDown(ListControl objControl)
    {
      List<QuoteDetailBE> quoteDetailBeList = new List<QuoteDetailBE>();
      List<QuoteDetailBE> statusForDropDown = QuoteDetailMgmt.GetPaymentStatusForDropDown();
      if (statusForDropDown.Count > 0)
      {
        objControl.DataSource = (object) statusForDropDown;
        objControl.DataTextField = "PaymentStatusName";
        objControl.DataValueField = "PaymentStatusID";
      }
      objControl.DataBind();
      UtilityFunctions.DropDownItemToolTip(objControl);
    }

    public static void BindYear(ListControl ddlExpireYear)
    {
      int year = DateTime.UtcNow.Year;
      ddlExpireYear.Items.Add(new ListItem("Year", "-1"));
      for (int index = year; index <= 2050; ++index)
        ddlExpireYear.Items.Add(new ListItem(index.ToString(), index.ToString()));
    }
  }
}
