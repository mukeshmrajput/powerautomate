﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.PageURL
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

namespace WindsorTurfWeb.Common
{
  public static class PageURL
  {
    public const string LoginPage = "~/Admin/Default.aspx";
    public const string PlaceOrderPage = "~/Admin/PlaceAnOrder.aspx";
    public const string AdminAddUpdateUserPage = "~/Admin/AddUpdateUser.aspx";
    public const string AdminViewUserPage = "~/Admin/ViewUser.aspx";
    public const string AdminViewCommercialPartnerUserPage = "~/Admin/ViewCommercialPartnerUser.aspx";
    public const string ViewCommercialPartnerStatusPopUp = "~/Admin/ViewCommercialPartnerStatusPopUp.aspx";
    public const string AdminCommercialPartnerApproval = "~/Admin/CommercialPartnerApproval.aspx";
    public const string AdminAddEditPage = "~/Admin/PageManagementEdit.aspx";
    public const string AdminPageManagementList = "~/Admin/ViewPageManagement.aspx";
    public const string AdminAddUpdatePickUpDetailsPage = "~/Admin/AddUpdatePickUpDetails.aspx";
    public const string AdminViewPickUpDetailPage = "~/Admin/ViewPickUpDetails.aspx";
    public const string AdminAddUpdateHearAboutUsPage = "~/Admin/AddUpdateHearAboutUs.aspx";
    public const string AdminViewHearAboutUsPage = "~/Admin/ViewHearAboutUs.aspx";
    public const string AdminAddUpdateNewsPage = "~/Admin/AddUpdateNews.aspx";
    public const string AdminViewOrderProcessingPurchaseDetail = "~/Admin/ViewOrderProcessingPurchaseDetail.aspx";
    public const string AdminViewNewsPage = "~/Admin/ViewNews.aspx";
    public const string AdminViewBannerPage = "~/Admin/ViewBanner.aspx";
    public const string AdminViewCausalCommercialPurchaseDetail = "~/Admin/CausalCommercialPurchaseDetail.aspx";
    public const string ViewCausalCommercialPurchaseDetailPage = "~/Admin/ViewCausalCommercialPurchaseDetail.aspx";
    public const string ViewCausalCommercialPurchaseDetail = "~/Admin/ViewCausalCommercialPurchaseDetailPopUp.aspx";
    public const string AdminAddUpdateTurfRangePage = "~/Admin/AddUpdateTurfRange.aspx";
    public const string AdminViewTurfRangePage = "~/Admin/ViewTurfRange.aspx";
    public const string AdminAddUpdateTurfZonePage = "~/Admin/AddUpdateTurfZone.aspx";
    public const string AdminViewTurfZonePage = "~/Admin/ViewTurfZone.aspx";
    public const string AdminAddUpdateTurfPricePage = "~/Admin/AddUpdateTurfPrice.aspx";
    public const string AdminViewTurfPricePage = "~/Admin/ViewTurfPrice.aspx";
    public const string AdminAddUpdateServiceRegionPage = "~/Admin/AddUpdateServiceRegion.aspx";
    public const string AdminViewServiceRegionPage = "~/Admin/ViewServiceRegion.aspx";
    public const string AdminAddUpdateServiceFeesPage = "~/Admin/AddUpdateServiceFees.aspx";
    public const string AdminViewServiceFeesPage = "~/Admin/ViewServiceFees.aspx";
    public const string AdminAddUpdateQuantityRangesPage = "~/Admin/AddUpdateQuantityRanges.aspx";
    public const string AdminViewQuantityRangePage = "~/Admin/ViewQuantityRanges.aspx";
    public const string AdminAddUpdateQuantityZonePage = "~/Admin/AddUpdateQuantityZone.aspx";
    public const string AdminViewQuantityZonePage = "~/Admin/ViewQuantityZone.aspx";
    public const string AdminAddUpdateQuantityPricingPage = "~/Admin/AddUpdateQuantityPricing.aspx";
    public const string AdminViewQuantityPricingPage = "~/Admin/ViewQuantityPricing.aspx";
    public const string AdminAddUpdateDeliveryRegionPage = "~/Admin/AddUpdateDeliveryRegion.aspx";
    public const string AdminViewDeliveryRegionPage = "~/Admin/ViewDeliveryRegion.aspx";
    public const string AdminAddUpdateDeliveryPricePage = "~/Admin/AddUpdateDeliveryPrice.aspx";
    public const string AdminViewDeliveryPricePage = "~/Admin/ViewDeliveryPrice.aspx";
    public const string AdminAddUpdateTurfProductPage = "~/Admin/AddUpdateTurfProduct.aspx";
    public const string AdminViewTurfProductPage = "~/Admin/ViewTurfProduct.aspx";
    public const string AdminViewTurfProductDetailsPage = "~/Admin/ViewTurfProductDetails.aspx";
    public const string AdminViewNonTurfProductDetailsPage = "~/Admin/ViewNonTurfProductDetails.aspx";
    public const string AdminAddUpdateNonTurfProductPage = "~/Admin/AddUpdateNonTurfProduct.aspx";
    public const string AdminViewNonTurfProductPage = "~/Admin/ViewNonTurfProduct.aspx";
    public const string AdminAddUpdateTurfClassificationPage = "~/Admin/AddUpdateTurfClassification.aspx";
    public const string AdminViewTurfClassificationPage = "~/Admin/ViewTurfClassifications.aspx";
    public const string AdminAddUpdateNonTurfClassificationPage = "~/Admin/AddUpdateNonTurfClassification.aspx";
    public const string AdminViewNonTurfClassificationPage = "~/Admin/ViewNonTurfClassifications.aspx";
    public const string AdminAddUpdateNonTurfStockAvailablePage = "~/Admin/AddUpdateNonTurfStockAvailable.aspx";
    public const string AdminViewNonTurfStockAvaialblePage = "~/Admin/ViewNonTurfStockAvailable.aspx";
    public const string AdminAddUpdateTurfStockAvailablePage = "~/Admin/AddUpdateTurfStockAvailable.aspx";
    public const string AdminViewTurfStockAvaialblePage = "~/Admin/ViewTurfStockAvailable.aspx";
    public const string AdminLandingPage = "~/Admin/Welcome.aspx";
    public const string AdminDashboardPage = "/Admin/Welcome.aspx";
    public const string AdminViewClassificationsPage = "~/Admin/ViewTurfClassifications.aspx";
    public const string AdminViewNonTurfClassificationsPage = "~/Admin/ViewNonTurfClassifications.aspx";
    public const string AdminViewNonTurfStockAvailablePage = "~/Admin/ViewNonTurfStockAvailable.aspx";
    public const string AdminAddUpdatePaymentTypePage = "~/Admin/AdminAddUpdatePaymentType.aspx";
    public const string AdminViewPaymentTypePage = "~/Admin/ViewPaymentType.aspx";
    public const string AdminAddUpdateAccountDetailPage = "~/Admin/AddUpdateAccountDetail.aspx";
    public const string AdminViewAccountDetailPage = "~/Admin/ViewAccountDetail.aspx";
    public const string AdminSiteConfiguration = "~/Admin/SiteConfiguration.aspx";
    public const string AdminSiteConfigurationPage = "~/Admin/SiteConfiguration.aspx";
    public const string AdminChangePasswordPage = "~/Admin/ChangePassword.aspx";
    public const string FrontPageNotFoundPage = "/page-not-found";
    public const string AdminPageNotFound = "~/Admin/AdminPageNotFound.aspx";
    public const string FrontLandingPage = "/default.aspx";
    public const string FrontThankYouPage = "/thank-you";
    public const string CheckOutPage = "/checkout";
    public const string CommercialRegistrationPage = "/commercial-registration";
    public const string ShopPage = "/shop";
    public const string retailpurchasedetailPage = "/retail-purchase-detail";
    public const string ConfirmPaymentPage = "/confirm-payment";
    public const string NewsletterList = "~/Admin/Newsletterlist.aspx";
    public const string AddNewsletter = "~/Admin/AddNewsletter.aspx";
    public const string OrderHistory = "/order-history";
    public const string QuoteHistory = "/quote-history";
    public const string ChangePassword = "/change-password";
    public const string UpdateProfile = "/updateprofile";
    public const string ViewCommercialPartnerApproval = "~/Admin/ViewCommercialPartnerApproval.aspx";
    public const string ViewUpdateOrderProcessingPurchaseDetailsPopUp = "~/Admin/ViewUpdateOrderProcessingPurchaseDetailsPopUp.aspx";
    public const string ViewQuoteDetailPopUp = "~/Admin/ViewQuoteDetailPopUp.aspx";
    public const string ViewPurchaseOrderDetails = "~/CommercialPartner/ViewOrderProcessingPurchaseDetailsPopUpFront.aspx";
    public const string GetQuotePage = "/get-quote";
    public const string ViewQuoteDetailPopUpFront = "~/CommercialPartner/ViewQuoteDetailPopUpFront.aspx";
    public const string CalculateTurfArea = "/calculate-turfarea";
    public const string ViewQuoteDetails = "/quote-detail";
    public const string ViewQuoteDetailList = "~/Admin/ViewQuoteDetail.aspx";
    public const string AdminShopPage = "~/Admin/AdminShopPage.aspx";
    public const string AdminOrderPage = "~/Admin/AdminOrderPage.aspx";
    public const string AdminTurfDescription = "~/Admin/AdminTurfDescriptionPage.aspx";
    public const string AdminTurfCheckOut = "~/Admin/AdminCheckoutPage.aspx";
    public const string AdminTurfRetailPurchase = "~/Admin/AdminRetailPurchaseOrderPage.aspx";
    public const string AdminTurfConfirmPayment = "~/Admin/AdminConfirmPaymentPage.aspx";
    public const string AdminViewGalleryPage = "~/Admin/ViewGallerys.aspx";
    public const string AdminViewTestimonialsPage = "~/Admin/ViewTestimonials.aspx";
  }
}
