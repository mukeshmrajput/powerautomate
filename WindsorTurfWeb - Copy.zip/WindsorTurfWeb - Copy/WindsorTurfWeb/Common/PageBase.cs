﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.PageBase
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.EmailHistory;
using BLL.Error;
using Entity.Response.PageManagement;
using Helper;
using System;
using System.ComponentModel;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;

namespace WindsorTurfWeb.Common
{
  public class PageBase : Page
  {
    public static string AppPath = PageBase.GetAppPath();
    public static string AppPhysicalPath = HttpContext.Current.Server.MapPath("~");
    public static bool EnableSSL = bool.Parse(ConfigurationManager.AppSettings[nameof (EnableSSL)].ToString());

    [Browsable(true)]
    [Description("Indicates the web.config key of Css")]
    public virtual string CssKey { get; set; }

    [Browsable(true)]
    [Description("Indicates the web.config key of Js")]
    public virtual string JsKey { get; set; }

    public static void PushSSL(bool RequiredSSL)
    {
      if (!PageBase.EnableSSL)
        return;
      if (RequiredSSL && !HttpContext.Current.Request.IsSecureConnection)
        HttpContext.Current.Response.Redirect(HttpContext.Current.Request.Url.ToString().Replace("http://", "https://"));
      if (!RequiredSSL && HttpContext.Current.Request.IsSecureConnection)
        HttpContext.Current.Response.Redirect(HttpContext.Current.Request.Url.ToString().Replace("https://", "http://"));
    }

    protected override void OnInit(EventArgs e) => base.OnInit(e);

    protected override void OnLoad(EventArgs e)
    {
      try
      {
        if (this.Page.Header != null)
        {
          HtmlLink child = new HtmlLink();
          child.Attributes.Add("href", PageBase.AppPath + "favicon.ico");
          child.Attributes.Add("rel", "Shortcut Icon");
          this.Page.Header.Controls.Add((Control) child);
        }
      }
      catch
      {
      }
      this.Response.Cache.SetNoStore();
    }

    public static string GetAppPath() => HttpContext.Current.Request.ApplicationPath.Length > 1 ? HttpContext.Current.Request.ApplicationPath + "/" : HttpContext.Current.Request.ApplicationPath;

    public static DateTime GetUTCdate() => DateTime.UtcNow;

    public void RegisterCssKey(string cssKey)
    {
      if (string.IsNullOrEmpty(cssKey))
        return;
      HtmlLink child = new HtmlLink();
      child.Attributes.Add("type", "text/css");
      child.Attributes.Add("rel", "stylesheet");
      child.Attributes.Add("href", PageBase.AppPath + "Handler/CssJsHandler.ashx?s=" + cssKey + "&t=text/css&v=1");
      if (this.Page.Header != null)
      {
        this.Page.Header.Controls.Add((Control) child);
        this.Page.Header.Controls.Add((Control) new LiteralControl()
        {
          Text = "<!--[if lt IE 7]><style type=\"text/css\">body{height: 100%;}#progressBackgroundFilter{position: absolute;height: expression(document.documentElement.scrollTop + document.documentElement.clientHeight + \"px\");width: expression(document.body.clientWidth + \"px\");}#processMessage{position: absolute;top: expression(document.documentElement.scrollTop + (document.documentElement.clientHeight * .47) + \"px\");}</style><![endif]-->"
        });
      }
    }

    public static void RegisterCssKey(Page p, string cssKey)
    {
      if (string.IsNullOrEmpty(cssKey))
        return;
      HtmlLink child = new HtmlLink();
      child.Attributes.Add("type", "text/css");
      child.Attributes.Add("rel", "stylesheet");
      child.Attributes.Add("href", PageBase.AppPath + "Handler/CssJsHandler.ashx?s=" + cssKey + "&t=text/css&v=1");
      if (p.Header != null)
      {
        p.Header.Controls.Add((Control) child);
        p.Header.Controls.Add((Control) new LiteralControl()
        {
          Text = "<!--[if lt IE 7]><style type=\"text/css\">body{height: 100%;}#progressBackgroundFilter{position: absolute;height: expression(document.documentElement.scrollTop + document.documentElement.clientHeight + \"px\");width: expression(document.body.clientWidth + \"px\");}#processMessage{position: absolute;top: expression(document.documentElement.scrollTop + (document.documentElement.clientHeight * .47) + \"px\");}</style><![endif]-->"
        });
      }
    }

    public void RegisterJsKey(string jsKey)
    {
      if (string.IsNullOrEmpty(jsKey))
        return;
      this.Page.ClientScript.RegisterClientScriptInclude(typeof (string), jsKey, PageBase.AppPath + "Handler/CssJsHandler.ashx?s=" + jsKey + "&t=text/javascript&v=1");
    }

    public static void RegisterJsKey(Page p, string jsKey)
    {
      if (string.IsNullOrEmpty(jsKey))
        return;
      p.ClientScript.RegisterClientScriptInclude(typeof (string), jsKey, PageBase.AppPath + "Handler/CssJsHandler.ashx?s=" + jsKey + "&t=text/javascript&v=1");
    }

    protected override void OnError(EventArgs e)
    {
      HttpContext current = HttpContext.Current;
      Exception lastError = current.Server.GetLastError();
      Entity.Common.Error.Error error = new Entity.Common.Error.Error();
      error.Url = current.Request.Url.ToString();
      error.RawUrl = current.Request.RawUrl;
      error.IpAddress = current.Request.UserHostAddress;
      error.ExceptionSource = lastError.Source;
      error.ExceptionMessage = lastError.Message;
      error.ExceptionStackTrace = lastError.StackTrace;
      error.UserName = current.User.Identity.IsAuthenticated ? current.User.Identity.Name : "Anonymous";
      error.Browser = current.Request.Browser.Browser;
      error.Screen = current.Request.Browser.ScreenPixelsWidth.ToString() + "x" + current.Request.Browser.ScreenPixelsHeight.ToString() + " @" + current.Request.Browser.ScreenBitDepth.ToString() + "bit";
      error.SessionID = "";
      error.Cookie = current.Request.Browser.Cookies;
      error.JavaScript = current.Request.Browser.JavaScript;
      ErrorMgmt.AddError(error);
      string str = string.Empty;
      str = "<br><b>Url:</b> " + error.Url + "<br><b>Raw Url:</b> " + error.RawUrl + "<br><b>IP Address:</b> " + error.IpAddress + "<br><b>Exception Source:</b> " + error.ExceptionSource + "<br><b>Exception Message:</b> " + error.ExceptionMessage + "<br><b>Exception StackTrace:</b> " + error.ExceptionStackTrace + "<br><b>UserName:</b> " + error.UserName + "<br><b>Browser:</b> " + error.Browser + "<br><b>Screen:</b> " + error.Screen + "<br><b>Cookie:</b> " + error.Cookie.ToString() + "<br><b>JavaScript:</b> " + error.JavaScript.ToString();
      string appSetting1 = ConfigurationManager.AppSettings["ErrorFromEmail"];
      string appSetting2 = ConfigurationManager.AppSettings["ErrorToEmail"];
      string appSetting3 = ConfigurationManager.AppSettings["ErrorCCEmail"];
      string appSetting4 = ConfigurationManager.AppSettings["ErrorBCCEmail"];
      this.Response.Redirect(!this.Request.RawUrl.ToLower().Contains("/Admin/") ? "~/PageNotFound.aspx" : "~/Admin/Error.aspx");
    }

    public static string GetPreviousUrl()
    {
      string rawUrl = HttpContext.Current.Request.RawUrl;
      return rawUrl.Substring(0, rawUrl.LastIndexOf("/")) + ".htm";
    }

    public static void WriteCookie(string CookiesValues, string ExpiryKey)
    {
      HttpResponse response = HttpContext.Current.Response;
      try
      {
        HttpCookie cookie = new HttpCookie("RememberMe");
        cookie.Values.Add("RememberMe", CookiesValues);
        DateTime dateTime = DateTime.Now.AddDays(Convert.ToDouble(ExpiryKey));
        response.Cookies["RememberMe"].Expires = dateTime;
        response.Cookies.Add(cookie);
      }
      catch
      {
      }
    }

    public static void WriteDaysCookie(string CookiesValues, string TempExpiry)
    {
      HttpResponse response = HttpContext.Current.Response;
      try
      {
        HttpCookie cookie = new HttpCookie("TempUserGUID");
        cookie.Values.Add("TempUserGUID", CookiesValues);
        DateTime dateTime = DateTime.Now.AddDays(Convert.ToDouble(TempExpiry));
        response.Cookies["TempUserGUID"].Expires = dateTime;
        response.Cookies.Add(cookie);
      }
      catch
      {
      }
    }

    public static void WriteCookieForSourceCode(string CookiesValues, string Hours)
    {
      HttpResponse response = HttpContext.Current.Response;
      try
      {
        HttpCookie cookie = new HttpCookie("SourceCode");
        cookie.Values.Add("SourceCode", CookiesValues);
        DateTime dateTime = DateTime.Now.AddHours(Convert.ToDouble(Hours));
        response.Cookies["SourceCode"].Expires = dateTime;
        response.Cookies.Add(cookie);
      }
      catch
      {
      }
    }

    public static string ReadCookie(int FieldID)
    {
      string empty = string.Empty;
      string[] strArray = HttpContext.Current.User.Identity.Name.Split(',');
      return strArray.Length - 1 < FieldID ? string.Empty : strArray[FieldID];
    }

    public static void RemoveCookie(string KeyName)
    {
      HttpCookie cookie = HttpContext.Current.Request.Cookies[KeyName] == null ? new HttpCookie(KeyName) : HttpContext.Current.Request.Cookies[KeyName];
      cookie.Values[KeyName] = string.Empty;
      DateTime dateTime = DateTime.Now.AddYears(-1);
      HttpContext.Current.Response.Cookies[KeyName].Expires = dateTime;
      HttpContext.Current.Response.Cookies.Add(cookie);
    }

    public static void CreateTicket(int Type, string UserName, bool Remember, string ReturnURL)
    {
      HttpResponse response = HttpContext.Current.Response;
      int num = int.Parse(ConfigurationManager.AppSettings["LoginSessionExpireTime"].ToString());
      switch (Type)
      {
        case 1:
          FormsAuthenticationTicket ticket1 = !Remember ? new FormsAuthenticationTicket(1, UserName, PageBase.GetUTCdate(), PageBase.GetUTCdate().AddMinutes((double) num), false, "Corporate") : new FormsAuthenticationTicket(1, UserName, PageBase.GetUTCdate(), PageBase.GetUTCdate().AddYears(4), true, "Corporate");
          HttpCookie cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(ticket1));
          cookie1.Path = FormsAuthentication.FormsCookiePath;
          if (Remember)
            cookie1.Expires = ticket1.Expiration;
          response.Cookies.Add(cookie1);
          break;
        case 2:
          FormsAuthenticationTicket ticket2 = !Remember ? new FormsAuthenticationTicket(1, UserName, PageBase.GetUTCdate(), PageBase.GetUTCdate().AddMinutes((double) num), false, "OE") : new FormsAuthenticationTicket(1, UserName, PageBase.GetUTCdate(), PageBase.GetUTCdate().AddYears(4), true, "OE");
          HttpCookie cookie2 = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(ticket2));
          cookie2.Path = FormsAuthentication.FormsCookiePath;
          if (Remember)
            cookie2.Expires = ticket2.Expiration;
          response.Cookies.Add(cookie2);
          break;
        case 3:
          FormsAuthenticationTicket ticket3 = !Remember ? new FormsAuthenticationTicket(1, UserName, PageBase.GetUTCdate(), PageBase.GetUTCdate().AddMinutes((double) num), false, "Club") : new FormsAuthenticationTicket(1, UserName, PageBase.GetUTCdate(), PageBase.GetUTCdate().AddYears(4), true, "Club");
          HttpCookie cookie3 = new HttpCookie(FormsAuthentication.FormsCookieName, FormsAuthentication.Encrypt(ticket3));
          cookie3.Path = FormsAuthentication.FormsCookiePath;
          if (Remember)
            cookie3.Expires = ticket3.Expiration;
          response.Cookies.Add(cookie3);
          break;
      }
    }

    public static bool CheckRole(Enums.PersonType TypeObject)
    {
      bool flag = false;
      try
      {
        flag = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3))) == (long) Convert.ToInt16((object) TypeObject);
      }
      catch
      {
      }
      return flag;
    }

    public static bool CheckRoleByUserTypeID(long UserTypeID)
    {
      bool flag = false;
      try
      {
        flag = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3))) == (long) Convert.ToInt16(UserTypeID);
      }
      catch
      {
      }
      return flag;
    }

    public static void AddEmailHistory(
      string FromEmail,
      string FromName,
      string ToEmail,
      string MailBody,
      string Subject,
      string CCMail,
      string BCCMail,
      Enums.BackEndProcess EmailType)
    {
      EmailHistoryMgmt.AddEmailHistory(new Entity.Common.Email.EmailHistory()
      {
        FromEmail = FromEmail,
        FromName = FromName,
        ToEmails = ToEmail,
        ReplyTo = "",
        MailBody = MailBody,
        Subject = Subject,
        CCMail = CCMail,
        BCCMail = BCCMail,
        AttachFileName = "",
        SendDate = DateTime.Now,
        EmailType = new int?((int) Convert.ToInt16((object) EmailType)),
        Status = 1
      });
    }

    public static string SetSEO(PageManagementResponseBE objDesc) => Environment.NewLine + "<meta name=\"Description\" content=\"" + objDesc.MetaDescription + "\"/>" + Environment.NewLine + "<title>" + objDesc.PageTitle + " | " + ConfigurationManager.AppSettings["PageTitle"] + "</title>" + Environment.NewLine + "<meta name=\"keywords\" content=\"" + objDesc.MetaKeyword + "\"/>";

    public static string SetSEO(GetConttentPageDataBE objDesc) => Environment.NewLine + "<meta name=\"Description\" content=\"" + objDesc.MetaDescription + "\"/>" + Environment.NewLine + "<title>" + objDesc.PageTitle + "</title>" + Environment.NewLine + "<meta name=\"keywords\" content=\"" + objDesc.MetaKeyword + "\"/>";

    public void SetSEODetails(string PageTitle, string MetaKeywords, string MetaDescription)
    {
      this.Page.Title = PageTitle;
      if (this.Page.Header == null)
        return;
      HtmlMeta child1 = new HtmlMeta();
      child1.Name = "keywords";
      child1.Content = MetaKeywords;
      HtmlMeta child2 = new HtmlMeta();
      child2.Name = "description";
      child2.Content = MetaDescription;
      this.Page.Header.Controls.Add((Control) child1);
      this.Page.Header.Controls.Add((Control) child2);
    }
  }
}
