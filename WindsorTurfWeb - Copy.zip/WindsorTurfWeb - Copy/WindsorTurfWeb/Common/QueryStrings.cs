﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.QueryStrings
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

namespace WindsorTurfWeb.Common
{
  public class QueryStrings
  {
    public const string ReturnURL = "ReturnURL";
    public const string LinkURL = "LinkURL";
    public const string cmd = "cmd";
    public const string PageID = "PageManagementID";
    public const string PickUpDetailID = "PickUpDetailID";
    public const string UserID = "UserID";
    public const string HearAboutUsID = "HearAboutUsID";
    public const string NewsID = "NewsID";
    public const string BannerManagementId = "BannerManagementId";
    public const string TurfRangeID = "TurfRangeID";
    public const string TurfZoneID = "TurfZoneID";
    public const string TurfPriceID = "TurfPriceID";
    public const string ServiceRegionID = "ServiceRegionID";
    public static string QuantityZoneID = nameof (QuantityZoneID);
    public static string TurfClassificationID = nameof (TurfClassificationID);
    public static string NonTurfClassificationID = nameof (NonTurfClassificationID);
    public static string ServiceFeesID = nameof (ServiceFeesID);
    public static string DeliveryRegionID = nameof (DeliveryRegionID);
    public static string QuantityRangeID = nameof (QuantityRangeID);
    public static string QuantityPriceID = nameof (QuantityPriceID);
    public static string DeliveryPriceID = nameof (DeliveryPriceID);
    public static string PageManagementID = nameof (PageManagementID);
    public static string TurfProductID = nameof (TurfProductID);
    public static string NonTurfProductID = nameof (NonTurfProductID);
    public static string TurfStockAvailableID = nameof (TurfStockAvailableID);
    public static string NonTurfStockAvailableID = nameof (NonTurfStockAvailableID);
    public static string PaymentTypeID = nameof (PaymentTypeID);
    public static string LoginMasterID = nameof (LoginMasterID);
    public static string CommercialPartnerID = nameof (CommercialPartnerID);
    public static string AccountDetailID = nameof (AccountDetailID);
    public static string RetailPurchaseOrderID = nameof (RetailPurchaseOrderID);
    public static string QuoteDetailID = nameof (QuoteDetailID);
    public static string Status = nameof (Status);
    public static string TurfID = nameof (TurfID);
    public static string IsDash = nameof (IsDash);
    public const string GalleryMgmntID = "GalleryMgmntID";
    public const string TestimonialsID = "TestimonialsID";
  }
}
