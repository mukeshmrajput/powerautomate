﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.Validations
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using Resources;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WindsorTurfWeb.Common
{
  public class Validations
  {
    public static void SetRequiredFieldValidatorWithNoScriptTag(
      RequiredFieldValidator reqValidator,
      RegularExpressionValidator regValidator,
      bool isEnabled,
      object sender,
      string strValGroup)
    {
      Control control = (Control) sender;
      if (control == null)
        return;
      reqValidator.ControlToValidate = control.ID;
      reqValidator.ErrorMessage = Messages.Required;
      reqValidator.Enabled = isEnabled;
      reqValidator.Display = ValidatorDisplay.Dynamic;
      reqValidator.CssClass = "callout";
      reqValidator.ValidationGroup = strValGroup;
      regValidator.ControlToValidate = control.ID;
      regValidator.Enabled = isEnabled;
      regValidator.ValidationExpression = Regex.Alphabetonly;
      regValidator.ErrorMessage = Messages.Invalid;
      regValidator.Display = ValidatorDisplay.Dynamic;
      regValidator.SetFocusOnError = true;
      reqValidator.CssClass = "callout";
      reqValidator.ValidationGroup = strValGroup;
    }

    public static void SetRegularExpressionValidator(
      RegularExpressionValidator regValidator,
      string regExpression,
      bool isEnabled,
      object sender,
      string strValGroup)
    {
      Control control = (Control) sender;
      if (control == null)
        return;
      regValidator.ControlToValidate = control.ID;
      regValidator.Enabled = isEnabled;
      regValidator.ValidationExpression = regExpression;
      regValidator.ErrorMessage = Messages.Invalid;
      regValidator.Display = ValidatorDisplay.Dynamic;
      regValidator.SetFocusOnError = true;
      regValidator.CssClass = "callout";
      regValidator.ValidationGroup = strValGroup;
    }

    public static void SetRequiredFieldValidator(
      RequiredFieldValidator reqValidator,
      bool isEnabled,
      object sender,
      string strValGroup)
    {
      Control control = (Control) sender;
      if (control == null)
        return;
      reqValidator.ControlToValidate = control.ID;
      reqValidator.ErrorMessage = Messages.Required;
      reqValidator.Enabled = isEnabled;
      reqValidator.Display = ValidatorDisplay.Dynamic;
      reqValidator.SetFocusOnError = true;
      reqValidator.CssClass = "callout";
      reqValidator.ValidationGroup = strValGroup;
    }

    public static void SetRequiredFieldValidatorDropdown(
      RequiredFieldValidator reqValidator,
      bool isEnabled,
      object sender,
      string DrpInitialValue,
      string strValGroup)
    {
      Control control = (Control) sender;
      if (control == null)
        return;
      reqValidator.ControlToValidate = control.ID;
      reqValidator.InitialValue = DrpInitialValue;
      reqValidator.ErrorMessage = Messages.Required;
      reqValidator.Enabled = isEnabled;
      reqValidator.Display = ValidatorDisplay.Dynamic;
      reqValidator.ValidationGroup = strValGroup;
      reqValidator.CssClass = "callout";
      reqValidator.SetFocusOnError = true;
    }

    public static void SetRequiredFieldValidatorDropdownForFront(
      RequiredFieldValidator reqValidator,
      bool isEnabled,
      object sender,
      string DrpInitialValue,
      string strValGroup)
    {
      Control control = (Control) sender;
      if (control == null)
        return;
      reqValidator.ControlToValidate = control.ID;
      reqValidator.InitialValue = DrpInitialValue;
      reqValidator.ErrorMessage = Messages.Required;
      reqValidator.Enabled = isEnabled;
      reqValidator.Display = ValidatorDisplay.Dynamic;
      reqValidator.ValidationGroup = strValGroup;
      reqValidator.CssClass = "requerd_msg";
      reqValidator.SetFocusOnError = true;
    }

    public static void SetRequiredFieldValidatorDropdownForAdmin(
      RequiredFieldValidator reqValidator,
      bool isEnabled,
      object sender,
      string DrpInitialValue,
      string strValGroup)
    {
      Control control = (Control) sender;
      if (control == null)
        return;
      reqValidator.ControlToValidate = control.ID;
      reqValidator.InitialValue = DrpInitialValue;
      reqValidator.ErrorMessage = Messages.Required;
      reqValidator.Enabled = isEnabled;
      reqValidator.Display = ValidatorDisplay.Dynamic;
      reqValidator.ValidationGroup = strValGroup;
      reqValidator.CssClass = "callout";
      reqValidator.SetFocusOnError = true;
    }

    public static void SetCompareFieldValidator(
      CompareValidator cmpValidator,
      bool isEnabled,
      object ctrlToValidate,
      object ctrlToCompare,
      string strValGroup)
    {
      Control control1 = (Control) ctrlToValidate;
      Control control2 = (Control) ctrlToCompare;
      if (control1 == null || control2 == null)
        return;
      cmpValidator.ControlToValidate = control1.ID;
      cmpValidator.ControlToCompare = control2.ID;
      cmpValidator.ErrorMessage = Messages.NewPassAndConfirmPassNotMatch;
      cmpValidator.Enabled = isEnabled;
      cmpValidator.Display = ValidatorDisplay.Dynamic;
      cmpValidator.SetFocusOnError = true;
      cmpValidator.CssClass = "callout";
      cmpValidator.ValidationGroup = strValGroup;
    }

    public static void SetRequiredFieldValidatorForFront(
      RequiredFieldValidator reqValidator,
      bool isEnabled,
      object sender,
      string strValGroup)
    {
      Control control = (Control) sender;
      if (control == null)
        return;
      reqValidator.ControlToValidate = control.ID;
      reqValidator.ErrorMessage = Messages.Required;
      reqValidator.Enabled = isEnabled;
      reqValidator.Display = ValidatorDisplay.Dynamic;
      reqValidator.SetFocusOnError = true;
      reqValidator.CssClass = "requerd_msg";
      reqValidator.ValidationGroup = strValGroup;
    }

    public static void SetRegularExpressionValidatorForFront(
      RegularExpressionValidator regValidator,
      string regExpression,
      bool isEnabled,
      object sender,
      string strValGroup)
    {
      Control control = (Control) sender;
      if (control == null)
        return;
      regValidator.ControlToValidate = control.ID;
      regValidator.Enabled = isEnabled;
      regValidator.ValidationExpression = regExpression;
      regValidator.ErrorMessage = Messages.Invalid;
      regValidator.Display = ValidatorDisplay.Dynamic;
      regValidator.SetFocusOnError = true;
      regValidator.CssClass = "requerd_msg";
      regValidator.ValidationGroup = strValGroup;
    }

    public static void SetCompareFieldValidatorForFront(
      CompareValidator cmpValidator,
      bool isEnabled,
      object ctrlToValidate,
      object ctrlToCompare,
      string strValGroup)
    {
      Control control1 = (Control) ctrlToValidate;
      Control control2 = (Control) ctrlToCompare;
      if (control1 == null || control2 == null)
        return;
      cmpValidator.ControlToValidate = control1.ID;
      cmpValidator.ControlToCompare = control2.ID;
      cmpValidator.ErrorMessage = Messages.NewPassAndConfirmPassNotMatch;
      cmpValidator.Enabled = isEnabled;
      cmpValidator.Display = ValidatorDisplay.Dynamic;
      cmpValidator.SetFocusOnError = true;
      cmpValidator.CssClass = "requerd_msg newpass";
      cmpValidator.ValidationGroup = strValGroup;
    }

    public static void SetCompareFieldValidatorForResetChangePasswordFront(
      CompareValidator cmpValidator,
      bool isEnabled,
      object ctrlToValidate,
      object ctrlToCompare,
      string strValGroup)
    {
      Control control1 = (Control) ctrlToValidate;
      Control control2 = (Control) ctrlToCompare;
      if (control1 == null || control2 == null)
        return;
      cmpValidator.ControlToValidate = control1.ID;
      cmpValidator.ControlToCompare = control2.ID;
      cmpValidator.ErrorMessage = Messages.NewPasswordAndConfirmPasswordNotMatch;
      cmpValidator.Enabled = isEnabled;
      cmpValidator.Display = ValidatorDisplay.Dynamic;
      cmpValidator.SetFocusOnError = true;
      cmpValidator.CssClass = "requerd_msg newpass";
      cmpValidator.ValidationGroup = strValGroup;
    }
  }
}
