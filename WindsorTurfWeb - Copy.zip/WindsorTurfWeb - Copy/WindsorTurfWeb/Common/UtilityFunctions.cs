﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.UtilityFunctions
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.CommercialPartner;
using BLL.PurchaseOrderDetail;
using BLL.UserManagement;
using Entity.Common.PurchaseOrderDetail;
using Entity.Common.Response;
using Entity.Common.UserManagement;
using Entity.Response.CommercialPartner;
using Entity.Response.PageManagement;
using Helper;
using Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Xml;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Common
{
  public class UtilityFunctions
  {
    public static string API_URL = "https://auspost.com.au/api/postcode/search.json?";
    public static string API_Key = "1e870b94-366a-4b89-9d3f-0083aaea927b";
    public static string strDefaultPDFToHtmlFile = ConfigurationManager.AppSettings["DefaultPDFToHtmlFile"].ToString();

    public static string RemoveSpecialCharactor(string strToReplace)
    {
      strToReplace = strToReplace.Replace("~", "");
      strToReplace = strToReplace.Replace("`", "");
      strToReplace = strToReplace.Replace("!", "");
      strToReplace = strToReplace.Replace("@", "");
      strToReplace = strToReplace.Replace("#", "");
      strToReplace = strToReplace.Replace("$", "");
      strToReplace = strToReplace.Replace("%", "");
      strToReplace = strToReplace.Replace("^", "");
      strToReplace = strToReplace.Replace("&", "");
      strToReplace = strToReplace.Replace("*", "");
      strToReplace = strToReplace.Replace("(", "");
      strToReplace = strToReplace.Replace(")", "");
      strToReplace = strToReplace.Replace("-", "");
      strToReplace = strToReplace.Replace("_", "");
      strToReplace = strToReplace.Replace("+", "");
      strToReplace = strToReplace.Replace("=", "");
      strToReplace = strToReplace.Replace("[", "");
      strToReplace = strToReplace.Replace("]", "");
      strToReplace = strToReplace.Replace("{", "");
      strToReplace = strToReplace.Replace("}", "");
      strToReplace = strToReplace.Replace("|", "");
      strToReplace = strToReplace.Replace("\\", "");
      strToReplace = strToReplace.Replace(":", "");
      strToReplace = strToReplace.Replace(";", "");
      strToReplace = strToReplace.Replace("'", "");
      strToReplace = strToReplace.Replace("\"", "");
      strToReplace = strToReplace.Replace(".", "");
      strToReplace = strToReplace.Replace(",", "");
      strToReplace = strToReplace.Replace("<", "");
      strToReplace = strToReplace.Replace(">", "");
      strToReplace = strToReplace.Replace("''", "");
      strToReplace = strToReplace.Replace("?", "");
      strToReplace = strToReplace.Replace("/", "");
      strToReplace = strToReplace.Replace(" ", "-");
      strToReplace = strToReplace.Replace("  ", "-");
      return strToReplace.ToLower();
    }

    public static string GetNewGuid() => Guid.NewGuid().ToString();

    public static string GetTextFromHtml(string Details) => System.Text.RegularExpressions.Regex.Replace(System.Text.RegularExpressions.Regex.Replace(Details, "<(.|\\n)*?>", string.Empty), "\\s+", " ");

    public static string GetMailFile(string filepath)
    {
      StreamReader streamReader = new StreamReader(filepath);
      string end = streamReader.ReadToEnd();
      streamReader.Close();
      return end.Replace("[Livepath]", ConfigurationManager.AppSettings["Livepath"]);
    }

    public static string GetNotification(
      string Message,
      Enums.NotificationType objNotificationType,
      bool AutoClose = true)
    {
      return AutoClose ? "showNotification({message: '" + Message + "',type: '" + objNotificationType.ToString() + "',duration:'" + ConfigurationManager.AppSettings["NotificationDuration"].ToString() + "',autoClose:'" + AutoClose.ToString() + "'});" : "showNotification({message: '" + Message + "',type: '" + objNotificationType.ToString() + "'});";
    }

    public static string GetNotificationOnParentPage(
      string Message,
      Enums.NotificationType objNotificationType,
      bool AutoClose = true)
    {
      return AutoClose ? "parent.showNotification({message: '" + Message + "',type: '" + objNotificationType.ToString() + "',duration:'" + ConfigurationManager.AppSettings["NotificationDuration"].ToString() + "',autoClose:'" + AutoClose.ToString() + "'});" : "parent.showNotification({message: '" + Message + "',type: '" + objNotificationType.ToString() + "'});";
    }

    public static string GetNotificationFront(
      string Message,
      Enums.NotificationType objNotificationType,
      bool AutoClose = true)
    {
      return AutoClose ? "showNotificationFront({message: '" + Message + "',type: '" + objNotificationType.ToString() + "',duration:'" + ConfigurationManager.AppSettings["NotificationDuration"].ToString() + "',autoClose:'" + AutoClose.ToString() + "'});" : "showNotificationFront({message: '" + Message + "',type: '" + objNotificationType.ToString() + "'});";
    }

    public static string GetNotificationFront_Comm(
      string Message,
      Enums.NotificationType objNotificationType,
      bool AutoClose = true)
    {
      return AutoClose ? "parent.showNotificationFront({message: '" + Message + "',type: '" + objNotificationType.ToString() + "',duration:'" + ConfigurationManager.AppSettings["NotificationDuration"].ToString() + "',autoClose:'" + AutoClose.ToString() + "'});" : "parent.showNotificationFront({message: '" + Message + "',type: '" + objNotificationType.ToString() + "'});";
    }

    public static string GetPlainTextFromHtml(string htmlText, int Len)
    {
      string empty = string.Empty;
      bool flag = true;
      while (flag)
      {
        if (htmlText.ToLower().IndexOf("<xml>") >= 0 && htmlText.ToLower().IndexOf("</xml>") >= 0)
          htmlText = htmlText.Remove(htmlText.ToLower().IndexOf("<xml>"), htmlText.ToLower().IndexOf("</xml>") - htmlText.ToLower().IndexOf("<xml>") + 6);
        if (htmlText.ToLower().IndexOf("<style") >= 0 && htmlText.ToLower().IndexOf("</style>") >= 0)
          htmlText = htmlText.Remove(htmlText.ToLower().IndexOf("<style"), htmlText.ToLower().IndexOf("</style>") - htmlText.ToLower().IndexOf("<style") + 8);
        if (htmlText.ToLower().IndexOf("<xml>") < 0 && htmlText.ToLower().IndexOf("<style") < 0)
          flag = false;
      }
      string plainTextFromHtml = UtilityFunctions.GetTextFromHtml(htmlText).Replace("\r\n", "").Trim().Replace("&nbsp;", "");
      if (Len < plainTextFromHtml.Length)
        plainTextFromHtml = plainTextFromHtml.Substring(0, Len) + "...";
      return plainTextFromHtml;
    }

    public static string RandomString(int size, bool lowerCase)
    {
      StringBuilder stringBuilder = new StringBuilder();
      Random random = new Random();
      for (int index = 0; index < size; ++index)
      {
        char ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26.0 * random.NextDouble() + 65.0)));
        stringBuilder.Append(ch);
      }
      return lowerCase ? stringBuilder.ToString().ToLower() : stringBuilder.ToString();
    }

    public static string GetShortText(string TextValue, int Length)
    {
      if (TextValue.Length > Length)
      {
        string[] strArray = TextValue.Split(' ');
        TextValue = "";
        for (int index = 0; index < strArray.Length; ++index)
        {
          if (TextValue.Length + strArray[index].Length < Length)
            TextValue = TextValue + strArray[index].ToString() + " ";
          else
            index = strArray.Length;
          if (index < strArray.Length)
          {
            TextValue += " ";
          }
          else
          {
            TextValue = TextValue.Trim();
            TextValue += "...";
          }
        }
      }
      return TextValue;
    }

    public static void DropDownItemToolTip(ListControl dropDownList)
    {
      foreach (ListItem listItem in dropDownList.Items)
        listItem.Attributes.Add("title", listItem.Text);
    }

    public static DataTable CreateDataTable(string[] fields)
    {
      DataTable dataTable = new DataTable();
      for (int index = 0; index < fields.Length; ++index)
        dataTable.Columns.Add(fields[index]);
      return dataTable;
    }

    public static void SetDataTableValue(DataTable dt, string[] fields, string[] values)
    {
      DataRow row = dt.NewRow();
      for (int index = 0; index < fields.Length; ++index)
        row[fields[index]] = (object) values[index];
      dt.Rows.Add(row);
    }

    public static string getTruncatedString(string Textvalue, int maxLength, int Length)
    {
      Textvalue = Textvalue.Replace("<br />", "\n\r");
      if (Textvalue.Length > maxLength)
      {
        Textvalue = Textvalue.Substring(0, maxLength) + "...";
        Textvalue = Textvalue.Replace("\n\r", "<br />");
      }
      return Textvalue;
    }

    public static string getTruncatedStringForEmail(string Textvalue, int maxLength) => Textvalue.Length > maxLength ? Textvalue.Substring(0, maxLength) + "..." : Textvalue;

    public static string GetToolTip(string ToolTip) => ToolTip.Replace("'", "&#39");

    public static string GetAppSettings(string key) => ConfigurationManager.AppSettings[key].ToString();

    public static string AdminPageTitle(string ModuleName) => ModuleName + " | Admin | " + ConfigurationManager.AppSettings["PageTitle"];

    public static string FrontEndPageTitle(string ModuleName) => ModuleName + " | " + ConfigurationManager.AppSettings["PageTitle"];

    public static string PTManagerPageTitle(string ModuleName) => ModuleName + " | PT Manager | " + ConfigurationManager.AppSettings["PageTitle"];

    public static string ClubPageTitle(string ModuleName) => ModuleName + " | Club | " + ConfigurationManager.AppSettings["PageTitle"];

    public static string TrainerPageTitle(string ModuleName) => ModuleName + " | Trainer | " + ConfigurationManager.AppSettings["PageTitle"];

    public static void DeleteImage(string FileName)
    {
      if (!new FileInfo(FileName).Exists)
        return;
      System.IO.File.Delete(FileName);
    }

    public static string SetDeleteConfirmation(string ModuleName) => "return confirm('" + string.Format(Messages.ConfirmDeleteSingleItem, (object) ModuleName) + "')";

    public static string SetConfirmDeleteTransferedSingleItem(string ModuleName) => "return confirm('" + string.Format(Messages.ConfirmDeleteTransferedSingleItem, (object) ModuleName) + "')";

    public static string SetMultiDeleteConfirmation(string ModuleName) => "javascript:if(SelectOneMessage('chkDelete','','" + string.Format(Messages.SelectOnetoDelete, (object) ModuleName) + "')){ return confirm('" + string.Format(Messages.ConfirmDeleteMultipleItem, (object) ModuleName) + "'); } else {return false;}";

    public static string ChangeFileName(string filename)
    {
      string strToReplace = filename.Substring(0, filename.LastIndexOf("."));
      string str1 = filename.Substring(filename.LastIndexOf(".") + 1);
      string str2 = UtilityFunctions.RemoveSpecialCharactor(strToReplace);
      string str3 = PageBase.GetUTCdate().ToString("MMddyyyyhhmmssfff");
      string str4 = str1;
      string str5;
      return str5 = str2 + str3 + "." + str4;
    }

    public static string CheckSupplementSelection(string ModuleName) => "javascript:if(SelectOneMessage('chkDelete','','" + string.Format(Messages.SelectOnetoDelete, (object) ModuleName) + "')){ return true;); } else {return false;}";

    public static string GetMinsKeyword() => "Mins";

    public static string GetDollarSign() => "$";

    public static string GetPriceNote() => "[e.g. : XX.XX]";

    public static string SetMessageColor(int val)
    {
      string str = string.Empty;
      switch (val)
      {
        case 0:
          str = "Red";
          break;
        case 1:
          str = "#4745AA";
          break;
        case 2:
          str = "#006a25";
          break;
      }
      return str;
    }

    public static string GetNumberWithComma(string Price)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      bool flag = true;
      string str1 = Price.ToString();
      string numberWithComma = "";
      if (Price.ToString().Contains("."))
      {
        string str2 = Price.ToString().Substring(0, Price.ToString().LastIndexOf("."));
        string str3 = Price.ToString().Substring(Price.ToString().LastIndexOf(".") + 1);
        for (int index = str2.Length - 1; index >= 0; --index)
        {
          numberWithComma = str2[index].ToString() + numberWithComma;
          if ((str2.Length - index) % 3 == 0 & index > 0)
            numberWithComma = "," + numberWithComma;
          else if ((str2.Length - index) % 3 == 2 & index > 0)
          {
            if (!flag)
              numberWithComma = "," + numberWithComma;
            flag = false;
          }
        }
        numberWithComma = numberWithComma + "." + str3;
      }
      else
      {
        for (int index = str1.Length - 1; index >= 0; --index)
        {
          numberWithComma = str1[index].ToString() + numberWithComma;
          if ((str1.Length - index) % 3 == 0 & index > 0)
            numberWithComma = "," + numberWithComma;
          else if ((str1.Length - index) % 3 == 2 & index > 0)
          {
            if (!flag)
              numberWithComma = "," + numberWithComma;
            flag = false;
          }
        }
      }
      return numberWithComma;
    }

    public static string GetShopType(int Type)
    {
      if (Type == 1)
        return "order-supplements";
      return Type == 2 ? "personal-training" : (string) null;
    }

    public static string GetNoteforScheduler() => "NOTE : Drag session to schedule across days or calendars to change the date & time which will automatically schedule a session on that date & time.";

    public static DataTable ReverseRowsInDataTable(DataTable inputTable)
    {
      DataTable dataTable = inputTable.Clone();
      for (int index = inputTable.Rows.Count - 1; index >= 0; --index)
        dataTable.ImportRow(inputTable.Rows[index]);
      return dataTable;
    }

    public static void SetUserModuleAccess(HtmlGenericControl div)
    {
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
      {
        long int64 = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
        List<UserBE> userBeList = new List<UserBE>();
        foreach (UserBE userBe in UserMgmt.GetUserModuleInfoById(int64))
        {
          foreach (object control in div.Controls)
          {
            if (control is HtmlGenericControl htmlGenericControl && htmlGenericControl.ID.Contains("li"))
            {
              if (userBe.objModuleDetail.ModuleControld == htmlGenericControl.ID && userBe.objModuleDetail.IsChecked)
                htmlGenericControl.Visible = true;
              else if (userBe.objModuleDetail.ModuleControld == htmlGenericControl.ID && !userBe.objModuleDetail.IsChecked)
                htmlGenericControl.Visible = false;
            }
          }
        }
      }
      else
        HttpContext.Current.Response.Redirect("~/Admin/Default.aspx?ReturnURL=" + HttpContext.Current.Request.RawUrl);
    }

    public static void SetUserModuleAccessOnPage(
      HtmlGenericControl divUserAccess,
      HtmlGenericControl divData,
      string ModuleControlID)
    {
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
      {
        long int64 = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
        List<UserBE> userBeList = new List<UserBE>();
        if (UserMgmt.GetUserModuleInfoById(int64).Where<UserBE>((System.Func<UserBE, bool>) (m => m.objModuleDetail.ModuleControld == ModuleControlID && !m.objModuleDetail.IsChecked)).ToList<UserBE>().Count <= 0)
          return;
        divUserAccess.Visible = true;
        divData.Visible = false;
      }
      else
        HttpContext.Current.Response.Redirect("~/Admin/Default.aspx?ReturnURL=" + HttpContext.Current.Request.RawUrl);
    }

    public static void CheckUserModuleAccessOnPage(string ModuleControlID)
    {
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
      {
        long int64 = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
        List<UserBE> userBeList = new List<UserBE>();
        List<UserBE> list = UserMgmt.GetUserModuleInfoById(int64).Where<UserBE>((System.Func<UserBE, bool>) (m => m.objModuleDetail.ModuleControld == ModuleControlID && !m.objModuleDetail.IsChecked)).ToList<UserBE>();
        if (list.Count <= 0)
          return;
        HttpContext.Current.Session["UserAccessPageName"] = (object) list[0].objModuleDetail.ModuleName;
        HttpContext.Current.Response.Redirect("~/Admin/Welcome.aspx");
      }
      else
        HttpContext.Current.Response.Redirect("~/Admin/Default.aspx?ReturnURL=" + HttpContext.Current.Request.RawUrl);
    }

    public static void CheckAccessOfLoginUser()
    {
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString())
      {
        long int64 = Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)));
        if (!PageBase.CheckRoleByUserTypeID(Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)))))
          HttpContext.Current.Response.Redirect("~/Admin/Default.aspx?ReturnURL=" + HttpContext.Current.Request.RawUrl);
        UserBE userInfoById = UserMgmt.GetUserInfoById(Convert.ToInt64(int64));
        if (userInfoById == null || userInfoById.IsActive)
          return;
        HttpContext.Current.Response.Redirect("~/Admin/Default.aspx", false);
      }
      else
        HttpContext.Current.Response.Redirect("~/Admin/Default.aspx?ReturnURL=" + HttpContext.Current.Request.RawUrl);
    }

    public static string getLastModifiedTimeStamp(string filePath)
    {
      string empty = string.Empty;
      string modifiedTimeStamp;
      try
      {
        modifiedTimeStamp = System.IO.File.GetLastWriteTime(HttpContext.Current.Server.MapPath("/") + filePath).Ticks.ToString();
      }
      catch (Exception ex)
      {
        modifiedTimeStamp = DateTime.Now.Ticks.ToString();
      }
      return modifiedTimeStamp;
    }

    public static string GetFixedLengthText(string stringVal, int Length)
    {
      int length = Length;
      stringVal = string.IsNullOrEmpty(stringVal) ? "" : stringVal;
      return stringVal.Length > length ? stringVal.Substring(0, length) + "..." : stringVal;
    }

    public static string GetProductPageName(string str)
    {
      str = "Turf_Type_" + str.Replace(" ", "_");
      return str;
    }

    public static string ReadUserdataCookie(string Dataname)
    {
      string str = "";
      HttpCookie cookie = HttpContext.Current.Request.Cookies[".Frontendcookie"];
      try
      {
        if (cookie != null)
        {
          string[] strArray1 = Encryption.Decrypt(cookie.Value).Split('|');
          if (strArray1.Length != 0)
          {
            for (int index = 0; index < strArray1.Length; ++index)
            {
              string[] strArray2 = strArray1[index].Split('=');
              if (strArray2.Length != 0 && strArray2[0].ToLower() == Dataname.ToLower())
              {
                str = strArray2[1].ToString();
                break;
              }
            }
          }
        }
        return str;
      }
      catch
      {
        return "0";
      }
    }

    public static bool CreateUserdataCookie(
      long UserID,
      string UserName,
      string LoginEmail,
      string UserTypeId)
    {
      bool userdataCookie = false;
      HttpResponse response = HttpContext.Current.Response;
      try
      {
        string str = "";
        HttpCookie cookie = new HttpCookie(".Frontendcookie");
        string plainText = str + "LoginFrontUserID=" + UserID.ToString() + "|" + "LoginFrontUserName=" + UserName + "|" + "LoginFrontEmail=" + LoginEmail + "|" + "LoginFrontUserTypeID=" + UserTypeId + "|";
        cookie.Value = Encryption.Encrypt(plainText);
        cookie.Expires = DateTime.UtcNow.AddDays(20.0);
        response.Cookies.Add(cookie);
        userdataCookie = true;
      }
      catch
      {
      }
      return userdataCookie;
    }

    public static string GetUnitPrice(string price) => string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) Convert.ToDouble(price));

    public static string GetSubTotal(string price, string quantity)
    {
      double num1 = Convert.ToDouble(quantity);
      double num2 = Math.Round((double) float.Parse(price) * num1, 2);
      num2.ToString();
      return string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) num2);
    }

    public static string GetGrandTotal(DataTable _dtCart, DataTable dtSessionCart)
    {
      double num1 = 0.0;
      try
      {
        if (dtSessionCart == null)
          return "0.00";
        _dtCart = dtSessionCart;
        if (_dtCart.Rows.Count <= 0)
          return "0.00";
        for (int index = 0; index < _dtCart.Rows.Count; ++index)
        {
          double num2 = Convert.ToDouble(_dtCart.Rows[index]["Price"].ToString()) * Convert.ToDouble(_dtCart.Rows[index]["Quantity"].ToString());
          num1 += num2;
        }
        num1.ToString();
        return string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) num1);
      }
      catch
      {
        double num3 = Math.Round(Convert.ToDouble(num1.ToString()), 2);
        num3.ToString();
        return string.Format("{0:#,##0.00;(#,##0.00);0.00}", (object) num3);
      }
    }

    #region GetPaymentResponseFromXMLPostData
	public static Entity.Common.Response.PaymentGatewayResponse GetPaymentResponseFromXMLPostData(string GrandTotal, string cardNumber, string expiryDate, string cvv, string cardType, string carddescription, string cardHolderName, string purchaseOrderNo)
	{
		string MerchantId, MerchantPassword, ServerUrl, Timeout = "60";
		if (cardType == "1")
			cardType = "5"; //Master Card
		else if(cardType == "2")
			cardType = "6"; //Visa

		int tmp = Convert.ToInt32(ConfigurationManager.AppSettings["PaymentTest"]);

		if (tmp == 0)
		{
			MerchantId = ConfigurationManager.AppSettings["CamtechMerchantId"];
			MerchantPassword = ConfigurationManager.AppSettings["CamtechMerchantPassword"];
			ServerUrl = ConfigurationManager.AppSettings["CamtechServer"];
			Timeout = ConfigurationManager.AppSettings["CamtechTimeout"];
		}
		else
		{
			MerchantId = ConfigurationManager.AppSettings["CamtechMerchantId_live"];
			MerchantPassword = ConfigurationManager.AppSettings["CamtechMerchantPassword_live"];
			ServerUrl = ConfigurationManager.AppSettings["CamtechServer_live"];
			Timeout = ConfigurationManager.AppSettings["CamtechTimeout_live"];
		}

		string Params = "";

		System.Guid strGuid = System.Guid.NewGuid();

		StringBuilder sb = new StringBuilder();
		sb = sb.Append("<?xml version='1.0' encoding='UTF-8'?>");
		sb = sb.Append("<SecurePayMessage>");
		sb = sb.Append("<MessageInfo>");
		sb = sb.Append("<messageID>" + strGuid.ToString().Replace("-", "") + "</messageID><messageTimestamp>20041803161306527000+660</messageTimestamp>");
		sb = sb.Append("<timeoutValue>60</timeoutValue><apiVersion>xml-4.2</apiVersion>");
		sb = sb.Append("</MessageInfo>");
		sb = sb.Append("<MerchantInfo>");
		sb = sb.Append("<merchantID>" + MerchantId + "</merchantID>");
		sb = sb.Append("<password>" + MerchantPassword + "</password>");
		sb = sb.Append("</MerchantInfo>");
		sb = sb.Append("<RequestType>Payment</RequestType>");
		sb = sb.Append("<Payment>");
		sb = sb.Append("<TxnList count='1'><Txn ID='1'><txnType>0</txnType><txnSource>0</txnSource><txnChannel>0</txnChannel>");
		sb = sb.Append("<amount>" + GrandTotal + "</amount><purchaseOrderNo>" + purchaseOrderNo + "</purchaseOrderNo>");
		sb = sb.Append("<CreditCardInfo>");
		sb = sb.Append("<cardNumber>" + cardNumber + "</cardNumber><expiryDate> " + expiryDate + "</expiryDate><cvv>" + cvv + "</cvv><cardType>" + cardType + "</cardType><carddescription>" + carddescription + "</carddescription><cardHolderName>" + cardHolderName + "</cardHolderName>");
		sb = sb.Append("<recurringFlag>no</recurringFlag>");
		sb = sb.Append("</CreditCardInfo>");
		sb = sb.Append("</Txn></TxnList>");
		sb = sb.Append("</Payment>");
		sb = sb.Append("</SecurePayMessage>");
		Params = sb.ToString();

		string Url = ServerUrl;

		Uri uri = new Uri(Url);

		//Checks to make sure Params is not empty
		//Checks to make sure that the URL is an HTTPS url.
		ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
		if (uri.Scheme == System.Uri.UriSchemeHttps)
		{
			///''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			///'''''''''''''''''''''''''Create Connection Settings'''''''''''''''''''''''''''''''''''''
			System.Net.WebRequest request = System.Net.WebRequest.Create(uri);
			request.Method = System.Net.WebRequestMethods.Http.Post;
			request.ContentLength = Params.Length;
			request.ContentType = "text/xml; charset=utf-8";
			request.Timeout = 100000;
			///''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			///''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
			try
			{
				System.IO.StreamWriter writer = new System.IO.StreamWriter(request.GetRequestStream());
				//Open SSL Connection
				writer.Write(Params);
				//Send data to open connection
				writer.Close();
				System.Net.WebResponse oResponse = request.GetResponse();
				//Listen for response
				System.IO.StreamReader reader = new System.IO.StreamReader(oResponse.GetResponseStream(), System.Text.Encoding.UTF8);
				//Receive response
				string Reply = reader.ReadToEnd();
				//Read response
				oResponse.Close();

				Entity.Common.Response.PaymentGatewayResponse objPayment = new Entity.Common.Response.PaymentGatewayResponse();

				TextReader tr = new StringReader(Reply);
				XmlDocument xmlDoc = new XmlDocument();

				xmlDoc.LoadXml(Reply);
				XmlNodeList parentNode = xmlDoc.GetElementsByTagName("SecurePayMessage");

				XmlNodeList xnList = xmlDoc.SelectNodes("/SecurePayMessage/MessageInfo");
				foreach (XmlNode node in xnList)
				{
					string messageID = node["messageID"].InnerText;
					objPayment.messageID = messageID;
					string messageTimestamp = node["messageTimestamp"].InnerText;
					objPayment.messageTimestamp = messageTimestamp;
				}

				XmlNodeList xnList1 = xmlDoc.SelectNodes("/SecurePayMessage/Status");
				foreach (XmlNode node in xnList1)
				{
					string statusCode = node["statusCode"].InnerText;
					objPayment.statusCode = statusCode;

					string statusDescription = node["statusDescription"].InnerText;
					objPayment.statusDescription = statusDescription;
				}

				XmlNodeList xnList2 = xmlDoc.SelectNodes("/SecurePayMessage/Payment/TxnList/Txn");
				foreach (XmlNode node in xnList2)
				{
					string responseCode = node["responseCode"].InnerText;
					objPayment.responseCode = responseCode;

					string txnID = node["txnID"].InnerText;
					objPayment.txnID = txnID;

					string txnType = node["txnType"].InnerText;
					objPayment.txnType = txnType;

					string txnSource = node["txnSource"].InnerText;
					objPayment.txnSource = txnSource;

					string settlementDate = node["settlementDate"].InnerText;
					objPayment.settlementDate = settlementDate;

					string approved = node["approved"].InnerText;
					objPayment.approved = approved;

					string responseText = node["responseText"].InnerText;
					objPayment.responseText = responseText;
				}

				return objPayment;
			}
			catch (Exception Ex)
			{
				return null;
			}
		}
		else
		{
			return null;
		}
	}
	#endregion

    public static void SetDefaultCommonHeader(Page p, string ImageName, string PageName)
    {
      string appSetting1 = ConfigurationManager.AppSettings["HeaderImagePath"];
      string appSetting2 = ConfigurationManager.AppSettings["ImagePath"];
      string appSetting3 = ConfigurationManager.AppSettings["CommonInternalBannerName"];
      ((Image) p.Master.FindControl("imgHeader")).ImageUrl = string.IsNullOrEmpty(ImageName) ? ConfigurationManager.AppSettings["LivePath"] + appSetting2 + appSetting3 : ConfigurationManager.AppSettings["LivePath"] + appSetting1 + ImageName;
      Literal control1 = (Literal) p.Master.FindControl("ltrPageName");
      Literal control2 = (Literal) p.Master.FindControl("ltrMainPageName");
      control1.Text = PageName;
      control2.Text = PageName;
    }

    public static void SetBreadCum(Page p, GetConttentPageDataBE objPageManagement)
    {
      string appSetting1 = ConfigurationManager.AppSettings["HeaderImagePath"];
      string appSetting2 = ConfigurationManager.AppSettings["ImagePath"];
      string appSetting3 = ConfigurationManager.AppSettings["CommonInternalBannerName"];
      ((Image) p.Master.FindControl("imgHeader")).ImageUrl = string.IsNullOrEmpty(objPageManagement.HeaderImage) ? ConfigurationManager.AppSettings["LivePath"] + appSetting2 + appSetting3 : ConfigurationManager.AppSettings["LivePath"] + appSetting1 + objPageManagement.HeaderImage;
      HtmlGenericControl control1 = (HtmlGenericControl) p.Master.FindControl("DivCommon");
      HtmlGenericControl control2 = (HtmlGenericControl) p.Master.FindControl("DivBreadCum");
      Repeater control3 = (Repeater) p.Master.FindControl("rptBreadCum");
      Literal control4 = (Literal) p.Master.FindControl("LtePageMainName");
      if (control1 != null)
        control1.Visible = false;
      if (control2 != null)
        control2.Visible = true;
      control4.Text = objPageManagement.NameOnMenu;
      if (objPageManagement.LstGetConttentPageDataListBE.Count <= 0)
        return;
      control3.DataSource = (object) objPageManagement.LstGetConttentPageDataListBE;
      control3.DataBind();
    }

    public static string CheckPostCodeUsingAPI(string PostCodeVal)
    {
      string str = "&q=" + PostCodeVal;
      string format = UtilityFunctions.API_URL + str;
      HttpContext.Current.Response.ContentType = "text/json";
      string empty = string.Empty;
      if (WebRequest.Create(string.Format(format, (object) HttpContext.Current.Server.UrlEncode(HttpContext.Current.Request.QueryString["q"]))) is HttpWebRequest httpWebRequest)
      {
        httpWebRequest.Headers.Add("AUTH-KEY", UtilityFunctions.API_Key);
        httpWebRequest.Method = "GET";
        httpWebRequest.ServicePoint.Expect100Continue = false;
        httpWebRequest.Timeout = 20000;
        httpWebRequest.ContentType = "application/json";
      }
      return new StreamReader(httpWebRequest.GetResponse().GetResponseStream()).ReadToEnd().ToString();
    }

    public static int GetFrontUserID()
    {
      int frontUserId = 0;
      if (HttpContext.Current.Session["PlaceOrderType"] != null)
      {
        if (HttpContext.Current.Session["PlaceOrderType"].ToString() == ((Enums.PersonType) 4).ToString())
          frontUserId = 1;
        else if (HttpContext.Current.Session["PlaceOrderType"].ToString() == ((Enums.PersonType) 5).ToString())
          frontUserId = 2;
        else if (HttpContext.Current.Session["PlaceOrderType"].ToString() == ((Enums.PersonType) 6).ToString())
          frontUserId = 3;
      }
      else
        frontUserId = string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")) ? 0 : 1;
      return frontUserId;
    }

    public static long GetFrontCommercialPartnerUserID()
    {
      CommercialPartnerResponseBE partnerResponseBe = new CommercialPartnerResponseBE();
      return string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")) ? 0L : CommercialPartnerMgmt.GetCommercialPartnerIDByLoginMasterID(Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID"))).CommercialPartnerID;
    }

    public static void SetCartEmptyMessage(Page p, DataTable _dtCart)
    {
      if (HttpContext.Current.Session["dtCART"] != null)
      {
        _dtCart = (DataTable) HttpContext.Current.Session["dtCART"];
        _dtCart.Rows.Clear();
        HttpContext.Current.Session["dtCART"] = (object) _dtCart;
      }
      Label control = (Label) p.Master.FindControl("HeaderTopMenu1").FindControl("ltr_cart");
      control.Text = "Cart (0)";
      control.ToolTip = "Cart (0)";
    }

    public static void SetAdminCartEmptyMessage(
      Page p,
      DataTable _dtAdminCART,
      UserControl AdminPurchaseProcess1)
    {
      if (HttpContext.Current.Session["dtAdminCART"] != null)
      {
        _dtAdminCART = (DataTable) HttpContext.Current.Session["dtAdminCART"];
        _dtAdminCART.Rows.Clear();
        HttpContext.Current.Session["dtAdminCART"] = (object) _dtAdminCART;
      }
      Label control = (Label) AdminPurchaseProcess1.FindControl("ltradmin_cart");
      control.Text = "Cart (0)";
      control.ToolTip = "Cart (0)";
    }

    public static void SetQuoteEmptyMessage(Page p, DataTable _dtQUOTE)
    {
      if (HttpContext.Current.Session["dtQUOTE"] == null)
        return;
      _dtQUOTE = (DataTable) HttpContext.Current.Session["dtQUOTE"];
      _dtQUOTE.Rows.Clear();
      _dtQUOTE = (DataTable) null;
      HttpContext.Current.Session["dtQUOTE"] = (object) _dtQUOTE;
    }

    public static void SetQuoteDetailEmptyMessage(Page p, DataTable _dtQuoteDetail)
    {
      if (HttpContext.Current.Session["dtQuoteDetail"] == null)
        return;
      _dtQuoteDetail = (DataTable) HttpContext.Current.Session["dtQuoteDetail"];
      _dtQuoteDetail.Rows.Clear();
      _dtQuoteDetail = (DataTable) null;
      HttpContext.Current.Session["dtQuoteDetail"] = (object) _dtQuoteDetail;
    }

    public static string GetWindsorTurfAddressForEmails()
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("<span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #9f5497; font-weight: bold;\">Windsor Turf Management Team </span>");
      stringBuilder.Append("<br />");
      stringBuilder.Append("<span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #9f5497;\">Windsor Turf</span>");
      stringBuilder.Append("<br />");
      stringBuilder.Append("<span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #9f5497;\">Gate 6, Cornwallis Road</span><br />");
      stringBuilder.Append("<span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 13px; color: #9f5497;\">Windsor, NSW, 2756</span>");
      return stringBuilder.ToString();
    }

    public static string ChangeFileNameForPDF(string filename)
    {
      char[] separator = new char[1]{ '.' };
      string[] strArray = filename.Replace(" ", "").Split(separator, 2);
      string str1 = strArray[0];
      string str2 = DateTime.UtcNow.ToString("MMddyyyyhhmmssfff");
      string str3 = strArray[1];
      string str4;
      return str4 = str1 + str2 + "." + str3;
    }

    public static void writetext(string data)
    {
      string path = HttpContext.Current.Server.MapPath("~") + "Content/Log.txt";
      try
      {
        StreamReader streamReader = new StreamReader(path);
        string end = streamReader.ReadToEnd();
        streamReader.Close();
        TextWriter textWriter = (TextWriter) new StreamWriter(path);
        textWriter.WriteLine(end + data);
        textWriter.Close();
      }
      catch (Exception ex)
      {
        if (System.IO.File.Exists(path))
          return;
        System.IO.File.Create(path);
      }
    }

    public static void GeneratePDFInvoice(
      string PurchaseProductDetail,
      string iOrderNo,
      string DeliveryDate,
      string PickupDate,
      string PaymentStatus,
      string PaymentOption,
      string PickUpdetail,
      string hdnRetailPurchaseOrderID,
      string hdnPickUpDetailID,
      string hdnSubTotal,
      string hdnFinalTotal,
      string hdnPickDeliveryPrice,
      string CompletedOrderedPickUpInvoicePath,
      string CompletedOrderedDeliveryInvoicePath,
      string hdnGSTVal)
    {
      PurchaseOrderDetailBE retailPurchaseOrderId = PurchaseOrderDetailMgmt.GetAllOrderProcessingPurchaseDetailByRetailPurchaseOrderID(Convert.ToInt64(hdnRetailPurchaseOrderID));
      string str1 = string.Empty;
      string str2 = string.Empty;
      string str3 = string.Empty;
      string appSetting = ConfigurationManager.AppSettings["EmailTemplateImageFolderName"];
      if (Convert.ToInt32(hdnPickUpDetailID) == 1)
      {
        str1 = UtilityFunctions.GetMailFile(HttpContext.Current.Server.MapPath("~") + appSetting + "OrderInvoiceForPickUp.html");
        PickUpdetail = "PickUp";
      }
      else if (Convert.ToInt32(hdnPickUpDetailID) == 2)
      {
        str1 = UtilityFunctions.GetMailFile(HttpContext.Current.Server.MapPath("~") + appSetting + "OrderInvoiceForDelivery.html");
        PickUpdetail = "Delivery";
      }
      string str4 = str1.Replace("{ContactPersonName}", retailPurchaseOrderId.Name).Replace("{BillingBusinessName}", retailPurchaseOrderId.objBillingResponse.BillingBusinessName);
      string str5 = (string.IsNullOrEmpty(retailPurchaseOrderId.objBillingResponse.BillingAddressLine2) ? str4.Replace("{BillingAddress1}", retailPurchaseOrderId.objBillingResponse.BillingAddressLine1.Trim()) : str4.Replace("{BillingAddress1}", retailPurchaseOrderId.objBillingResponse.BillingAddressLine1.Trim() + "," + retailPurchaseOrderId.objBillingResponse.BillingAddressLine2)).Replace("{BillingCityCommaState}", retailPurchaseOrderId.objBillingResponse.BillingSuburb.Trim() + "," + retailPurchaseOrderId.objBillingResponse.BillingStateName);
      int num = retailPurchaseOrderId.objBillingResponse.BillingPostcode;
      string newValue1 = num.ToString().Trim();
      string str6 = str5.Replace("{BillingPostalcode}", newValue1).Replace("{invoiceno}", iOrderNo.ToString()).Replace("{InvoiceDate}", DateTime.Now.ToString("dd/MM/yyyy")).Replace("{ShippingBusinessName}", retailPurchaseOrderId.objBillingResponse.ShippingBusinessName);
      if (Convert.ToInt32(hdnPickUpDetailID) == 2)
      {
        string str7 = str6.Replace("{ShippingAddress1}", retailPurchaseOrderId.objBillingResponse.ShippingAddressLine1.Trim() + (!string.IsNullOrEmpty(retailPurchaseOrderId.objBillingResponse.ShippingAddressLine2) ? "," + retailPurchaseOrderId.objBillingResponse.ShippingAddressLine2 : "")).Replace("{ShippingCityCommaState}", retailPurchaseOrderId.objBillingResponse.ShippingSuburb + "," + retailPurchaseOrderId.objBillingResponse.ShippingStateName);
        num = retailPurchaseOrderId.objBillingResponse.ShippingPostcode;
        string newValue2 = num.ToString();
        str6 = str7.Replace("{ShippingPostalcode}", newValue2).Replace("{ShippingPhone}", retailPurchaseOrderId.objBillingResponse.ShippingHomePhone);
      }
      string str8 = str6.Replace("{Subtotal}", hdnSubTotal).Replace("{GST}", hdnGSTVal);
      if (Convert.ToInt32(hdnPickUpDetailID) == 1)
        str8 = str8.Replace("{PickupPriceInclGST}", hdnPickDeliveryPrice);
      else if (Convert.ToInt32(hdnPickUpDetailID) == 2)
        str8 = str8.Replace("{DeliveryPriceInclGST}", hdnPickDeliveryPrice);
      string str9 = str8.Replace("{GrandTotal}", hdnFinalTotal).Replace("{PurchaseProductDetail}", PurchaseProductDetail).Replace("{TermsAndConditions}", UtilityFunctions.PDFTermsAndConditions());
      if (Convert.ToInt32(hdnPickUpDetailID) == 1)
        str3 = HttpContext.Current.Server.MapPath("~") + CompletedOrderedPickUpInvoicePath;
      else if (Convert.ToInt32(hdnPickUpDetailID) == 2)
        str3 = HttpContext.Current.Server.MapPath("~") + CompletedOrderedDeliveryInvoicePath;
      string str10 = str3;
      string str11 = UtilityFunctions.ChangeFileNameForPDF("I-" + iOrderNo + "_" + retailPurchaseOrderId.Name.ToString() + "_.pdf");
      if (Convert.ToInt32(hdnPickUpDetailID) == 1)
        str9 = str9.Replace("{filename}", ConfigurationManager.AppSettings["LivePath"].ToString() + CompletedOrderedPickUpInvoicePath.ToString() + str11);
      else if (Convert.ToInt32(hdnPickUpDetailID) == 2)
        str9 = str9.Replace("{filename}", ConfigurationManager.AppSettings["LivePath"].ToString() + CompletedOrderedDeliveryInvoicePath.ToString() + str11);
      string str12 = HttpContext.Current.Server.MapPath("~\\wkhtmltopdf\\bin\\wkhtmltopdf.exe");
      string str13 = str10;
      try
      {
        string str14 = str13;
        string str15 = str11;
        Process process = new Process()
        {
          StartInfo = {
            FileName = str12,
            Arguments = "-q -n --page-size A4 - " + str15,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            RedirectStandardInput = true,
            WorkingDirectory = str14
          }
        };
        process.Start();
        try
        {
          StreamWriter standardInput = process.StandardInput;
          standardInput.AutoFlush = true;
          standardInput.Write(str9);
          standardInput.Close();
          standardInput.Dispose();
          if (process.WaitForExit(60000))
            HttpContext.Current.Response.BinaryWrite(System.IO.File.ReadAllBytes(str14 + str15));
          int exitCode = process.ExitCode;
          process.Close();
        }
        catch (Exception ex)
        {
          UtilityFunctions.writetext("========================PDF Proces Error====================================" + DateTime.Now.ToString());
          UtilityFunctions.writetext(ex.Message.ToString());
          UtilityFunctions.writetext(ex.Source.ToString());
          UtilityFunctions.writetext(ex.StackTrace.ToString());
          UtilityFunctions.writetext("========================PDF Proces Error====================================" + DateTime.Now.ToString());
        }
        finally
        {
          process.Close();
          process.Dispose();
          HttpContext.Current.Response.Clear();
        }
        str2 = str14 + str15;
        if (!System.IO.File.Exists(str2))
          ;
      }
      catch (Exception ex)
      {
        UtilityFunctions.writetext("========================PDF Error====================================" + DateTime.Now.ToString());
        UtilityFunctions.writetext(ex.Message.ToString());
        UtilityFunctions.writetext(ex.Source.ToString());
        UtilityFunctions.writetext(ex.StackTrace.ToString());
        UtilityFunctions.writetext("========================PDF Error====================================" + DateTime.Now.ToString());
      }
      PurchaseOrderDetailMgmt.UpdateInvoiceFilenameByOrderID(Convert.ToInt64(iOrderNo), str11);
      if (Convert.ToInt32(hdnPickUpDetailID) == 1)
        Mail.OrderPickUpDetailEmail(retailPurchaseOrderId.EmailAddress, retailPurchaseOrderId.Name, "I-" + iOrderNo, hdnFinalTotal, DeliveryDate.ToString(), PickupDate.ToString(), retailPurchaseOrderId.DeliveryInstructions, str2, PickUpdetail, PaymentOption, PaymentStatus);
      else if (Convert.ToInt32(hdnPickUpDetailID) == 2)
        Mail.OrderDeliveryDetailEmail(retailPurchaseOrderId.EmailAddress, retailPurchaseOrderId.Name, "I-" + iOrderNo, hdnFinalTotal, DeliveryDate.ToString(), PickupDate.ToString(), retailPurchaseOrderId.DeliveryInstructions, str2, PickUpdetail, PaymentOption, PaymentStatus);
      StringBuilder stringBuilder = new StringBuilder();
      if (retailPurchaseOrderId.objBillingResponse.BillingAddressLine2 != "")
      {
        stringBuilder.Append(" <strong>" + retailPurchaseOrderId.Name.Trim() + "</strong><br/> ");
        stringBuilder.Append(" " + retailPurchaseOrderId.objBillingResponse.BillingBusinessName.Trim() + "<br/> ");
        stringBuilder.Append(" ABN - " + retailPurchaseOrderId.objBillingResponse.BillingCompanyABN.Trim() + "<br/> ");
        stringBuilder.Append(" " + retailPurchaseOrderId.objBillingResponse.BillingAddressLine1.Trim() + "," + retailPurchaseOrderId.objBillingResponse.BillingAddressLine2.Trim() + " <br/> ");
        stringBuilder.Append(" " + retailPurchaseOrderId.objBillingResponse.BillingSuburb.Trim() + " <br/> ");
        stringBuilder.Append(" " + retailPurchaseOrderId.objBillingResponse.BillingStateName.Trim() + "," + retailPurchaseOrderId.objBillingResponse.BillingPostcode.ToString().Trim() + " <br/>");
        stringBuilder.Append(" Contact No. - " + (!string.IsNullOrEmpty(retailPurchaseOrderId.objBillingResponse.BillingHomePhone) ? retailPurchaseOrderId.objBillingResponse.BillingHomePhone : "N/A") + " <br/>");
      }
      else
      {
        stringBuilder.Append(" <strong>" + retailPurchaseOrderId.Name.Trim() + "</strong><br/> ");
        stringBuilder.Append(" " + retailPurchaseOrderId.objBillingResponse.BillingBusinessName.Trim() + "<br/> ");
        stringBuilder.Append(" ABN - " + retailPurchaseOrderId.objBillingResponse.BillingCompanyABN.Trim() + "<br/> ");
        stringBuilder.Append(" " + retailPurchaseOrderId.objBillingResponse.BillingAddressLine1.Trim() + " <br/> ");
        stringBuilder.Append(" " + retailPurchaseOrderId.objBillingResponse.BillingSuburb.Trim() + " <br/> ");
        stringBuilder.Append(" " + retailPurchaseOrderId.objBillingResponse.BillingStateName.Trim() + "," + retailPurchaseOrderId.objBillingResponse.BillingPostcode.ToString().Trim() + " <br/>");
        stringBuilder.Append(" Contact No. - " + (!string.IsNullOrEmpty(retailPurchaseOrderId.objBillingResponse.BillingHomePhone) ? retailPurchaseOrderId.objBillingResponse.BillingHomePhone : "N/A") + " <br/>");
      }
      string empty = string.Empty;
      string ClientOrderText = string.Empty;
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3))))
        ClientOrderText = !(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) == "1") ? "Below are purchased order detail addded by " + PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 2)) + "for client " + retailPurchaseOrderId.Name : "Below are purchased order detail addded by Administrator for client " + retailPurchaseOrderId.Name + ".";
      else if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
        ClientOrderText = "Below are purchased order detail added by commercial partner user " + retailPurchaseOrderId.Name + ".";
      else if (retailPurchaseOrderId.IsOrderUnderCompany == 1)
        ClientOrderText = "Below are purchased order detail added by commercial partner user " + retailPurchaseOrderId.Name + ".";
      else if (retailPurchaseOrderId.IsOrderUnderCompany == 2)
        ClientOrderText = "Below are purchased order detail added by commercial partner user " + retailPurchaseOrderId.Name + ".";
      List<PurchaseOrderProductDetailBE> orderProductDetailBeList = new List<PurchaseOrderProductDetailBE>();
      string PurchaseOrderInformation = UtilityFunctions.BindProductDetailForInvoice((DataTable) null, (List<PurchaseOrderProductDetailBE>) null, PurchaseOrderDetailMgmt.PurchaseOrderDetailByPurchaseOrderID(retailPurchaseOrderId.PurchaseOrderId));
      Mail.OrderEmailForAdminUser(retailPurchaseOrderId.EmailAddress, retailPurchaseOrderId.Name, "I-" + iOrderNo, hdnFinalTotal, DeliveryDate.ToString(), PickupDate.ToString(), retailPurchaseOrderId.DeliveryInstructions, PickUpdetail, PaymentOption, PaymentStatus, stringBuilder.ToString(), retailPurchaseOrderId.UserTypeName, PurchaseOrderInformation, ClientOrderText);
    }

    public static string BindProductDetailForInvoice(
      DataTable dtPurchase,
      List<PurchaseOrderProductDetailBE> lstProduct,
      List<PurchaseOrderProductDetailBE> lstOrderDetail)
    {
      string empty = string.Empty;
      if (dtPurchase != null)
      {
        if (dtPurchase.Rows.Count > 0)
        {
          for (int index = 0; index <= dtPurchase.Rows.Count - 1; ++index)
          {
            string str = "<tr><td style=\"text-align: left\"> " + dtPurchase.Rows[index]["TurfProductName"].ToString() + "</td><td style=\"text-align: left\">" + (dtPurchase.Rows[index]["ProductType"].ToString() == "1" ? PageName.strTurfTypeName : PageName.strNonTurfTypeName) + "</td><td style=\"text-align: right\">" + dtPurchase.Rows[index]["ProductPrice"].ToString() + "</td><td style=\"text-align: right\">" + dtPurchase.Rows[index]["ProductQuantity"].ToString() + "</td><td style=\"text-align: right\">" + dtPurchase.Rows[index]["ProductTotalPrice"].ToString() + "</td></tr>";
            empty += str;
          }
        }
      }
      else if (lstProduct != null)
      {
        if (lstProduct.Count > 0)
        {
          for (int index = 0; index <= lstProduct.Count - 1; ++index)
          {
            string str = "<tr><td style=\"text-align: left\"> " + lstProduct[index].TurfProductName.ToString() + "</td><td style=\"text-align: left\">" + (lstProduct[index].ProductType.Trim() == "1" ? PageName.strTurfTypeName : PageName.strNonTurfTypeName) + "</td><td style=\"text-align: right\">" + lstProduct[index].ProductPrice.ToString() + "</td><td style=\"text-align: right\">" + lstProduct[index].ProductQuantity.ToString() + "</td><td style=\"text-align: right\">" + lstProduct[index].ProductTotalPrice.ToString() + "</td></tr>";
            empty += str;
          }
        }
      }
      else if (lstOrderDetail != null && lstOrderDetail.Count > 0)
      {
        for (int index = 0; index <= lstOrderDetail.Count - 1; ++index)
        {
          string str = "<tr><td height=\"25\" style=\"margin: 0px; padding: 0px; border-bottom: 1px solid #cccccc;\" width=\"100%\" valign=\"middle\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\" ><tr><td width=\"20\" style=\"margin: 0px; padding: 0px;\"></td> <td width=\"200\" style=\"margin: 0px; padding: 0px;\"><span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #484848;\">" + lstOrderDetail[index].TurfProductName.Trim() + "</span></td><td width=\"120\" style=\"margin: 0px; padding: 0px;\"><span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #484848;\">" + (lstOrderDetail[index].ProductType.Trim() == "1" ? PageName.strTurfTypeName : PageName.strNonTurfTypeName) + "</span> </td><td width=\"80\" style=\"margin: 0px; padding: 0px;\" align=\"center\"><span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #484848;margin-left: 5px;text-align:right;\">" + lstOrderDetail[index].ProductQuantity.ToString() + "</span> </td><td width=\"200\" style=\"margin: 0px; padding: 0px;\" align=\"right\"> <span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #484848;\">" + lstOrderDetail[index].ProductPrice.ToString() + "</span></td><td width=\"100\" style=\"margin: 0px; padding: 0px;\" align=\"right\"> <span style=\"font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #484848;\">" + lstOrderDetail[index].ProductTotalPrice.ToString() + "</span></td><td width=\"20\" style=\"margin: 0px; padding: 0px;\"></td></tr></table></td></tr>";
          empty += str;
        }
      }
      return empty;
    }

    public static void CheckForInactiveUserForLogout(Page p, DataTable _dtcart)
    {
      if (!string.IsNullOrEmpty(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")))
      {
        CommercialPartnerResponseBE detailByLoginMasterId = CommercialPartnerMgmt.GetCommercialPartnerDetailByLoginMasterID(Convert.ToInt64(UtilityFunctions.ReadUserdataCookie("LoginFrontUserID")));
        if (detailByLoginMasterId == null || detailByLoginMasterId.IsActive)
          return;
        HttpContext.Current.Response.Redirect("/default.aspx");
      }
      else
      {
        if (string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0))) || !(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != Convert.ToInt32((object) (Enums.UserType) 4).ToString()))
          return;
        UserBE userInfoById = UserMgmt.GetUserInfoById(Convert.ToInt64(Convert.ToInt64(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 0)))));
        if (userInfoById != null && !userInfoById.IsActive)
          HttpContext.Current.Response.Redirect("/default.aspx");
      }
    }

    public static void CreateDirectory(string DirectoryPath)
    {
      if (Directory.Exists(DirectoryPath))
        return;
      Directory.CreateDirectory(DirectoryPath);
    }

    public static string FillPaymentStatus(int PaymentStatus, int PaymentTypeID)
    {
      string empty = string.Empty;
      int num = PaymentStatus;
      if (PaymentStatus == 0)
        num = PaymentTypeID;
      string str;
      switch (num)
      {
        case -1:
          str = "N/A";
          break;
        case 1:
          str = "<span class='greenclr'>Paid</span>";
          break;
        case 5:
          str = "<span class='redclr'>Awaiting Payment</span>";
          break;
        case 6:
          str = "<span class='redclr'>Awaiting Payment</span>";
          break;
        case 7:
          str = "<span class='redclr'>Awaiting Payment</span>";
          break;
        default:
          str = "<span class='redclr'>Failed</span>";
          break;
      }
      return str;
    }

    public static DateTime ConvertToDate(string DateField)
    {
      if (!DateTime.TryParseExact(DateField, "dd/MM/yyyy", (IFormatProvider) CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime _))
        return DateTime.MinValue;
      return Convert.ToDateTime(DateField.ToString().Split('/')[1] + "/" + DateField.ToString().Split('/')[0] + "/" + DateField.ToString().Split('/')[2]);
    }

    public static void GeneratePDFUsingHtml(
      string SeverPath,
      string FileName,
      string strFileName,
      string sb)
    {
      StringBuilder sb1 = new StringBuilder();
      sb1.Append(Mail.GetMailFile(SeverPath + "/EmailTemplates/ConvertHTMLtoPDF.html"));
      sb1.Replace("{Contant}", sb.ToString());
      UtilityFunctions.HTMLToPdf(sb1, SeverPath + UtilityFunctions.strDefaultPDFToHtmlFile + FileName + ".html");
      UtilityFunctions.ConvertHtmlToPdf(FileName, strFileName);
      System.IO.File.ReadAllBytes(SeverPath + UtilityFunctions.strDefaultPDFToHtmlFile + FileName + ".pdf");
      HttpResponse response = HttpContext.Current.Response;
      string path1 = HttpContext.Current.Server.MapPath("~") + UtilityFunctions.strDefaultPDFToHtmlFile;
      string address = HttpContext.Current.Server.MapPath("~") + UtilityFunctions.strDefaultPDFToHtmlFile + Path.GetFileName(FileName + ".pdf");
      Path.Combine(path1, Path.GetFileName(FileName + ".pdf"));
      byte[] buffer = new WebClient().DownloadData(address);
      response.ContentType = "application/pdf";
      response.AddHeader("content-length", buffer.Length.ToString());
      response.BinaryWrite(buffer);
      System.IO.File.Delete(SeverPath + UtilityFunctions.strDefaultPDFToHtmlFile + FileName + ".html");
      System.IO.File.Delete(SeverPath + UtilityFunctions.strDefaultPDFToHtmlFile + FileName + ".pdf");
      response.Flush();
      response.End();
    }

    public static void HTMLToPdf(StringBuilder sb, string HtmlFileName)
    {
      using (FileStream fileStream = System.IO.File.Create(HtmlFileName))
      {
        using (StreamWriter streamWriter = new StreamWriter((Stream) fileStream))
          streamWriter.WriteLine(sb.ToString());
      }
    }

    public static void ConvertHtmlToPdf(string FileName, string strFileName)
    {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.Append("--page-size A4 ");
      stringBuilder.Append("--page-offset 0 ");
      stringBuilder.Append("--margin-left 10 ");
      stringBuilder.Append("--margin-right 10 ");
      stringBuilder.Append("--header-spacing 5 ");
      stringBuilder.Append("--footer-spacing 5 ");
      stringBuilder.Append("--orientation portrait ");
      string str1 = HttpContext.Current.Server.MapPath("~") + UtilityFunctions.strDefaultPDFToHtmlFile;
      string str2 = HttpContext.Current.Server.MapPath("~") + UtilityFunctions.strDefaultPDFToHtmlFile + FileName + ".html";
      string str3 = FileName + ".PDF";
      stringBuilder.AppendFormat("\"{0}\" \"{1}\"", (object) str2, (object) (str1 + str3));
      ProcessStartInfo processStartInfo = new ProcessStartInfo();
      processStartInfo.CreateNoWindow = false;
      processStartInfo.FileName = HttpContext.Current.Server.MapPath("~\\wkhtmltopdf\\bin\\wkhtmltopdf.exe");
      processStartInfo.Arguments = stringBuilder.ToString();
      processStartInfo.UseShellExecute = false;
      processStartInfo.RedirectStandardError = false;
      processStartInfo.RedirectStandardInput = true;
      try
      {
        using (Process process = new Process())
        {
          process.StartInfo = processStartInfo;
          process.Start();
          process.WaitForExit();
        }
      }
      finally
      {
      }
    }

    public static string PDFTermsAndConditions() => "<div class=\"pdfTerms\">" + "<span>Conditions of Sale & Delivery:</span>" + "<ul>" + "<li>The Supplier&#39;s responsibility for delivery of materials will cease at the kerbside of the site address. If it is necessary for a vehicle to cross the kerb or enter private property in the course of effecting the delivery,the purchaser will provide safe and adequate access and notwithstanding will pay for all damage to any property, and injury or wrong which may result therefrom.</ li >" + "<li class=\"dbold\">Terms are strictly 30 days nett to approved accounts. Otherwise all transactions are C.O.D. Overdue accounts will incur interest at our current overdraft rate.</li>" + "<li>Quotations are valid for 90 days and are based on the quantity quotes being a minimum. Placement of an order, either written or verbal, based on a quotation implies acceptance of the supplier&#39;s offer and of these conditions. </li>" + "<li>Risk in any turf supplied by Windsor Turf to a customer shall pass when the turf is delivered to the customer or into the custody on the customer&#39;s behalf but ownership in such turf is retained by Windsor Turf until payment is made and all other turf supplied by Windsor Turf to the customer.If such turf is sold by the customer prior to payment thereof then the proceeds thereof shall become the property of Windsor Turf and the customer shall hold such proceeds as agent for Windsor Turf. The customer hereby expressly authorises and appoints Windsor Turf and its servants and contractors as the authorised agent of the customer For the purpose of entering into any site where such turf shall be required to be delivered or for the purpose of removing such turf pursuant of its rights hereunder.</ li >" + "</ul>" + "</div>" + "<div class=\"pdfTerms\" >" + "<span>Infringement of the Plant Breeder&#39;s Rights include:</span>" + "<ul>" + "<li>Commercial propagation of the grass without written authority from the breeder or licensee.</li>" + "<li>Sale of the grass or offering of the grass for sale.</li>" + "<li>Conditioning of the grass.</li>" + "<li>Export or Import of the grass.</li>" + "<li>Storage of the grass for any of the aforementioned purposes.</li>" + "</ul>" + "</div>" + "<div class=\"pdfTerms\" >" + "<p>Apart from damages for losses incurred by infringements, recoverable in civil Federal Court action, intentional and reckless infringement of the breeder&#39;s rights may under the Plant Breeders Rights Act 1994 attract a penalty of up to $50,000 for individuals and $250,000 for corporations. </p>" + "</div>" + "<div class=\"pdfTerms\" >" + "<span>Acknowledgment and Conditions of purchase:</span>" + "<ol>" + "<li>I acknowledge that I am aware of the restrictions and penalties imposed by the Plant Breeder&#39;s Rights Act 1994 as set out above.</li>" + "<li>I agree not to infringe the breeder&#39;s rights under the said Act.</li>" + "<li>I further agree: " + "<ol class=\"ulABC\">" + "<li><span>Not to leave the grass where it may be taken.</span></li>" + "<li><span>To take all reasonable precautions to prevent any unauthorised act which will infringe the breeder&#39;s rights under the Plant Breeder&#39;s Rights Act1994</span></li>" + "<li><span>Not to replant in a different area whether on the same property or not without the written consent of the breeder or licensee.</span></li>" + "</ol>" + "</li>" + "</ol>" + "</div>";

    public static DataTable ConvertToDataTable<T>(IList<T> data)
    {
      PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof (T));
      DataTable dataTable = new DataTable();
      foreach (PropertyDescriptor propertyDescriptor in properties)
      {
        DataColumnCollection columns = dataTable.Columns;
        string name = propertyDescriptor.Name;
        Type type = Nullable.GetUnderlyingType(propertyDescriptor.PropertyType);
        if ((object) type == null)
          type = propertyDescriptor.PropertyType;
        columns.Add(name, type);
      }
      foreach (T component in (IEnumerable<T>) data)
      {
        DataRow row = dataTable.NewRow();
        foreach (PropertyDescriptor propertyDescriptor in properties)
          row[propertyDescriptor.Name] = propertyDescriptor.GetValue((object) component) ?? (object) DBNull.Value;
        dataTable.Rows.Add(row);
      }
      return dataTable;
    }
  }
}
