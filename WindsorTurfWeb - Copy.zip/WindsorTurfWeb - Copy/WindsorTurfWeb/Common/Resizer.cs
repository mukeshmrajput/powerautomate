﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.Resizer
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Net;
using System.Web;
using System.Web.UI.WebControls;

namespace WindsorTurfWeb.Common
{
  public class Resizer
  {
    private Stream _imgstream;
    private int _Height;
    private int _Width;
    private int _destHeight;
    private int _destWidth;
    private System.Drawing.Image _InputImage;

    public static byte[] CropPicture(
      byte[] ImageFile,
      int TargetWidth,
      int TargetHeight,
      int TargetX,
      int TargetY)
    {
      System.Drawing.Image image = System.Drawing.Image.FromStream((Stream) new MemoryStream(ImageFile));
      Bitmap bitmap = new Bitmap(TargetWidth, TargetHeight, PixelFormat.Format24bppRgb);
      bitmap.SetResolution(80f, 60f);
      Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap);
      graphics.SmoothingMode = SmoothingMode.AntiAlias;
      graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
      graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
      graphics.DrawImage(image, new Rectangle(0, 0, TargetWidth, TargetHeight), TargetX, TargetY, TargetWidth, TargetHeight, GraphicsUnit.Pixel);
      MemoryStream memoryStream = new MemoryStream();
      bitmap.Save((Stream) memoryStream, ImageFormat.Jpeg);
      image.Dispose();
      bitmap.Dispose();
      graphics.Dispose();
      return memoryStream.GetBuffer();
    }

    public static string byteArrayToImage(
      byte[] byteArrayIn,
      string ImageName,
      int TargetWidth,
      int TargetHeight,
      string Extension,
      string TargetFolder)
    {
      if (byteArrayIn == null)
        return (string) null;
      try
      {
        using (MemoryStream memoryStream = new MemoryStream(byteArrayIn))
          return Resizer.Resize(System.Drawing.Image.FromStream((Stream) memoryStream), ImageName, TargetWidth, TargetHeight, Extension, TargetFolder);
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public static string Resize(
      string InputFilePath,
      string Name,
      int TargetWidth,
      int TargetHeight,
      string Extension,
      string TargetFolder)
    {
      string empty = string.Empty;
      string str = string.Empty;
      try
      {
        using (Bitmap original = new Bitmap(InputFilePath))
        {
          Size relativeImageSize = Resizer.GetRelativeImageSize(original.Width, original.Height, TargetWidth, TargetHeight);
          str = Name;
          string filename = TargetFolder + str;
          using (Bitmap bitmap = new Bitmap((System.Drawing.Image) original, relativeImageSize))
          {
            using (Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap))
            {
              graphics.SmoothingMode = SmoothingMode.HighQuality;
              graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
              graphics.CompositingQuality = CompositingQuality.HighQuality;
              ImageCodecInfo imageCodec = Resizer.GetImageCodec(Extension);
              EncoderParameters encoderParams = new EncoderParameters(1);
              encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, 100L);
              graphics.DrawImage((System.Drawing.Image) original, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
              bitmap.Save(filename, imageCodec, encoderParams);
            }
          }
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return str;
    }

    public static string Resize(
      Stream InputFileStream,
      string Name,
      int TargetWidth,
      int TargetHeight,
      string Extension,
      string TargetFolder)
    {
      string empty = string.Empty;
      string str = string.Empty;
      try
      {
        using (Bitmap original = new Bitmap(InputFileStream))
        {
          Size relativeImageSize = Resizer.GetRelativeImageSize(original.Width, original.Height, TargetWidth, TargetHeight);
          str = Name;
          string filename = TargetFolder + str;
          using (Bitmap bitmap = new Bitmap((System.Drawing.Image) original, relativeImageSize))
          {
            using (Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap))
            {
              graphics.SmoothingMode = SmoothingMode.HighQuality;
              graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
              graphics.CompositingQuality = CompositingQuality.HighQuality;
              ImageCodecInfo imageCodec = Resizer.GetImageCodec(Extension);
              EncoderParameters encoderParams = new EncoderParameters(1);
              encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, 100L);
              graphics.DrawImage((System.Drawing.Image) original, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
              bitmap.Save(filename, imageCodec, encoderParams);
            }
          }
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return str;
    }

    public static string Resize(
      Bitmap InputFile,
      string Name,
      int TargetWidth,
      int TargetHeight,
      string Extension,
      string TargetFolder)
    {
      string empty = string.Empty;
      string str = string.Empty;
      try
      {
        using (Bitmap original = InputFile)
        {
          Size relativeImageSize = Resizer.GetRelativeImageSize(original.Width, original.Height, TargetWidth, TargetHeight);
          str = Name + Extension;
          string filename = TargetFolder + str;
          using (Bitmap bitmap = new Bitmap((System.Drawing.Image) original, relativeImageSize))
          {
            using (Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap))
            {
              graphics.SmoothingMode = SmoothingMode.HighQuality;
              graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
              graphics.CompositingQuality = CompositingQuality.HighQuality;
              ImageCodecInfo imageCodec = Resizer.GetImageCodec(Extension);
              EncoderParameters encoderParams = new EncoderParameters(1);
              encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, 100L);
              graphics.DrawImage((System.Drawing.Image) original, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
              bitmap.Save(filename, imageCodec, encoderParams);
            }
          }
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return str;
    }

    public static string Resize(
      Bitmap InputFile,
      string Name,
      string Extension,
      string TargetFolder,
      Size TargetSize)
    {
      string empty = string.Empty;
      string str = string.Empty;
      try
      {
        using (Bitmap original = (Bitmap) InputFile.Clone())
        {
          Size relativeImageSize = Resizer.GetRelativeImageSize(original.Width, original.Height, TargetSize.Width, TargetSize.Height);
          str = Name;
          string filename = HttpContext.Current.Server.MapPath("~") + TargetFolder + str;
          using (Bitmap bitmap = new Bitmap((System.Drawing.Image) original, relativeImageSize))
          {
            using (Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap))
            {
              graphics.SmoothingMode = SmoothingMode.HighQuality;
              graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
              graphics.CompositingQuality = CompositingQuality.HighQuality;
              ImageCodecInfo imageCodec = Resizer.GetImageCodec(Extension);
              EncoderParameters encoderParams = new EncoderParameters(1);
              encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, 100L);
              graphics.DrawImage((System.Drawing.Image) original, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
              bitmap.Save(filename, imageCodec, encoderParams);
            }
          }
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return str;
    }

    public static string Resize(
      System.Drawing.Image InputFile,
      string Name,
      int TargetWidth,
      int TargetHeight,
      string Extension,
      string TargetFolder)
    {
      string empty = string.Empty;
      string str = string.Empty;
      try
      {
        using (Bitmap original = new Bitmap(InputFile))
        {
          Size relativeImageSize = Resizer.GetRelativeImageSize(original.Width, original.Height, TargetWidth, TargetHeight);
          str = Name + Extension;
          string filename = TargetFolder + str;
          using (Bitmap bitmap = new Bitmap((System.Drawing.Image) original, relativeImageSize))
          {
            using (Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap))
            {
              graphics.SmoothingMode = SmoothingMode.HighQuality;
              graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
              graphics.CompositingQuality = CompositingQuality.HighQuality;
              ImageCodecInfo imageCodec = Resizer.GetImageCodec(Extension);
              EncoderParameters encoderParams = new EncoderParameters(1);
              encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, 100L);
              graphics.DrawImage((System.Drawing.Image) original, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
              bitmap.Save(filename, imageCodec, encoderParams);
            }
          }
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return str;
    }

    public static string UploadImage(
      string FileName,
      FileUpload FUControls,
      string TargetFolder,
      Size TargetSize)
    {
      try
      {
        bool flag = false;
        string lower = FUControls.FileName.Substring(FUControls.FileName.LastIndexOf('.')).ToLower();
        string[] strArray = new string[9]
        {
          ".jpg",
          ".gif",
          ".png",
          ".bmp",
          ".jpeg",
          ".tif",
          ".jpe",
          ".jfif",
          ".tiff"
        };
        foreach (string str in strArray)
        {
          if (str == lower)
          {
            flag = true;
            break;
          }
        }
        if (!flag)
          return (string) null;
        using (Bitmap InputFile = new Bitmap(FUControls.FileContent))
          return Resizer.Resize(InputFile, FileName, lower, TargetFolder, TargetSize);
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    public static string UploadImage(
      string FileName,
      FileUpload FUControls,
      string[] TargetFolders,
      Size[] TargetSizes)
    {
      if (TargetFolders.Length != TargetSizes.Length)
        throw new Exception("Target Folder length must match to Target size length");
      try
      {
        bool flag = false;
        string lower = FUControls.FileName.Substring(FUControls.FileName.LastIndexOf('.')).ToLower();
        string[] strArray = new string[9]
        {
          ".jpg",
          ".gif",
          ".png",
          ".bmp",
          ".jpeg",
          ".tif",
          ".jpe",
          ".jfif",
          ".tiff"
        };
        foreach (string str in strArray)
        {
          if (str == lower)
          {
            flag = true;
            break;
          }
        }
        if (!flag)
          return (string) null;
        FileName = Resizer.ChangeFileName(FileName);
        using (Bitmap InputFile = new Bitmap(FUControls.FileContent))
        {
          for (int index = 0; index < TargetFolders.Length; ++index)
            Resizer.Resize(InputFile, FileName, lower, TargetFolders[index], TargetSizes[index]);
        }
        return FileName + lower;
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    private static Size GetRelativeImageSize(
      int SourceWidth,
      int SourceHeight,
      int TargetWidth,
      int TargetHeight)
    {
      if (SourceWidth <= TargetWidth && SourceHeight <= TargetHeight)
        return new Size(SourceWidth, SourceHeight);
      float num1;
      if (TargetWidth == 0)
      {
        if (SourceHeight <= TargetHeight)
          return new Size(SourceWidth, SourceHeight);
        num1 = (float) TargetHeight / (float) SourceHeight;
      }
      else if (TargetHeight == 0)
      {
        if (SourceWidth <= TargetWidth)
          return new Size(SourceWidth, SourceHeight);
        num1 = (float) TargetWidth / (float) SourceWidth;
      }
      else
      {
        float num2 = (float) TargetWidth / (float) SourceWidth;
        float num3 = (float) TargetHeight / (float) SourceHeight;
        num1 = (double) num3 >= (double) num2 ? num2 : num3;
      }
      return new Size(Convert.ToInt32((float) SourceWidth * num1), Convert.ToInt32((float) SourceHeight * num1));
    }

    private static ImageCodecInfo GetImageCodec(string Ext)
    {
      switch (Ext)
      {
        case "bmp":
          return ImageCodecInfo.GetImageEncoders()[0];
        case "gif":
          return ImageCodecInfo.GetImageEncoders()[2];
        case "jfif":
          return ImageCodecInfo.GetImageEncoders()[1];
        case "jpe":
          return ImageCodecInfo.GetImageEncoders()[1];
        case "jpeg":
          return ImageCodecInfo.GetImageEncoders()[1];
        case "jpg":
          return ImageCodecInfo.GetImageEncoders()[1];
        case "png":
          return ImageCodecInfo.GetImageEncoders()[4];
        case "tif":
          return ImageCodecInfo.GetImageEncoders()[3];
        case "tiff":
          return ImageCodecInfo.GetImageEncoders()[3];
        default:
          return ImageCodecInfo.GetImageEncoders()[1];
      }
    }

    private static string ChangeFileName(string FileName) => Resizer.RemoveSpecialCharactor(FileName) + DateTime.Now.ToString("MMddyyyyhhmmssfff");

    private static string RemoveSpecialCharactor(string strToReplace)
    {
      strToReplace = strToReplace.Replace("~", "");
      strToReplace = strToReplace.Replace("`", "");
      strToReplace = strToReplace.Replace("!", "");
      strToReplace = strToReplace.Replace("@", "");
      strToReplace = strToReplace.Replace("#", "");
      strToReplace = strToReplace.Replace("$", "");
      strToReplace = strToReplace.Replace("%", "");
      strToReplace = strToReplace.Replace("^", "");
      strToReplace = strToReplace.Replace("&", "");
      strToReplace = strToReplace.Replace("*", "");
      strToReplace = strToReplace.Replace("(", "");
      strToReplace = strToReplace.Replace(")", "");
      strToReplace = strToReplace.Replace("-", "");
      strToReplace = strToReplace.Replace("_", "");
      strToReplace = strToReplace.Replace("+", "");
      strToReplace = strToReplace.Replace("=", "");
      strToReplace = strToReplace.Replace("[", "");
      strToReplace = strToReplace.Replace("]", "");
      strToReplace = strToReplace.Replace("{", "");
      strToReplace = strToReplace.Replace("}", "");
      strToReplace = strToReplace.Replace("|", "");
      strToReplace = strToReplace.Replace("\\", "");
      strToReplace = strToReplace.Replace(":", "");
      strToReplace = strToReplace.Replace(";", "");
      strToReplace = strToReplace.Replace("'", "");
      strToReplace = strToReplace.Replace("\"", "");
      strToReplace = strToReplace.Replace(".", "");
      strToReplace = strToReplace.Replace(",", "");
      strToReplace = strToReplace.Replace("<", "");
      strToReplace = strToReplace.Replace(">", "");
      strToReplace = strToReplace.Replace("''", "");
      strToReplace = strToReplace.Replace("?", "");
      strToReplace = strToReplace.Replace("/", "");
      strToReplace = strToReplace.Replace("  ", " ");
      strToReplace = strToReplace.Replace(" ", "-");
      return strToReplace.ToLower();
    }

    public static System.Drawing.Image Crop(
      System.Drawing.Image imgPhoto,
      int Width,
      int Height,
      Resizer.AnchorPosition Anchor)
    {
      int width = imgPhoto.Width;
      int height = imgPhoto.Height;
      int x = 0;
      int y = 0;
      float num1 = (float) Width / (float) width;
      float num2 = (float) Height / (float) height;
      float num3;
      if ((double) num2 < (double) num1)
      {
        num3 = num1;
        switch (Anchor)
        {
          case Resizer.AnchorPosition.Top:
            y = 0;
            break;
          case Resizer.AnchorPosition.Bottom:
            y = (int) ((double) Height - (double) height * (double) num3);
            break;
          default:
            y = (int) (((double) Height - (double) height * (double) num3) / 2.0);
            break;
        }
      }
      else
      {
        num3 = num2;
        switch (Anchor)
        {
          case Resizer.AnchorPosition.Left:
            x = 0;
            break;
          case Resizer.AnchorPosition.Right:
            x = (int) ((double) Width - (double) width * (double) num3);
            break;
          default:
            x = (int) (((double) Width - (double) width * (double) num3) / 2.0);
            break;
        }
      }
      int num4 = (int) ((double) width * (double) num3);
      int num5 = (int) ((double) height * (double) num3);
      Bitmap bitmap = new Bitmap(Width, Height, PixelFormat.Format24bppRgb);
      bitmap.SetResolution(imgPhoto.HorizontalResolution, imgPhoto.VerticalResolution);
      Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap);
      graphics.SmoothingMode = SmoothingMode.HighQuality;
      graphics.InterpolationMode = InterpolationMode.HighQualityBilinear;
      graphics.PixelOffsetMode = PixelOffsetMode.HighQuality;
      graphics.CompositingQuality = CompositingQuality.HighQuality;
      graphics.DrawImage(imgPhoto, new Rectangle(x, y, num4 + 1, num5 + 1));
      graphics.Dispose();
      return (System.Drawing.Image) bitmap;
    }

    public System.Drawing.Image InputImage
    {
      get => this._InputImage;
      set => this._InputImage = value;
    }

    public int Height
    {
      get => this._Height;
      set => this._Height = value;
    }

    public int Width
    {
      get => this._Width;
      set => this._Width = value;
    }

    public int DestHeight
    {
      get => this._destHeight;
      set => this._destHeight = value;
    }

    public int DestWidth
    {
      get => this._destWidth;
      set => this._destWidth = value;
    }

    public Stream ImageStream
    {
      get => this._imgstream;
      set => this._imgstream = value;
    }

    public System.Drawing.Image ResizeImage()
    {
      System.Drawing.Image image = System.Drawing.Image.FromStream(this._imgstream);
      int width = image.Width;
      int height = image.Height;
      int num1 = 0;
      int num2 = 0;
      if (width <= this._Width && height <= this._Height)
        return image;
      float num3 = (float) this._Width / (float) width;
      float num4 = (float) this._Height / (float) height;
      if ((double) num4 < (double) num3)
      {
        float num5 = num4;
        num1 = (int) (((double) this._Height - (double) width * (double) num5) / 2.0);
      }
      else
      {
        float num6 = num3;
        num2 = (int) (((double) this._Width - (double) height * (double) num6) / 2.0);
      }
      this._destWidth = this._Width;
      this._destHeight = this._Height;
      IntPtr num7 = new IntPtr(0);
      System.Drawing.Image thumbnailImage = image.GetThumbnailImage(this._destWidth, this._destHeight, (System.Drawing.Image.GetThumbnailImageAbort) null, IntPtr.Zero);
      image.Dispose();
      return thumbnailImage;
    }

    public static string ResizeFromStream(
      string ImageSavePath,
      int width,
      int Height,
      string Buffer)
    {
      System.Drawing.Image image1 = System.Drawing.Image.FromFile(Buffer);
      ImageFormat rawFormat = image1.RawFormat;
      System.Drawing.Image image2 = (System.Drawing.Image) new Bitmap(width, Height, image1.PixelFormat);
      Graphics graphics = Graphics.FromImage(image2);
      graphics.CompositingQuality = CompositingQuality.HighQuality;
      graphics.SmoothingMode = SmoothingMode.HighQuality;
      graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
      Rectangle rect = new Rectangle(0, 0, width, Height);
      graphics.DrawImage(image1, rect);
      image2.Save(ImageSavePath, rawFormat);
      image1.Dispose();
      return image1.ToString();
    }

    public static void FixedSize(
      string FileName,
      FileUpload objFileUpload,
      string TargetPath,
      int Width,
      int Height)
    {
      System.Drawing.Image image = System.Drawing.Image.FromStream((Stream) new MemoryStream(objFileUpload.FileBytes));
      string filename = HttpContext.Current.Server.MapPath("~") + TargetPath + FileName;
      int width1 = image.Width;
      int height1 = image.Height;
      int x1 = 0;
      int y1 = 0;
      int x2 = 0;
      int y2 = 0;
      float num1 = (float) Width / (float) width1;
      float num2 = (float) Height / (float) height1;
      float num3;
      if ((double) num2 < (double) num1)
      {
        num3 = num2;
        x2 = (int) (((double) Width - (double) width1 * (double) num3) / 2.0);
      }
      else
      {
        num3 = num1;
        y2 = (int) (((double) Height - (double) height1 * (double) num3) / 2.0);
      }
      int width2 = (int) ((double) width1 * (double) num3);
      int height2 = (int) ((double) height1 * (double) num3);
      Bitmap bitmap = new Bitmap(Width, Height, PixelFormat.Format24bppRgb);
      bitmap.SetResolution(image.HorizontalResolution, image.VerticalResolution);
      Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap);
      graphics.Clear(Color.White);
      graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
      graphics.DrawImage(image, new Rectangle(x2, y2, width2, height2), new Rectangle(x1, y1, width1, height1), GraphicsUnit.Pixel);
      graphics.Dispose();
      bitmap.Save(filename);
    }

    public static void FixedSize(
      string FileName,
      FileUpload objFileUpload,
      string TargetPath,
      int Width,
      int Height,
      Color ColorObject)
    {
      System.Drawing.Image image = System.Drawing.Image.FromStream((Stream) new MemoryStream(objFileUpload.FileBytes));
      string filename = HttpContext.Current.Server.MapPath("~") + TargetPath + FileName;
      int width1 = image.Width;
      int height1 = image.Height;
      int x1 = 0;
      int y1 = 0;
      int x2 = 0;
      int y2 = 0;
      float num1 = (float) Width / (float) width1;
      float num2 = (float) Height / (float) height1;
      if (image.Height > Height || image.Width > Width)
      {
        float num3;
        if ((double) num2 < (double) num1)
        {
          num3 = num2;
          x2 = (int) (((double) Width - (double) width1 * (double) num3) / 2.0);
        }
        else
        {
          num3 = num1;
          y2 = (int) (((double) Height - (double) height1 * (double) num3) / 2.0);
        }
        int width2 = (int) ((double) width1 * (double) num3);
        int height2 = (int) ((double) height1 * (double) num3);
        Bitmap bitmap = new Bitmap(Width, Height, PixelFormat.Format24bppRgb);
        bitmap.SetResolution(image.HorizontalResolution, image.VerticalResolution);
        Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap);
        graphics.Clear(ColorObject);
        graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
        graphics.DrawImage(image, new Rectangle(x2, y2, width2, height2), new Rectangle(x1, y1, width1, height1), GraphicsUnit.Pixel);
        graphics.Dispose();
        bitmap.Save(filename);
      }
      else
        image.Save(filename);
    }

    public static byte[] FixedSize(string ImageLiveURL, int Width, int Height)
    {
      System.Drawing.Image image = System.Drawing.Image.FromStream(new WebClient().OpenRead(ImageLiveURL));
      int width1 = image.Width;
      int height1 = image.Height;
      int x1 = 0;
      int y1 = 0;
      int x2 = 0;
      int y2 = 0;
      float num1 = (float) Width / (float) width1;
      float num2 = (float) Height / (float) height1;
      float num3;
      if ((double) num2 < (double) num1)
      {
        num3 = num2;
        x2 = (int) (((double) Width - (double) width1 * (double) num3) / 2.0);
      }
      else
      {
        num3 = num1;
        y2 = (int) (((double) Height - (double) height1 * (double) num3) / 2.0);
      }
      int width2 = (int) ((double) width1 * (double) num3);
      int height2 = (int) ((double) height1 * (double) num3);
      Bitmap bitmap = new Bitmap(Width, Height, PixelFormat.Format24bppRgb);
      bitmap.SetResolution(image.HorizontalResolution, image.VerticalResolution);
      Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap);
      graphics.Clear(Color.White);
      graphics.InterpolationMode = InterpolationMode.Low;
      graphics.DrawImage(image, new Rectangle(x2, y2, width2, height2), new Rectangle(x1, y1, width1, height1), GraphicsUnit.Pixel);
      graphics.Dispose();
      using (MemoryStream memoryStream = new MemoryStream())
      {
        bitmap.Save((Stream) memoryStream, ImageFormat.Png);
        return memoryStream.ToArray();
      }
    }

    public static string SaveOriginalImage(
      FileUpload objFileUpload,
      string Name,
      string Extension,
      string TargetFolder)
    {
      Stream stream = (Stream) new MemoryStream(objFileUpload.FileBytes);
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string str;
      try
      {
        using (Bitmap original = new Bitmap(stream))
        {
          str = Name;
          string filename = HttpContext.Current.Server.MapPath("~") + TargetFolder + str;
          using (Bitmap bitmap = new Bitmap((System.Drawing.Image) original))
          {
            using (Graphics graphics = Graphics.FromImage((System.Drawing.Image) bitmap))
            {
              graphics.SmoothingMode = SmoothingMode.AntiAlias;
              graphics.InterpolationMode = InterpolationMode.Low;
              graphics.CompositingQuality = CompositingQuality.Invalid;
              ImageCodecInfo imageCodec = Resizer.GetImageCodec(Extension);
              EncoderParameters encoderParams = new EncoderParameters(1);
              encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, 10L);
              graphics.DrawImage((System.Drawing.Image) original, new Rectangle(0, 0, bitmap.Width, bitmap.Height));
              bitmap.Save(filename, imageCodec, encoderParams);
            }
          }
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }
      return str;
    }

    public static void CreateThumbVideoImage(
      string ThumbPath,
      string ThumbFileName,
      string OrignalFilePath)
    {
      string str1 = HttpContext.Current.Server.MapPath("~/") + ThumbPath + ThumbFileName.Split('.')[0] + ".jpeg";
      string str2 = "-i " + HttpContext.Current.Server.MapPath("~/") + OrignalFilePath + ThumbFileName + " -vcodec mjpeg -vframes 1 -ss 00:00:07 -s 50x50 " + str1;
      Process process1 = new Process();
      Process process2 = new Process();
      process2.StartInfo.FileName = HttpContext.Current.Server.MapPath("~\\Content\\ffmpeg\\ffmpeg.exe");
      process2.StartInfo.Arguments = str2;
      process2.StartInfo.UseShellExecute = false;
      process2.StartInfo.CreateNoWindow = false;
      process2.StartInfo.RedirectStandardOutput = false;
      try
      {
        process2.Start();
      }
      catch (Exception ex)
      {
      }
      process2.WaitForExit();
      process2.Close();
    }

    public static void CreateThumbVideoImageLivePath(string ThumbPath)
    {
      string str = "-i http://www.youtube.com/watch?v=fMKCPW_HO8E -vcodec mjpeg -vframes 1 -ss 00:00:07 -s 80x60 " + (HttpContext.Current.Server.MapPath("~/") + ThumbPath + "Test.jpeg");
      Process process1 = new Process();
      Process process2 = new Process();
      process2.StartInfo.FileName = HttpContext.Current.Server.MapPath("~\\Content\\ffmpeg\\ffmpeg.exe");
      process2.StartInfo.Arguments = str;
      process2.StartInfo.UseShellExecute = false;
      process2.StartInfo.CreateNoWindow = false;
      process2.StartInfo.RedirectStandardOutput = false;
      try
      {
        process2.Start();
      }
      catch (Exception ex)
      {
      }
      process2.WaitForExit();
      process2.Close();
    }

    public static string GetYoutubeThumbnil(string YoutubeId, string ThumbPath)
    {
      string empty = string.Empty;
      string str = "http://img.youtube.com/vi/" + YoutubeId + "/0.jpg";
      string youtubeThumbnil = UtilityFunctions.ChangeFileName(str.Substring(str.LastIndexOf('/') + 1));
      System.Drawing.Image image = Resizer.Crop((System.Drawing.Image) new Bitmap(WebRequest.Create("http://img.youtube.com/vi/" + YoutubeId + "/0.jpg").GetResponse().GetResponseStream()), 50, 50, Resizer.AnchorPosition.Center);
      ImageCodecInfo imageEncoder = ImageCodecInfo.GetImageEncoders()[1];
      EncoderParameters encoderParams = new EncoderParameters(1);
      encoderParams.Param[0] = new EncoderParameter(Encoder.Quality, 100L);
      image.Save(HttpContext.Current.Server.MapPath("~/" + ThumbPath) + "\\" + youtubeThumbnil, imageEncoder, encoderParams);
      return youtubeThumbnil;
    }

    public enum Dimensions
    {
      Width,
      Height,
    }

    public enum AnchorPosition
    {
      Top,
      Center,
      Bottom,
      Left,
      Right,
    }
  }
}
