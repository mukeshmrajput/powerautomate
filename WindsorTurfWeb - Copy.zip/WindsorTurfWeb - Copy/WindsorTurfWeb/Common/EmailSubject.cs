﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.EmailSubject
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

namespace WindsorTurfWeb.Common
{
  public class EmailSubject
  {
    public const string strCommercialApproval = "Your Windsor Turf Account has been activated";
    public const string strWindsorTurfAdmin = "Your Windsor Turf Admin details";
    public const string strCommercialPartnerRegistration = "Thank you for Commercial Partner Registration";
    public const string strAdminCommercialPartnerRegistration = "New Commercial Partner Registration";
    public const string strOrderConfirmation = "Your Windsor Turf order confirmation";
    public const string strAdminOrderConfirmation = "New Windsor Turf order confirmation";
    public const string strOrderTransactionFailed = "Your Windsor Turf order Transaction Failed";
  }
}
