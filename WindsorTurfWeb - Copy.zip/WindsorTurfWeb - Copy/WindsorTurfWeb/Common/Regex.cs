﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.Regex
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

namespace WindsorTurfWeb.Common
{
  public class Regex
  {
    private static string _CompanyName = "[A-Za-z0-9 .&\\-\\'()]*";
    private static string _CompanyNameInformation = "Only A-Z,a-z,0-9,space,dot,&,-,&lsquo;,() are allowed. Length must be 0-100";
    private static string _Title = "[A-Za-z0-9| ,.&\\/ \\-\\'()@$: ]*";
    private static string _TitleInformation = "Length must be 0-50";
    private static string _NewsTitle = "([^\\<\\>]*)";
    private static string _Titles = "[A-Za-z0-9| ,.&\\/ \\-\\'(): ]*";
    private static string _Name = "[A-Za-z0-9.& ']*";
    private static string _NameInformation = "Only A-Z,a-z,0-9,dot,&,&lsquo; are allowed. Length must be 0-25";
    private static string _FirstName = "[A-Za-z.& ']*";
    private static string _LastName = "[A-Za-z.& ']*";
    private static string _Alphabetonly = "[A-Za-z ']*";
    private static string _NameOnly = "[A-Za-z0-9]*";
    private static string _FullName = "[A-Za-z0-9.& ']{0,100}";
    private static string _BadgeNo = "[A-Za-z0-9-.()+ ']{0,30}";
    private static string _BuildingName = "[A-Za-z0-9.& '#]{0,25}";
    private static string _BuildingNameInformation = "Only A-Z,a-z,0-9,dot,&,&lsquo;,# are allowed. Length must be 0-25";
    private static string _JobNo = "[A-Za-z0-9.& '-.]{0,25}";
    private static string _CVVNo = "[0-9]{3,4}";
    private static string _NameOnlyWithLength = "[A-Za-z0-9 .&-']";
    private static string _Address = "[^\\<\\>]{0,500}";
    private static string _Subject = "[^\\<\\>]{0,100}";
    private static string _SubjectInformation = "Length must be 0-100";
    private static string _City = "[^\\<\\>#]{0,100}";
    private static string _ZipCode = "[0-9]*";
    private static string _ZipCodeWithWatermark = "^(ZIPCode)|[0-9]{5}";
    private static string _ZipCodeUS = "[0-9 ]{5,10}";
    private static string _Password = "((?=(.*\\d){1})(?=.*[a-z]{1})(?=.*[A-Z]{1})(?=(.*[@#$%()_&!]){1}).{8,20})";
    private static string _PasswordInformation = "Length must be 7-20 and must be alphanumeric";
    private static string _SearchKeyword = "[^\\<\\>]*";
    private static string _Description = "[^\\<\\>]{0,500}";
    private static string _DescriptionInformation = "Length must be 0-2000";
    private static string _Comments = "Length must be 0-500";
    private static string _Email = "^[A-Za-z0-9!#\\$%&'\\*\\+/=\\?\\^_`\\{\\|}~-]+(\\.[a-z0-9,!#\\$%&'\\*\\+/=\\?\\^_`\\{\\|}~-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9]+)*\\.([A-Za-z]{2,150})$";
    private static string _EmailInformation = "Only A-Z,a-z,0-9,&,-,_,.,!,#,$,%,&lsquo;,*,+,/,=,?,^,`,{,|,},~ are allowed. Length must be 2-150";
    private static string _MultipleEmailWithCommaSeparted = "^((\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*)\\s*[,]{0,1}\\s*)+$";
    private static string _URL = "(^http(s)?://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&amp;=]*)?)*";
    private static string _WEBSITE = "((http(s)?://)?([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&amp;=]*)?)*";
    private static string _URLInformation = "Only a-z,A-Z,0-9,.,-,{,},;,?,&lsquo;,+,&,%,$,[,],*,(,),:,#,=,~,_,-,/^ are allowed. Length must be 0-1000";
    private static string _Image = "Only .jpg, .gif, .png or .bmp file allowed";
    private static string _Flash = "Only swf file allowed";
    private static string _PressImage = "Only .jpg, .gif, .png file allowed";
    private static string _USPhoneMobileNumber = "[0-9-+ .()]{0,30}";
    private static string _AUSPhoneMobileNumber = "[0-9-+ .()]{0,30}";
    private static string _NumbersOnly = "[0-9]";
    private static string _Quantity = "(?!^0*$)[0-9]*";
    private static string _NumbersOnlyWithLength = "[0-9]";
    private static string _MetaKeyword = "[^\\<\\>]*";
    private static string _MetaKeywordInformation = "Length must be 0-500";
    private static string _OnlyNumbers = "[0-9]*";
    private static string _NumbersWithSpaceOnly = "[0-9 ]";
    private static string _NumbersWithDotOnly = "[0-9]*([.][0-9]{1,2})?";
    private static string _NumbersWithDotOnlyWatermark = "^(Min)|^(Max)|([0-9]*([.][0-9]{1,2})?)";
    private static string _AlphanumericWithSpecialChars = "([^\\<\\>])*";
    private static string _AlphanumericwithSpecialCharactersof1000 = "([^\\<\\>]{0,1000})";
    private static string _MaxLenth1000 = "(^[\\s\\S]{0,1000}$)";
    private static string _AlphanumericOnly = "[A-Za-z0-9]";
    private static string _AlphanumericOnlyWithWatermark = "^(Vehicle Identification Number)|[A-Za-z0-9]";
    private static string _AlphanumericWithSpaceOnly = "[A-Za-z0-9 /s]";
    private static string _MaxLenth100 = "(^[\\s\\S]{0,100}$)";
    private static string _UsPhoneNo = "/(0[1-9]|1[012])[-](0[1-9]|[12][0-9]|3[01])[-](19|20)\\d\\d/";
    private static string _AUSPhoneNo = "[0-9 -.+()]{0,25}";
    private static string _UsDate = "^(([1][0-2])|([0]?[1-9]{1}))\\/(([0-2]?\\d{1})|([3][0,1]{1}))\\/(([1]{1}[9]{1}[9]{1}\\d{1})|([2-9]{1}\\d{3}))$";
    private static string _AUSDate = "^(([1][0-2])|([0]?[1-9]{1}))\\/(([0-2]?\\d{1})|([3][0,1]{1}))\\/(([1]{1}[9]{1}[9]{1}\\d{1})|([2-9]{1}\\d{3}))$";
    private static string _ExpireDate = "^(([1][0-2])|([0]?[1-9]{1}))\\/(([0-2]?\\d{1})|([3][0,1]{1}))\\/(([1]{1}[9]{1}[9]{1}\\d{1})|([2-9]{1}\\d{3}))$";
    private static string _NumericNumbers = "^\\d+.?\\d{0,2}$";
    private static string _Percentage = "^(100(\\.00)?)$|^[0-9]{1,2}$|^[0-9]{1,2}\\.[0-9]{1,2}$";
    private static string __Month = "^([1][0-2])|([0]?[1-9]{1})$";
    private static string __Year = "^([1]{1}[9]{1}[9]{1}\\d{1})|([2-9]{1}\\d{3})$";
    private static string _CuponCode = "[A-Za-z0-9.&#']*";
    private static string _AmountPrice = "^\\$?[+]?[\\d]{0,10}(\\.\\d{1,2})?$|^\\$?[+]?[\\d]*";
    private static string _PayRates = "(^\\d{1,4})+(\\.[0-9]{2})?$";
    private static string _ClubClientRates = "(?!^0*$)(?!^0*\\.0*$)^\\d{1,4}(\\.\\d{2})?$";
    private static string _PayRatesPTSesion = "(?!^0*$)(?!^0*\\.0*$)^\\d{1,4}(\\.\\d{2})?$";
    private static string _SupplementPrice = "(^\\d{1,7})+(\\.[0-9]{2})?$";
    private static string _GST = "^[0-9]{1,2}([\\.][0-9]{2})?$";
    private static string _AnythingExceptscriptTag = "[^\\<\\>]*";
    private static string _BIAN = "[A-Za-z0-9 .&\\-\\']{0,100}";
    private static string _AccountNumber = "[0-9]{0,15}";
    private static string _BSBNumber = "[0-9]{0,6}";
    private static string _ABN = "[A-Za-z0-9 ]{11,14}";
    private static string _DateFormatForAllDates = "^(?:(?:31(\\/|-|\\.)(?:0?[13578]|1[02]))\\1|(?:(?:29|30)(\\/|-|\\.)(?:0?[1,3-9]|1[0-2])\\2))(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$|^(?:29(\\/|-|\\.)0?2\\3(?:(?:(?:1[6-9]|[2-9]\\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\\d|2[0-8])(\\/|-|\\.)(?:(?:0?[1-9])|(?:1[0-2]))\\4(?:(?:1[6-9]|[2-9]\\d)?\\d{2})$";
    private static string _NoOfCredits = "[0-9]{0,6}";
    private static string _AdminPTSessionPayRates = "^[0-9]{1,4}([\\.][0-9]{2})?$";
    private static string _UploadImage = "^((.)*)+(.jpeg|.JPEG|.gif|.GIF|.png|.PNG|.JPG|.jpg|.bitmap|.BITMAP|.bmp|.BMP)$";
    private static string _FaxVal = "^\\+?[0-9]{7,}$/";
    private static string _BusinessName = "[A-Za-z0-9| ,.&\\/ \\-\\'(): ]";
    private static string _NumericWithDecimal = "^\\d+\\.?\\d{0,2}$";

    public static string CompanyName
    {
      get => Regex._CompanyName;
      set => Regex._CompanyName = value;
    }

    public static string CompanyNameInformation
    {
      get => Regex._CompanyNameInformation;
      set => Regex._CompanyNameInformation = value;
    }

    public static string Title
    {
      get => Regex._Title;
      set => Regex._Title = value;
    }

    public static string NewsTitle
    {
      get => Regex._NewsTitle;
      set => Regex._NewsTitle = value;
    }

    public static string TitleInformation
    {
      get => Regex._TitleInformation;
      set => Regex._TitleInformation = value;
    }

    public static string Titles
    {
      get => Regex._Titles;
      set => Regex._Titles = value;
    }

    public static string Name
    {
      get => Regex._Name;
      set => Regex._Name = value;
    }

    public static string NameInformation
    {
      get => Regex._NameInformation;
      set => Regex._NameInformation = value;
    }

    public static string FirstName
    {
      get => Regex._FirstName;
      set => Regex._FirstName = value;
    }

    public static string LastName
    {
      get => Regex._LastName;
      set => Regex._LastName = value;
    }

    public static string Alphabetonly
    {
      get => Regex._Alphabetonly;
      set => Regex._Alphabetonly = value;
    }

    public static string NameOnly
    {
      get => Regex._NameOnly;
      set => Regex._NameOnly = value;
    }

    public static string FullName
    {
      get => Regex._FullName;
      set => Regex._FullName = value;
    }

    public static string BadgeNo
    {
      get => Regex._BadgeNo;
      set => Regex._BadgeNo = value;
    }

    public static string BuildingName
    {
      get => Regex._BuildingName;
      set => Regex._BuildingName = value;
    }

    public static string BuildingNameInformation
    {
      get => Regex._BuildingNameInformation;
      set => Regex._BuildingNameInformation = value;
    }

    public static string JobNo
    {
      get => Regex._JobNo;
      set => Regex._JobNo = value;
    }

    public static string CVVNo
    {
      get => Regex._CVVNo;
      set => Regex._CVVNo = value;
    }

    public static string NameOnlyWithLength(int Length) => Regex._NameOnlyWithLength + "{0," + Length.ToString() + "}";

    public static string Address
    {
      get => Regex._Address;
      set => Regex._Address = value;
    }

    public static string Subject
    {
      get => Regex._Subject;
      set => Regex._Subject = value;
    }

    public static string SubjectInformation
    {
      get => Regex._SubjectInformation;
      set => Regex._SubjectInformation = value;
    }

    public static string City
    {
      get => Regex._City;
      set => Regex._City = value;
    }

    public static string ZipCode
    {
      get => Regex._ZipCode;
      set => Regex._ZipCode = value;
    }

    public static string ZipCodeWithWatermark
    {
      get => Regex._ZipCodeWithWatermark;
      set => Regex._ZipCodeWithWatermark = value;
    }

    public static string ZipCodeUS
    {
      get => Regex._ZipCodeUS;
      set => Regex._ZipCodeUS = value;
    }

    public static string Password
    {
      get => Regex._Password;
      set => Regex._Password = value;
    }

    public static string PasswordInformation
    {
      get => Regex._PasswordInformation;
      set => Regex._PasswordInformation = value;
    }

    public static string SearchKeyword
    {
      get => Regex._SearchKeyword;
      set => Regex._SearchKeyword = value;
    }

    public static string Description
    {
      get => Regex._Description;
      set => Regex._Description = value;
    }

    public static string Comments
    {
      get => Regex._Comments;
      set => Regex._Comments = value;
    }

    public static string DescriptionInformation
    {
      get => Regex._DescriptionInformation;
      set => Regex._DescriptionInformation = value;
    }

    public static string Email
    {
      get => Regex._Email;
      set => Regex._Email = value;
    }

    public static string EmailInformation
    {
      get => Regex._EmailInformation;
      set => Regex._EmailInformation = value;
    }

    public static string MultipleEmailWithSemiColonSeparted
    {
      get => Regex._MultipleEmailWithCommaSeparted;
      set => Regex._MultipleEmailWithCommaSeparted = value;
    }

    public static string URL
    {
      get => Regex._URL;
      set => Regex._URL = value;
    }

    public static string WEBSITE
    {
      get => Regex._WEBSITE;
      set => Regex._WEBSITE = value;
    }

    public static string URLInformation
    {
      get => Regex._URLInformation;
      set => Regex._URLInformation = value;
    }

    public static string ImageInformation
    {
      get => Regex._Image;
      set => Regex._Image = value;
    }

    public static string FlashInformation
    {
      get => Regex._Flash;
      set => Regex._Flash = value;
    }

    public static string PressImageInformation
    {
      get => Regex._PressImage;
      set => Regex._PressImage = value;
    }

    public static string USPhoneMobileNumber
    {
      get => Regex._USPhoneMobileNumber;
      set => Regex._USPhoneMobileNumber = value;
    }

    public static string AUSPhoneMobileNumber
    {
      get => Regex._AUSPhoneMobileNumber;
      set => Regex._AUSPhoneMobileNumber = value;
    }

    public static string NumbersOnly
    {
      get => Regex._NumbersOnly;
      set => Regex.NumbersOnly = value;
    }

    public static string Quantity
    {
      get => Regex._Quantity;
      set => Regex._Quantity = value;
    }

    public static string NumbersOnlyWithLength(int Length) => Regex._NumbersOnlyWithLength + "{0," + Length.ToString() + "}";

    public static string NumbersOnlyWithLength(int Length, bool AllowZero)
    {
      if (!AllowZero)
        Regex._NumbersOnlyWithLength = "^[1-9]+[0-9]";
      return Regex._NumbersOnlyWithLength + "{0," + Length.ToString() + "}";
    }

    public static string MetaKeyword
    {
      get => Regex._MetaKeyword;
      set => Regex._MetaKeyword = value;
    }

    public static string MetaKeywordInformation
    {
      get => Regex._MetaKeywordInformation;
      set => Regex._MetaKeywordInformation = value;
    }

    public static string OnlyNumbers
    {
      get => Regex._OnlyNumbers;
      set => Regex.OnlyNumbers = value;
    }

    public static string NumbersWithSpaceOnly
    {
      get => Regex._NumbersWithSpaceOnly;
      set => Regex.NumbersWithSpaceOnly = value;
    }

    public static string NumbersWithDotOnly
    {
      get => Regex._NumbersWithDotOnly;
      set => Regex._NumbersWithDotOnly = value;
    }

    public static string NumbersWithDotOnlyWatermark
    {
      get => Regex._NumbersWithDotOnlyWatermark;
      set => Regex._NumbersWithDotOnlyWatermark = value;
    }

    public static string AlphanumericWithSpecialChars
    {
      get => Regex._AlphanumericWithSpecialChars;
      set => Regex._AlphanumericWithSpecialChars = value;
    }

    public static string AlphanumericWithSpecialCharactersof1000
    {
      get => Regex._AlphanumericwithSpecialCharactersof1000;
      set => Regex._AlphanumericwithSpecialCharactersof1000 = value;
    }

    public static string MaxLenth1000
    {
      get => Regex._MaxLenth1000;
      set => Regex._MaxLenth1000 = value;
    }

    public static string AlphanumericOnly
    {
      get => Regex._AlphanumericOnly;
      set => Regex._AlphanumericOnly = value;
    }

    public static string AlphanumericOnlyWithWatermark
    {
      get => Regex._AlphanumericOnlyWithWatermark;
      set => Regex._AlphanumericOnlyWithWatermark = value;
    }

    public static string AlphanumericWithSpaceOnly
    {
      get => Regex._AlphanumericWithSpaceOnly;
      set => Regex._AlphanumericWithSpaceOnly = value;
    }

    public static string MaxLenth100
    {
      get => Regex._MaxLenth100;
      set => Regex._MaxLenth100 = value;
    }

    public static string UsPhoneNo
    {
      get => Regex._UsPhoneNo;
      set => Regex._UsPhoneNo = value;
    }

    public static string AUSPhoneNo
    {
      get => Regex._AUSPhoneNo;
      set => Regex._AUSPhoneNo = value;
    }

    public static string UsDate
    {
      get => Regex._UsDate;
      set => Regex._UsDate = value;
    }

    public static string AUSDate
    {
      get => Regex._AUSDate;
      set => Regex._AUSDate = value;
    }

    public static string ExpireDate
    {
      get => Regex._ExpireDate;
      set => Regex._ExpireDate = value;
    }

    public static string NumericNumbers
    {
      get => Regex._NumericNumbers;
      set => Regex.NumericNumbers = value;
    }

    public static string Percentage
    {
      get => Regex._Percentage;
      set => Regex._Percentage = value;
    }

    public static string Month
    {
      get => Regex.__Month;
      set => Regex.__Month = value;
    }

    public static string Year
    {
      get => Regex.__Year;
      set => Regex.__Year = value;
    }

    public static string CuponCode
    {
      get => Regex._CuponCode;
      set => Regex._CuponCode = value;
    }

    public static string AmountPrice
    {
      get => Regex._AmountPrice;
      set => Regex._AmountPrice = value;
    }

    public static string PayRates
    {
      get => Regex._PayRates;
      set => Regex._PayRates = value;
    }

    public static string ClubClientRates
    {
      get => Regex._ClubClientRates;
      set => Regex._ClubClientRates = value;
    }

    public static string PayRatesPTSesion
    {
      get => Regex._PayRatesPTSesion;
      set => Regex._PayRatesPTSesion = value;
    }

    public static string SupplementPrice
    {
      get => Regex._SupplementPrice;
      set => Regex._SupplementPrice = value;
    }

    public static string GST
    {
      get => Regex._GST;
      set => Regex._GST = value;
    }

    public static string AnythingExceptscriptTag
    {
      get => Regex._AnythingExceptscriptTag;
      set => Regex._AnythingExceptscriptTag = value;
    }

    public static string BIAN
    {
      get => Regex._BIAN;
      set => Regex._BIAN = value;
    }

    public static string AccountNumber
    {
      get => Regex._AccountNumber;
      set => Regex._AccountNumber = value;
    }

    public static string BSBNumber
    {
      get => Regex._BSBNumber;
      set => Regex._BSBNumber = value;
    }

    public static string ABN
    {
      get => Regex._ABN;
      set => Regex._ABN = value;
    }

    public static string DateFormatForAllDates
    {
      get => Regex._DateFormatForAllDates;
      set => Regex._DateFormatForAllDates = value;
    }

    public static string NoOfCredits
    {
      get => Regex._NoOfCredits;
      set => Regex._NoOfCredits = value;
    }

    public static string AdminPTSessionPayRates
    {
      get => Regex._AdminPTSessionPayRates;
      set => Regex._AdminPTSessionPayRates = value;
    }

    public static string UploadImage
    {
      get => Regex._UploadImage;
      set => Regex._UploadImage = value;
    }

    public static string FaxVal
    {
      get => Regex._FaxVal;
      set => Regex._FaxVal = value;
    }

    public static string BusinessName
    {
      get => Regex._BusinessName;
      set => Regex._BusinessName = value;
    }

    public static string NumericWithDecimal
    {
      get => Regex._NumericWithDecimal;
      set => Regex._NumericWithDecimal = value;
    }
  }
}
