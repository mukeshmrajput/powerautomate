﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.Mail
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.Miscellaneous;
using Entity.Common.CommercialPartner;
using Entity.Common.Miscellaneous;
using Helper;
using Resources;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using System.Web;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb.Common
{
  public class Mail
  {
    public static bool SendMailNotification(
      string FromEmail,
      string FromName,
      string ToEmails,
      string MailBody,
      string Subject,
      string CcEmails,
      string BccEmails,
      bool IsBodyHtml)
    {
      bool boolean = Convert.ToBoolean(ConfigurationManager.AppSettings["IsSendGridLiveAppEmail"]);
      UtilityFunctions.writetext("========================Send Mail Notification 21====================================" + DateTime.Now.ToString());
      if (ToEmails == ConfigurationManager.AppSettings["NotifyEmail"] || ToEmails == ConfigurationManager.AppSettings["ErrorMail"])
      {
        PageBase.AddEmailHistory(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, (Enums.BackEndProcess) 3);
        return WindsorTurfWeb.Common.Mail.SendMail(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, IsBodyHtml);
      }
      if (boolean)
        return WindsorTurfWeb.Common.Mail.SendMailBySendGrid(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, (string) null).Result;
      PageBase.AddEmailHistory(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, (Enums.BackEndProcess) 3);
      return WindsorTurfWeb.Common.Mail.SendMail(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, IsBodyHtml);
    }

    public static bool SendMailNotification(
      string FromEmail,
      string FromName,
      string ToEmails,
      string MailBody,
      string Subject,
      string CcEmails,
      string BccEmails,
      string ContactName,
      string emailAttachement)
    {
      bool boolean = Convert.ToBoolean(ConfigurationManager.AppSettings["IsSendGridLiveAppEmail"]);
      UtilityFunctions.writetext("========================Send Mail Notification with Attchment====================================" + DateTime.Now.ToString());
      if (ToEmails == ConfigurationManager.AppSettings["NotifyEmail"] || ToEmails == ConfigurationManager.AppSettings["ErrorMail"])
      {
        PageBase.AddEmailHistory(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, (Enums.BackEndProcess) 3);
        return WindsorTurfWeb.Common.Mail.SendMailWithAttachment(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, true, emailAttachement);
      }
      if (boolean)
        return WindsorTurfWeb.Common.Mail.SendMailBySendGrid(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, ContactName, emailAttachement).Result;
      PageBase.AddEmailHistory(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, (Enums.BackEndProcess) 3);
      return WindsorTurfWeb.Common.Mail.SendMailWithAttachment(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, true, emailAttachement);
    }

    public static async Task<bool> SendMailBySendGrid(
      string FromEmail,
      string FromName,
      string ToEmails,
      string MailBody,
      string Subject,
      string CcEmails,
      string BccEmails,
      string ContactName)
    {
      bool returnVal = false;
      UtilityFunctions.writetext("========================Sendgrid API Key 67====================================" + DateTime.Now.ToString());
      string apiKey = Convert.ToString(ConfigurationManager.AppSettings["SENDGRID_APIKEY"]);
      UtilityFunctions.writetext(apiKey.ToString());
      UtilityFunctions.writetext("CcEmails = > " + CcEmails.ToString());
      UtilityFunctions.writetext("BccEmails = > " + BccEmails.ToString());
      try
      {
        SendGridClient client = new SendGridClient(apiKey, (string) null, (Dictionary<string, string>) null, (string) null, (string) null);
        SendGridMessage objMail = new SendGridMessage();
        objMail.From = new EmailAddress(FromEmail, ContactName);
        EmailAddress rpto = new EmailAddress(FromEmail, (string) null);
        objMail.ReplyTo = rpto;
        if (!string.IsNullOrEmpty(ToEmails))
        {
          List<EmailAddress> toEmailsList = new List<EmailAddress>();
          string[] strEmails = ToEmails.Split(',');
          string[] strArray = strEmails;
          for (int index = 0; index < strArray.Length; ++index)
          {
            string item = strArray[index];
            EmailAddress objEmail = new EmailAddress()
            {
              Email = item
            };
            toEmailsList.Add(objEmail);
            objEmail = (EmailAddress) null;
            item = (string) null;
          }
          strArray = (string[]) null;
          objMail.AddTos(toEmailsList, 0, (Personalization) null);
          toEmailsList = (List<EmailAddress>) null;
          strEmails = (string[]) null;
        }
        if (!string.IsNullOrEmpty(CcEmails))
        {
          List<EmailAddress> toEmailsList = new List<EmailAddress>();
          string[] strEmails = CcEmails.Split(',');
          string[] strArray = strEmails;
          for (int index = 0; index < strArray.Length; ++index)
          {
            string item = strArray[index];
            EmailAddress objEmail = new EmailAddress()
            {
              Email = item
            };
            toEmailsList.Add(objEmail);
            objEmail = (EmailAddress) null;
            item = (string) null;
          }
          strArray = (string[]) null;
          objMail.AddCcs(toEmailsList, 0, (Personalization) null);
          toEmailsList = (List<EmailAddress>) null;
          strEmails = (string[]) null;
        }
        if (!string.IsNullOrEmpty(BccEmails))
        {
          List<EmailAddress> toEmailsList = new List<EmailAddress>();
          string[] strEmails = BccEmails.Split(',');
          string[] strArray = strEmails;
          for (int index = 0; index < strArray.Length; ++index)
          {
            string item = strArray[index];
            EmailAddress objEmail = new EmailAddress()
            {
              Email = item
            };
            toEmailsList.Add(objEmail);
            objEmail = (EmailAddress) null;
            item = (string) null;
          }
          strArray = (string[]) null;
          objMail.AddBccs(toEmailsList, 0, (Personalization) null);
          toEmailsList = (List<EmailAddress>) null;
          strEmails = (string[]) null;
        }
        objMail.Subject = Subject;
        objMail.HtmlContent = MailBody;
        Response response = await ((BaseClient) client).SendEmailAsync(objMail, new CancellationToken()).ConfigureAwait(false);
        try
        {
          if (response.StatusCode == HttpStatusCode.Accepted || response.StatusCode == HttpStatusCode.OK)
          {
            returnVal = true;
            return returnVal;
          }
          returnVal = false;
          return returnVal;
        }
        catch (Exception ex)
        {
          UtilityFunctions.writetext("========================Sendgrid error 152====================================" + DateTime.Now.ToString());
          UtilityFunctions.writetext(Convert.ToString(ex.Message));
          UtilityFunctions.writetext(Convert.ToString((object) ex.InnerException));
          returnVal = false;
          return returnVal;
        }
      }
      catch (Exception ex)
      {
        UtilityFunctions.writetext("========================Sendgrid error 161====================================" + DateTime.Now.ToString());
        UtilityFunctions.writetext(Convert.ToString(ex.Message));
        UtilityFunctions.writetext(Convert.ToString((object) ex.InnerException));
        returnVal = false;
        return returnVal;
      }
      finally
      {
        PageBase.AddEmailHistory(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, (Enums.BackEndProcess) 3);
      }
    }

    public static async Task<bool> SendMailBySendGrid(
      string FromEmail,
      string FromName,
      string ToEmails,
      string MailBody,
      string Subject,
      string CcEmails,
      string BccEmails,
      string ContactName,
      string emailAttachement)
    {
      bool returnVal = false;
      try
      {
        UtilityFunctions.writetext("========================Sendgrid API Key 180====================================" + DateTime.Now.ToString());
        string apiKey = Convert.ToString(ConfigurationManager.AppSettings["SENDGRID_APIKEY"]);
        UtilityFunctions.writetext(apiKey.ToString());
        UtilityFunctions.writetext("CcEmails = > " + CcEmails.ToString());
        UtilityFunctions.writetext("BccEmails = > " + BccEmails.ToString());
        try
        {
          SendGridClient client = new SendGridClient(apiKey, (string) null, (Dictionary<string, string>) null, (string) null, (string) null);
          SendGridMessage objMail = new SendGridMessage();
          objMail.From = new EmailAddress(FromEmail, ContactName);
          EmailAddress rpto = new EmailAddress(FromEmail, (string) null);
          objMail.ReplyTo = rpto;
          if (!string.IsNullOrEmpty(ToEmails))
          {
            List<EmailAddress> toEmailsList = new List<EmailAddress>();
            string[] strEmails = ToEmails.Split(',');
            string[] strArray = strEmails;
            for (int index = 0; index < strArray.Length; ++index)
            {
              string item = strArray[index];
              EmailAddress objEmail = new EmailAddress()
              {
                Email = item
              };
              toEmailsList.Add(objEmail);
              objEmail = (EmailAddress) null;
              item = (string) null;
            }
            strArray = (string[]) null;
            objMail.AddTos(toEmailsList, 0, (Personalization) null);
            toEmailsList = (List<EmailAddress>) null;
            strEmails = (string[]) null;
          }
          if (string.IsNullOrEmpty(ToEmails))
            return false;
          if (!string.IsNullOrEmpty(CcEmails))
          {
            List<EmailAddress> toEmailsList = new List<EmailAddress>();
            string[] strEmails = CcEmails.Split(',');
            string[] strArray = strEmails;
            for (int index = 0; index < strArray.Length; ++index)
            {
              string item = strArray[index];
              EmailAddress objEmail = new EmailAddress()
              {
                Email = item
              };
              toEmailsList.Add(objEmail);
              objEmail = (EmailAddress) null;
              item = (string) null;
            }
            strArray = (string[]) null;
            objMail.AddCcs(toEmailsList, 0, (Personalization) null);
            toEmailsList = (List<EmailAddress>) null;
            strEmails = (string[]) null;
          }
          if (!string.IsNullOrEmpty(BccEmails))
          {
            List<EmailAddress> toEmailsList = new List<EmailAddress>();
            string[] strEmails = BccEmails.Split(',');
            string[] strArray = strEmails;
            for (int index = 0; index < strArray.Length; ++index)
            {
              string item = strArray[index];
              EmailAddress objEmail = new EmailAddress()
              {
                Email = item
              };
              toEmailsList.Add(objEmail);
              objEmail = (EmailAddress) null;
              item = (string) null;
            }
            strArray = (string[]) null;
            objMail.AddBccs(toEmailsList, 0, (Personalization) null);
            toEmailsList = (List<EmailAddress>) null;
            strEmails = (string[]) null;
          }
          objMail.Subject = Subject;
          objMail.HtmlContent = MailBody;
          byte[] byteData = System.IO.File.ReadAllBytes(emailAttachement.ToString());
          objMail.Attachments = new List<Attachment>()
          {
            new Attachment()
            {
              Content = Convert.ToBase64String(byteData),
              Filename = Path.GetFileName(emailAttachement),
              Type = "attachment",
              Disposition = "attachment"
            }
          };
          Response response = await ((BaseClient) client).SendEmailAsync(objMail, new CancellationToken()).ConfigureAwait(false);
          try
          {
            if (response.StatusCode == HttpStatusCode.Accepted || response.StatusCode == HttpStatusCode.OK)
            {
              returnVal = true;
              return returnVal;
            }
            returnVal = false;
            return returnVal;
          }
          catch (Exception ex)
          {
            UtilityFunctions.writetext("========================Sendgrid error 290====================================" + DateTime.Now.ToString());
            UtilityFunctions.writetext(Convert.ToString(ex.Message));
            UtilityFunctions.writetext(Convert.ToString((object) ex.InnerException));
            returnVal = false;
            return returnVal;
          }
          finally
          {
            PageBase.AddEmailHistory(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, (Enums.BackEndProcess) 3);
          }
        }
        catch (Exception ex)
        {
          UtilityFunctions.writetext("========================Sendgrid error 303====================================" + DateTime.Now.ToString());
          UtilityFunctions.writetext(Convert.ToString(ex.Message));
          UtilityFunctions.writetext(Convert.ToString((object) ex.InnerException));
          returnVal = false;
          return returnVal;
        }
      }
      catch (Exception ex)
      {
        UtilityFunctions.writetext("========================Sendgrid error 312 ====================================" + DateTime.Now.ToString());
        UtilityFunctions.writetext(Convert.ToString(ex.Message));
        UtilityFunctions.writetext(Convert.ToString((object) ex.InnerException));
        returnVal = false;
        return returnVal;
      }
    }

    public static string GetMailFile(string filepath)
    {
      StreamReader streamReader = new StreamReader(filepath);
      string end = streamReader.ReadToEnd();
      streamReader.Close();
      return end;
    }

    public static bool SendMailWithAttachment(
      string FromEmail,
      string FromName,
      string ToEmails,
      string MailBody,
      string Subject,
      string CcEmails,
      string BccEmails,
      bool IsBodyHtml,
      string fieName)
    {
      MailMessage message = new MailMessage();
      message.From = string.IsNullOrEmpty(FromName) ? new MailAddress(FromEmail) : new MailAddress(FromEmail, FromName);
      if (!string.IsNullOrEmpty(ToEmails))
        message.To.Add(ToEmails);
      if (!string.IsNullOrEmpty(CcEmails))
        message.CC.Add(CcEmails);
      if (!string.IsNullOrEmpty(BccEmails))
        message.Bcc.Add(BccEmails);
      message.Subject = Subject;
      message.Body = MailBody;
      message.IsBodyHtml = IsBodyHtml;
      Attachment attachment = new Attachment(fieName, "application/octet-stream");
      ContentDisposition contentDisposition = attachment.ContentDisposition;
      contentDisposition.CreationDate = System.IO.File.GetCreationTime(fieName);
      contentDisposition.ModificationDate = System.IO.File.GetLastWriteTime(fieName);
      contentDisposition.ReadDate = System.IO.File.GetLastAccessTime(fieName);
      contentDisposition.FileName = Path.GetFileName(fieName);
      contentDisposition.Size = new FileInfo(fieName).Length;
      contentDisposition.DispositionType = "attachment";
      message.Attachments.Add(attachment);
      bool flag;
      try
      {
        new SmtpClient() { EnableSsl = false }.Send(message);
        flag = true;
      }
      catch (Exception ex)
      {
        flag = false;
        UtilityFunctions.writetext("========================email 398====================================" + DateTime.Now.ToString());
        UtilityFunctions.writetext(ex.Message.ToString());
        UtilityFunctions.writetext(ex.InnerException.ToString());
        UtilityFunctions.writetext(ex.Source.ToString());
        UtilityFunctions.writetext(ex.StackTrace.ToString());
        UtilityFunctions.writetext("========================email====================================" + DateTime.Now.ToString());
      }
      return flag;
    }

    public static bool SendMailWithAttachment(
      string FromEmail,
      string FromName,
      string ToEmails,
      string MailBody,
      string Subject,
      string CcEmails,
      string BccEmails,
      string fieName)
    {
      return WindsorTurfWeb.Common.Mail.SendMailNotification(FromEmail, FromName, ToEmails, MailBody, Subject, CcEmails, BccEmails, "", fieName);
    }

    public static bool SendMail(
      string FromEmail,
      string FromName,
      string ToEmails,
      string MailBody,
      string Subject,
      string CcEmails,
      string BccEmails,
      bool IsBodyHtml)
    {
      try
      {
        MailMessage message = new MailMessage();
        message.From = string.IsNullOrEmpty(FromName) ? new MailAddress(FromEmail) : new MailAddress(FromEmail, FromName);
        if (!string.IsNullOrEmpty(ToEmails))
          message.To.Add(ToEmails);
        if (!string.IsNullOrEmpty(CcEmails))
          message.CC.Add(CcEmails);
        if (!string.IsNullOrEmpty(BccEmails))
          message.Bcc.Add(BccEmails);
        message.Subject = Subject;
        message.Body = MailBody;
        message.IsBodyHtml = IsBodyHtml;
        try
        {
          new SmtpClient().Send(message);
          return true;
        }
        catch (Exception ex)
        {
          return false;
        }
      }
      catch (Exception ex)
      {
        return false;
      }
    }

    public static bool ForgotPassword(string Email, string UserName, string Password, long UserID)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string newValue = Encryption.DecryptQueryString(Password);
      string MailBody = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/ForgotPassword.html").Replace("{Email}", Email).Replace("{UserName}", UserName).Replace("{Password}", newValue).Replace("{AccountPanelPath}", ConfigurationManager.AppSettings["AccountPanelPath"]).Replace("{ContactNumber}", ConfigurationManager.AppSettings["ContactNumber"]).Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["Livepath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]);
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      return WindsorTurfWeb.Common.Mail.SendMailNotification(siteConfiguration.FromEmail, siteConfiguration.FromName, Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Forgot Password", "", "", true);
    }

    public static bool CommercialPartnerApproval(
      string Email,
      string ContactPersonName,
      long UserID)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string str1 = string.Empty;
      string str2 = string.Empty;
      string str3 = string.Empty;
      string mailFile = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/CommercialPartnerConfirmation.html");
      string newValue = ConfigurationManager.AppSettings["LivePath"] + "SetPassword.aspx?UserID=" + Encryption.EncryptQueryString(Convert.ToInt64(UserID).ToString());
      string MailBody = mailFile.Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["Livepath"]).Replace("{ContactPersonName}", ContactPersonName).Replace("{UserEmail}", Email).Replace("{SetPasswordLink}", newValue).Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails());
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      str1 = siteConfiguration.ToEmail;
      str2 = siteConfiguration.CcEmail;
      str3 = siteConfiguration.BccEmail;
      return WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Your Windsor Turf Account has been activated", "", "", true);
    }

    public static bool CommercialPartnerRegistration(CommercialPartnerBE objBE, string StateName)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string str1 = string.Empty;
      string str2 = string.Empty;
      string str3 = string.Empty;
      string MailBody = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/CommercialPartnerRegistration.html").Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{AccountPanelPath}", ConfigurationManager.AppSettings["AccountPanelPath"]).Replace("{ContactPersonName}", objBE.FirstName + " " + objBE.LastName).Replace("{BusinessName}", objBE.BusinessName).Replace("{ABN}", objBE.CompanyABN).Replace("{FirstName}", objBE.FirstName).Replace("{LastName}", objBE.LastName).Replace("{Email}", objBE.Email).Replace("{Telephone}", objBE.Telephone).Replace("{Fax}", objBE.Fax).Replace("{Mobile}", objBE.Mobile).Replace("{Address1}", objBE.Address1).Replace("{Address2}", objBE.Address2).Replace("{Suburb}", objBE.Suburb).Replace("{State}", StateName).Replace("{PostalCode}", objBE.PostCode).Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails());
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      str1 = siteConfiguration.ToEmail;
      str2 = siteConfiguration.CcEmail;
      str3 = siteConfiguration.BccEmail;
      return WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, objBE.Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Thank you for Commercial Partner Registration", "", "", true);
    }

    public static bool CommercialPartnerRegistrationAdmin(
      CommercialPartnerBE objBE,
      string StateName)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      string empty4 = string.Empty;
      string empty5 = string.Empty;
      string MailBody = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/CommercialPartnerRegistrationAdmin.html").Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{AccountPanelPath}", ConfigurationManager.AppSettings["AccountPanelPath"]).Replace("{ContactPersonName}", "Administrator").Replace("{BusinessName}", objBE.BusinessName).Replace("{ABN}", objBE.CompanyABN).Replace("{FirstName}", objBE.FirstName).Replace("{LastName}", objBE.LastName).Replace("{Email}", objBE.Email).Replace("{Telephone}", objBE.Telephone).Replace("{Fax}", objBE.Fax).Replace("{Mobile}", objBE.Mobile).Replace("{Address1}", objBE.Address1).Replace("{Address2}", objBE.Address2).Replace("{Suburb}", objBE.Suburb).Replace("{State}", StateName).Replace("{PostalCode}", objBE.PostCode).Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails());
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      string toEmail = siteConfiguration.ToEmail;
      string ccEmail = siteConfiguration.CcEmail;
      string bccEmail = siteConfiguration.BccEmail;
      return WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, toEmail, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: New Commercial Partner Registration", ccEmail, bccEmail, true);
    }

    public static bool NewUserCreatedUpdated(
      string Email,
      string ContactPersonName,
      string UserPassword,
      string UserType,
      string processStatus)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string str1 = string.Empty;
      string str2 = string.Empty;
      string str3 = string.Empty;
      string str4 = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/NewUserCreatedUpdated.html").Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{AccountPanelPath}", ConfigurationManager.AppSettings["AccountPanelPath"]).Replace("{ContactPersonName}", ContactPersonName).Replace("{UserEmail}", Email).Replace("{UserPassword}", UserPassword).Replace("{UserType}", UserType);
      string MailBody = (!(processStatus == "0") ? str4.Replace("{ConfirmText}", "Please find your updated Windsor Turf login details as follows:") : str4.Replace("{ConfirmText}", "We can confirm that your Windsor Turf login details are as follows:")).Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails());
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      str1 = siteConfiguration.ToEmail;
      str2 = siteConfiguration.CcEmail;
      str3 = siteConfiguration.BccEmail;
      return WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Your Windsor Turf Admin details", "", "", true);
    }

    public static bool OrderDeliveryDetailEmail(
      string Email,
      string ContactPersonName,
      string OrderID,
      string OrderPrice,
      string ExpectedDeliveryDate,
      string PickupDate,
      string Specialinstructions,
      string lstfilename,
      string PickUpDetail,
      string PaymentOption,
      string PaymentStatus)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string str1 = string.Empty;
      string str2 = string.Empty;
      string str3 = string.Empty;
      if (PaymentOption == "Account")
        PaymentStatus = "Awaiting Payment";
      string MailBody = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/OrderEmailForDelivery.html").Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{ContactPersonName}", ContactPersonName).Replace("{OrderID}", OrderID).Replace("{PickUpDetail}", PickUpDetail).Replace("{PaymentOption}", PaymentOption).Replace("{PaymentStatus}", PaymentStatus).Replace("{OrderA$}", OrderPrice).Replace("{OrderStatus}", "Order Delivery Pending").Replace("{ExpectedDeliveryDate}", ExpectedDeliveryDate).Replace("{Specialinstructions}", !string.IsNullOrEmpty(Specialinstructions) ? Specialinstructions : "N/A").Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails()).Replace("{ImageRolloverText}", Messages.ImageRolloverText);
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      str1 = siteConfiguration.ToEmail;
      str2 = siteConfiguration.CcEmail;
      str3 = siteConfiguration.BccEmail;
      return WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Your Windsor Turf order confirmation", "", "", "", lstfilename);
    }

    public static bool OrderPickUpDetailEmail(
      string Email,
      string ContactPersonName,
      string OrderID,
      string OrderPrice,
      string ExpectedDeliveryDate,
      string PickupDate,
      string Specialinstructions,
      string lstfilename,
      string PickUpDetail,
      string PaymentOption,
      string PaymentStatus)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string str1 = string.Empty;
      string str2 = string.Empty;
      string str3 = string.Empty;
      if (PaymentOption == "Account")
        PaymentStatus = "Awaiting Payment";
      string MailBody = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/OrderEmailForPickUp.html").Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{ContactPersonName}", ContactPersonName).Replace("{OrderID}", OrderID).Replace("{PickUpDetail}", PickUpDetail).Replace("{PaymentOption}", PaymentOption).Replace("{PaymentStatus}", PaymentStatus).Replace("{OrderA$}", OrderPrice).Replace("{OrderStatus}", "Order PickUp Pending").Replace("{PickupDate}", PickupDate).Replace("{Specialinstructions}", !string.IsNullOrEmpty(Specialinstructions) ? Specialinstructions : "N/A").Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails()).Replace("{ImageRolloverText}", Messages.ImageRolloverText);
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      str1 = siteConfiguration.ToEmail;
      str2 = siteConfiguration.CcEmail;
      str3 = siteConfiguration.BccEmail;
      return WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Your Windsor Turf order confirmation", "", "", "", lstfilename);
    }

    public static bool OrderEmailForFailedPayment(
      string Email,
      string ContactPersonName,
      string OrderID,
      string OrderPrice,
      string ExpectedDeliveryDate,
      string PickupDate,
      string Specialinstructions,
      string PickUpDetail)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string str1 = string.Empty;
      string str2 = string.Empty;
      string str3 = string.Empty;
      string MailBody = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/OrderEmailForFailedPayment.html").Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{ContactPersonName}", ContactPersonName).Replace("{OrderID}", OrderID).Replace("{PickUpDetail}", PickUpDetail).Replace("{PaymentOption}", "Still needs to be selected and paid for.").Replace("{PaymentStatus}", "Failed").Replace("{OrderA$}", OrderPrice).Replace("{ExpectedDeliveryDate}", ExpectedDeliveryDate).Replace("{PickupDate}", PickupDate).Replace("{Specialinstructions}", !string.IsNullOrEmpty(Specialinstructions) ? Specialinstructions : "N/A").Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails());
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      str1 = siteConfiguration.ToEmail;
      str2 = siteConfiguration.CcEmail;
      str3 = siteConfiguration.BccEmail;
      return WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Your Windsor Turf order Transaction Failed", "", "", true);
    }

    public static bool OrderEmailForAdminUser(
      string Email,
      string ContactPersonName,
      string OrderID,
      string OrderPrice,
      string ExpectedDeliveryDate,
      string PickupDate,
      string Specialinstructions,
      string PickUpDetail,
      string PaymentOption,
      string PaymentStatus,
      string ClientDetail,
      string ClientType,
      string PurchaseOrderInformation,
      string ClientOrderText)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string empty3 = string.Empty;
      string empty4 = string.Empty;
      string empty5 = string.Empty;
      string str = string.Empty;
      string newValue = string.Empty;
      if (PaymentOption == "Account")
        PaymentStatus = "Awaiting Payment";
      switch (PickUpDetail)
      {
        case "PickUp":
          str = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/OrderEmailForPickUpToAdmin.html");
          newValue = "Order PickUp Pending";
          break;
        case "Delivery":
          str = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/OrderEmailForDeliveryToAdmin.html");
          newValue = "Order Delivery Pending";
          break;
      }
      string MailBody = str.Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{ContactPersonName}", "Administrator").Replace("{OrderID}", OrderID).Replace("{PickUpDetail}", PickUpDetail).Replace("{PaymentOption}", PaymentOption).Replace("{PaymentStatus}", PaymentStatus).Replace("{OrderA$}", OrderPrice).Replace("{OrderStatus}", newValue).Replace("{ExpectedDeliveryDate}", ExpectedDeliveryDate).Replace("{PickupDate}", PickupDate).Replace("{Specialinstructions}", !string.IsNullOrEmpty(Specialinstructions) ? Specialinstructions : "N/A").Replace("{ClientDetail}", ClientDetail).Replace("{ClientType}", ClientType).Replace("{PurchaseOrderInformation}", PurchaseOrderInformation).Replace("{ClientOrderText}", ClientOrderText).Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails());
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      string toEmail = siteConfiguration.ToEmail;
      string ccEmail = siteConfiguration.CcEmail;
      string bccEmail = siteConfiguration.BccEmail;
      bool flag = WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, toEmail, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: New Windsor Turf order confirmation", ccEmail, bccEmail, true);
      if (!string.IsNullOrEmpty(PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3))) && PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 3)) != "1")
        WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, PageBase.ReadCookie(Convert.ToInt32((object) (Enums.CookiesIndex) 1)), MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: New Windsor Turf order confirmation", ccEmail, bccEmail, true);
      return flag;
    }

    public static bool ConfirmFinalOrderEmail(
      string Email,
      string ContactPersonName,
      string OrderID,
      string OrderPrice,
      string ExpectedDeliveryDate,
      string PickupDate,
      string Specialinstructions,
      string PickUpDetail,
      string PaymentOption)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string str1 = string.Empty;
      string empty3 = string.Empty;
      string empty4 = string.Empty;
      string mailFile = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/ConfirmFinalOrderEmail.html");
      string str2 = string.Empty;
      switch (PickUpDetail)
      {
        case "PickUp":
          str2 = "Order PickUp Pending";
          break;
        case "Delivery":
          str2 = "Order Delivery Pending";
          break;
      }
      string MailBody = mailFile.Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{ContactPersonName}", ContactPersonName).Replace("{OrderID}", OrderID).Replace("{PickUpDetail}", PickUpDetail).Replace("{PaymentOption}", PaymentOption).Replace("{PaymentStatus}", "Paid").Replace("{OrderA$}", OrderPrice).Replace("{OrderStatus}", PickUpDetail == "PickUp" ? "Order PickUp Completed" : "Order Delivery Completed").Replace("{ExpectedDeliveryDate}", ExpectedDeliveryDate.ToString()).Replace("{PickupDate}", PickupDate.ToString()).Replace("{Specialinstructions}", !string.IsNullOrEmpty(Specialinstructions) ? Specialinstructions : "N/A").Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails()).Replace("{ImageRolloverText}", Messages.ImageRolloverText);
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      str1 = siteConfiguration.ToEmail;
      string ccEmail = siteConfiguration.CcEmail;
      string bccEmail = siteConfiguration.BccEmail;
      return WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Your Windsor Turf order confirmation", ccEmail, bccEmail, true);
    }

    public static bool AcceptedByAdmin(
      string Email,
      string ContactPersonName,
      string OrderID,
      string OrderPrice,
      string ExpectedDeliveryDate,
      string PickupDate,
      string Specialinstructions,
      string PickUpDetail,
      string PaymentOption)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string str = string.Empty;
      string empty3 = string.Empty;
      string empty4 = string.Empty;
      string mailFile = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/ConfirmFinalOrderEmail.html");
      string newValue = string.Empty;
      switch (PickUpDetail)
      {
        case "PickUp":
          newValue = "Order PickUp Pending";
          break;
        case "Delivery":
          newValue = "Order Delivery Pending";
          break;
      }
      string MailBody = mailFile.Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{ContactPersonName}", ContactPersonName).Replace("{OrderID}", OrderID).Replace("{PickUpDetail}", PickUpDetail).Replace("{PaymentOption}", PaymentOption).Replace("{PaymentStatus}", "Paid").Replace("{OrderA$}", OrderPrice).Replace("{OrderStatus}", newValue).Replace("{ExpectedDeliveryDate}", ExpectedDeliveryDate.ToString()).Replace("{PickupDate}", PickupDate.ToString()).Replace("{Specialinstructions}", !string.IsNullOrEmpty(Specialinstructions) ? Specialinstructions : "N/A").Replace("{WindsorTurfContactText}", string.Format(Messages.WindsorTurfContactTextForEmail, (object) ConfigurationManager.AppSettings["ContactNumber"])).Replace("{WindsorTrufAddressText}", UtilityFunctions.GetWindsorTurfAddressForEmails()).Replace("{ImageRolloverText}", Messages.ImageRolloverText);
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      string fromEmail = siteConfiguration.FromEmail;
      string fromName = siteConfiguration.FromName;
      str = siteConfiguration.ToEmail;
      string ccEmail = siteConfiguration.CcEmail;
      string bccEmail = siteConfiguration.BccEmail;
      return WindsorTurfWeb.Common.Mail.SendMailNotification(fromEmail, fromName, Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Your Windsor Turf order confirmation", ccEmail, bccEmail, true);
    }

    public static bool ForgotPasswordForCommercialUser(
      string Email,
      long LoginMasterID,
      string Name)
    {
      string empty1 = string.Empty;
      string empty2 = string.Empty;
      string mailFile = WindsorTurfWeb.Common.Mail.GetMailFile(HttpContext.Current.Server.MapPath("~") + "EmailTemplates/ForgotPasswordForCommercialUser.html");
      string newValue = ConfigurationManager.AppSettings["LivePath"] + "ReSetPassword.aspx?LoginMasterID=" + Encryption.EncryptQueryString(Convert.ToInt64(LoginMasterID).ToString());
      string MailBody = mailFile.Replace("{ProjectName}", ConfigurationManager.AppSettings["ProjectName"]).Replace("{Name}", Name).Replace("{Email}", Email).Replace("{SetPasswordPath}", newValue).Replace("{ContactNumber}", ConfigurationManager.AppSettings["ContactNumber"]).Replace("{LivepathImage}", ConfigurationManager.AppSettings["LivePath"] + ConfigurationManager.AppSettings["EmailTemplateImageFolderName"]).Replace("{Livepath}", ConfigurationManager.AppSettings["LivePath"]);
      SiteConfiguration siteConfiguration = SiteConfigurationMgmt.GetSiteConfiguration();
      return WindsorTurfWeb.Common.Mail.SendMailNotification(siteConfiguration.FromEmail, siteConfiguration.FromName, Email, MailBody, ConfigurationManager.AppSettings["ProjectName"] + " :: Forgot Password", "", "", true);
    }
  }
}
