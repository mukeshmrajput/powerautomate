﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.Common.PageName
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

namespace WindsorTurfWeb.Common
{
  public class PageName
  {
    public const string strAddPage = "Page Management";
    public const string strAddPickUpDetail = "PickUp Detail";
    public const string strAddUser = "Admin User";
    public const string strAddHearAboutUs = "Hear About Us";
    public const string strAddNews = "News";
    public const string strAddBanner = "Banner";
    public const string strAddTurfRange = "Turf Range";
    public const string strAddTurfZone = "Turf Zone";
    public const string strAddTurfPrice = "Turf Price";
    public const string strAddServiceRegion = "Service Region";
    public static string strAddServiceFees = "Delivery Fee";
    public static string strAddServiceNote = "Delivery Note";
    public static string strAddQuantityZone = "Quantity Zone";
    public static string strAddQuantityRange = "Quantity Range";
    public static string strAddQuantityPrice = "Quantity Price";
    public static string strAddDeliveryRegion = "Delivery Region";
    public static string strAddDeliveryPrice = "Delivery Price";
    public static string strAddTurfProduct = "Turf Product";
    public static string strAddNonTurfProduct = "Non-Turf Product";
    public static string strAddTurfStockAvailable = "Turf Stock Available";
    public static string strAddNonTurfStockAvailable = "Non-Turf Stock Available";
    public static string strAddPaymentType = "Payment Type";
    public static string strAddAcount = "Account Detail";
    public static string strAddChangePassword = "Change Password";
    public static string strWelcome = "Dashboard";
    public static string strSiteConfiguration = "Site Configuration";
    public static string strSelectedPress = "Selected Press";
    public static string strTestimonials = "Testimonials";
    public static string strOurLocation = "Our Location";
    public static string strSetPassword = "Set Password";
    public static string strReSetPassword = "Reset Password";
    public static string strShopPage = "Shop";
    public static string strOrderPage = "Order";
    public static string strThankYou = "Thank You";
    public static string strFailedTransaction = "Transaction Failed";
    public static string strPageNotFound = "Page Not Found";
    public static string strPaymentEditor = "Payment Editor";
    public static string strTurfPricingandServiceFees = "Turf Pricing and Service Fees";
    public static string strNonTurfProductpricingandDeliveryfees = "Non Turf Product pricing and Delivery fees";
    public static string strAddPlaceAnOrder = "Place an Order";
    public static string strResidential = "Residential Order";
    public static string strCausalCommercial = "Casual Commercial Order";
    public static string strCommercialPartner = "Commercial Registration";
    public static string strCheckout = "Checkout";
    public static string strRetailPurchase = "Retail Purchase Order";
    public static string strCommonSearch = "Search";
    public static string strComfirmPayment = "Confirm Payment";
    public static string strBtnShopName = "Return to store";
    public static string strMenuOrderHistory = "Order History";
    public static string strMenuUpdateProfile = "Update Profile";
    public static string strMenuChangePassowrd = "Change Password";
    public static string strPostCodeRange = "PostCode Range";
    public static string strCancel = "Cancel Payment";
    public static string strAddNonTurfProductName = "Non-Turf Product Name";
    public static string strAddTurfClassification = "Turf Classification";
    public static string strAddNonTurfClassification = "Non-Turf Classification";
    public static string strTurfSelection = "Turf Selection";
    public static string strTurfCare = "Turf Care";
    public static string strCommercialPartners = "Commercial Partner Order";
    public static string strMenuQuoteHistory = "Quote History";
    public static string strTurfTypeName = "Turf Selection";
    public static string strNonTurfTypeName = "Turf Care";
    public static string strCalculateTurfArea = "Calculate Turf Area";
    public static string strQuoteDetail = "Quote Detail";
    public static string strQuoteQuote = "Get Quote";
    public static string strCausalCommercialDetail = "Casual Commercial Detail";
    public static string strCommercialPartnerDetail = "Commercial Partner Detail";
    public static string strTurfDescription = "Turf Description";
    public static string strBtnDashboardName = "Return to Dashboard";
    public static string strUserTypeNameR = "Residential";
    public static string strUserTypeNameCC = "Casual Commercial";
    public static string strUserTypeNameCP = "Commercial Partner";
    public const string strAddGallery = "Gallery";
    public const string strAddTestimonials = "Testimonials";
    public const string strViewPage = "Page Management";
    public const string strViewPickUpDetail = "View PickUp Detail(s)";
    public const string strViewUser = "View Admin User(s)";
    public const string strViewCommercialPartnerUser = "View Commercial Partner(s)";
    public const string strViewHearAboutUs = "View Hear About Us";
    public const string strViewNews = "View News";
    public const string strViewBanner = "View Banner";
    public const string strViewNewsletter = "View Newsletter(s)";
    public const string strAddNewsletter = "Add Newsletter";
    public const string strViewTurfRange = "View Turf Range(s)";
    public const string strViewTurfZone = "View Turf Zone(s)";
    public const string strViewTurfPrice = "View Turf Price(s)";
    public const string strViewServiceRegion = "View Service Region(s)";
    public static string strViewServiceFees = "View Delivery Fee(s)";
    public static string strViewQuantityZone = "View Quantity Zone(s)";
    public static string strViewQuantityRange = "View Quantity Range(s)";
    public static string strViewQuantityPrice = "View Quantity Price(s)";
    public static string strViewDeliveryRegion = "View Delivery Region(s)";
    public static string strViewDeliveryPrice = "View Delivery Price(s)";
    public static string strViewTurfClassification = "View Turf Classification(s)";
    public static string strViewNonTurfClassification = "View Non-Turf Classification(s)";
    public static string strViewTurfProduct = "View Turf Product(s)";
    public static string strViewNonTurfProduct = "View Non-Turf Product(s)";
    public static string strViewTurfStockAvailable = "View Turf Stock Available(s)";
    public static string strViewNonTurfStockAvailable = "View Non-Turf Stock Available(s)";
    public static string strViewPaymentType = "View Payment Type(s)";
    public static string strViewAccount = "Commercial Partner Account Detail(s)";
    public static string strCommercialPartnerApproval = "Commercial Registration Approval";
    public static string strApprovalStatus = "Commercial Registration Approval Status";
    public const string strViewCausalCommercialPurchaseDetail = "View Casual Commercial Purchase eDetail(s)";
    public const string strViewOrderProcessingPaymentDetail = "View Order Processing Payment Detail(s)";
    public const string strViewQuotesForCommercialPartner = "View Quotes For Commercial Partner(s)";
    public const string strViewGallery = "View Gallery";
    public const string strViewTestimonials = "View Testimonials";
  }
}
