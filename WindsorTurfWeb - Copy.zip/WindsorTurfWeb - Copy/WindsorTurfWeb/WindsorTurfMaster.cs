﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.WindsorTurfMaster
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using WindsorTurfWeb.FrontUserControl;

namespace WindsorTurfWeb
{
  public class WindsorTurfMaster : MasterPage
  {
    protected ContentPlaceHolder head;
    protected HtmlForm form1;
    protected ScriptManager Scrpt1;
    protected Image imgHeader;
    protected HeaderTopMenu HeaderTopMenu1;
    protected HtmlGenericControl DivCommon;
    protected Literal ltrPageName;
    protected Literal ltrMainPageName;
    protected HtmlGenericControl DivBreadCum;
    protected Repeater rptBreadCum;
    protected Literal LtePageMainName;
    protected ContentPlaceHolder ContentPlaceHolder1;
    protected FooterPart FooterPart1;
    protected GoogleAnalytics GoogleAnalytics1;
    protected LoadingControl Loading1;

    protected void Page_Load(object sender, EventArgs e)
    {
      if (this.Request.Url.ToString().ToLower().Contains("testimonials"))
        ((WebControl) this.FindControl("imgHeader")).Attributes.Add("class", "thumb_banner");
      else
        ((WebControl) this.FindControl("imgHeader")).Attributes.Add("class", "");
    }

    protected void rptBreadCum_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
      if (e.Item.ItemType != ListItemType.Item && e.Item.ItemType != ListItemType.AlternatingItem)
        return;
      Literal control1 = (Literal) e.Item.FindControl("LtrBradCum");
      HtmlAnchor control2 = (HtmlAnchor) e.Item.FindControl("aLinkURL");
      long int64 = Convert.ToInt64(DataBinder.Eval(e.Item.DataItem, "TotalCount"));
      if ((long) e.Item.ItemIndex == int64 - 1L)
      {
        if (control1 != null)
          control1.Visible = true;
        if (control2 != null)
          control2.Visible = false;
      }
      else
      {
        if (control1 != null)
          control1.Visible = false;
        if (control2 != null)
          control2.Visible = true;
      }
    }
  }
}
