﻿// Decompiled with JetBrains decompiler
// Type: WindsorTurfWeb.GetTestimonialsDetails
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using BLL.PageManagement;
using BLL.Testimonials;
using Entity.Response.PageManagement;
using System;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using WindsorTurfWeb.Common;
using WindsorTurfWeb.FrontUserControl;
using WindsorTurfWeb.Security;

namespace WindsorTurfWeb
{
  public class GetTestimonialsDetails : Page
  {
    protected Literal ltrTestimonialsTitle;
    protected HighslideControlFront HighslideControlFront1;
    protected Literal ltrTitle;
    protected Literal ltrDesCription;

    protected void Page_Load(object sender, EventArgs e)
    {
      this.Page.Form.Action = this.Request.RawUrl;
      if (this.IsPostBack)
        return;
      this.GetTestimonialsCriteria();
    }

    protected void GetTestimonialsCriteria()
    {
      string[] strArray = this.Request.RawUrl.ToString().Split('/');
      string str = string.Empty;
      if (!string.IsNullOrEmpty(strArray[2].ToString()))
        str = Encryption.DecryptQueryString(strArray[2].ToString());
      Entity.Common.Testimonials.Testimonials testimonialsDetailsById = TestimonialsMgmt.GetTestimonialsDetailsByID((long) Convert.ToInt32(str.ToString()));
      if (testimonialsDetailsById == null)
        return;
      if (testimonialsDetailsById.IsActive)
      {
        UtilityFunctions.SetDefaultCommonHeader(this.Page, "", testimonialsDetailsById.Title);
        this.ltrTestimonialsTitle.Text = testimonialsDetailsById.Title + " | " + PageName.strTestimonials;
        this.ltrTitle.Text = testimonialsDetailsById.Title.ToString();
        this.ltrDesCription.Text = testimonialsDetailsById.Description;
        GetConttentPageDataBE crumbByUrlKeyWord = PageManagementMgmt.GetBreadCrumbByURLKeyWord("testimonials");
        if (crumbByUrlKeyWord != null && crumbByUrlKeyWord.PageManagementID > 0L)
          UtilityFunctions.SetDefaultCommonHeader(this.Page, crumbByUrlKeyWord.HeaderImage, crumbByUrlKeyWord.NameOnMenu);
      }
      else
        this.Response.Redirect(WebConfigurationManager.AppSettings["LivePath"].ToString() + "testimonials");
    }
  }
}
