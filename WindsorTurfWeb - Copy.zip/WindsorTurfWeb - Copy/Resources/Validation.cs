﻿// Decompiled with JetBrains decompiler
// Type: Resources.Validation
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Resources
{
  [GeneratedCode("Microsoft.VisualStudio.Web.Application.StronglyTypedResourceProxyBuilder", "15.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Validation
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Validation()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (Validation.resourceMan == null)
          Validation.resourceMan = new ResourceManager("Resources.Validation", Assembly.Load("App_GlobalResources"));
        return Validation.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => Validation.resourceCulture;
      set => Validation.resourceCulture = value;
    }

    internal static string Invalid => Validation.ResourceManager.GetString(nameof (Invalid), Validation.resourceCulture);

    internal static string Invalid1 => Validation.ResourceManager.GetString(nameof (Invalid1), Validation.resourceCulture);

    internal static string InvalidEmailPassword => Validation.ResourceManager.GetString(nameof (InvalidEmailPassword), Validation.resourceCulture);

    internal static string NewPasswordConfirmPasswordSame => Validation.ResourceManager.GetString(nameof (NewPasswordConfirmPasswordSame), Validation.resourceCulture);

    internal static string PriceGreaterThanZero => Validation.ResourceManager.GetString(nameof (PriceGreaterThanZero), Validation.resourceCulture);

    internal static string Required => Validation.ResourceManager.GetString(nameof (Required), Validation.resourceCulture);

    internal static string RequiredFieldDate => Validation.ResourceManager.GetString(nameof (RequiredFieldDate), Validation.resourceCulture);

    internal static string RequiredFieldDropbox => Validation.ResourceManager.GetString(nameof (RequiredFieldDropbox), Validation.resourceCulture);

    internal static string RequiredFieldImage => Validation.ResourceManager.GetString(nameof (RequiredFieldImage), Validation.resourceCulture);

    internal static string RequiredFieldTextbox => Validation.ResourceManager.GetString(nameof (RequiredFieldTextbox), Validation.resourceCulture);

    internal static string ValidateBirthDate => Validation.ResourceManager.GetString(nameof (ValidateBirthDate), Validation.resourceCulture);

    internal static string ValidateBirthDateYear => Validation.ResourceManager.GetString(nameof (ValidateBirthDateYear), Validation.resourceCulture);

    internal static string ValidateClubsListSelection => Validation.ResourceManager.GetString(nameof (ValidateClubsListSelection), Validation.resourceCulture);

    internal static string ValidateFromToDate => Validation.ResourceManager.GetString(nameof (ValidateFromToDate), Validation.resourceCulture);

    internal static string ValidateJoiningDateYear => Validation.ResourceManager.GetString(nameof (ValidateJoiningDateYear), Validation.resourceCulture);
  }
}
