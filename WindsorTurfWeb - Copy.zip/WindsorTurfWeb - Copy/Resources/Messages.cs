﻿// Decompiled with JetBrains decompiler
// Type: Resources.Messages
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Resources
{
  [GeneratedCode("Microsoft.VisualStudio.Web.Application.StronglyTypedResourceProxyBuilder", "15.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class Messages
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal Messages()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (Messages.resourceMan == null)
          Messages.resourceMan = new ResourceManager("Resources.Messages", Assembly.Load("App_GlobalResources"));
        return Messages.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => Messages.resourceCulture;
      set => Messages.resourceCulture = value;
    }

    internal static string AddSuccess => Messages.ResourceManager.GetString(nameof (AddSuccess), Messages.resourceCulture);

    internal static string AlreadyExists => Messages.ResourceManager.GetString(nameof (AlreadyExists), Messages.resourceCulture);

    internal static string AlreadyExistsEmail => Messages.ResourceManager.GetString(nameof (AlreadyExistsEmail), Messages.resourceCulture);

    internal static string AlreadySelectedTurf => Messages.ResourceManager.GetString(nameof (AlreadySelectedTurf), Messages.resourceCulture);

    internal static string AlreadySetPassowrd => Messages.ResourceManager.GetString(nameof (AlreadySetPassowrd), Messages.resourceCulture);

    internal static string AlreadySubscribeNewsletter => Messages.ResourceManager.GetString(nameof (AlreadySubscribeNewsletter), Messages.resourceCulture);

    internal static string AreaPriceValidation => Messages.ResourceManager.GetString(nameof (AreaPriceValidation), Messages.resourceCulture);

    internal static string AreaSizeValidation => Messages.ResourceManager.GetString(nameof (AreaSizeValidation), Messages.resourceCulture);

    internal static string AstrickNote => Messages.ResourceManager.GetString(nameof (AstrickNote), Messages.resourceCulture);

    internal static string AstrickNoteis => Messages.ResourceManager.GetString(nameof (AstrickNoteis), Messages.resourceCulture);

    internal static string BannerImage => Messages.ResourceManager.GetString(nameof (BannerImage), Messages.resourceCulture);

    internal static string BannerImageTypeOrImageSizeInvalidWithSize => Messages.ResourceManager.GetString(nameof (BannerImageTypeOrImageSizeInvalidWithSize), Messages.resourceCulture);

    internal static string BannerImageUpldDimension => Messages.ResourceManager.GetString(nameof (BannerImageUpldDimension), Messages.resourceCulture);

    internal static string CalendarValPastDateForInvoiceCycle => Messages.ResourceManager.GetString(nameof (CalendarValPastDateForInvoiceCycle), Messages.resourceCulture);

    internal static string CalendarValPastDates => Messages.ResourceManager.GetString(nameof (CalendarValPastDates), Messages.resourceCulture);

    internal static string ChangePasswordSuccess => Messages.ResourceManager.GetString(nameof (ChangePasswordSuccess), Messages.resourceCulture);

    internal static string ChangeSuccess => Messages.ResourceManager.GetString(nameof (ChangeSuccess), Messages.resourceCulture);

    internal static string ClassificationNotFound => Messages.ResourceManager.GetString(nameof (ClassificationNotFound), Messages.resourceCulture);

    internal static string ConfirmDeleteMultipleItem => Messages.ResourceManager.GetString(nameof (ConfirmDeleteMultipleItem), Messages.resourceCulture);

    internal static string ConfirmDeleteSingleItem => Messages.ResourceManager.GetString(nameof (ConfirmDeleteSingleItem), Messages.resourceCulture);

    internal static string ConfirmDeleteTransferedSingleItem => Messages.ResourceManager.GetString(nameof (ConfirmDeleteTransferedSingleItem), Messages.resourceCulture);

    internal static string CurrentPasswordDoesNotMatch => Messages.ResourceManager.GetString(nameof (CurrentPasswordDoesNotMatch), Messages.resourceCulture);

    internal static string CurrentPasswordNotMatch => Messages.ResourceManager.GetString(nameof (CurrentPasswordNotMatch), Messages.resourceCulture);

    internal static string DefaultText => Messages.ResourceManager.GetString(nameof (DefaultText), Messages.resourceCulture);

    internal static string DeleteSuccessMultipleItem => Messages.ResourceManager.GetString(nameof (DeleteSuccessMultipleItem), Messages.resourceCulture);

    internal static string DeleteSuccessSingleItem => Messages.ResourceManager.GetString(nameof (DeleteSuccessSingleItem), Messages.resourceCulture);

    internal static string Email => Messages.ResourceManager.GetString(nameof (Email), Messages.resourceCulture);

    internal static string EmailDoesNotExists => Messages.ResourceManager.GetString(nameof (EmailDoesNotExists), Messages.resourceCulture);

    internal static string EmailNotExit => Messages.ResourceManager.GetString(nameof (EmailNotExit), Messages.resourceCulture);

    internal static string EmailSentSuccess => Messages.ResourceManager.GetString(nameof (EmailSentSuccess), Messages.resourceCulture);

    internal static string ForgotPasswordsent => Messages.ResourceManager.GetString(nameof (ForgotPasswordsent), Messages.resourceCulture);

    internal static string ForgotThankyou => Messages.ResourceManager.GetString(nameof (ForgotThankyou), Messages.resourceCulture);

    internal static string GalleryImage => Messages.ResourceManager.GetString(nameof (GalleryImage), Messages.resourceCulture);

    internal static string GalleryImageUpladed => Messages.ResourceManager.GetString(nameof (GalleryImageUpladed), Messages.resourceCulture);

    internal static string GoogleURL => Messages.ResourceManager.GetString(nameof (GoogleURL), Messages.resourceCulture);

    internal static string HeaderImage => Messages.ResourceManager.GetString(nameof (HeaderImage), Messages.resourceCulture);

    internal static string HomePageImage => Messages.ResourceManager.GetString(nameof (HomePageImage), Messages.resourceCulture);

    internal static string HomePageImageUpldDimensionHeader => Messages.ResourceManager.GetString(nameof (HomePageImageUpldDimensionHeader), Messages.resourceCulture);

    internal static string Imagemsg => Messages.ResourceManager.GetString(nameof (Imagemsg), Messages.resourceCulture);

    internal static string ImageRolloverText => Messages.ResourceManager.GetString(nameof (ImageRolloverText), Messages.resourceCulture);

    internal static string ImageTypeOrImageSizeInvalid => Messages.ResourceManager.GetString(nameof (ImageTypeOrImageSizeInvalid), Messages.resourceCulture);

    internal static string ImageTypeOrImageSizeInvalidWithSize => Messages.ResourceManager.GetString(nameof (ImageTypeOrImageSizeInvalidWithSize), Messages.resourceCulture);

    internal static string ImageUpldDimension => Messages.ResourceManager.GetString(nameof (ImageUpldDimension), Messages.resourceCulture);

    internal static string ImageUpldDimensionHeader => Messages.ResourceManager.GetString(nameof (ImageUpldDimensionHeader), Messages.resourceCulture);

    internal static string InactiveMsg => Messages.ResourceManager.GetString(nameof (InactiveMsg), Messages.resourceCulture);

    internal static string Invalid => Messages.ResourceManager.GetString(nameof (Invalid), Messages.resourceCulture);

    internal static string InvalidFile => Messages.ResourceManager.GetString(nameof (InvalidFile), Messages.resourceCulture);

    internal static string InvalidRangePurchase => Messages.ResourceManager.GetString(nameof (InvalidRangePurchase), Messages.resourceCulture);

    internal static string LegendsStr => Messages.ResourceManager.GetString(nameof (LegendsStr), Messages.resourceCulture);

    internal static string MaxBannerAllowed => Messages.ResourceManager.GetString(nameof (MaxBannerAllowed), Messages.resourceCulture);

    internal static string NewPassAndConfirmPassNotMatch => Messages.ResourceManager.GetString(nameof (NewPassAndConfirmPassNotMatch), Messages.resourceCulture);

    internal static string NewPasswordAndConfirmPasswordNotMatch => Messages.ResourceManager.GetString(nameof (NewPasswordAndConfirmPasswordNotMatch), Messages.resourceCulture);

    internal static string News => Messages.ResourceManager.GetString(nameof (News), Messages.resourceCulture);

    internal static string NewsImage => Messages.ResourceManager.GetString(nameof (NewsImage), Messages.resourceCulture);

    internal static string NewsLetterSucess => Messages.ResourceManager.GetString(nameof (NewsLetterSucess), Messages.resourceCulture);

    internal static string NoAccessInactivateUser => Messages.ResourceManager.GetString(nameof (NoAccessInactivateUser), Messages.resourceCulture);

    internal static string NoClientList => Messages.ResourceManager.GetString(nameof (NoClientList), Messages.resourceCulture);

    internal static string NoEmailFound => Messages.ResourceManager.GetString(nameof (NoEmailFound), Messages.resourceCulture);

    internal static string NonTurfExists => Messages.ResourceManager.GetString(nameof (NonTurfExists), Messages.resourceCulture);

    internal static string NoOrderHistoryfound => Messages.ResourceManager.GetString(nameof (NoOrderHistoryfound), Messages.resourceCulture);

    internal static string NoRecordFound => Messages.ResourceManager.GetString(nameof (NoRecordFound), Messages.resourceCulture);

    internal static string NoRecordsFoundByModule => Messages.ResourceManager.GetString(nameof (NoRecordsFoundByModule), Messages.resourceCulture);

    internal static string NoScheduleInInvoiceDates => Messages.ResourceManager.GetString(nameof (NoScheduleInInvoiceDates), Messages.resourceCulture);

    internal static string OrderPlaceSuccess => Messages.ResourceManager.GetString(nameof (OrderPlaceSuccess), Messages.resourceCulture);

    internal static string Password => Messages.ResourceManager.GetString(nameof (Password), Messages.resourceCulture);

    internal static string PasswordAndConfirmPasswordNotMatch => Messages.ResourceManager.GetString(nameof (PasswordAndConfirmPasswordNotMatch), Messages.resourceCulture);

    internal static string PlaceanOrderText => Messages.ResourceManager.GetString(nameof (PlaceanOrderText), Messages.resourceCulture);

    internal static string ProductRemovedFromCart => Messages.ResourceManager.GetString(nameof (ProductRemovedFromCart), Messages.resourceCulture);

    internal static string PurchaseLastSession => Messages.ResourceManager.GetString(nameof (PurchaseLastSession), Messages.resourceCulture);

    internal static string PurchaseSuccess => Messages.ResourceManager.GetString(nameof (PurchaseSuccess), Messages.resourceCulture);

    internal static string RecordAddFail => Messages.ResourceManager.GetString(nameof (RecordAddFail), Messages.resourceCulture);

    internal static string RecordUpdateFail => Messages.ResourceManager.GetString(nameof (RecordUpdateFail), Messages.resourceCulture);

    internal static string Required => Messages.ResourceManager.GetString(nameof (Required), Messages.resourceCulture);

    internal static string SameDate => Messages.ResourceManager.GetString(nameof (SameDate), Messages.resourceCulture);

    internal static string Select => Messages.ResourceManager.GetString(nameof (Select), Messages.resourceCulture);

    internal static string SelectOnetoDelete => Messages.ResourceManager.GetString(nameof (SelectOnetoDelete), Messages.resourceCulture);

    internal static string SessionAddUpdate => Messages.ResourceManager.GetString(nameof (SessionAddUpdate), Messages.resourceCulture);

    internal static string SetPasswordStr => Messages.ResourceManager.GetString(nameof (SetPasswordStr), Messages.resourceCulture);

    internal static string ShoppingCartEmpty => Messages.ResourceManager.GetString(nameof (ShoppingCartEmpty), Messages.resourceCulture);

    internal static string strCurrentlyUnavailable => Messages.ResourceManager.GetString(nameof (strCurrentlyUnavailable), Messages.resourceCulture);

    internal static string String1 => Messages.ResourceManager.GetString(nameof (String1), Messages.resourceCulture);

    internal static string TransactionFailed => Messages.ResourceManager.GetString(nameof (TransactionFailed), Messages.resourceCulture);

    internal static string TransactionSuccess => Messages.ResourceManager.GetString(nameof (TransactionSuccess), Messages.resourceCulture);

    internal static string TurfAddedSuccess => Messages.ResourceManager.GetString(nameof (TurfAddedSuccess), Messages.resourceCulture);

    internal static string TurfProductExists => Messages.ResourceManager.GetString(nameof (TurfProductExists), Messages.resourceCulture);

    internal static string UpdateModuleStatusSuccess => Messages.ResourceManager.GetString(nameof (UpdateModuleStatusSuccess), Messages.resourceCulture);

    internal static string UpdateStatusSuccess => Messages.ResourceManager.GetString(nameof (UpdateStatusSuccess), Messages.resourceCulture);

    internal static string UpdateStockStatusSuccess => Messages.ResourceManager.GetString(nameof (UpdateStockStatusSuccess), Messages.resourceCulture);

    internal static string UpdateSuccess => Messages.ResourceManager.GetString(nameof (UpdateSuccess), Messages.resourceCulture);

    internal static string UploadHomePageImageForPagemanagement => Messages.ResourceManager.GetString(nameof (UploadHomePageImageForPagemanagement), Messages.resourceCulture);

    internal static string UploadImageForPagemanagement => Messages.ResourceManager.GetString(nameof (UploadImageForPagemanagement), Messages.resourceCulture);

    internal static string UserAccessMessage => Messages.ResourceManager.GetString(nameof (UserAccessMessage), Messages.resourceCulture);

    internal static string UserAccessMessageForPage => Messages.ResourceManager.GetString(nameof (UserAccessMessageForPage), Messages.resourceCulture);

    internal static string WindsorTurfContactTextForEmail => Messages.ResourceManager.GetString(nameof (WindsorTurfContactTextForEmail), Messages.resourceCulture);

    internal static string YouHaveSuccessfullyChangedYourPassword => Messages.ResourceManager.GetString(nameof (YouHaveSuccessfullyChangedYourPassword), Messages.resourceCulture);
  }
}
