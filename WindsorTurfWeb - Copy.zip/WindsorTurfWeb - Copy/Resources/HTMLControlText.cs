﻿// Decompiled with JetBrains decompiler
// Type: Resources.HTMLControlText
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;

namespace Resources
{
  [GeneratedCode("Microsoft.VisualStudio.Web.Application.StronglyTypedResourceProxyBuilder", "15.0.0.0")]
  [DebuggerNonUserCode]
  [CompilerGenerated]
  internal class HTMLControlText
  {
    private static ResourceManager resourceMan;
    private static CultureInfo resourceCulture;

    internal HTMLControlText()
    {
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static ResourceManager ResourceManager
    {
      get
      {
        if (HTMLControlText.resourceMan == null)
          HTMLControlText.resourceMan = new ResourceManager("Resources.HTMLControlText", Assembly.Load("App_GlobalResources"));
        return HTMLControlText.resourceMan;
      }
    }

    [EditorBrowsable(EditorBrowsableState.Advanced)]
    internal static CultureInfo Culture
    {
      get => HTMLControlText.resourceCulture;
      set => HTMLControlText.resourceCulture = value;
    }

    internal static string aAdd => HTMLControlText.ResourceManager.GetString(nameof (aAdd), HTMLControlText.resourceCulture);

    internal static string aChangePassword => HTMLControlText.ResourceManager.GetString(nameof (aChangePassword), HTMLControlText.resourceCulture);

    internal static string aClassAddEdit => HTMLControlText.ResourceManager.GetString(nameof (aClassAddEdit), HTMLControlText.resourceCulture);

    internal static string aClassList => HTMLControlText.ResourceManager.GetString(nameof (aClassList), HTMLControlText.resourceCulture);

    internal static string aCreditCardDetails => HTMLControlText.ResourceManager.GetString(nameof (aCreditCardDetails), HTMLControlText.resourceCulture);

    internal static string Action => HTMLControlText.ResourceManager.GetString(nameof (Action), HTMLControlText.resourceCulture);

    internal static string ActionBy => HTMLControlText.ResourceManager.GetString(nameof (ActionBy), HTMLControlText.resourceCulture);

    internal static string active => HTMLControlText.ResourceManager.GetString(nameof (active), HTMLControlText.resourceCulture);

    internal static string active1 => HTMLControlText.ResourceManager.GetString(nameof (active1), HTMLControlText.resourceCulture);

    internal static string ActiveStatus => HTMLControlText.ResourceManager.GetString(nameof (ActiveStatus), HTMLControlText.resourceCulture);

    internal static string activityOrAction => HTMLControlText.ResourceManager.GetString(nameof (activityOrAction), HTMLControlText.resourceCulture);

    internal static string aCustomerDetail => HTMLControlText.ResourceManager.GetString(nameof (aCustomerDetail), HTMLControlText.resourceCulture);

    internal static string aCustomerPackage => HTMLControlText.ResourceManager.GetString(nameof (aCustomerPackage), HTMLControlText.resourceCulture);

    internal static string aCustomerProfile => HTMLControlText.ResourceManager.GetString(nameof (aCustomerProfile), HTMLControlText.resourceCulture);

    internal static string AddressInformation => HTMLControlText.ResourceManager.GetString(nameof (AddressInformation), HTMLControlText.resourceCulture);

    internal static string aDuplicateSchedule => HTMLControlText.ResourceManager.GetString(nameof (aDuplicateSchedule), HTMLControlText.resourceCulture);

    internal static string AdvancedSearch => HTMLControlText.ResourceManager.GetString(nameof (AdvancedSearch), HTMLControlText.resourceCulture);

    internal static string aEdit => HTMLControlText.ResourceManager.GetString(nameof (aEdit), HTMLControlText.resourceCulture);

    internal static string aEventList => HTMLControlText.ResourceManager.GetString(nameof (aEventList), HTMLControlText.resourceCulture);

    internal static string aGeneralSettings => HTMLControlText.ResourceManager.GetString(nameof (aGeneralSettings), HTMLControlText.resourceCulture);

    internal static string aGeneralSettings1 => HTMLControlText.ResourceManager.GetString(nameof (aGeneralSettings1), HTMLControlText.resourceCulture);

    internal static string aListing => HTMLControlText.ResourceManager.GetString(nameof (aListing), HTMLControlText.resourceCulture);

    internal static string aManageCreditCards => HTMLControlText.ResourceManager.GetString(nameof (aManageCreditCards), HTMLControlText.resourceCulture);

    internal static string aNote => HTMLControlText.ResourceManager.GetString(nameof (aNote), HTMLControlText.resourceCulture);

    internal static string aPageManagement => HTMLControlText.ResourceManager.GetString(nameof (aPageManagement), HTMLControlText.resourceCulture);

    internal static string aProfile => HTMLControlText.ResourceManager.GetString(nameof (aProfile), HTMLControlText.resourceCulture);

    internal static string aPromocode => HTMLControlText.ResourceManager.GetString(nameof (aPromocode), HTMLControlText.resourceCulture);

    internal static string aSettingsAdminInputs => HTMLControlText.ResourceManager.GetString(nameof (aSettingsAdminInputs), HTMLControlText.resourceCulture);

    internal static string Assigned => HTMLControlText.ResourceManager.GetString(nameof (Assigned), HTMLControlText.resourceCulture);

    internal static string AssignInspecor => HTMLControlText.ResourceManager.GetString(nameof (AssignInspecor), HTMLControlText.resourceCulture);

    internal static string aStaff => HTMLControlText.ResourceManager.GetString(nameof (aStaff), HTMLControlText.resourceCulture);

    internal static string aStudioManagement => HTMLControlText.ResourceManager.GetString(nameof (aStudioManagement), HTMLControlText.resourceCulture);

    internal static string aTransactions => HTMLControlText.ResourceManager.GetString(nameof (aTransactions), HTMLControlText.resourceCulture);

    internal static string aUser => HTMLControlText.ResourceManager.GetString(nameof (aUser), HTMLControlText.resourceCulture);

    internal static string aViewClass => HTMLControlText.ResourceManager.GetString(nameof (aViewClass), HTMLControlText.resourceCulture);

    internal static string aViewClasses => HTMLControlText.ResourceManager.GetString(nameof (aViewClasses), HTMLControlText.resourceCulture);

    internal static string BillingAddress => HTMLControlText.ResourceManager.GetString(nameof (BillingAddress), HTMLControlText.resourceCulture);

    internal static string Cancel => HTMLControlText.ResourceManager.GetString(nameof (Cancel), HTMLControlText.resourceCulture);

    internal static string ChangeStatus => HTMLControlText.ResourceManager.GetString(nameof (ChangeStatus), HTMLControlText.resourceCulture);

    internal static string ClearFilter => HTMLControlText.ResourceManager.GetString(nameof (ClearFilter), HTMLControlText.resourceCulture);

    internal static string ClientSingular => HTMLControlText.ResourceManager.GetString(nameof (ClientSingular), HTMLControlText.resourceCulture);

    internal static string ClientsSingular => HTMLControlText.ResourceManager.GetString(nameof (ClientsSingular), HTMLControlText.resourceCulture);

    internal static string CompanyInformation => HTMLControlText.ResourceManager.GetString(nameof (CompanyInformation), HTMLControlText.resourceCulture);

    internal static string CompanyName => HTMLControlText.ResourceManager.GetString(nameof (CompanyName), HTMLControlText.resourceCulture);

    internal static string CompanyTag => HTMLControlText.ResourceManager.GetString(nameof (CompanyTag), HTMLControlText.resourceCulture);

    internal static string CompanyUser => HTMLControlText.ResourceManager.GetString(nameof (CompanyUser), HTMLControlText.resourceCulture);

    internal static string DateTime => HTMLControlText.ResourceManager.GetString(nameof (DateTime), HTMLControlText.resourceCulture);

    internal static string Delete => HTMLControlText.ResourceManager.GetString(nameof (Delete), HTMLControlText.resourceCulture);

    internal static string Discount => HTMLControlText.ResourceManager.GetString(nameof (Discount), HTMLControlText.resourceCulture);

    internal static string Edit => HTMLControlText.ResourceManager.GetString(nameof (Edit), HTMLControlText.resourceCulture);

    internal static string Email => HTMLControlText.ResourceManager.GetString(nameof (Email), HTMLControlText.resourceCulture);

    internal static string Email1 => HTMLControlText.ResourceManager.GetString(nameof (Email1), HTMLControlText.resourceCulture);

    internal static string ErrorDate => HTMLControlText.ResourceManager.GetString(nameof (ErrorDate), HTMLControlText.resourceCulture);

    internal static string ErrorListing => HTMLControlText.ResourceManager.GetString(nameof (ErrorListing), HTMLControlText.resourceCulture);

    internal static string ErrorLogsListing => HTMLControlText.ResourceManager.GetString(nameof (ErrorLogsListing), HTMLControlText.resourceCulture);

    internal static string ExceptionMessage => HTMLControlText.ResourceManager.GetString(nameof (ExceptionMessage), HTMLControlText.resourceCulture);

    internal static string From => HTMLControlText.ResourceManager.GetString(nameof (From), HTMLControlText.resourceCulture);

    internal static string FromName => HTMLControlText.ResourceManager.GetString(nameof (FromName), HTMLControlText.resourceCulture);

    internal static string FrontContactUsAddress => HTMLControlText.ResourceManager.GetString(nameof (FrontContactUsAddress), HTMLControlText.resourceCulture);

    internal static string FrontContactUsAddress1 => HTMLControlText.ResourceManager.GetString(nameof (FrontContactUsAddress1), HTMLControlText.resourceCulture);

    internal static string FrontPhoneNo => HTMLControlText.ResourceManager.GetString(nameof (FrontPhoneNo), HTMLControlText.resourceCulture);

    internal static string FrontStoreName => HTMLControlText.ResourceManager.GetString(nameof (FrontStoreName), HTMLControlText.resourceCulture);

    internal static string Has => HTMLControlText.ResourceManager.GetString(nameof (Has), HTMLControlText.resourceCulture);

    internal static string Inactive => HTMLControlText.ResourceManager.GetString(nameof (Inactive), HTMLControlText.resourceCulture);

    internal static string InactiveStatus => HTMLControlText.ResourceManager.GetString(nameof (InactiveStatus), HTMLControlText.resourceCulture);

    internal static string IPAddress => HTMLControlText.ResourceManager.GetString(nameof (IPAddress), HTMLControlText.resourceCulture);

    internal static string IPRestriction => HTMLControlText.ResourceManager.GetString(nameof (IPRestriction), HTMLControlText.resourceCulture);

    internal static string Legend => HTMLControlText.ResourceManager.GetString(nameof (Legend), HTMLControlText.resourceCulture);

    internal static string ListofCompanies => HTMLControlText.ResourceManager.GetString(nameof (ListofCompanies), HTMLControlText.resourceCulture);

    internal static string LogSingular => HTMLControlText.ResourceManager.GetString(nameof (LogSingular), HTMLControlText.resourceCulture);

    internal static string LogsListing => HTMLControlText.ResourceManager.GetString(nameof (LogsListing), HTMLControlText.resourceCulture);

    internal static string MailingAddress => HTMLControlText.ResourceManager.GetString(nameof (MailingAddress), HTMLControlText.resourceCulture);

    internal static string NoOfCompany => HTMLControlText.ResourceManager.GetString(nameof (NoOfCompany), HTMLControlText.resourceCulture);

    internal static string PackageName => HTMLControlText.ResourceManager.GetString(nameof (PackageName), HTMLControlText.resourceCulture);

    internal static string PageDisplay => HTMLControlText.ResourceManager.GetString(nameof (PageDisplay), HTMLControlText.resourceCulture);

    internal static string PagingModuleName => HTMLControlText.ResourceManager.GetString(nameof (PagingModuleName), HTMLControlText.resourceCulture);

    internal static string PagingModuleNames => HTMLControlText.ResourceManager.GetString(nameof (PagingModuleNames), HTMLControlText.resourceCulture);

    internal static string PlanName => HTMLControlText.ResourceManager.GetString(nameof (PlanName), HTMLControlText.resourceCulture);

    internal static string PlanSingular => HTMLControlText.ResourceManager.GetString(nameof (PlanSingular), HTMLControlText.resourceCulture);

    internal static string Profile => HTMLControlText.ResourceManager.GetString(nameof (Profile), HTMLControlText.resourceCulture);

    internal static string ProfileListingClass => HTMLControlText.ResourceManager.GetString(nameof (ProfileListingClass), HTMLControlText.resourceCulture);

    internal static string ProfileMy => HTMLControlText.ResourceManager.GetString(nameof (ProfileMy), HTMLControlText.resourceCulture);

    internal static string ProfileName => HTMLControlText.ResourceManager.GetString(nameof (ProfileName), HTMLControlText.resourceCulture);

    internal static string ProfileSingular => HTMLControlText.ResourceManager.GetString(nameof (ProfileSingular), HTMLControlText.resourceCulture);

    internal static string ReassignInspector => HTMLControlText.ResourceManager.GetString(nameof (ReassignInspector), HTMLControlText.resourceCulture);

    internal static string Select => HTMLControlText.ResourceManager.GetString(nameof (Select), HTMLControlText.resourceCulture);

    internal static string Service => HTMLControlText.ResourceManager.GetString(nameof (Service), HTMLControlText.resourceCulture);

    internal static string Settings => HTMLControlText.ResourceManager.GetString(nameof (Settings), HTMLControlText.resourceCulture);

    internal static string SiteAddress => HTMLControlText.ResourceManager.GetString(nameof (SiteAddress), HTMLControlText.resourceCulture);

    internal static string StaffInformation => HTMLControlText.ResourceManager.GetString(nameof (StaffInformation), HTMLControlText.resourceCulture);

    internal static string Status => HTMLControlText.ResourceManager.GetString(nameof (Status), HTMLControlText.resourceCulture);

    internal static string StatusSingular => HTMLControlText.ResourceManager.GetString(nameof (StatusSingular), HTMLControlText.resourceCulture);

    internal static string Successfully => HTMLControlText.ResourceManager.GetString(nameof (Successfully), HTMLControlText.resourceCulture);

    internal static string To => HTMLControlText.ResourceManager.GetString(nameof (To), HTMLControlText.resourceCulture);

    internal static string Update => HTMLControlText.ResourceManager.GetString(nameof (Update), HTMLControlText.resourceCulture);

    internal static string UpdateStatus => HTMLControlText.ResourceManager.GetString(nameof (UpdateStatus), HTMLControlText.resourceCulture);

    internal static string UploadSiteSurvey => HTMLControlText.ResourceManager.GetString(nameof (UploadSiteSurvey), HTMLControlText.resourceCulture);

    internal static string UserActive => HTMLControlText.ResourceManager.GetString(nameof (UserActive), HTMLControlText.resourceCulture);

    internal static string UserInActive => HTMLControlText.ResourceManager.GetString(nameof (UserInActive), HTMLControlText.resourceCulture);

    internal static string UserInformation => HTMLControlText.ResourceManager.GetString(nameof (UserInformation), HTMLControlText.resourceCulture);

    internal static string UserSingular => HTMLControlText.ResourceManager.GetString(nameof (UserSingular), HTMLControlText.resourceCulture);

    internal static string ViewContactRequest => HTMLControlText.ResourceManager.GetString(nameof (ViewContactRequest), HTMLControlText.resourceCulture);

    internal static string ViewCustomer => HTMLControlText.ResourceManager.GetString(nameof (ViewCustomer), HTMLControlText.resourceCulture);

    internal static string ViewImage => HTMLControlText.ResourceManager.GetString(nameof (ViewImage), HTMLControlText.resourceCulture);

    internal static string ViewName => HTMLControlText.ResourceManager.GetString(nameof (ViewName), HTMLControlText.resourceCulture);

    internal static string ViewSingular => HTMLControlText.ResourceManager.GetString(nameof (ViewSingular), HTMLControlText.resourceCulture);

    internal static string ViewSiteSurvey => HTMLControlText.ResourceManager.GetString(nameof (ViewSiteSurvey), HTMLControlText.resourceCulture);
  }
}
