﻿// Decompiled with JetBrains decompiler
// Type: DAL.CamtechRef
// Assembly: WindsorTurfWeb, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: CF313E8F-916B-4C52-A8E8-430EB9732A47
// Assembly location: C:\Users\brian\Desktop\WindsorTurfWeb.dll\WinsorTurfWeb.dll\WindsorTurfWeb.dll

using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Text;
using System.Xml;
using System.Xml.XPath;

namespace DAL
{
  public class CamtechRef
  {
    private string MerchantId;
    private string Password;
    private string ServerUrl = ConfigurationManager.AppSettings["CamtechServer"];
    private string Timeout = "120";
    private string _MessageId;
    private string _TimeStamp;
    private string _XmlApi;
    private Stream _RequestStream;
    private Stream _ResponseStream;
    private static string[] _Methods = new string[2]
    {
      "Echo",
      "Payment"
    };
    private static string[] _txnType = new string[7]
    {
      "0",
      "4",
      "6",
      "10",
      "11",
      "15",
      "17"
    };
    private byte[] _Data;
    private HttpWebRequest _Request;
    private HttpWebResponse _Response;
    private XPathDocument _ResponseDoc;
    private XPathNavigator _XPathNavigator;
    private TextWriter _RequestWriter;

    public string messageID { get; set; }

    public string messageTimestamp { get; set; }

    public string CamtechRequestType { get; set; }

    public string statusCode { get; set; }

    public string statusDescription { get; set; }

    public string txnType { get; set; }

    public string txnSource { get; set; }

    public string amount { get; set; }

    public string purchaseOrderNo { get; set; }

    public string approved { get; set; }

    public string responseCode { get; set; }

    public string responseText { get; set; }

    public string settlementDate { get; set; }

    public string txnID { get; set; }

    public string cardDescription { get; set; }

    public CamtechRef(
      string PurchaseOrderNo,
      string Amount,
      string CardNumber,
      string CVV,
      string ExpiryDate,
      CamtechRef.TransactionType TxnType,
      CamtechRef.RequestType RType,
      bool LoadConfig)
    {
      if (Convert.ToInt32(ConfigurationManager.AppSettings["PaymentTest"]) == 0)
      {
        this.MerchantId = ConfigurationManager.AppSettings["CamtechMerchantId"];
        this.Password = ConfigurationManager.AppSettings["CamtechMerchantPassword"];
        this.ServerUrl = ConfigurationManager.AppSettings["CamtechServer"];
        this.Timeout = ConfigurationManager.AppSettings["CamtechTimeout"];
      }
      else
      {
        this.MerchantId = ConfigurationManager.AppSettings["CamtechMerchantId_live"];
        this.Password = ConfigurationManager.AppSettings["CamtechMerchantPassword_live"];
        this.ServerUrl = ConfigurationManager.AppSettings["CamtechServer_live"];
        this.Timeout = ConfigurationManager.AppSettings["CamtechTimeout_live"];
      }
      this._MessageId = Guid.NewGuid().ToString().Replace("-", "");
      this._TimeStamp = DateTime.UtcNow.ToString("yyyyddMMhhmmssfff") + "000+600";
      this._XmlApi = "xml-4.2";
      this._RequestWriter = (TextWriter) new StringWriter();
      XmlTextWriter xmlTextWriter = new XmlTextWriter(this._RequestWriter);
      xmlTextWriter.Formatting = Formatting.Indented;
      xmlTextWriter.WriteStartDocument();
      xmlTextWriter.WriteStartElement("SecurePayMessage");
      xmlTextWriter.WriteStartElement("MessageInfo");
      xmlTextWriter.WriteElementString(nameof (messageID), this._MessageId);
      xmlTextWriter.WriteElementString(nameof (messageTimestamp), this._TimeStamp);
      xmlTextWriter.WriteElementString("timeoutValue", this.Timeout);
      xmlTextWriter.WriteElementString("apiVersion", this._XmlApi);
      xmlTextWriter.WriteEndElement();
      xmlTextWriter.WriteStartElement("MerchantInfo");
      xmlTextWriter.WriteElementString("merchantID", this.MerchantId);
      xmlTextWriter.WriteElementString("password", this.Password);
      xmlTextWriter.WriteEndElement();
      xmlTextWriter.WriteElementString("RequestType", CamtechRef._Methods[(int) RType]);
      xmlTextWriter.WriteStartElement("Payment");
      xmlTextWriter.WriteStartElement("TxnList");
      xmlTextWriter.WriteAttributeString("count", "1");
      xmlTextWriter.WriteStartElement("Txn");
      xmlTextWriter.WriteAttributeString("ID", "1");
      xmlTextWriter.WriteElementString(nameof (txnType), CamtechRef._txnType[(int) TxnType]);
      xmlTextWriter.WriteElementString(nameof (txnSource), "23");
      xmlTextWriter.WriteElementString(nameof (amount), Amount.Replace(".", "").Replace(",", ""));
      xmlTextWriter.WriteElementString(nameof (purchaseOrderNo), PurchaseOrderNo);
      xmlTextWriter.WriteStartElement("CreditCardInfo");
      xmlTextWriter.WriteElementString("cardNumber", CardNumber);
      xmlTextWriter.WriteElementString("cvv", CVV);
      xmlTextWriter.WriteElementString("expiryDate", ExpiryDate);
      xmlTextWriter.WriteEndElement();
      xmlTextWriter.WriteEndElement();
      xmlTextWriter.WriteEndElement();
      xmlTextWriter.WriteEndElement();
      xmlTextWriter.WriteEndElement();
      xmlTextWriter.Flush();
      xmlTextWriter.Close();
      this._Data = new ASCIIEncoding().GetBytes(this._RequestWriter.ToString());
    }

    public void SendTransaction()
    {
      this._Request = (HttpWebRequest) WebRequest.CreateDefault(new Uri(this.ServerUrl));
      this._Request.Method = "POST";
      this._Request.ContentType = "application/x-www-form-urlencoded";
      this._Request.ContentLength = (long) this._Data.Length;
      this._RequestStream = this._Request.GetRequestStream();
      this._RequestStream.Write(this._Data, 0, this._Data.Length);
      this._RequestStream.Close();
      this._Response = (HttpWebResponse) this._Request.GetResponse();
      this._ResponseStream = this._Response.GetResponseStream();
      this._ResponseDoc = new XPathDocument(this._ResponseStream);
      this._XPathNavigator = this._ResponseDoc.CreateNavigator();
      this.messageID = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/MessageInfo/messageID");
      this.messageTimestamp = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/MessageInfo/messageTimestamp");
      this.CamtechRequestType = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/RequestType");
      this.statusCode = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Status/statusCode");
      this.statusDescription = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Status/statusDescription");
      this.txnType = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/txnType");
      this.txnSource = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/txnSource");
      this.amount = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/amount");
      this.purchaseOrderNo = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/purchaseOrderNo");
      this.approved = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/approved");
      this.responseCode = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/responseCode");
      this.responseText = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/responseText");
      this.settlementDate = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/settlementDate");
      this.txnID = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/txnID");
      this.cardDescription = this.GetNodeValue(this._XPathNavigator, "/SecurePayMessage/Payment/TxnList/Txn/CreditCardInfo/cardDescription");
    }

    public int AddCardResponseInfo()
    {
      SqlParameter sqlParameter = new SqlParameter("@return", (object) "");
      sqlParameter.Direction = ParameterDirection.ReturnValue;
      return SqlHelper.ExecuteReturnQuery(CommandType.StoredProcedure, nameof (AddCardResponseInfo), new SqlParameter[16]
      {
        sqlParameter,
        new SqlParameter("@MsgId", (object) this.messageID),
        new SqlParameter("@MessageTimestamp", (object) this.messageTimestamp),
        new SqlParameter("@RequestType", (object) CamtechRef.RequestType.Payment),
        new SqlParameter("@statusCode", (object) this.statusCode),
        new SqlParameter("@StatusDescription", (object) this.statusDescription),
        new SqlParameter("@TxnType", (object) this.txnType),
        new SqlParameter("@TxnSource", (object) this.txnSource),
        new SqlParameter("@Amount", (object) this.amount),
        new SqlParameter("@PurchaseOrderNo", (object) this.purchaseOrderNo),
        new SqlParameter("@Approved", (object) this.approved),
        new SqlParameter("@ResponseCode", (object) this.responseCode),
        new SqlParameter("@ResponseText", (object) this.responseText),
        new SqlParameter("@SettlementDate", (object) this.settlementDate),
        new SqlParameter("@TxnID", (object) this.txnID),
        new SqlParameter("@CardDescription", (object) this.cardDescription)
      });
    }

    protected string GetNodeValue(XPathNavigator xpn, string xPath)
    {
      XPathNodeIterator xpathNodeIterator = xpn.Select(xPath);
      return xpathNodeIterator.MoveNext() ? xpathNodeIterator.Current.Value : "";
    }

    public enum RequestType
    {
      Echo,
      Payment,
    }

    public enum TransactionType
    {
      StandardPayment,
      Refund,
      ClientReversal,
      Preauthorise,
      PreauthComplete,
      DirectEntryDebit,
      DirectEntryCredit,
    }
  }
}
